let e;var t,r,n,i,o,s,a,u,l,d,p,c,h,f,g,m,b,y,_,v,x,w,$,T,I,S,O,E,P,k,A,D,z,C,N,j,R,B,M,F,L,V,U,q,G,H,W,K,X,Z,J,Q,Y,ee,et,er,en,ei,eo,es,ea,eu,el,ed,ep,ec,eh,ef,eg,em,eb,ey,e_,ev,ex,ew,e$,eT,eI,eS,eO,eE,eP,ek,eA,eD,ez,eC,eN,ej,eR,eB,eM,eF,eL,eV,eU,eq,eG,eH,eW,eK,eX,eZ,eJ,eQ,eY,e0,e1,e2,e3,e4,e6,e8,e5,e7,e9,te,tt,tr,tn,ti,to,ts,ta,tu,tl,td,tp,tc,th,tf,tg,tm,tb,ty,t_,tv,tx,tw,t$,tT,tI,tS,tO,tE,tP,tk,tA,tD,tz,tC,tN,tj,tR,tB,tM,tF,tL,tV,tU,tq,tG,tH,tW,tK,tX,tZ,tJ,tQ,tY,t0,t1,t2,t3,t4,t6,t8,t5,t7,t9,re,rt,rr,rn,ri,ro,rs,ra,ru,rl,rd,rp,rc,rh,rf,rg,rm,rb,ry,r_,rv,rx,rw,r$,rT,rI,rS,rO,rE,rP,rk,rA,rD,rz,rC,rN,rj,rR,rB,rM,rF,rL,rV,rU,rq,rG,rH,rW,rK,rX,rZ,rJ,rQ,rY,r0,r1,r2,r3,r4,r6,r8,r5,r7,r9,ne,nt,nr,nn,ni,no,ns,na,nu,nl,nd,np,nc,nh,nf,ng,nm,nb,ny,n_,nv,nx,nw,n$,nT,nI,nS,nO,nE,nP,nk,nA,nD,nz,nC,nN,nj,nR,nB,nM,nF,nL,nV,nU,nq,nG,nH,nW,nK,nX,nZ,nJ,nQ,nY,n0,n1,n2,n3,n4,n6,n8,n5,n7,n9,ie,it,ir,ii,io,is,ia,iu,il,id,ip,ic,ih,ig,im,ib,iy,i_,iv,ix,iw,i$,iT,iI,iS,iO,iE,iP,ik,iA,iD,iz,iC,iN,ij,iR,iB,iM,iF,iL,iV,iU,iq,iG,iH,iW,iK,iX,iZ,iJ,iQ,iY,i0,i1,i2,i3,i4,i6,i8,i5,i7,i9,oe,ot,or,on,oi,oo,os,oa,ou,ol,od,op,oc,oh,of,og,om,ob,oy,o_,ov,ox,ow,o$,oT,oI,oS,oO,oE,oP,ok,oA,oD,oz,oC,oN,oj,oR,oB,oM,oF,oL,oV,oU,oq,oG,oH,oW,oK,oX,oZ,oJ,oQ,oY,o0,o1,o2,o3,o4,o6,o8,o5,o7,o9,se,st,sr,sn,si,so,ss,sa,su,sl,sd,sp,sc,sh,sf,sg,sm,sb,sy,s_,sv,sx,sw,s$,sT,sI,sS,sO,sE,sP,sk,sA,sD,sz,sC,sN,sj,sR,sB,sM,sF,sL,sV,sU,sq,sG,sH,sW,sK,sX,sZ,sJ,sQ,sY,s0,s1,s2,s3,s4,s6,s8,s5,s7,s9,ae,at,ar,an,ai,ao,as,aa,au,al,ad,ap,ac,ah,af,ag,am,ab,ay,a_,av,ax,aw,a$,aT,aI,aS,aO,aE,aP,ak,aA,aD,az,aC,aN,aj,aR,aB,aM,aF,aL,aV,aU,aq,aG,aH,aW,aK,aX,aZ,aJ,aQ,aY,a0,a1,a2,a3,a4,a6,a8,a5,a7,a9,ue,ut,ur,un,ui,uo,us,ua,uu,ul,ud,up,uc,uh,uf,ug,um,ub,uy,u_,uv,ux,uw,u$,uT,uI,uS,uO,uE,uP,uk,uA,uD,uz,uC,uN,uj,uR,uB,uM,uF,uL,uV,uU,uq,uG,uH,uW,uK,uX,uZ,uJ,uQ,uY,u0,u1,u2,u3,u4,u6,u8,u5,u7,u9,le,lt,lr,ln,li,lo,ls,la,lu,ll,ld,lp,lc,lh,lf,lg,lm,lb,ly,l_,lv,lx,lw,l$,lT,lI,lS,lO,lE,lP,lk,lA,lD,lz,lC,lN,lj,lR,lB,lM,lF,lL,lV,lU,lq,lG,lH,lW,lK,lX,lZ,lJ,lQ,lY,l0,l1,l2,l3,l4,l6,l8,l5,l7,l9,de,dt,dr,dn,di,ds,da,du,dl,dd,dp,dc,dh,df,dg,dm,db,dy,d_,dv,dx,dw,d$,dT,dI,dS,dO,dE,dP,dk,dA,dD,dz,dC,dN,dj,dR,dB,dM,dF,dL,dV,dU,dq,dG=Object.create,dH=Object.defineProperty,dW=Object.getOwnPropertyDescriptor,dK=Object.getOwnPropertyNames,dX=Object.getPrototypeOf,dZ=Object.prototype.hasOwnProperty,dJ=(e=function(e){if("u">typeof require)return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')},"u">typeof require?require:"u">typeof Proxy?new Proxy(e,{get:(e,t)=>("u">typeof require?require:e)[t]}):e),dQ=(e,t,r)=>function(){if(r)throw r[0];try{return e&&(t=(0,e[dK(e)[0]])(e=0)),t}catch(e){throw r=[e],e}},dY=(e,t)=>function(){try{return t||(0,e[dK(e)[0]])((t={exports:{}}).exports,t),t.exports}catch(e){throw t=0,e}},d0=(e,t)=>{for(var r in t)dH(e,r,{get:t[r],enumerable:!0})},d1=(e,t,r,n)=>{if(t&&"object"==typeof t||"function"==typeof t)for(let i of dK(t))dZ.call(e,i)||i===r||dH(e,i,{get:()=>t[i],enumerable:!(n=dW(t,i))||n.enumerable});return e},d2=(e,t,r)=>(r=null!=e?dG(dX(e)):{},d1(!t&&e&&e.__esModule?r:dH(r,"default",{value:e,enumerable:!0}),e)),d3=e=>d1(dH({},"__esModule",{value:!0}),e),d4=dQ({"common/dist/esm/backend-impl.js"(){"use strict";t=new Map,r=[],n=(e,n,i)=>{if(n&&"function"==typeof n.init&&"function"==typeof n.createInferenceSessionHandler){let o=t.get(e);if(void 0===o)t.set(e,{backend:n,priority:i});else if(o.priority>i)return;else if(o.priority===i&&o.backend!==n)throw Error(`cannot register backend "${e}" using priority ${i}`);if(i>=0){let n=r.indexOf(e);-1!==n&&r.splice(n,1);for(let n=0;n<r.length;n++)if(t.get(r[n]).priority<=i)return void r.splice(n,0,e);r.push(e)}return}throw TypeError("not a valid backend")},i=async e=>{let r=t.get(e);if(!r)return"backend not found.";if(r.initialized)return r.backend;{if(r.aborted)return r.error;let t=!!r.initPromise;try{return t||(r.initPromise=r.backend.init(e)),await r.initPromise,r.initialized=!0,r.backend}catch(e){return t||(r.error=`${e}`,r.aborted=!0),r.error}finally{delete r.initPromise}}},o=async e=>{let t,n=e.executionProviders||[],o=n.map(e=>"string"==typeof e?e:e.name),s=0===o.length?r:o,a=[],u=new Set;for(let e of s){let r=await i(e);"string"==typeof r?a.push({name:e,err:r}):(t||(t=r),t===r&&u.add(e))}if(!t)throw Error(`no available backend found. ERR: ${a.map(e=>`[${e.name}] ${e.err}`).join(", ")}`);for(let{name:e,err:t}of a)o.includes(e)&&console.warn(`removing requested execution provider "${e}" from session options because it is not available: ${t}`);let l=n.filter(e=>u.has("string"==typeof e?e:e.name));return[t,new Proxy(e,{get:(e,t)=>"executionProviders"===t?l:Reflect.get(e,t)})]}}}),d6=dQ({"common/dist/esm/backend.js"(){"use strict";d4()}}),d8=dQ({"common/dist/esm/version.js"(){"use strict";s="1.30.0"}}),d5=dQ({"common/dist/esm/env-impl.js"(){"use strict";d8(),a="warning",Object.defineProperty(u={wasm:{},webgl:{},webgpu:{},versions:{common:s},set logLevel(value){if(void 0===value)return;if("string"!=typeof value||-1===["verbose","info","warning","error","fatal"].indexOf(value))throw Error(`Unsupported logging level: ${value}`);a=value},get logLevel(){return a}},"logLevel",{enumerable:!0})}}),d7=dQ({"common/dist/esm/env.js"(){"use strict";d5(),l=u}}),d9=dQ({"common/dist/esm/tensor-conversion-impl.js"(){"use strict";d=(e,t)=>{let r="u">typeof document?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let n=r.getContext("2d");if(null!=n){let i,o,s,a;t?.tensorLayout!==void 0&&"NHWC"===t.tensorLayout?(i=e.dims[2],o=e.dims[3]):(i=e.dims[3],o=e.dims[2]);let u=t?.format!==void 0?t.format:"RGB",l=t?.norm;void 0===l||void 0===l.mean?s=[255,255,255,255]:"number"==typeof l.mean?s=[l.mean,l.mean,l.mean,l.mean]:(s=[l.mean[0],l.mean[1],l.mean[2],0],void 0!==l.mean[3]&&(s[3]=l.mean[3])),void 0===l||void 0===l.bias?a=[0,0,0,0]:"number"==typeof l.bias?a=[l.bias,l.bias,l.bias,l.bias]:(a=[l.bias[0],l.bias[1],l.bias[2],0],void 0!==l.bias[3]&&(a[3]=l.bias[3]));let d=o*i,p=0,c=d,h=2*d,f=-1;"RGBA"===u?(p=0,c=d,h=2*d,f=3*d):"RGB"===u?(p=0,c=d,h=2*d):"RBG"===u&&(p=0,h=d,c=2*d);for(let t=0;t<o;t++)for(let r=0;r<i;r++)n.fillStyle="rgba("+(e.data[p++]-a[0])*s[0]+","+(e.data[c++]-a[1])*s[1]+","+(e.data[h++]-a[2])*s[2]+","+(-1===f?255:(e.data[f++]-a[3])*s[3])+")",n.fillRect(r,t,1,1);if("toDataURL"in r)return r.toDataURL();throw Error("toDataURL is not supported")}throw Error("Can not access image data")},p=(e,t)=>{let r,n="u">typeof document?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d");if(null!=n){let i,o,s,a,u;t?.tensorLayout!==void 0&&"NHWC"===t.tensorLayout?(i=e.dims[2],o=e.dims[1],s=e.dims[3]):(i=e.dims[3],o=e.dims[2],s=e.dims[1]);let l=void 0!==t&&void 0!==t.format?t.format:"RGB",d=t?.norm;void 0===d||void 0===d.mean?a=[255,255,255,255]:"number"==typeof d.mean?a=[d.mean,d.mean,d.mean,d.mean]:(a=[d.mean[0],d.mean[1],d.mean[2],255],void 0!==d.mean[3]&&(a[3]=d.mean[3])),void 0===d||void 0===d.bias?u=[0,0,0,0]:"number"==typeof d.bias?u=[d.bias,d.bias,d.bias,d.bias]:(u=[d.bias[0],d.bias[1],d.bias[2],0],void 0!==d.bias[3]&&(u[3]=d.bias[3]));let p=o*i;if(void 0!==t&&(void 0!==t.format&&4===s&&"RGBA"!==t.format||3===s&&"RGB"!==t.format&&"BGR"!==t.format))throw Error("Tensor format doesn't match input tensor dims");let c=0,h=1,f=2,g=3,m=0,b=p,y=2*p,_=-1;"RGBA"===l?(m=0,b=p,y=2*p,_=3*p):"RGB"===l?(m=0,b=p,y=2*p):"RBG"===l&&(m=0,y=p,b=2*p),r=n.createImageData(i,o);for(let t=0;t<o*i;c+=4,h+=4,f+=4,g+=4,t++)r.data[c]=(e.data[m++]-u[0])*a[0],r.data[h]=(e.data[b++]-u[1])*a[1],r.data[f]=(e.data[y++]-u[2])*a[2],r.data[g]=-1===_?255:(e.data[_++]-u[3])*a[3]}else throw Error("Can not access image data");return r}}}),pe=dQ({"common/dist/esm/tensor-factory-impl.js"(){"use strict";pn(),c=(e,t)=>{let r,n;if(void 0===e)throw Error("Image buffer must be defined");if(void 0===t.height||void 0===t.width)throw Error("Image height and width must be defined");if("NHWC"===t.tensorLayout)throw Error("NHWC Tensor layout is not supported yet");let{height:i,width:o}=t,s=t.norm??{mean:255,bias:0};r="number"==typeof s.mean?[s.mean,s.mean,s.mean,s.mean]:[s.mean[0],s.mean[1],s.mean[2],s.mean[3]??255],n="number"==typeof s.bias?[s.bias,s.bias,s.bias,s.bias]:[s.bias[0],s.bias[1],s.bias[2],s.bias[3]??0];let a=void 0!==t.format?t.format:"RGBA",u=void 0!==t.tensorFormat&&void 0!==t.tensorFormat?t.tensorFormat:"RGB",l=i*o,d=new Float32Array("RGBA"===u?4*l:3*l),p=4,c=0,h=1,f=2,g=3,m=0,b=l,y=2*l,_=-1;"RGB"===a&&(p=3,c=0,h=1,f=2,g=-1),"RGBA"===u?_=3*l:"RBG"===u?(m=0,y=l,b=2*l):"BGR"===u&&(y=0,b=l,m=2*l);for(let t=0;t<l;t++,c+=p,f+=p,h+=p,g+=p)d[m++]=(e[c]+n[0])/r[0],d[b++]=(e[h]+n[1])/r[1],d[y++]=(e[f]+n[2])/r[2],-1!==_&&-1!==g&&(d[_++]=(e[g]+n[3])/r[3]);return"RGBA"===u?new T("float32",d,[1,4,i,o]):new T("float32",d,[1,3,i,o])},h=async(e,t)=>{let r,n="u">typeof HTMLImageElement&&e instanceof HTMLImageElement,i="u">typeof ImageData&&e instanceof ImageData,o="u">typeof ImageBitmap&&e instanceof ImageBitmap,s="string"==typeof e,a=t??{},u=()=>{if("u">typeof document)return document.createElement("canvas");if("u">typeof OffscreenCanvas)return new OffscreenCanvas(1,1);throw Error("Canvas is not supported")},l=e=>"u">typeof HTMLCanvasElement&&e instanceof HTMLCanvasElement||e instanceof OffscreenCanvas?e.getContext("2d"):null;if(n){let n=u();n.width=e.width,n.height=e.height;let i=l(n);if(null!=i){let n=e.height,o=e.width;if(void 0!==t&&void 0!==t.resizedHeight&&void 0!==t.resizedWidth&&(n=t.resizedHeight,o=t.resizedWidth),void 0!==t){if(a=t,void 0!==t.tensorFormat)throw Error("Image input config format must be RGBA for HTMLImageElement");a.tensorFormat="RGBA",a.height=n,a.width=o}else a.tensorFormat="RGBA",a.height=n,a.width=o;i.drawImage(e,0,0),r=i.getImageData(0,0,o,n).data}else throw Error("Can not access image data")}else if(i){let n,i;if(void 0!==t&&void 0!==t.resizedWidth&&void 0!==t.resizedHeight?(n=t.resizedHeight,i=t.resizedWidth):(n=e.height,i=e.width),void 0!==t&&(a=t),a.format="RGBA",a.height=n,a.width=i,void 0!==t){let t=u();t.width=i,t.height=n;let o=l(t);if(null!=o)o.putImageData(e,0,0),r=o.getImageData(0,0,i,n).data;else throw Error("Can not access image data")}else r=e.data}else if(o){if(void 0===t)throw Error("Please provide image config with format for Imagebitmap");let n=u();n.width=e.width,n.height=e.height;let i=l(n);if(null!=i){let t=e.height,n=e.width;return i.drawImage(e,0,0,n,t),r=i.getImageData(0,0,n,t).data,a.height=t,a.width=n,c(r,a)}throw Error("Can not access image data")}else if(s)return new Promise((t,r)=>{let n=u(),i=l(n);if(!e||!i)return r();let o=new Image;o.crossOrigin="Anonymous",o.src=e,o.onload=()=>{n.width=o.width,n.height=o.height,i.drawImage(o,0,0,n.width,n.height);let e=i.getImageData(0,0,n.width,n.height);a.height=n.height,a.width=n.width,t(c(e.data,a))}});else throw Error("Input data provided is not supported - aborted tensor creation");if(void 0!==r)return c(r,a);throw Error("Input data provided is not supported - aborted tensor creation")},f=(e,t)=>{let{width:r,height:n,download:i,dispose:o}=t;return new T({location:"texture",type:"float32",texture:e,dims:[1,n,r,4],download:i,dispose:o})},g=(e,t)=>{let{dataType:r,dims:n,download:i,dispose:o}=t;return new T({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:n,download:i,dispose:o})},m=(e,t)=>{let{dataType:r,dims:n,download:i,dispose:o}=t;return new T({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:n,download:i,dispose:o})},b=(e,t,r)=>new T({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}}),pt=dQ({"common/dist/esm/tensor-impl-type-mapping.js"(){"use strict";y=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),_=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),v=!1,x=()=>{if(!v){v=!0;let e="u">typeof BigInt64Array&&BigInt64Array.from,t="u">typeof BigUint64Array&&BigUint64Array.from,r=globalThis.Float16Array,n=void 0!==r&&r.from;e&&(y.set("int64",BigInt64Array),_.set(BigInt64Array,"int64")),t&&(y.set("uint64",BigUint64Array),_.set(BigUint64Array,"uint64")),n?(y.set("float16",r),_.set(r,"float16")):y.set("float16",Uint16Array)}}}}),pr=dQ({"common/dist/esm/tensor-utils-impl.js"(){"use strict";pn(),w=e=>{let t=1;for(let r=0;r<e.length;r++){let n=e[r];if("number"!=typeof n||!Number.isSafeInteger(n))throw TypeError(`dims[${r}] must be an integer, got: ${n}`);if(n<0)throw RangeError(`dims[${r}] must be a non-negative integer, got: ${n}`);t*=n}return t},$=(e,t)=>{switch(e.location){case"cpu":return new T(e.type,e.data,t);case"cpu-pinned":return new T({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new T({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new T({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new T({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}}),pn=dQ({"common/dist/esm/tensor-impl.js"(){"use strict";d9(),pe(),pt(),pr(),T=class{constructor(e,t,r){let n,i;if(x(),"object"==typeof e&&"location"in e)switch(this.dataLocation=e.location,n=e.type,i=e.dims,e.location){case"cpu-pinned":{let t=y.get(n);if(!t)throw TypeError(`unsupported type "${n}" to create tensor from pinned buffer`);if(!(e.data instanceof t))throw TypeError(`buffer should be of type ${t.name}`);this.cpuData=e.data;break}case"texture":if("float32"!==n)throw TypeError(`unsupported type "${n}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break;case"gpu-buffer":if("float32"!==n&&"float16"!==n&&"int32"!==n&&"int64"!==n&&"uint32"!==n&&"uint8"!==n&&"bool"!==n&&"uint4"!==n&&"int4"!==n)throw TypeError(`unsupported type "${n}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break;case"ml-tensor":if("float32"!==n&&"float16"!==n&&"int32"!==n&&"int64"!==n&&"uint32"!==n&&"uint64"!==n&&"int8"!==n&&"uint8"!==n&&"bool"!==n&&"uint4"!==n&&"int4"!==n)throw TypeError(`unsupported type "${n}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break;default:throw Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let o,s;if("string"==typeof e)if(n=e,s=r,"string"===e){if(!Array.isArray(t))throw TypeError("A string tensor's data must be a string array.");o=t}else{let r=y.get(e);if(void 0===r)throw TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t))if("float16"===e&&r===Uint16Array||"uint4"===e||"int4"===e)throw TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${r.name} as data.`);else o="uint64"===e||"int64"===e?r.from(t,BigInt):r.from(t);else if(t instanceof r)o=t;else if(t instanceof Uint8ClampedArray)if("uint8"===e)o=Uint8Array.from(t);else throw TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else if("float16"===e&&t instanceof Uint16Array&&r!==Uint16Array)o=new globalThis.Float16Array(t.buffer,t.byteOffset,t.length);else throw TypeError(`A ${n} tensor's data must be type of ${r}`)}else if(s=t,Array.isArray(e)){if(0===e.length)throw TypeError("Tensor type cannot be inferred from an empty array.");let t=typeof e[0];if("string"===t)n="string",o=e;else if("boolean"===t)n="bool",o=Uint8Array.from(e);else throw TypeError(`Invalid element type of data array: ${t}.`)}else if(e instanceof Uint8ClampedArray)n="uint8",o=Uint8Array.from(e);else{let t=_.get(e.constructor);if(void 0===t)throw TypeError(`Unsupported type for tensor data: ${e.constructor}.`);n=t,o=e}if(void 0===s)s=[o.length];else if(!Array.isArray(s))throw TypeError("A tensor's dims must be a number array");i=s,this.cpuData=o,this.dataLocation="cpu"}let o=w(i);if(this.cpuData&&o!==this.cpuData.length)if(("uint4"===n||"int4"===n)&&Math.ceil(o/2)===this.cpuData.length);else throw Error(`Tensor's size(${o}) does not match data length(${this.cpuData.length}).`);this.type=n,this.dims=i,this.size=o}static async fromImage(e,t){return h(e,t)}static fromTexture(e,t){return f(e,t)}static fromGpuBuffer(e,t){return g(e,t)}static fromMLTensor(e,t){return m(e,t)}static fromPinnedBuffer(e,t,r){return b(e,t,r)}toDataURL(e){return d(this,e)}toImageData(e){return p(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":if(!this.downloader)throw Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}default:throw Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if("none"===this.dataLocation)throw Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw Error("Cannot reshape a tensor that owns GPU resource.");return $(this,e)}}}}),pi=dQ({"common/dist/esm/tensor.js"(){"use strict";pn(),I=T}}),po=dQ({"common/dist/esm/trace.js"(){"use strict";d5(),S=(e,t)=>{(void 0===u.trace?u.wasm.trace:u.trace)&&console.timeStamp(`${e}::ORT::${t}`)},O=(e,t)=>{let r=Error().stack?.split(/\r\n|\r|\n/g)||[],n=!1;for(let i=0;i<r.length;i++){if(n&&!r[i].includes("TRACE_FUNC")){let n=`FUNC_${e}::${r[i].trim().split(" ")[1]}`;t&&(n+=`::${t}`),S("CPU",n);return}r[i].includes("TRACE_FUNC")&&(n=!0)}},E=e=>{(void 0===u.trace?u.wasm.trace:u.trace)&&O("BEGIN",e)},P=e=>{(void 0===u.trace?u.wasm.trace:u.trace)&&O("END",e)},k=e=>{(void 0===u.trace?u.wasm.trace:u.trace)&&console.time(`ORT::${e}`)},A=e=>{(void 0===u.trace?u.wasm.trace:u.trace)&&console.timeEnd(`ORT::${e}`)}}}),ps=dQ({"common/dist/esm/inference-session-impl.js"(){"use strict";d4(),pi(),po(),D=class e{constructor(e){this.handler=e}async run(e,t,r){E(),k("InferenceSession.run");let n={},i={};if("object"!=typeof e||null===e||e instanceof I||Array.isArray(e))throw TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let o=!0;if("object"==typeof t){if(null===t)throw TypeError("Unexpected argument[1]: cannot be null.");if(t instanceof I)throw TypeError("'fetches' cannot be a Tensor");if(Array.isArray(t)){if(0===t.length)throw TypeError("'fetches' cannot be an empty array.");for(let e of(o=!1,t)){if("string"!=typeof e)throw TypeError("'fetches' must be a string array or an object.");if(-1===this.outputNames.indexOf(e))throw RangeError(`'fetches' contains invalid output name: ${e}.`);n[e]=null}if("object"==typeof r&&null!==r)i=r;else if(void 0!==r)throw TypeError("'options' must be an object.")}else{let e=!1,s=Object.getOwnPropertyNames(t);for(let r of this.outputNames)if(-1!==s.indexOf(r)){let i=t[r];(null===i||i instanceof I)&&(e=!0,o=!1,n[r]=i)}if(e){if("object"==typeof r&&null!==r)i=r;else if(void 0!==r)throw TypeError("'options' must be an object.")}else i=t}}else if(void 0!==t)throw TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let t of this.inputNames)if(void 0===e[t])throw Error(`input '${t}' is missing in 'feeds'.`);if(o)for(let e of this.outputNames)n[e]=null;let s=await this.handler.run(e,n,i),a={};for(let e in s)if(Object.hasOwnProperty.call(s,e)){let t=s[e];t instanceof I?a[e]=t:a[e]=new I(t.type,t.data,t.dims)}return A("InferenceSession.run"),P(),a}async release(){return this.handler.dispose()}static async create(t,r,n,i){let s;E(),k("InferenceSession.create");let a={};if("string"==typeof t){if(s=t,"object"==typeof r&&null!==r)a=r;else if(void 0!==r)throw TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(s=t,"object"==typeof r&&null!==r)a=r;else if(void 0!==r)throw TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||"u">typeof SharedArrayBuffer&&t instanceof SharedArrayBuffer){let e=0,o=t.byteLength;if("object"==typeof r&&null!==r)a=r;else if("number"==typeof r){if(!Number.isSafeInteger(e=r))throw RangeError("'byteOffset' must be an integer.");if(e<0||e>=t.byteLength)throw RangeError(`'byteOffset' is out of range [0, ${t.byteLength}).`);if(o=t.byteLength-e,"number"==typeof n){if(!Number.isSafeInteger(o=n))throw RangeError("'byteLength' must be an integer.");if(o<=0||e+o>t.byteLength)throw RangeError(`'byteLength' is out of range (0, ${t.byteLength-e}].`);if("object"==typeof i&&null!==i)a=i;else if(void 0!==i)throw TypeError("'options' must be an object.")}else if(void 0!==n)throw TypeError("'byteLength' must be a number.")}else if(void 0!==r)throw TypeError("'options' must be an object.");s=new Uint8Array(t,e,o)}else throw TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[u,l]=await o(a),d=await u.createInferenceSessionHandler(s,l);return A("InferenceSession.create"),P(),new e(d)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}get inputMetadata(){return this.handler.inputMetadata}get outputMetadata(){return this.handler.outputMetadata}}}}),pa=dQ({"common/dist/esm/inference-session.js"(){"use strict";ps(),z=D}}),pu=dQ({"common/dist/esm/tensor-conversion.js"(){}}),pl=dQ({"common/dist/esm/tensor-factory.js"(){}}),pd=dQ({"common/dist/esm/onnx-model.js"(){}}),pp=dQ({"common/dist/esm/onnx-value.js"(){}}),pc={};d0(pc,{InferenceSession:()=>z,TRACE:()=>S,TRACE_EVENT_BEGIN:()=>k,TRACE_EVENT_END:()=>A,TRACE_FUNC_BEGIN:()=>E,TRACE_FUNC_END:()=>P,Tensor:()=>I,env:()=>l,registerBackend:()=>n});var ph=dQ({"common/dist/esm/index.js"(){"use strict";d6(),d7(),pa(),pi(),pu(),pl(),po(),pd(),pp()}});function pf(e,t,r,n){if(void 0===t){var i;return i=e,{verbose:pf.verbose.bind(null,i),info:pf.info.bind(null,i),warning:pf.warning.bind(null,i),error:pf.error.bind(null,i),fatal:pf.fatal.bind(null,i)}}if(void 0===r)pg(e,t,1);else if("number"==typeof r&&void 0===n)pg(e,t,r);else if("string"==typeof r&&void 0===n)pg(e,r,1,t);else if("string"==typeof r&&"number"==typeof n)pg(e,r,n,t);else throw TypeError("input is valid")}function pg(e,t,r,n){let i=M[n||""]||M[""];j[e]<j[i.minimalSeverity]||(i.logDateTime&&(t=`${(new Date).toISOString()}|${t}`),i.logSourceLocation,R[i.provider].log(e,t,n))}var pm=dQ({"web/lib/onnxjs/instrument.ts"(){"use strict";C=class{log(e,t,r){}},N=class{log(e,t,r){console.log(`${this.color(e)} ${r?"\x1b[35m"+r+"\x1b[0m ":""}${t}`)}color(e){switch(e){case"verbose":return"\x1b[34;40mv\x1b[0m";case"info":return"\x1b[32mi\x1b[0m";case"warning":return"\x1b[30;43mw\x1b[0m";case"error":return"\x1b[31;40me\x1b[0m";case"fatal":return"\x1b[101mf\x1b[0m";default:throw Error(`unsupported severity: ${e}`)}}},j={verbose:1e3,info:2e3,warning:4e3,error:5e3,fatal:6e3},R={none:new C,console:new N},M={"":B={provider:"console",minimalSeverity:"warning",logDateTime:!0,logSourceLocation:!1}};var e=pf||(pf={});function t(e){M={},r("",e||{})}function r(e,r){if("*"===e)t(r);else{let t=M[e]||B;M[e]={provider:r.provider||t.provider,minimalSeverity:r.minimalSeverity||t.minimalSeverity,logDateTime:void 0===r.logDateTime?t.logDateTime:r.logDateTime,logSourceLocation:void 0===r.logSourceLocation?t.logSourceLocation:r.logSourceLocation}}}e.verbose=function(t,r){e("verbose",t,r)},e.info=function(t,r){e("info",t,r)},e.warning=function(t,r){e("warning",t,r)},e.error=function(t,r){e("error",t,r)},e.fatal=function(t,r){e("fatal",t,r)},e.reset=t,e.set=r,e.setWithEnv=function(e){let t={};e.logLevel&&(t.minimalSeverity=e.logLevel),r("",t)},F=pf,L=class{constructor(e,t,r,n,i,o){this.category=e,this.name=t,this.startTime=r,this.endCallback=n,this.timer=i,this.ctx=o}async end(){return this.endCallback(this)}async checkTimer(){if(void 0!==this.ctx&&void 0!==this.timer)return this.ctx.endTimer(),this.ctx.waitForQueryAndGetTime(this.timer);throw Error("No webgl timer found")}},V=class{constructor(e,t,r,n){this.category=e,this.name=t,this.startTime=r,this.endTime=n}},U=class{constructor(e,t,r){this._started=!1,this._flushPointer=0,this._started=!1,this._maxNumberEvents=void 0===e?1e4:e,this._flushBatchSize=void 0===t?10:t,this._flushIntervalInMilliseconds=void 0===r?5e3:r}static create(e){return void 0===e?new this:new this(e.maxNumberEvents,e.flushBatchSize,e.flushIntervalInMilliseconds)}start(){this._started=!0,this._timingEvents=[],this._flushTime=q(),this._flushPointer=0}stop(){for(this._started=!1;this._flushPointer<this._timingEvents.length;this._flushPointer++)this.logOneEvent(this._timingEvents[this._flushPointer])}event(e,t,r,n){let i=this._started?this.begin(e,t,n):void 0,o=!1,s=r();if(s&&"function"==typeof s.then)return o=!0,new Promise((e,t)=>{s.then(async t=>{i&&await i.end(),e(t)},async e=>{i&&await i.end(),t(e)})});if(!o&&i){let e=i.end();if(e&&"function"==typeof e.then)return new Promise((t,r)=>{e.then(()=>{t(s)},e=>{r(e)})})}return s}begin(e,t,r){if(!this._started)throw Error("profiler is not started yet");if(void 0!==r)return new L(e,t,0,async e=>this.end(e),r.beginTimer(),r);{let r=q();return this.flush(r),new L(e,t,r,e=>this.endSync(e))}}async end(e){let t=await e.checkTimer();this._timingEvents.length<this._maxNumberEvents&&(this._timingEvents.push(new V(e.category,e.name,e.startTime,t)),this.flush(t))}endSync(e){let t=q();this._timingEvents.length<this._maxNumberEvents&&(this._timingEvents.push(new V(e.category,e.name,e.startTime,t)),this.flush(t))}logOneEvent(e){F.verbose(`Profiler.${e.category}`,`${(e.endTime-e.startTime).toFixed(2)}ms on event '${e.name}' at ${e.endTime.toFixed(2)}`)}flush(e){if(this._timingEvents.length-this._flushPointer>=this._flushBatchSize||e-this._flushTime>=this._flushIntervalInMilliseconds){for(let e=this._flushPointer;this._flushPointer<e+this._flushBatchSize&&this._flushPointer<this._timingEvents.length;this._flushPointer++)this.logOneEvent(this._timingEvents[this._flushPointer]);this._flushTime=q()}}get started(){return this._started}},q="u">typeof performance&&performance.now?()=>performance.now():Date.now}}),pb=dQ({"web/lib/onnxjs/opset.ts"(){}}),py=dY({"web/node_modules/guid-typescript/dist/guid.js"(e){"use strict";e.__esModule=!0,e.Guid=function(){function e(t){if(!t)throw TypeError("Invalid argument; `value` has no value.");this.value=e.EMPTY,t&&e.isGuid(t)&&(this.value=t)}return e.isGuid=function(t){var r=t.toString();return t&&(t instanceof e||e.validator.test(r))},e.create=function(){return new e([e.gen(2),e.gen(1),e.gen(1),e.gen(1),e.gen(3)].join("-"))},e.createEmpty=function(){return new e("emptyguid")},e.parse=function(t){return new e(t)},e.raw=function(){return[e.gen(2),e.gen(1),e.gen(1),e.gen(1),e.gen(3)].join("-")},e.gen=function(e){for(var t="",r=0;r<e;r++)t+=((1+Math.random())*65536|0).toString(16).substring(1);return t},e.prototype.equals=function(t){return e.isGuid(t)&&this.value===t.toString()},e.prototype.isEmpty=function(){return this.value===e.EMPTY},e.prototype.toString=function(){return this.value},e.prototype.toJSON=function(){return{value:this.value}},e.validator=RegExp("^[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}$","i"),e.EMPTY="00000000-0000-0000-0000-000000000000",e}()}});function p_(e,t,r){this.low=0|e,this.high=0|t,this.unsigned=!!r}function pv(e){return!0===(e&&e.__isLong__)}function px(e){var t=Math.clz32(e&-e);return e?31-t:t}function pw(e,t){var r,n,i;if(t)return(e>>>=0,(i=0<=e&&e<256)&&(n=W[e]))?n:(r=pT(e,0,!0),i&&(W[e]=r),r);return(e|=0,(i=-128<=e&&e<128)&&(n=H[e]))?n:(r=pT(e,e<0?-1:0,!1),i&&(H[e]=r),r)}function p$(e,t){if(isNaN(e))return t?ee:Y;if(t){if(e<0)return ee;if(e>=Z)return eo}else{if(e<=-J)return es;if(e+1>=J)return ei}return e<0?p$(-e,t).neg():pT(e%X|0,e/X|0,t)}function pT(e,t,r){return new p_(e,t,r)}function pI(e,t,r){if(0===e.length)throw Error("empty string");if("number"==typeof t?(r=t,t=!1):t=!!t,"NaN"===e||"Infinity"===e||"+Infinity"===e||"-Infinity"===e)return t?ee:Y;if((r=r||10)<2||36<r)throw RangeError("radix");if((n=e.indexOf("-"))>0)throw Error("interior hyphen");if(0===n)return pI(e.substring(1),t,r).neg();for(var n,i=p$(K(r,8)),o=Y,s=0;s<e.length;s+=8){var a=Math.min(8,e.length-s),u=parseInt(e.substring(s,s+a),r);if(a<8){var l=p$(K(r,a));o=o.mul(l).add(p$(u))}else o=(o=o.mul(i)).add(p$(u))}return o.unsigned=t,o}function pS(e,t){return"number"==typeof e?p$(e,t):"string"==typeof e?pI(e,t):pT(e.low,e.high,"boolean"==typeof t?t:e.unsigned)}var pO=dQ({"web/node_modules/long/index.js"(){G=null;try{G=new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0,97,115,109,1,0,0,0,1,13,2,96,0,1,127,96,4,127,127,127,127,1,127,3,7,6,0,1,1,1,1,1,6,6,1,127,1,65,0,11,7,50,6,3,109,117,108,0,1,5,100,105,118,95,115,0,2,5,100,105,118,95,117,0,3,5,114,101,109,95,115,0,4,5,114,101,109,95,117,0,5,8,103,101,116,95,104,105,103,104,0,0,10,191,1,6,4,0,35,0,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,126,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,127,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,128,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,129,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,130,34,4,66,32,135,167,36,0,32,4,167,11])),{}).exports}catch{}p_.prototype.__isLong__,Object.defineProperty(p_.prototype,"__isLong__",{value:!0}),p_.isLong=pv,H={},W={},p_.fromInt=pw,p_.fromNumber=p$,p_.fromBits=pT,K=Math.pow,p_.fromString=pI,p_.fromValue=pS,J=(Z=(X=0x100000000)*X)/2,Q=pw(0x1000000),p_.ZERO=Y=pw(0),p_.UZERO=ee=pw(0,!0),p_.ONE=et=pw(1),p_.UONE=er=pw(1,!0),p_.NEG_ONE=en=pw(-1),p_.MAX_VALUE=ei=pT(-1,0x7fffffff,!1),p_.MAX_UNSIGNED_VALUE=eo=pT(-1,-1,!0),p_.MIN_VALUE=es=pT(0,-0x80000000,!1),(ea=p_.prototype).toInt=function(){return this.unsigned?this.low>>>0:this.low},ea.toNumber=function(){return this.unsigned?(this.high>>>0)*X+(this.low>>>0):this.high*X+(this.low>>>0)},ea.toString=function(e){if((e=e||10)<2||36<e)throw RangeError("radix");if(this.isZero())return"0";if(this.isNegative())if(!this.eq(es))return"-"+this.neg().toString(e);else{var t=p$(e),r=this.div(t),n=r.mul(t).sub(this);return r.toString(e)+n.toInt().toString(e)}for(var i=p$(K(e,6),this.unsigned),o=this,s="";;){var a=o.div(i),u=(o.sub(a.mul(i)).toInt()>>>0).toString(e);if((o=a).isZero())return u+s;for(;u.length<6;)u="0"+u;s=""+u+s}},ea.getHighBits=function(){return this.high},ea.getHighBitsUnsigned=function(){return this.high>>>0},ea.getLowBits=function(){return this.low},ea.getLowBitsUnsigned=function(){return this.low>>>0},ea.getNumBitsAbs=function(){if(this.isNegative())return this.eq(es)?64:this.neg().getNumBitsAbs();for(var e=0!=this.high?this.high:this.low,t=31;t>0&&(e&1<<t)==0;t--);return 0!=this.high?t+33:t+1},ea.isSafeInteger=function(){var e=this.high>>21;return!e||!this.unsigned&&-1===e&&(0!==this.low||-2097152!==this.high)},ea.isZero=function(){return 0===this.high&&0===this.low},ea.eqz=ea.isZero,ea.isNegative=function(){return!this.unsigned&&this.high<0},ea.isPositive=function(){return this.unsigned||this.high>=0},ea.isOdd=function(){return(1&this.low)==1},ea.isEven=function(){return(1&this.low)==0},ea.equals=function(e){return pv(e)||(e=pS(e)),(this.unsigned===e.unsigned||this.high>>>31!=1||e.high>>>31!=1)&&this.high===e.high&&this.low===e.low},ea.eq=ea.equals,ea.notEquals=function(e){return!this.eq(e)},ea.neq=ea.notEquals,ea.ne=ea.notEquals,ea.lessThan=function(e){return 0>this.comp(e)},ea.lt=ea.lessThan,ea.lessThanOrEqual=function(e){return 0>=this.comp(e)},ea.lte=ea.lessThanOrEqual,ea.le=ea.lessThanOrEqual,ea.greaterThan=function(e){return this.comp(e)>0},ea.gt=ea.greaterThan,ea.greaterThanOrEqual=function(e){return this.comp(e)>=0},ea.gte=ea.greaterThanOrEqual,ea.ge=ea.greaterThanOrEqual,ea.compare=function(e){if(pv(e)||(e=pS(e)),this.eq(e))return 0;var t=this.isNegative(),r=e.isNegative();return t&&!r?-1:!t&&r?1:this.unsigned?e.high>>>0>this.high>>>0||e.high===this.high&&e.low>>>0>this.low>>>0?-1:1:this.sub(e).isNegative()?-1:1},ea.comp=ea.compare,ea.negate=function(){return!this.unsigned&&this.eq(es)?es:this.not().add(et)},ea.neg=ea.negate,ea.add=function(e){pv(e)||(e=pS(e));var t,r,n=this.high>>>16,i=65535&this.high,o=this.low>>>16,s=65535&this.low,a=e.high>>>16,u=65535&e.high,l=e.low>>>16,d=65535&e.low,p=0,c=0;return t=0+((r=0+(s+d))>>>16),r&=65535,t+=o+l,c+=t>>>16,t&=65535,c+=i+u,p+=c>>>16,c&=65535,p+=n+a,pT(t<<16|r,(p&=65535)<<16|c,this.unsigned)},ea.subtract=function(e){return pv(e)||(e=pS(e)),this.add(e.neg())},ea.sub=ea.subtract,ea.multiply=function(e){if(this.isZero())return this;if(pv(e)||(e=pS(e)),G)return pT(G.mul(this.low,this.high,e.low,e.high),G.get_high(),this.unsigned);if(e.isZero())return this.unsigned?ee:Y;if(this.eq(es))return e.isOdd()?es:Y;if(e.eq(es))return this.isOdd()?es:Y;if(this.isNegative())if(e.isNegative())return this.neg().mul(e.neg());else return this.neg().mul(e).neg();if(e.isNegative())return this.mul(e.neg()).neg();if(this.lt(Q)&&e.lt(Q))return p$(this.toNumber()*e.toNumber(),this.unsigned);var t,r,n=this.high>>>16,i=65535&this.high,o=this.low>>>16,s=65535&this.low,a=e.high>>>16,u=65535&e.high,l=e.low>>>16,d=65535&e.low,p=0,c=0;return t=0+((r=0+s*d)>>>16),r&=65535,t+=o*d,c+=t>>>16,t&=65535,t+=s*l,c+=t>>>16,t&=65535,c+=i*d,p+=c>>>16,c&=65535,c+=o*l,p+=c>>>16,c&=65535,c+=s*u,p+=c>>>16,c&=65535,p+=n*d+i*l+o*u+s*a,pT(t<<16|r,(p&=65535)<<16|c,this.unsigned)},ea.mul=ea.multiply,ea.divide=function(e){if(pv(e)||(e=pS(e)),e.isZero())throw Error("division by zero");if(G){var t,r,n;return this.unsigned||-0x80000000!==this.high||-1!==e.low||-1!==e.high?pT((this.unsigned?G.div_u:G.div_s)(this.low,this.high,e.low,e.high),G.get_high(),this.unsigned):this}if(this.isZero())return this.unsigned?ee:Y;if(this.unsigned){if(e.unsigned||(e=e.toUnsigned()),e.gt(this))return ee;if(e.gt(this.shru(1)))return er;n=ee}else{if(this.eq(es))if(e.eq(et)||e.eq(en))return es;else return e.eq(es)?et:(t=this.shr(1).div(e).shl(1)).eq(Y)?e.isNegative()?et:en:(r=this.sub(e.mul(t)),n=t.add(r.div(e)));if(e.eq(es))return this.unsigned?ee:Y;if(this.isNegative())return e.isNegative()?this.neg().div(e.neg()):this.neg().div(e).neg();if(e.isNegative())return this.div(e.neg()).neg();n=Y}for(r=this;r.gte(e);){for(var i=Math.ceil(Math.log(t=Math.max(1,Math.floor(r.toNumber()/e.toNumber())))/Math.LN2),o=i<=48?1:K(2,i-48),s=p$(t),a=s.mul(e);a.isNegative()||a.gt(r);)t-=o,a=(s=p$(t,this.unsigned)).mul(e);s.isZero()&&(s=et),n=n.add(s),r=r.sub(a)}return n},ea.div=ea.divide,ea.modulo=function(e){return(pv(e)||(e=pS(e)),G)?pT((this.unsigned?G.rem_u:G.rem_s)(this.low,this.high,e.low,e.high),G.get_high(),this.unsigned):this.sub(this.div(e).mul(e))},ea.mod=ea.modulo,ea.rem=ea.modulo,ea.not=function(){return pT(~this.low,~this.high,this.unsigned)},ea.countLeadingZeros=function(){return this.high?Math.clz32(this.high):Math.clz32(this.low)+32},ea.clz=ea.countLeadingZeros,ea.countTrailingZeros=function(){return this.low?px(this.low):px(this.high)+32},ea.ctz=ea.countTrailingZeros,ea.and=function(e){return pv(e)||(e=pS(e)),pT(this.low&e.low,this.high&e.high,this.unsigned)},ea.or=function(e){return pv(e)||(e=pS(e)),pT(this.low|e.low,this.high|e.high,this.unsigned)},ea.xor=function(e){return pv(e)||(e=pS(e)),pT(this.low^e.low,this.high^e.high,this.unsigned)},ea.shiftLeft=function(e){return(pv(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?pT(this.low<<e,this.high<<e|this.low>>>32-e,this.unsigned):pT(0,this.low<<e-32,this.unsigned)},ea.shl=ea.shiftLeft,ea.shiftRight=function(e){return(pv(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?pT(this.low>>>e|this.high<<32-e,this.high>>e,this.unsigned):pT(this.high>>e-32,this.high>=0?0:-1,this.unsigned)},ea.shr=ea.shiftRight,ea.shiftRightUnsigned=function(e){return(pv(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?pT(this.low>>>e|this.high<<32-e,this.high>>>e,this.unsigned):32===e?pT(this.high,0,this.unsigned):pT(this.high>>>e-32,0,this.unsigned)},ea.shru=ea.shiftRightUnsigned,ea.shr_u=ea.shiftRightUnsigned,ea.rotateLeft=function(e){var t;return(pv(e)&&(e=e.toInt()),0==(e&=63))?this:32===e?pT(this.high,this.low,this.unsigned):e<32?(t=32-e,pT(this.low<<e|this.high>>>t,this.high<<e|this.low>>>t,this.unsigned)):(e-=32,t=32-e,pT(this.high<<e|this.low>>>t,this.low<<e|this.high>>>t,this.unsigned))},ea.rotl=ea.rotateLeft,ea.rotateRight=function(e){var t;return(pv(e)&&(e=e.toInt()),0==(e&=63))?this:32===e?pT(this.high,this.low,this.unsigned):e<32?(t=32-e,pT(this.high<<t|this.low>>>e,this.low<<t|this.high>>>e,this.unsigned)):(e-=32,t=32-e,pT(this.low<<t|this.high>>>e,this.high<<t|this.low>>>e,this.unsigned))},ea.rotr=ea.rotateRight,ea.toSigned=function(){return this.unsigned?pT(this.low,this.high,!1):this},ea.toUnsigned=function(){return this.unsigned?this:pT(this.low,this.high,!0)},ea.toBytes=function(e){return e?this.toBytesLE():this.toBytesBE()},ea.toBytesLE=function(){var e=this.high,t=this.low;return[255&t,t>>>8&255,t>>>16&255,t>>>24,255&e,e>>>8&255,e>>>16&255,e>>>24]},ea.toBytesBE=function(){var e=this.high,t=this.low;return[e>>>24,e>>>16&255,e>>>8&255,255&e,t>>>24,t>>>16&255,t>>>8&255,255&t]},p_.fromBytes=function(e,t,r){return r?p_.fromBytesLE(e,t):p_.fromBytesBE(e,t)},p_.fromBytesLE=function(e,t){return new p_(e[0]|e[1]<<8|e[2]<<16|e[3]<<24,e[4]|e[5]<<8|e[6]<<16|e[7]<<24,t)},p_.fromBytesBE=function(e,t){return new p_(e[4]<<24|e[5]<<16|e[6]<<8|e[7],e[0]<<24|e[1]<<16|e[2]<<8|e[3],t)},"function"==typeof BigInt&&(p_.fromBigInt=function(e,t){return pT(Number(BigInt.asIntN(32,e)),Number(BigInt.asIntN(32,e>>BigInt(32))),t)},p_.fromValue=function(e,t){return"bigint"==typeof e?p_.fromBigInt(e,t):pS(e,t)},ea.toBigInt=function(){var e=BigInt(this.low>>>0);return BigInt(this.unsigned?this.high>>>0:this.high)<<BigInt(32)|e}),eu=p_}}),pE=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/arg-type.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.ArgType=void 0,(r=t||(e.ArgType=t={}))[r.INPUT=0]="INPUT",r[r.OUTPUT=1]="OUTPUT"}}),pP=dY({"web/node_modules/flatbuffers/js/constants.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.SIZE_PREFIX_LENGTH=e.FILE_IDENTIFIER_LENGTH=e.SIZEOF_INT=e.SIZEOF_SHORT=void 0,e.SIZEOF_SHORT=2,e.SIZEOF_INT=4,e.FILE_IDENTIFIER_LENGTH=4,e.SIZE_PREFIX_LENGTH=4}}),pk=dY({"web/node_modules/flatbuffers/js/utils.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.isLittleEndian=e.float64=e.float32=e.int32=void 0,e.int32=new Int32Array(2),e.float32=new Float32Array(e.int32.buffer),e.float64=new Float64Array(e.int32.buffer),e.isLittleEndian=1===new Uint16Array(new Uint8Array([1,0]).buffer)[0]}}),pA=dY({"web/node_modules/flatbuffers/js/encoding.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.Encoding=void 0,(r=t||(e.Encoding=t={}))[r.UTF8_BYTES=1]="UTF8_BYTES",r[r.UTF16_STRING=2]="UTF16_STRING"}}),pD=dY({"web/node_modules/flatbuffers/js/byte-buffer.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.ByteBuffer=void 0;var t=pP(),r=pA(),n=pk();e.ByteBuffer=class e{constructor(e){this.bytes_=e,this.position_=0,this.text_decoder_=new TextDecoder}static allocate(t){return new e(new Uint8Array(t))}clear(){this.position_=0}bytes(){return this.bytes_}position(){return this.position_}setPosition(e){this.position_=e}capacity(){return this.bytes_.length}readInt8(e){return this.readUint8(e)<<24>>24}readUint8(e){return this.bytes_[e]}readInt16(e){return this.readUint16(e)<<16>>16}readUint16(e){return this.bytes_[e]|this.bytes_[e+1]<<8}readInt32(e){return this.bytes_[e]|this.bytes_[e+1]<<8|this.bytes_[e+2]<<16|this.bytes_[e+3]<<24}readUint32(e){return this.readInt32(e)>>>0}readInt64(e){return BigInt.asIntN(64,BigInt(this.readUint32(e))+(BigInt(this.readUint32(e+4))<<BigInt(32)))}readUint64(e){return BigInt.asUintN(64,BigInt(this.readUint32(e))+(BigInt(this.readUint32(e+4))<<BigInt(32)))}readFloat32(e){return n.int32[0]=this.readInt32(e),n.float32[0]}readFloat64(e){return n.int32[+!n.isLittleEndian]=this.readInt32(e),n.int32[+!!n.isLittleEndian]=this.readInt32(e+4),n.float64[0]}writeInt8(e,t){this.bytes_[e]=t}writeUint8(e,t){this.bytes_[e]=t}writeInt16(e,t){this.bytes_[e]=t,this.bytes_[e+1]=t>>8}writeUint16(e,t){this.bytes_[e]=t,this.bytes_[e+1]=t>>8}writeInt32(e,t){this.bytes_[e]=t,this.bytes_[e+1]=t>>8,this.bytes_[e+2]=t>>16,this.bytes_[e+3]=t>>24}writeUint32(e,t){this.bytes_[e]=t,this.bytes_[e+1]=t>>8,this.bytes_[e+2]=t>>16,this.bytes_[e+3]=t>>24}writeInt64(e,t){this.writeInt32(e,Number(BigInt.asIntN(32,t))),this.writeInt32(e+4,Number(BigInt.asIntN(32,t>>BigInt(32))))}writeUint64(e,t){this.writeUint32(e,Number(BigInt.asUintN(32,t))),this.writeUint32(e+4,Number(BigInt.asUintN(32,t>>BigInt(32))))}writeFloat32(e,t){n.float32[0]=t,this.writeInt32(e,n.int32[0])}writeFloat64(e,t){n.float64[0]=t,this.writeInt32(e,n.int32[+!n.isLittleEndian]),this.writeInt32(e+4,n.int32[+!!n.isLittleEndian])}getBufferIdentifier(){if(this.bytes_.length<this.position_+t.SIZEOF_INT+t.FILE_IDENTIFIER_LENGTH)throw Error("FlatBuffers: ByteBuffer is too short to contain an identifier.");let e="";for(let r=0;r<t.FILE_IDENTIFIER_LENGTH;r++)e+=String.fromCharCode(this.readInt8(this.position_+t.SIZEOF_INT+r));return e}__offset(e,t){let r=e-this.readInt32(e);return t<this.readInt16(r)?this.readInt16(r+t):0}__union(e,t){return e.bb_pos=t+this.readInt32(t),e.bb=this,e}__string(e,n){e+=this.readInt32(e);let i=this.readInt32(e);e+=t.SIZEOF_INT;let o=this.bytes_.subarray(e,e+i);return n===r.Encoding.UTF8_BYTES?o:this.text_decoder_.decode(o)}__union_with_string(e,t){return"string"==typeof e?this.__string(t):this.__union(e,t)}__indirect(e){return e+this.readInt32(e)}__vector(e){return e+this.readInt32(e)+t.SIZEOF_INT}__vector_len(e){return this.readInt32(e+this.readInt32(e))}__has_identifier(e){if(e.length!=t.FILE_IDENTIFIER_LENGTH)throw Error("FlatBuffers: file identifier must be length "+t.FILE_IDENTIFIER_LENGTH);for(let r=0;r<t.FILE_IDENTIFIER_LENGTH;r++)if(e.charCodeAt(r)!=this.readInt8(this.position()+t.SIZEOF_INT+r))return!1;return!0}createScalarList(e,t){let r=[];for(let n=0;n<t;++n){let t=e(n);null!==t&&r.push(t)}return r}createObjList(e,t){let r=[];for(let n=0;n<t;++n){let t=e(n);null!==t&&r.push(t.unpack())}return r}}}}),pz=dY({"web/node_modules/flatbuffers/js/builder.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.Builder=void 0;var t=pD(),r=pP();e.Builder=class e{constructor(e){let r;this.minalign=1,this.vtable=null,this.vtable_in_use=0,this.isNested=!1,this.object_start=0,this.vtables=[],this.vector_num_elems=0,this.force_defaults=!1,this.string_maps=null,this.text_encoder=new TextEncoder,r=e||1024,this.bb=t.ByteBuffer.allocate(r),this.space=r}clear(){this.bb.clear(),this.space=this.bb.capacity(),this.minalign=1,this.vtable=null,this.vtable_in_use=0,this.isNested=!1,this.object_start=0,this.vtables=[],this.vector_num_elems=0,this.force_defaults=!1,this.string_maps=null}forceDefaults(e){this.force_defaults=e}dataBuffer(){return this.bb}asUint8Array(){return this.bb.bytes().subarray(this.bb.position(),this.bb.position()+this.offset())}prep(t,r){t>this.minalign&&(this.minalign=t);let n=~(this.bb.capacity()-this.space+r)+1&t-1;for(;this.space<n+t+r;){let t=this.bb.capacity();this.bb=e.growByteBuffer(this.bb),this.space+=this.bb.capacity()-t}this.pad(n)}pad(e){for(let t=0;t<e;t++)this.bb.writeInt8(--this.space,0)}writeInt8(e){this.bb.writeInt8(this.space-=1,e)}writeInt16(e){this.bb.writeInt16(this.space-=2,e)}writeInt32(e){this.bb.writeInt32(this.space-=4,e)}writeInt64(e){this.bb.writeInt64(this.space-=8,e)}writeFloat32(e){this.bb.writeFloat32(this.space-=4,e)}writeFloat64(e){this.bb.writeFloat64(this.space-=8,e)}addInt8(e){this.prep(1,0),this.writeInt8(e)}addInt16(e){this.prep(2,0),this.writeInt16(e)}addInt32(e){this.prep(4,0),this.writeInt32(e)}addInt64(e){this.prep(8,0),this.writeInt64(e)}addFloat32(e){this.prep(4,0),this.writeFloat32(e)}addFloat64(e){this.prep(8,0),this.writeFloat64(e)}addFieldInt8(e,t,r){(this.force_defaults||t!=r)&&(this.addInt8(t),this.slot(e))}addFieldInt16(e,t,r){(this.force_defaults||t!=r)&&(this.addInt16(t),this.slot(e))}addFieldInt32(e,t,r){(this.force_defaults||t!=r)&&(this.addInt32(t),this.slot(e))}addFieldInt64(e,t,r){(this.force_defaults||t!==r)&&(this.addInt64(t),this.slot(e))}addFieldFloat32(e,t,r){(this.force_defaults||t!=r)&&(this.addFloat32(t),this.slot(e))}addFieldFloat64(e,t,r){(this.force_defaults||t!=r)&&(this.addFloat64(t),this.slot(e))}addFieldOffset(e,t,r){(this.force_defaults||t!=r)&&(this.addOffset(t),this.slot(e))}addFieldStruct(e,t,r){t!=r&&(this.nested(t),this.slot(e))}nested(e){if(e!=this.offset())throw TypeError("FlatBuffers: struct must be serialized inline.")}notNested(){if(this.isNested)throw TypeError("FlatBuffers: object serialization must not be nested.")}slot(e){null!==this.vtable&&(this.vtable[e]=this.offset())}offset(){return this.bb.capacity()-this.space}static growByteBuffer(e){let r=e.capacity();if(0xc0000000&r)throw Error("FlatBuffers: cannot grow buffer beyond 2 gigabytes.");let n=r<<1,i=t.ByteBuffer.allocate(n);return i.setPosition(n-r),i.bytes().set(e.bytes(),n-r),i}addOffset(e){this.prep(r.SIZEOF_INT,0),this.writeInt32(this.offset()-e+r.SIZEOF_INT)}startObject(e){this.notNested(),null==this.vtable&&(this.vtable=[]),this.vtable_in_use=e;for(let t=0;t<e;t++)this.vtable[t]=0;this.isNested=!0,this.object_start=this.offset()}endObject(){if(null==this.vtable||!this.isNested)throw Error("FlatBuffers: endObject called without startObject");this.addInt32(0);let e=this.offset(),t=this.vtable_in_use-1;for(;t>=0&&0==this.vtable[t];t--);let n=t+1;for(;t>=0;t--)this.addInt16(0!=this.vtable[t]?e-this.vtable[t]:0);this.addInt16(e-this.object_start);let i=(n+2)*r.SIZEOF_SHORT;this.addInt16(i);let o=0,s=this.space;e:for(t=0;t<this.vtables.length;t++){let e=this.bb.capacity()-this.vtables[t];if(i==this.bb.readInt16(e)){for(let t=r.SIZEOF_SHORT;t<i;t+=r.SIZEOF_SHORT)if(this.bb.readInt16(s+t)!=this.bb.readInt16(e+t))continue e;o=this.vtables[t];break}}return o?(this.space=this.bb.capacity()-e,this.bb.writeInt32(this.space,o-e)):(this.vtables.push(this.offset()),this.bb.writeInt32(this.bb.capacity()-e,this.offset()-e)),this.isNested=!1,e}finish(e,t,n){let i=n?r.SIZE_PREFIX_LENGTH:0;if(t){if(this.prep(this.minalign,r.SIZEOF_INT+r.FILE_IDENTIFIER_LENGTH+i),t.length!=r.FILE_IDENTIFIER_LENGTH)throw TypeError("FlatBuffers: file identifier must be length "+r.FILE_IDENTIFIER_LENGTH);for(let e=r.FILE_IDENTIFIER_LENGTH-1;e>=0;e--)this.writeInt8(t.charCodeAt(e))}this.prep(this.minalign,r.SIZEOF_INT+i),this.addOffset(e),i&&this.addInt32(this.bb.capacity()-this.space),this.bb.setPosition(this.space)}finishSizePrefixed(e,t){this.finish(e,t,!0)}requiredField(e,t){let r=this.bb.capacity()-e,n=r-this.bb.readInt32(r);if(!(t<this.bb.readInt16(n)&&0!=this.bb.readInt16(n+t)))throw TypeError("FlatBuffers: field "+t+" must be set")}startVector(e,t,n){this.notNested(),this.vector_num_elems=t,this.prep(r.SIZEOF_INT,e*t),this.prep(n,e*t)}endVector(){return this.writeInt32(this.vector_num_elems),this.offset()}createSharedString(e){if(!e)return 0;if(this.string_maps||(this.string_maps=new Map),this.string_maps.has(e))return this.string_maps.get(e);let t=this.createString(e);return this.string_maps.set(e,t),t}createString(e){let t;return null==e?0:(t=e instanceof Uint8Array?e:this.text_encoder.encode(e),this.addInt8(0),this.startVector(1,t.length,1),this.bb.setPosition(this.space-=t.length),this.bb.bytes().set(t,this.space),this.endVector())}createByteVector(e){return null==e?0:(this.startVector(1,e.length,1),this.bb.setPosition(this.space-=e.length),this.bb.bytes().set(e,this.space),this.endVector())}createObjectOffset(e){return null===e?0:"string"==typeof e?this.createString(e):e.pack(this)}createObjectOffsetList(e){let t=[];for(let r=0;r<e.length;++r){let n=e[r];if(null!==n)t.push(this.createObjectOffset(n));else throw TypeError("FlatBuffers: Argument for createObjectOffsetList cannot contain null.")}return t}createStructOffsetList(e,t){return t(this,e.length),this.createObjectOffsetList(e.slice().reverse()),this.endVector()}}}}),pC=dY({"web/node_modules/flatbuffers/js/flatbuffers.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.Encoding=e.ByteBuffer=e.Builder=e.isLittleEndian=e.int32=e.float64=e.float32=e.SIZE_PREFIX_LENGTH=e.SIZEOF_SHORT=e.SIZEOF_INT=e.FILE_IDENTIFIER_LENGTH=void 0;var t=pP();Object.defineProperty(e,"FILE_IDENTIFIER_LENGTH",{enumerable:!0,get:function(){return t.FILE_IDENTIFIER_LENGTH}}),Object.defineProperty(e,"SIZEOF_INT",{enumerable:!0,get:function(){return t.SIZEOF_INT}}),Object.defineProperty(e,"SIZEOF_SHORT",{enumerable:!0,get:function(){return t.SIZEOF_SHORT}}),Object.defineProperty(e,"SIZE_PREFIX_LENGTH",{enumerable:!0,get:function(){return t.SIZE_PREFIX_LENGTH}});var r=pk();Object.defineProperty(e,"float32",{enumerable:!0,get:function(){return r.float32}}),Object.defineProperty(e,"float64",{enumerable:!0,get:function(){return r.float64}}),Object.defineProperty(e,"int32",{enumerable:!0,get:function(){return r.int32}}),Object.defineProperty(e,"isLittleEndian",{enumerable:!0,get:function(){return r.isLittleEndian}});var n=pz();Object.defineProperty(e,"Builder",{enumerable:!0,get:function(){return n.Builder}});var i=pD();Object.defineProperty(e,"ByteBuffer",{enumerable:!0,get:function(){return i.ByteBuffer}});var o=pA();Object.defineProperty(e,"Encoding",{enumerable:!0,get:function(){return o.Encoding}})}}),pN=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/arg-type-and-index.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.ArgTypeAndIndex=void 0;var o=i(pC()),s=pE();e.ArgTypeAndIndex=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsArgTypeAndIndex(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsArgTypeAndIndex(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}argType(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readInt8(this.bb_pos+e):s.ArgType.INPUT}index(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readUint32(this.bb_pos+e):0}static startArgTypeAndIndex(e){e.startObject(2)}static addArgType(e,t){e.addFieldInt8(0,t,s.ArgType.INPUT)}static addIndex(e,t){e.addFieldInt32(1,t,0)}static endArgTypeAndIndex(e){return e.endObject()}static createArgTypeAndIndex(t,r,n){return e.startArgTypeAndIndex(t),e.addArgType(t,r),e.addIndex(t,n),e.endArgTypeAndIndex(t)}}}}),pj=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/attribute-type.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.AttributeType=void 0,(r=t||(e.AttributeType=t={}))[r.UNDEFINED=0]="UNDEFINED",r[r.FLOAT=1]="FLOAT",r[r.INT=2]="INT",r[r.STRING=3]="STRING",r[r.TENSOR=4]="TENSOR",r[r.GRAPH=5]="GRAPH",r[r.FLOATS=6]="FLOATS",r[r.INTS=7]="INTS",r[r.STRINGS=8]="STRINGS",r[r.TENSORS=9]="TENSORS",r[r.GRAPHS=10]="GRAPHS",r[r.SPARSE_TENSOR=11]="SPARSE_TENSOR",r[r.SPARSE_TENSORS=12]="SPARSE_TENSORS"}}),pR=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/node-type.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.NodeType=void 0,(r=t||(e.NodeType=t={}))[r.Primitive=0]="Primitive",r[r.Fused=1]="Fused"}}),pB=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/node.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Node=void 0;var o=i(pC()),s=p6(),a=pR();e.Node=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsNode(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsNode(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}name(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}docString(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}domain(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.__string(this.bb_pos+t,e):null}sinceVersion(){let e=this.bb.__offset(this.bb_pos,10);return e?this.bb.readInt32(this.bb_pos+e):0}index(){let e=this.bb.__offset(this.bb_pos,12);return e?this.bb.readUint32(this.bb_pos+e):0}opType(e){let t=this.bb.__offset(this.bb_pos,14);return t?this.bb.__string(this.bb_pos+t,e):null}type(){let e=this.bb.__offset(this.bb_pos,16);return e?this.bb.readInt32(this.bb_pos+e):a.NodeType.Primitive}executionProviderType(e){let t=this.bb.__offset(this.bb_pos,18);return t?this.bb.__string(this.bb_pos+t,e):null}inputs(e,t){let r=this.bb.__offset(this.bb_pos,20);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}inputsLength(){let e=this.bb.__offset(this.bb_pos,20);return e?this.bb.__vector_len(this.bb_pos+e):0}outputs(e,t){let r=this.bb.__offset(this.bb_pos,22);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}outputsLength(){let e=this.bb.__offset(this.bb_pos,22);return e?this.bb.__vector_len(this.bb_pos+e):0}attributes(e,t){let r=this.bb.__offset(this.bb_pos,24);return r?(t||new s.Attribute).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}attributesLength(){let e=this.bb.__offset(this.bb_pos,24);return e?this.bb.__vector_len(this.bb_pos+e):0}inputArgCounts(e){let t=this.bb.__offset(this.bb_pos,26);return t?this.bb.readInt32(this.bb.__vector(this.bb_pos+t)+4*e):0}inputArgCountsLength(){let e=this.bb.__offset(this.bb_pos,26);return e?this.bb.__vector_len(this.bb_pos+e):0}inputArgCountsArray(){let e=this.bb.__offset(this.bb_pos,26);return e?new Int32Array(this.bb.bytes().buffer,this.bb.bytes().byteOffset+this.bb.__vector(this.bb_pos+e),this.bb.__vector_len(this.bb_pos+e)):null}implicitInputs(e,t){let r=this.bb.__offset(this.bb_pos,28);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}implicitInputsLength(){let e=this.bb.__offset(this.bb_pos,28);return e?this.bb.__vector_len(this.bb_pos+e):0}static startNode(e){e.startObject(13)}static addName(e,t){e.addFieldOffset(0,t,0)}static addDocString(e,t){e.addFieldOffset(1,t,0)}static addDomain(e,t){e.addFieldOffset(2,t,0)}static addSinceVersion(e,t){e.addFieldInt32(3,t,0)}static addIndex(e,t){e.addFieldInt32(4,t,0)}static addOpType(e,t){e.addFieldOffset(5,t,0)}static addType(e,t){e.addFieldInt32(6,t,a.NodeType.Primitive)}static addExecutionProviderType(e,t){e.addFieldOffset(7,t,0)}static addInputs(e,t){e.addFieldOffset(8,t,0)}static createInputsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startInputsVector(e,t){e.startVector(4,t,4)}static addOutputs(e,t){e.addFieldOffset(9,t,0)}static createOutputsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startOutputsVector(e,t){e.startVector(4,t,4)}static addAttributes(e,t){e.addFieldOffset(10,t,0)}static createAttributesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startAttributesVector(e,t){e.startVector(4,t,4)}static addInputArgCounts(e,t){e.addFieldOffset(11,t,0)}static createInputArgCountsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addInt32(t[r]);return e.endVector()}static startInputArgCountsVector(e,t){e.startVector(4,t,4)}static addImplicitInputs(e,t){e.addFieldOffset(12,t,0)}static createImplicitInputsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startImplicitInputsVector(e,t){e.startVector(4,t,4)}static endNode(e){return e.endObject()}static createNode(t,r,n,i,o,s,a,u,l,d,p,c,h,f){return e.startNode(t),e.addName(t,r),e.addDocString(t,n),e.addDomain(t,i),e.addSinceVersion(t,o),e.addIndex(t,s),e.addOpType(t,a),e.addType(t,u),e.addExecutionProviderType(t,l),e.addInputs(t,d),e.addOutputs(t,p),e.addAttributes(t,c),e.addInputArgCounts(t,h),e.addImplicitInputs(t,f),e.endNode(t)}}}}),pM=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/edge-end.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.EdgeEnd=void 0,e.EdgeEnd=class{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}nodeIndex(){return this.bb.readUint32(this.bb_pos)}srcArgIndex(){return this.bb.readInt32(this.bb_pos+4)}dstArgIndex(){return this.bb.readInt32(this.bb_pos+8)}static sizeOf(){return 12}static createEdgeEnd(e,t,r,n){return e.prep(4,12),e.writeInt32(n),e.writeInt32(r),e.writeInt32(t),e.offset()}}}}),pF=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/node-edge.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.NodeEdge=void 0;var o=i(pC()),s=pM();e.NodeEdge=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsNodeEdge(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsNodeEdge(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}nodeIndex(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readUint32(this.bb_pos+e):0}inputEdges(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new s.EdgeEnd).__init(this.bb.__vector(this.bb_pos+r)+12*e,this.bb):null}inputEdgesLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}outputEdges(e,t){let r=this.bb.__offset(this.bb_pos,8);return r?(t||new s.EdgeEnd).__init(this.bb.__vector(this.bb_pos+r)+12*e,this.bb):null}outputEdgesLength(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.__vector_len(this.bb_pos+e):0}static startNodeEdge(e){e.startObject(3)}static addNodeIndex(e,t){e.addFieldInt32(0,t,0)}static addInputEdges(e,t){e.addFieldOffset(1,t,0)}static startInputEdgesVector(e,t){e.startVector(12,t,4)}static addOutputEdges(e,t){e.addFieldOffset(2,t,0)}static startOutputEdgesVector(e,t){e.startVector(12,t,4)}static endNodeEdge(e){return e.endObject()}static createNodeEdge(t,r,n,i){return e.startNodeEdge(t),e.addNodeIndex(t,r),e.addInputEdges(t,n),e.addOutputEdges(t,i),e.endNodeEdge(t)}}}}),pL=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/nodes-to-optimize-indices.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.NodesToOptimizeIndices=void 0;var o=i(pC());e.NodesToOptimizeIndices=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsNodesToOptimizeIndices(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsNodesToOptimizeIndices(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}nodeIndices(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.readUint32(this.bb.__vector(this.bb_pos+t)+4*e):0}nodeIndicesLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}nodeIndicesArray(){let e=this.bb.__offset(this.bb_pos,4);return e?new Uint32Array(this.bb.bytes().buffer,this.bb.bytes().byteOffset+this.bb.__vector(this.bb_pos+e),this.bb.__vector_len(this.bb_pos+e)):null}numInputs(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readUint32(this.bb_pos+e):0}numOutputs(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.readUint32(this.bb_pos+e):0}hasVariadicInput(){let e=this.bb.__offset(this.bb_pos,10);return!!e&&!!this.bb.readInt8(this.bb_pos+e)}hasVariadicOutput(){let e=this.bb.__offset(this.bb_pos,12);return!!e&&!!this.bb.readInt8(this.bb_pos+e)}numVariadicInputs(){let e=this.bb.__offset(this.bb_pos,14);return e?this.bb.readUint32(this.bb_pos+e):0}numVariadicOutputs(){let e=this.bb.__offset(this.bb_pos,16);return e?this.bb.readUint32(this.bb_pos+e):0}static startNodesToOptimizeIndices(e){e.startObject(7)}static addNodeIndices(e,t){e.addFieldOffset(0,t,0)}static createNodeIndicesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addInt32(t[r]);return e.endVector()}static startNodeIndicesVector(e,t){e.startVector(4,t,4)}static addNumInputs(e,t){e.addFieldInt32(1,t,0)}static addNumOutputs(e,t){e.addFieldInt32(2,t,0)}static addHasVariadicInput(e,t){e.addFieldInt8(3,+t,0)}static addHasVariadicOutput(e,t){e.addFieldInt8(4,+t,0)}static addNumVariadicInputs(e,t){e.addFieldInt32(5,t,0)}static addNumVariadicOutputs(e,t){e.addFieldInt32(6,t,0)}static endNodesToOptimizeIndices(e){return e.endObject()}static createNodesToOptimizeIndices(t,r,n,i,o,s,a,u){return e.startNodesToOptimizeIndices(t),e.addNodeIndices(t,r),e.addNumInputs(t,n),e.addNumOutputs(t,i),e.addHasVariadicInput(t,o),e.addHasVariadicOutput(t,s),e.addNumVariadicInputs(t,a),e.addNumVariadicOutputs(t,u),e.endNodesToOptimizeIndices(t)}}}}),pV=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/runtime-optimization-record.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.RuntimeOptimizationRecord=void 0;var o=i(pC()),s=pL();e.RuntimeOptimizationRecord=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsRuntimeOptimizationRecord(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsRuntimeOptimizationRecord(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}actionId(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}nodesToOptimizeIndices(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new s.NodesToOptimizeIndices).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}producedOpIds(e,t){let r=this.bb.__offset(this.bb_pos,10);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}producedOpIdsLength(){let e=this.bb.__offset(this.bb_pos,10);return e?this.bb.__vector_len(this.bb_pos+e):0}static startRuntimeOptimizationRecord(e){e.startObject(4)}static addActionId(e,t){e.addFieldOffset(0,t,0)}static addNodesToOptimizeIndices(e,t){e.addFieldOffset(1,t,0)}static addProducedOpIds(e,t){e.addFieldOffset(3,t,0)}static createProducedOpIdsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startProducedOpIdsVector(e,t){e.startVector(4,t,4)}static endRuntimeOptimizationRecord(e){return e.endObject()}}}}),pU=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/runtime-optimization-record-container-entry.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.RuntimeOptimizationRecordContainerEntry=void 0;var o=i(pC()),s=pV();e.RuntimeOptimizationRecordContainerEntry=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsRuntimeOptimizationRecordContainerEntry(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsRuntimeOptimizationRecordContainerEntry(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}optimizerName(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}runtimeOptimizationRecords(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new s.RuntimeOptimizationRecord).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}runtimeOptimizationRecordsLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}static startRuntimeOptimizationRecordContainerEntry(e){e.startObject(2)}static addOptimizerName(e,t){e.addFieldOffset(0,t,0)}static addRuntimeOptimizationRecords(e,t){e.addFieldOffset(1,t,0)}static createRuntimeOptimizationRecordsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startRuntimeOptimizationRecordsVector(e,t){e.startVector(4,t,4)}static endRuntimeOptimizationRecordContainerEntry(e){let t=e.endObject();return e.requiredField(t,4),t}static createRuntimeOptimizationRecordContainerEntry(t,r,n){return e.startRuntimeOptimizationRecordContainerEntry(t),e.addOptimizerName(t,r),e.addRuntimeOptimizationRecords(t,n),e.endRuntimeOptimizationRecordContainerEntry(t)}}}}),pq=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/runtime-optimizations.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.RuntimeOptimizations=void 0;var o=i(pC()),s=pU();e.RuntimeOptimizations=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsRuntimeOptimizations(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsRuntimeOptimizations(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}records(e,t){let r=this.bb.__offset(this.bb_pos,4);return r?(t||new s.RuntimeOptimizationRecordContainerEntry).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}recordsLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}static startRuntimeOptimizations(e){e.startObject(1)}static addRecords(e,t){e.addFieldOffset(0,t,0)}static createRecordsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startRecordsVector(e,t){e.startVector(4,t,4)}static endRuntimeOptimizations(e){return e.endObject()}static createRuntimeOptimizations(t,r){return e.startRuntimeOptimizations(t),e.addRecords(t,r),e.endRuntimeOptimizations(t)}}}}),pG=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/tensor-data-type.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.TensorDataType=void 0,(r=t||(e.TensorDataType=t={}))[r.UNDEFINED=0]="UNDEFINED",r[r.FLOAT=1]="FLOAT",r[r.UINT8=2]="UINT8",r[r.INT8=3]="INT8",r[r.UINT16=4]="UINT16",r[r.INT16=5]="INT16",r[r.INT32=6]="INT32",r[r.INT64=7]="INT64",r[r.STRING=8]="STRING",r[r.BOOL=9]="BOOL",r[r.FLOAT16=10]="FLOAT16",r[r.DOUBLE=11]="DOUBLE",r[r.UINT32=12]="UINT32",r[r.UINT64=13]="UINT64",r[r.COMPLEX64=14]="COMPLEX64",r[r.COMPLEX128=15]="COMPLEX128",r[r.BFLOAT16=16]="BFLOAT16",r[r.FLOAT8E4M3FN=17]="FLOAT8E4M3FN",r[r.FLOAT8E4M3FNUZ=18]="FLOAT8E4M3FNUZ",r[r.FLOAT8E5M2=19]="FLOAT8E5M2",r[r.FLOAT8E5M2FNUZ=20]="FLOAT8E5M2FNUZ"}}),pH=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/tensor.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Tensor=void 0;var o=i(pC()),s=pG();e.Tensor=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsTensor(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsTensor(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}name(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}docString(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}dims(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.readInt64(this.bb.__vector(this.bb_pos+t)+8*e):BigInt(0)}dimsLength(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.__vector_len(this.bb_pos+e):0}dataType(){let e=this.bb.__offset(this.bb_pos,10);return e?this.bb.readInt32(this.bb_pos+e):s.TensorDataType.UNDEFINED}rawData(e){let t=this.bb.__offset(this.bb_pos,12);return t?this.bb.readUint8(this.bb.__vector(this.bb_pos+t)+e):0}rawDataLength(){let e=this.bb.__offset(this.bb_pos,12);return e?this.bb.__vector_len(this.bb_pos+e):0}rawDataArray(){let e=this.bb.__offset(this.bb_pos,12);return e?new Uint8Array(this.bb.bytes().buffer,this.bb.bytes().byteOffset+this.bb.__vector(this.bb_pos+e),this.bb.__vector_len(this.bb_pos+e)):null}stringData(e,t){let r=this.bb.__offset(this.bb_pos,14);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}stringDataLength(){let e=this.bb.__offset(this.bb_pos,14);return e?this.bb.__vector_len(this.bb_pos+e):0}externalDataOffset(){let e=this.bb.__offset(this.bb_pos,16);return e?this.bb.readInt64(this.bb_pos+e):BigInt("-1")}static startTensor(e){e.startObject(7)}static addName(e,t){e.addFieldOffset(0,t,0)}static addDocString(e,t){e.addFieldOffset(1,t,0)}static addDims(e,t){e.addFieldOffset(2,t,0)}static createDimsVector(e,t){e.startVector(8,t.length,8);for(let r=t.length-1;r>=0;r--)e.addInt64(t[r]);return e.endVector()}static startDimsVector(e,t){e.startVector(8,t,8)}static addDataType(e,t){e.addFieldInt32(3,t,s.TensorDataType.UNDEFINED)}static addRawData(e,t){e.addFieldOffset(4,t,0)}static createRawDataVector(e,t){e.startVector(1,t.length,1);for(let r=t.length-1;r>=0;r--)e.addInt8(t[r]);return e.endVector()}static startRawDataVector(e,t){e.startVector(1,t,1)}static addStringData(e,t){e.addFieldOffset(5,t,0)}static createStringDataVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startStringDataVector(e,t){e.startVector(4,t,4)}static addExternalDataOffset(e,t){e.addFieldInt64(6,t,BigInt("-1"))}static endTensor(e){return e.endObject()}static createTensor(t,r,n,i,o,s,a,u){return e.startTensor(t),e.addName(t,r),e.addDocString(t,n),e.addDims(t,i),e.addDataType(t,o),e.addRawData(t,s),e.addStringData(t,a),e.addExternalDataOffset(t,u),e.endTensor(t)}}}}),pW=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/sparse-tensor.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.SparseTensor=void 0;var o=i(pC()),s=pH();e.SparseTensor=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsSparseTensor(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsSparseTensor(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}values(e){let t=this.bb.__offset(this.bb_pos,4);return t?(e||new s.Tensor).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}indices(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new s.Tensor).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}dims(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.readInt64(this.bb.__vector(this.bb_pos+t)+8*e):BigInt(0)}dimsLength(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.__vector_len(this.bb_pos+e):0}static startSparseTensor(e){e.startObject(3)}static addValues(e,t){e.addFieldOffset(0,t,0)}static addIndices(e,t){e.addFieldOffset(1,t,0)}static addDims(e,t){e.addFieldOffset(2,t,0)}static createDimsVector(e,t){e.startVector(8,t.length,8);for(let r=t.length-1;r>=0;r--)e.addInt64(t[r]);return e.endVector()}static startDimsVector(e,t){e.startVector(8,t,8)}static endSparseTensor(e){return e.endObject()}}}}),pK=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/map-type.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.MapType=void 0;var o=i(pC()),s=pG(),a=p2();e.MapType=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsMapType(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsMapType(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}keyType(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readInt32(this.bb_pos+e):s.TensorDataType.UNDEFINED}valueType(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new a.TypeInfo).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startMapType(e){e.startObject(2)}static addKeyType(e,t){e.addFieldInt32(0,t,s.TensorDataType.UNDEFINED)}static addValueType(e,t){e.addFieldOffset(1,t,0)}static endMapType(e){return e.endObject()}}}}),pX=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/sequence-type.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.SequenceType=void 0;var o=i(pC()),s=p2();e.SequenceType=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsSequenceType(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsSequenceType(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}elemType(e){let t=this.bb.__offset(this.bb_pos,4);return t?(e||new s.TypeInfo).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startSequenceType(e){e.startObject(1)}static addElemType(e,t){e.addFieldOffset(0,t,0)}static endSequenceType(e){return e.endObject()}static createSequenceType(t,r){return e.startSequenceType(t),e.addElemType(t,r),e.endSequenceType(t)}}}}),pZ=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/dimension-value-type.js"(e){"use strict";var t,r;Object.defineProperty(e,"__esModule",{value:!0}),e.DimensionValueType=void 0,(r=t||(e.DimensionValueType=t={}))[r.UNKNOWN=0]="UNKNOWN",r[r.VALUE=1]="VALUE",r[r.PARAM=2]="PARAM"}}),pJ=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/dimension-value.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.DimensionValue=void 0;var o=i(pC()),s=pZ();e.DimensionValue=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDimensionValue(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDimensionValue(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}dimType(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readInt8(this.bb_pos+e):s.DimensionValueType.UNKNOWN}dimValue(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readInt64(this.bb_pos+e):BigInt("0")}dimParam(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.__string(this.bb_pos+t,e):null}static startDimensionValue(e){e.startObject(3)}static addDimType(e,t){e.addFieldInt8(0,t,s.DimensionValueType.UNKNOWN)}static addDimValue(e,t){e.addFieldInt64(1,t,BigInt("0"))}static addDimParam(e,t){e.addFieldOffset(2,t,0)}static endDimensionValue(e){return e.endObject()}static createDimensionValue(t,r,n,i){return e.startDimensionValue(t),e.addDimType(t,r),e.addDimValue(t,n),e.addDimParam(t,i),e.endDimensionValue(t)}}}}),pQ=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/dimension.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Dimension=void 0;var o=i(pC()),s=pJ();e.Dimension=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDimension(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDimension(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}value(e){let t=this.bb.__offset(this.bb_pos,4);return t?(e||new s.DimensionValue).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}denotation(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}static startDimension(e){e.startObject(2)}static addValue(e,t){e.addFieldOffset(0,t,0)}static addDenotation(e,t){e.addFieldOffset(1,t,0)}static endDimension(e){return e.endObject()}static createDimension(t,r,n){return e.startDimension(t),e.addValue(t,r),e.addDenotation(t,n),e.endDimension(t)}}}}),pY=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/shape.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Shape=void 0;var o=i(pC()),s=pQ();e.Shape=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsShape(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsShape(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}dim(e,t){let r=this.bb.__offset(this.bb_pos,4);return r?(t||new s.Dimension).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}dimLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}static startShape(e){e.startObject(1)}static addDim(e,t){e.addFieldOffset(0,t,0)}static createDimVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startDimVector(e,t){e.startVector(4,t,4)}static endShape(e){return e.endObject()}static createShape(t,r){return e.startShape(t),e.addDim(t,r),e.endShape(t)}}}}),p0=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/tensor-type-and-shape.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.TensorTypeAndShape=void 0;var o=i(pC()),s=pY(),a=pG();e.TensorTypeAndShape=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsTensorTypeAndShape(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsTensorTypeAndShape(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}elemType(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readInt32(this.bb_pos+e):a.TensorDataType.UNDEFINED}shape(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new s.Shape).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startTensorTypeAndShape(e){e.startObject(2)}static addElemType(e,t){e.addFieldInt32(0,t,a.TensorDataType.UNDEFINED)}static addShape(e,t){e.addFieldOffset(1,t,0)}static endTensorTypeAndShape(e){return e.endObject()}}}}),p1=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/type-info-value.js"(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.TypeInfoValue=void 0,e.unionToTypeInfoValue=function(e,t){switch(r[e]){case"NONE":default:return null;case"tensor_type":return t(new o.TensorTypeAndShape);case"sequence_type":return t(new i.SequenceType);case"map_type":return t(new n.MapType)}},e.unionListToTypeInfoValue=function(e,t,s){switch(r[e]){case"NONE":default:return null;case"tensor_type":return t(s,new o.TensorTypeAndShape);case"sequence_type":return t(s,new i.SequenceType);case"map_type":return t(s,new n.MapType)}};var t,r,n=pK(),i=pX(),o=p0();(t=r||(e.TypeInfoValue=r={}))[t.NONE=0]="NONE",t[t.tensor_type=1]="tensor_type",t[t.sequence_type=2]="sequence_type",t[t.map_type=3]="map_type"}}),p2=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/type-info.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.TypeInfo=void 0;var o=i(pC()),s=p1();e.TypeInfo=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsTypeInfo(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsTypeInfo(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}denotation(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}valueType(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readUint8(this.bb_pos+e):s.TypeInfoValue.NONE}value(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.__union(e,this.bb_pos+t):null}static startTypeInfo(e){e.startObject(3)}static addDenotation(e,t){e.addFieldOffset(0,t,0)}static addValueType(e,t){e.addFieldInt8(1,t,s.TypeInfoValue.NONE)}static addValue(e,t){e.addFieldOffset(2,t,0)}static endTypeInfo(e){return e.endObject()}static createTypeInfo(t,r,n,i){return e.startTypeInfo(t),e.addDenotation(t,r),e.addValueType(t,n),e.addValue(t,i),e.endTypeInfo(t)}}}}),p3=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/value-info.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.ValueInfo=void 0;var o=i(pC()),s=p2();e.ValueInfo=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsValueInfo(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsValueInfo(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}name(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}docString(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}type(e){let t=this.bb.__offset(this.bb_pos,8);return t?(e||new s.TypeInfo).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startValueInfo(e){e.startObject(3)}static addName(e,t){e.addFieldOffset(0,t,0)}static addDocString(e,t){e.addFieldOffset(1,t,0)}static addType(e,t){e.addFieldOffset(2,t,0)}static endValueInfo(e){return e.endObject()}}}}),p4=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/graph.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Graph=void 0;var o=i(pC()),s=pB(),a=pF(),u=pq(),l=pW(),d=pH(),p=p3();e.Graph=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsGraph(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsGraph(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}initializers(e,t){let r=this.bb.__offset(this.bb_pos,4);return r?(t||new d.Tensor).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}initializersLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}nodeArgs(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new p.ValueInfo).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}nodeArgsLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}nodes(e,t){let r=this.bb.__offset(this.bb_pos,8);return r?(t||new s.Node).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}nodesLength(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.__vector_len(this.bb_pos+e):0}maxNodeIndex(){let e=this.bb.__offset(this.bb_pos,10);return e?this.bb.readUint32(this.bb_pos+e):0}nodeEdges(e,t){let r=this.bb.__offset(this.bb_pos,12);return r?(t||new a.NodeEdge).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}nodeEdgesLength(){let e=this.bb.__offset(this.bb_pos,12);return e?this.bb.__vector_len(this.bb_pos+e):0}inputs(e,t){let r=this.bb.__offset(this.bb_pos,14);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}inputsLength(){let e=this.bb.__offset(this.bb_pos,14);return e?this.bb.__vector_len(this.bb_pos+e):0}outputs(e,t){let r=this.bb.__offset(this.bb_pos,16);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}outputsLength(){let e=this.bb.__offset(this.bb_pos,16);return e?this.bb.__vector_len(this.bb_pos+e):0}sparseInitializers(e,t){let r=this.bb.__offset(this.bb_pos,18);return r?(t||new l.SparseTensor).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}sparseInitializersLength(){let e=this.bb.__offset(this.bb_pos,18);return e?this.bb.__vector_len(this.bb_pos+e):0}runtimeOptimizations(e){let t=this.bb.__offset(this.bb_pos,20);return t?(e||new u.RuntimeOptimizations).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startGraph(e){e.startObject(9)}static addInitializers(e,t){e.addFieldOffset(0,t,0)}static createInitializersVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startInitializersVector(e,t){e.startVector(4,t,4)}static addNodeArgs(e,t){e.addFieldOffset(1,t,0)}static createNodeArgsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startNodeArgsVector(e,t){e.startVector(4,t,4)}static addNodes(e,t){e.addFieldOffset(2,t,0)}static createNodesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startNodesVector(e,t){e.startVector(4,t,4)}static addMaxNodeIndex(e,t){e.addFieldInt32(3,t,0)}static addNodeEdges(e,t){e.addFieldOffset(4,t,0)}static createNodeEdgesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startNodeEdgesVector(e,t){e.startVector(4,t,4)}static addInputs(e,t){e.addFieldOffset(5,t,0)}static createInputsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startInputsVector(e,t){e.startVector(4,t,4)}static addOutputs(e,t){e.addFieldOffset(6,t,0)}static createOutputsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startOutputsVector(e,t){e.startVector(4,t,4)}static addSparseInitializers(e,t){e.addFieldOffset(7,t,0)}static createSparseInitializersVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startSparseInitializersVector(e,t){e.startVector(4,t,4)}static addRuntimeOptimizations(e,t){e.addFieldOffset(8,t,0)}static endGraph(e){return e.endObject()}}}}),p6=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/attribute.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Attribute=void 0;var o=i(pC()),s=pj(),a=p4(),u=pH();e.Attribute=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsAttribute(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsAttribute(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}name(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}docString(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}type(){let e=this.bb.__offset(this.bb_pos,8);return e?this.bb.readInt32(this.bb_pos+e):s.AttributeType.UNDEFINED}f(){let e=this.bb.__offset(this.bb_pos,10);return e?this.bb.readFloat32(this.bb_pos+e):0}i(){let e=this.bb.__offset(this.bb_pos,12);return e?this.bb.readInt64(this.bb_pos+e):BigInt("0")}s(e){let t=this.bb.__offset(this.bb_pos,14);return t?this.bb.__string(this.bb_pos+t,e):null}t(e){let t=this.bb.__offset(this.bb_pos,16);return t?(e||new u.Tensor).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}g(e){let t=this.bb.__offset(this.bb_pos,18);return t?(e||new a.Graph).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}floats(e){let t=this.bb.__offset(this.bb_pos,20);return t?this.bb.readFloat32(this.bb.__vector(this.bb_pos+t)+4*e):0}floatsLength(){let e=this.bb.__offset(this.bb_pos,20);return e?this.bb.__vector_len(this.bb_pos+e):0}floatsArray(){let e=this.bb.__offset(this.bb_pos,20);return e?new Float32Array(this.bb.bytes().buffer,this.bb.bytes().byteOffset+this.bb.__vector(this.bb_pos+e),this.bb.__vector_len(this.bb_pos+e)):null}ints(e){let t=this.bb.__offset(this.bb_pos,22);return t?this.bb.readInt64(this.bb.__vector(this.bb_pos+t)+8*e):BigInt(0)}intsLength(){let e=this.bb.__offset(this.bb_pos,22);return e?this.bb.__vector_len(this.bb_pos+e):0}strings(e,t){let r=this.bb.__offset(this.bb_pos,24);return r?this.bb.__string(this.bb.__vector(this.bb_pos+r)+4*e,t):null}stringsLength(){let e=this.bb.__offset(this.bb_pos,24);return e?this.bb.__vector_len(this.bb_pos+e):0}tensors(e,t){let r=this.bb.__offset(this.bb_pos,26);return r?(t||new u.Tensor).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}tensorsLength(){let e=this.bb.__offset(this.bb_pos,26);return e?this.bb.__vector_len(this.bb_pos+e):0}graphs(e,t){let r=this.bb.__offset(this.bb_pos,28);return r?(t||new a.Graph).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}graphsLength(){let e=this.bb.__offset(this.bb_pos,28);return e?this.bb.__vector_len(this.bb_pos+e):0}static startAttribute(e){e.startObject(13)}static addName(e,t){e.addFieldOffset(0,t,0)}static addDocString(e,t){e.addFieldOffset(1,t,0)}static addType(e,t){e.addFieldInt32(2,t,s.AttributeType.UNDEFINED)}static addF(e,t){e.addFieldFloat32(3,t,0)}static addI(e,t){e.addFieldInt64(4,t,BigInt("0"))}static addS(e,t){e.addFieldOffset(5,t,0)}static addT(e,t){e.addFieldOffset(6,t,0)}static addG(e,t){e.addFieldOffset(7,t,0)}static addFloats(e,t){e.addFieldOffset(8,t,0)}static createFloatsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addFloat32(t[r]);return e.endVector()}static startFloatsVector(e,t){e.startVector(4,t,4)}static addInts(e,t){e.addFieldOffset(9,t,0)}static createIntsVector(e,t){e.startVector(8,t.length,8);for(let r=t.length-1;r>=0;r--)e.addInt64(t[r]);return e.endVector()}static startIntsVector(e,t){e.startVector(8,t,8)}static addStrings(e,t){e.addFieldOffset(10,t,0)}static createStringsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startStringsVector(e,t){e.startVector(4,t,4)}static addTensors(e,t){e.addFieldOffset(11,t,0)}static createTensorsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startTensorsVector(e,t){e.startVector(4,t,4)}static addGraphs(e,t){e.addFieldOffset(12,t,0)}static createGraphsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startGraphsVector(e,t){e.startVector(4,t,4)}static endAttribute(e){return e.endObject()}}}}),p8=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/deprecated-kernel-create-infos.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.DeprecatedKernelCreateInfos=void 0;var o=i(pC());e.DeprecatedKernelCreateInfos=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDeprecatedKernelCreateInfos(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDeprecatedKernelCreateInfos(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}nodeIndices(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.readUint32(this.bb.__vector(this.bb_pos+t)+4*e):0}nodeIndicesLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}nodeIndicesArray(){let e=this.bb.__offset(this.bb_pos,4);return e?new Uint32Array(this.bb.bytes().buffer,this.bb.bytes().byteOffset+this.bb.__vector(this.bb_pos+e),this.bb.__vector_len(this.bb_pos+e)):null}kernelDefHashes(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.readUint64(this.bb.__vector(this.bb_pos+t)+8*e):BigInt(0)}kernelDefHashesLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}static startDeprecatedKernelCreateInfos(e){e.startObject(2)}static addNodeIndices(e,t){e.addFieldOffset(0,t,0)}static createNodeIndicesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addInt32(t[r]);return e.endVector()}static startNodeIndicesVector(e,t){e.startVector(4,t,4)}static addKernelDefHashes(e,t){e.addFieldOffset(1,t,0)}static createKernelDefHashesVector(e,t){e.startVector(8,t.length,8);for(let r=t.length-1;r>=0;r--)e.addInt64(t[r]);return e.endVector()}static startKernelDefHashesVector(e,t){e.startVector(8,t,8)}static endDeprecatedKernelCreateInfos(e){return e.endObject()}static createDeprecatedKernelCreateInfos(t,r,n){return e.startDeprecatedKernelCreateInfos(t),e.addNodeIndices(t,r),e.addKernelDefHashes(t,n),e.endDeprecatedKernelCreateInfos(t)}}}}),p5=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/deprecated-node-index-and-kernel-def-hash.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.DeprecatedNodeIndexAndKernelDefHash=void 0;var o=i(pC());e.DeprecatedNodeIndexAndKernelDefHash=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDeprecatedNodeIndexAndKernelDefHash(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDeprecatedNodeIndexAndKernelDefHash(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}nodeIndex(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readUint32(this.bb_pos+e):0}kernelDefHash(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readUint64(this.bb_pos+e):BigInt("0")}static startDeprecatedNodeIndexAndKernelDefHash(e){e.startObject(2)}static addNodeIndex(e,t){e.addFieldInt32(0,t,0)}static addKernelDefHash(e,t){e.addFieldInt64(1,t,BigInt("0"))}static endDeprecatedNodeIndexAndKernelDefHash(e){return e.endObject()}static createDeprecatedNodeIndexAndKernelDefHash(t,r,n){return e.startDeprecatedNodeIndexAndKernelDefHash(t),e.addNodeIndex(t,r),e.addKernelDefHash(t,n),e.endDeprecatedNodeIndexAndKernelDefHash(t)}}}}),p7=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/deprecated-sub-graph-session-state.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.DeprecatedSubGraphSessionState=void 0;var o=i(pC()),s=p9();e.DeprecatedSubGraphSessionState=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDeprecatedSubGraphSessionState(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDeprecatedSubGraphSessionState(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}graphId(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}sessionState(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new s.DeprecatedSessionState).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startDeprecatedSubGraphSessionState(e){e.startObject(2)}static addGraphId(e,t){e.addFieldOffset(0,t,0)}static addSessionState(e,t){e.addFieldOffset(1,t,0)}static endDeprecatedSubGraphSessionState(e){let t=e.endObject();return e.requiredField(t,4),t}}}}),p9=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/deprecated-session-state.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.DeprecatedSessionState=void 0;var o=i(pC()),s=p8(),a=p7();e.DeprecatedSessionState=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsDeprecatedSessionState(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsDeprecatedSessionState(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}kernels(e){let t=this.bb.__offset(this.bb_pos,4);return t?(e||new s.DeprecatedKernelCreateInfos).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}subGraphSessionStates(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new a.DeprecatedSubGraphSessionState).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}subGraphSessionStatesLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}static startDeprecatedSessionState(e){e.startObject(2)}static addKernels(e,t){e.addFieldOffset(0,t,0)}static addSubGraphSessionStates(e,t){e.addFieldOffset(1,t,0)}static createSubGraphSessionStatesVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startSubGraphSessionStatesVector(e,t){e.startVector(4,t,4)}static endDeprecatedSessionState(e){return e.endObject()}static createDeprecatedSessionState(t,r,n){return e.startDeprecatedSessionState(t),e.addKernels(t,r),e.addSubGraphSessionStates(t,n),e.endDeprecatedSessionState(t)}}}}),ce=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/kernel-type-str-args-entry.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.KernelTypeStrArgsEntry=void 0;var o=i(pC()),s=pN();e.KernelTypeStrArgsEntry=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsKernelTypeStrArgsEntry(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsKernelTypeStrArgsEntry(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}kernelTypeStr(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}args(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new s.ArgTypeAndIndex).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}argsLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}static startKernelTypeStrArgsEntry(e){e.startObject(2)}static addKernelTypeStr(e,t){e.addFieldOffset(0,t,0)}static addArgs(e,t){e.addFieldOffset(1,t,0)}static createArgsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startArgsVector(e,t){e.startVector(4,t,4)}static endKernelTypeStrArgsEntry(e){let t=e.endObject();return e.requiredField(t,4),t}static createKernelTypeStrArgsEntry(t,r,n){return e.startKernelTypeStrArgsEntry(t),e.addKernelTypeStr(t,r),e.addArgs(t,n),e.endKernelTypeStrArgsEntry(t)}}}}),ct=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/op-id-kernel-type-str-args-entry.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.OpIdKernelTypeStrArgsEntry=void 0;var o=i(pC()),s=ce();e.OpIdKernelTypeStrArgsEntry=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsOpIdKernelTypeStrArgsEntry(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsOpIdKernelTypeStrArgsEntry(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}opId(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}kernelTypeStrArgs(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new s.KernelTypeStrArgsEntry).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}kernelTypeStrArgsLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}static startOpIdKernelTypeStrArgsEntry(e){e.startObject(2)}static addOpId(e,t){e.addFieldOffset(0,t,0)}static addKernelTypeStrArgs(e,t){e.addFieldOffset(1,t,0)}static createKernelTypeStrArgsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startKernelTypeStrArgsVector(e,t){e.startVector(4,t,4)}static endOpIdKernelTypeStrArgsEntry(e){let t=e.endObject();return e.requiredField(t,4),t}static createOpIdKernelTypeStrArgsEntry(t,r,n){return e.startOpIdKernelTypeStrArgsEntry(t),e.addOpId(t,r),e.addKernelTypeStrArgs(t,n),e.endOpIdKernelTypeStrArgsEntry(t)}}}}),cr=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/kernel-type-str-resolver.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.KernelTypeStrResolver=void 0;var o=i(pC()),s=ct();e.KernelTypeStrResolver=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsKernelTypeStrResolver(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsKernelTypeStrResolver(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}opKernelTypeStrArgs(e,t){let r=this.bb.__offset(this.bb_pos,4);return r?(t||new s.OpIdKernelTypeStrArgsEntry).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}opKernelTypeStrArgsLength(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.__vector_len(this.bb_pos+e):0}static startKernelTypeStrResolver(e){e.startObject(1)}static addOpKernelTypeStrArgs(e,t){e.addFieldOffset(0,t,0)}static createOpKernelTypeStrArgsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startOpKernelTypeStrArgsVector(e,t){e.startVector(4,t,4)}static endKernelTypeStrResolver(e){return e.endObject()}static createKernelTypeStrResolver(t,r){return e.startKernelTypeStrResolver(t),e.addOpKernelTypeStrArgs(t,r),e.endKernelTypeStrResolver(t)}}}}),cn=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/operator-set-id.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.OperatorSetId=void 0;var o=i(pC());e.OperatorSetId=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsOperatorSetId(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsOperatorSetId(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}domain(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}version(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.readInt64(this.bb_pos+e):BigInt("0")}static startOperatorSetId(e){e.startObject(2)}static addDomain(e,t){e.addFieldOffset(0,t,0)}static addVersion(e,t){e.addFieldInt64(1,t,BigInt("0"))}static endOperatorSetId(e){return e.endObject()}static createOperatorSetId(t,r,n){return e.startOperatorSetId(t),e.addDomain(t,r),e.addVersion(t,n),e.endOperatorSetId(t)}}}}),ci=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/string-string-entry.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.StringStringEntry=void 0;var o=i(pC());e.StringStringEntry=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsStringStringEntry(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsStringStringEntry(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}key(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}value(e){let t=this.bb.__offset(this.bb_pos,6);return t?this.bb.__string(this.bb_pos+t,e):null}static startStringStringEntry(e){e.startObject(2)}static addKey(e,t){e.addFieldOffset(0,t,0)}static addValue(e,t){e.addFieldOffset(1,t,0)}static endStringStringEntry(e){return e.endObject()}static createStringStringEntry(t,r,n){return e.startStringStringEntry(t),e.addKey(t,r),e.addValue(t,n),e.endStringStringEntry(t)}}}}),co=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/model.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.Model=void 0;var o=i(pC()),s=p4(),a=cn(),u=ci();e.Model=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsModel(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsModel(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}irVersion(){let e=this.bb.__offset(this.bb_pos,4);return e?this.bb.readInt64(this.bb_pos+e):BigInt("0")}opsetImport(e,t){let r=this.bb.__offset(this.bb_pos,6);return r?(t||new a.OperatorSetId).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}opsetImportLength(){let e=this.bb.__offset(this.bb_pos,6);return e?this.bb.__vector_len(this.bb_pos+e):0}producerName(e){let t=this.bb.__offset(this.bb_pos,8);return t?this.bb.__string(this.bb_pos+t,e):null}producerVersion(e){let t=this.bb.__offset(this.bb_pos,10);return t?this.bb.__string(this.bb_pos+t,e):null}domain(e){let t=this.bb.__offset(this.bb_pos,12);return t?this.bb.__string(this.bb_pos+t,e):null}modelVersion(){let e=this.bb.__offset(this.bb_pos,14);return e?this.bb.readInt64(this.bb_pos+e):BigInt("0")}docString(e){let t=this.bb.__offset(this.bb_pos,16);return t?this.bb.__string(this.bb_pos+t,e):null}graph(e){let t=this.bb.__offset(this.bb_pos,18);return t?(e||new s.Graph).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}graphDocString(e){let t=this.bb.__offset(this.bb_pos,20);return t?this.bb.__string(this.bb_pos+t,e):null}metadataProps(e,t){let r=this.bb.__offset(this.bb_pos,22);return r?(t||new u.StringStringEntry).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos+r)+4*e),this.bb):null}metadataPropsLength(){let e=this.bb.__offset(this.bb_pos,22);return e?this.bb.__vector_len(this.bb_pos+e):0}static startModel(e){e.startObject(10)}static addIrVersion(e,t){e.addFieldInt64(0,t,BigInt("0"))}static addOpsetImport(e,t){e.addFieldOffset(1,t,0)}static createOpsetImportVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startOpsetImportVector(e,t){e.startVector(4,t,4)}static addProducerName(e,t){e.addFieldOffset(2,t,0)}static addProducerVersion(e,t){e.addFieldOffset(3,t,0)}static addDomain(e,t){e.addFieldOffset(4,t,0)}static addModelVersion(e,t){e.addFieldInt64(5,t,BigInt("0"))}static addDocString(e,t){e.addFieldOffset(6,t,0)}static addGraph(e,t){e.addFieldOffset(7,t,0)}static addGraphDocString(e,t){e.addFieldOffset(8,t,0)}static addMetadataProps(e,t){e.addFieldOffset(9,t,0)}static createMetadataPropsVector(e,t){e.startVector(4,t.length,4);for(let r=t.length-1;r>=0;r--)e.addOffset(t[r]);return e.endVector()}static startMetadataPropsVector(e,t){e.startVector(4,t,4)}static endModel(e){return e.endObject()}}}}),cs=dY({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs/inference-session.js"(e){"use strict";var t,r=e&&e.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r);var i=Object.getOwnPropertyDescriptor(t,r);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]}),n=e&&e.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),i=e&&e.__importStar||(t=function(e){return(t=Object.getOwnPropertyNames||function(e){var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(t[t.length]=r);return t})(e)},function(e){if(e&&e.__esModule)return e;var i={};if(null!=e)for(var o=t(e),s=0;s<o.length;s++)"default"!==o[s]&&r(i,e,o[s]);return n(i,e),i});Object.defineProperty(e,"__esModule",{value:!0}),e.InferenceSession=void 0;var o=i(pC()),s=cr(),a=co();e.InferenceSession=class e{constructor(){this.bb=null,this.bb_pos=0}__init(e,t){return this.bb_pos=e,this.bb=t,this}static getRootAsInferenceSession(t,r){return(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static getSizePrefixedRootAsInferenceSession(t,r){return t.setPosition(t.position()+o.SIZE_PREFIX_LENGTH),(r||new e).__init(t.readInt32(t.position())+t.position(),t)}static bufferHasIdentifier(e){return e.__has_identifier("ORTM")}ortVersion(e){let t=this.bb.__offset(this.bb_pos,4);return t?this.bb.__string(this.bb_pos+t,e):null}model(e){let t=this.bb.__offset(this.bb_pos,6);return t?(e||new a.Model).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}kernelTypeStrResolver(e){let t=this.bb.__offset(this.bb_pos,10);return t?(e||new s.KernelTypeStrResolver).__init(this.bb.__indirect(this.bb_pos+t),this.bb):null}static startInferenceSession(e){e.startObject(4)}static addOrtVersion(e,t){e.addFieldOffset(0,t,0)}static addModel(e,t){e.addFieldOffset(1,t,0)}static addKernelTypeStrResolver(e,t){e.addFieldOffset(3,t,0)}static endInferenceSession(e){return e.endObject()}static finishInferenceSessionBuffer(e,t){e.finish(t,"ORTM")}static finishSizePrefixedInferenceSessionBuffer(e,t){e.finish(t,"ORTM",!0)}}}}),ca=dQ({"web/lib/onnxjs/ort-schema/flatbuffers/onnxruntime/fbs.ts"(){"use strict";d2(pE()),d2(pN()),el=d2(p6()),ed=d2(pj()),d2(p8()),d2(p5()),d2(p9()),d2(p7()),d2(pQ()),d2(pJ()),d2(pZ()),d2(pM()),ep=d2(p4()),ec=d2(cs()),d2(ce()),d2(cr()),d2(pK()),d2(co()),eh=d2(pB()),d2(pF()),d2(pR()),d2(pL()),d2(ct()),d2(cn()),d2(pV()),d2(pU()),d2(pq()),d2(pX()),d2(pY()),d2(pW()),d2(ci()),d2(pH()),ef=d2(pG()),eg=d2(p0()),d2(p2()),em=d2(p1()),d2(p3())}}),cu=dQ({"web/lib/onnxjs/ort-schema/flatbuffers/ort-generated.ts"(){"use strict";ca()}}),cl=dY({"web/node_modules/@protobufjs/aspromise/index.js"(e,t){"use strict";t.exports=function(e,t){for(var r=Array(arguments.length-1),n=0,i=2,o=!0;i<arguments.length;)r[n++]=arguments[i++];return new Promise(function(i,s){r[n]=function(e){if(o)if(o=!1,e)s(e);else{for(var t=Array(arguments.length-1),r=0;r<t.length;)t[r++]=arguments[r];i.apply(null,t)}};try{e.apply(t||null,r)}catch(e){o&&(o=!1,s(e))}})}}}),cd=dY({"web/node_modules/@protobufjs/base64/index.js"(e){"use strict";e.length=function(e){var t=e.length;if(!t)return 0;for(var r=0;--t%4>1&&"="===e.charAt(t);)++r;return Math.ceil(3*e.length)/4-r};var t,r=Array(64),n=Array(123);for(t=0;t<64;)n[r[t]=t<26?t+65:t<52?t+71:t<62?t-4:t-59|43]=t++;e.encode=function(e,t,n){for(var i,o=null,s=[],a=0,u=0;t<n;){var l=e[t++];switch(u){case 0:s[a++]=r[l>>2],i=(3&l)<<4,u=1;break;case 1:s[a++]=r[i|l>>4],i=(15&l)<<2,u=2;break;case 2:s[a++]=r[i|l>>6],s[a++]=r[63&l],u=0}a>8191&&((o||(o=[])).push(String.fromCharCode.apply(String,s)),a=0)}return(u&&(s[a++]=r[i],s[a++]=61,1===u&&(s[a++]=61)),o)?(a&&o.push(String.fromCharCode.apply(String,s.slice(0,a))),o.join("")):String.fromCharCode.apply(String,s.slice(0,a))};var i="invalid encoding";e.decode=function(e,t,r){for(var o,s=r,a=0,u=0;u<e.length;){var l=e.charCodeAt(u++);if(61===l&&a>1)break;if(void 0===(l=n[l]))throw Error(i);switch(a){case 0:o=l,a=1;break;case 1:t[r++]=o<<2|(48&l)>>4,o=l,a=2;break;case 2:t[r++]=(15&o)<<4|(60&l)>>2,o=l,a=3;break;case 3:t[r++]=(3&o)<<6|l,a=0}}if(1===a)throw Error(i);return r-s},e.test=function(e){return/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e)}}}),cp=dY({"web/node_modules/@protobufjs/eventemitter/index.js"(e,t){"use strict";function r(){this._listeners=Object.create(null)}t.exports=r,r.prototype.on=function(e,t,r){return(this._listeners[e]||(this._listeners[e]=[])).push({fn:t,ctx:r||this}),this},r.prototype.off=function(e,t){if(void 0===e)this._listeners=Object.create(null);else if(void 0===t)this._listeners[e]=[];else{var r=this._listeners[e];if(!r)return this;for(var n=0;n<r.length;)r[n].fn===t?r.splice(n,1):++n}return this},r.prototype.emit=function(e){var t=this._listeners[e];if(t){for(var r=[],n=1;n<arguments.length;)r.push(arguments[n++]);for(n=0;n<t.length;)t[n].fn.apply(t[n++].ctx,r)}return this}}}),cc=dY({"web/node_modules/@protobufjs/float/index.js"(e,t){"use strict";function r(e){if("u">typeof Float32Array)!function(){var t=new Float32Array([-0]),r=new Uint8Array(t.buffer),n=128===r[3];function i(e,n,i){t[0]=e,n[i]=r[0],n[i+1]=r[1],n[i+2]=r[2],n[i+3]=r[3]}function o(e,n,i){t[0]=e,n[i]=r[3],n[i+1]=r[2],n[i+2]=r[1],n[i+3]=r[0]}function s(e,n){return r[0]=e[n],r[1]=e[n+1],r[2]=e[n+2],r[3]=e[n+3],t[0]}function a(e,n){return r[3]=e[n],r[2]=e[n+1],r[1]=e[n+2],r[0]=e[n+3],t[0]}e.writeFloatLE=n?i:o,e.writeFloatBE=n?o:i,e.readFloatLE=n?s:a,e.readFloatBE=n?a:s}();else{function t(e,t,r,n){var i=+(t<0);if(i&&(t=-t),0===t)e(1/t>0?0:0x80000000,r,n);else if(isNaN(t))e(0x7fc00000,r,n);else if(t>34028234663852886e22)e((i<<31|0x7f800000)>>>0,r,n);else if(t<11754943508222875e-54)e((i<<31|Math.round(t/1401298464324817e-60))>>>0,r,n);else{var o=Math.floor(Math.log(t)/Math.LN2),s=8388607&Math.round(t*Math.pow(2,-o)*8388608);e((i<<31|o+127<<23|s)>>>0,r,n)}}function r(e,t,r){var n=e(t,r),i=(n>>31)*2+1,o=n>>>23&255,s=8388607&n;return 255===o?s?0/0:1/0*i:0===o?1401298464324817e-60*i*s:i*Math.pow(2,o-150)*(s+8388608)}e.writeFloatLE=t.bind(null,n),e.writeFloatBE=t.bind(null,i),e.readFloatLE=r.bind(null,o),e.readFloatBE=r.bind(null,s)}if("u">typeof Float64Array)!function(){var t=new Float64Array([-0]),r=new Uint8Array(t.buffer),n=128===r[7];function i(e,n,i){t[0]=e,n[i]=r[0],n[i+1]=r[1],n[i+2]=r[2],n[i+3]=r[3],n[i+4]=r[4],n[i+5]=r[5],n[i+6]=r[6],n[i+7]=r[7]}function o(e,n,i){t[0]=e,n[i]=r[7],n[i+1]=r[6],n[i+2]=r[5],n[i+3]=r[4],n[i+4]=r[3],n[i+5]=r[2],n[i+6]=r[1],n[i+7]=r[0]}function s(e,n){return r[0]=e[n],r[1]=e[n+1],r[2]=e[n+2],r[3]=e[n+3],r[4]=e[n+4],r[5]=e[n+5],r[6]=e[n+6],r[7]=e[n+7],t[0]}function a(e,n){return r[7]=e[n],r[6]=e[n+1],r[5]=e[n+2],r[4]=e[n+3],r[3]=e[n+4],r[2]=e[n+5],r[1]=e[n+6],r[0]=e[n+7],t[0]}e.writeDoubleLE=n?i:o,e.writeDoubleBE=n?o:i,e.readDoubleLE=n?s:a,e.readDoubleBE=n?a:s}();else{function a(e,t,r,n,i,o){var s,a=+(n<0);if(a&&(n=-n),0===n)e(0,i,o+t),e(1/n>0?0:0x80000000,i,o+r);else if(isNaN(n))e(0,i,o+t),e(0x7ff80000,i,o+r);else if(n>17976931348623157e292)e(0,i,o+t),e((a<<31|0x7ff00000)>>>0,i,o+r);else if(n<22250738585072014e-324)e((s=n/5e-324)>>>0,i,o+t),e((a<<31|s/0x100000000)>>>0,i,o+r);else{var u=Math.floor(Math.log(n)/Math.LN2);1024===u&&(u=1023),e(0x10000000000000*(s=n*Math.pow(2,-u))>>>0,i,o+t),e((a<<31|u+1023<<20|1048576*s&1048575)>>>0,i,o+r)}}function u(e,t,r,n,i){var o=e(n,i+t),s=e(n,i+r),a=(s>>31)*2+1,u=s>>>20&2047,l=0x100000000*(1048575&s)+o;return 2047===u?l?0/0:1/0*a:0===u?5e-324*a*l:a*Math.pow(2,u-1075)*(l+0x10000000000000)}e.writeDoubleLE=a.bind(null,n,0,4),e.writeDoubleBE=a.bind(null,i,4,0),e.readDoubleLE=u.bind(null,o,0,4),e.readDoubleBE=u.bind(null,s,4,0)}return e}function n(e,t,r){t[r]=255&e,t[r+1]=e>>>8&255,t[r+2]=e>>>16&255,t[r+3]=e>>>24}function i(e,t,r){t[r]=e>>>24,t[r+1]=e>>>16&255,t[r+2]=e>>>8&255,t[r+3]=255&e}function o(e,t){return(e[t]|e[t+1]<<8|e[t+2]<<16|e[t+3]<<24)>>>0}function s(e,t){return(e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3])>>>0}t.exports=r(r)}}),ch=dY({"web/node_modules/@protobufjs/inquire/index.js"(e,t){"use strict";t.exports=function(e){try{if("function"!=typeof dJ)return null;var t=dJ(e);if(t&&(t.length||Object.keys(t).length))return t;return null}catch(e){return null}}}}),cf=dY({"web/node_modules/@protobufjs/utf8/index.js"(e){"use strict";e.length=function(e){for(var t=0,r=0,n=0;n<e.length;++n)(r=e.charCodeAt(n))<128?t+=1:r<2048?t+=2:(64512&r)==55296&&(64512&e.charCodeAt(n+1))==56320?(++n,t+=4):t+=3;return t},e.read=function(e,t,r){if(r-t<1)return"";for(var n="",i=t;i<r;){var o=e[i++];if(o<=127)n+=String.fromCharCode(o);else if(o>=192&&o<224){var s=(31&o)<<6|63&e[i++];n+=s>=128?String.fromCharCode(s):"�"}else if(o>=224&&o<240){var a=(15&o)<<12|(63&e[i++])<<6|63&e[i++];n+=a>=2048?String.fromCharCode(a):"�"}else if(o>=240){var u=(7&o)<<18|(63&e[i++])<<12|(63&e[i++])<<6|63&e[i++];u<65536||u>1114111?n+="�":(u-=65536,n+=String.fromCharCode(55296+(u>>10)),n+=String.fromCharCode(56320+(1023&u)))}}return n},e.write=function(e,t,r){for(var n,i,o=r,s=0;s<e.length;++s)(n=e.charCodeAt(s))<128?t[r++]=n:(n<2048?t[r++]=n>>6|192:((64512&n)==55296&&(64512&(i=e.charCodeAt(s+1)))==56320?(n=65536+((1023&n)<<10)+(1023&i),++s,t[r++]=n>>18|240,t[r++]=n>>12&63|128):t[r++]=n>>12|224,t[r++]=n>>6&63|128),t[r++]=63&n|128);return r-o}}}),cg=dY({"web/node_modules/@protobufjs/pool/index.js"(e,t){"use strict";t.exports=function(e,t,r){var n=r||8192,i=n>>>1,o=null,s=n;return function(r){if(r<1||r>i)return e(r);s+r>n&&(o=e(n),s=0);var a=t.call(o,s,s+=r);return 7&s&&(s=(7|s)+1),a}}}}),cm=dY({"web/node_modules/protobufjs/src/util/longbits.js"(e,t){"use strict";t.exports=n;var r=cy();function n(e,t){this.lo=e>>>0,this.hi=t>>>0}var i=n.zero=new n(0,0);i.toNumber=function(){return 0},i.zzEncode=i.zzDecode=function(){return this},i.length=function(){return 1};var o=n.zeroHash="\0\0\0\0\0\0\0\0";n.fromNumber=function(e){if(0===e)return i;var t=e<0;t&&(e=-e);var r=e>>>0,o=(e-r)/0x100000000>>>0;return t&&(o=~o>>>0,r=~r>>>0,++r>0xffffffff&&(r=0,++o>0xffffffff&&(o=0))),new n(r,o)},n.from=function(e){if("number"==typeof e)return n.fromNumber(e);if(r.isString(e))if(!r.Long)return n.fromNumber(parseInt(e,10));else e=r.Long.fromString(e);return e.low||e.high?new n(e.low>>>0,e.high>>>0):i},n.prototype.toNumber=function(e){if(!e&&this.hi>>>31){var t=~this.lo+1>>>0,r=~this.hi>>>0;return t||(r=r+1>>>0),-(t+0x100000000*r)}return this.lo+0x100000000*this.hi},n.prototype.toLong=function(e){return r.Long?new r.Long(0|this.lo,0|this.hi,!!e):{low:0|this.lo,high:0|this.hi,unsigned:!!e}};var s=String.prototype.charCodeAt;n.fromHash=function(e){return e===o?i:new n((s.call(e,0)|s.call(e,1)<<8|s.call(e,2)<<16|s.call(e,3)<<24)>>>0,(s.call(e,4)|s.call(e,5)<<8|s.call(e,6)<<16|s.call(e,7)<<24)>>>0)},n.prototype.toHash=function(){return String.fromCharCode(255&this.lo,this.lo>>>8&255,this.lo>>>16&255,this.lo>>>24,255&this.hi,this.hi>>>8&255,this.hi>>>16&255,this.hi>>>24)},n.prototype.zzEncode=function(){var e=this.hi>>31;return this.hi=((this.hi<<1|this.lo>>>31)^e)>>>0,this.lo=(this.lo<<1^e)>>>0,this},n.prototype.zzDecode=function(){var e=-(1&this.lo);return this.lo=((this.lo>>>1|this.hi<<31)^e)>>>0,this.hi=(this.hi>>>1^e)>>>0,this},n.prototype.length=function(){var e=this.lo,t=(this.lo>>>28|this.hi<<4)>>>0,r=this.hi>>>24;return 0===r?0===t?e<16384?e<128?1:2:e<2097152?3:4:t<16384?t<128?5:6:t<2097152?7:8:r<128?9:10}}}),cb=dY({"web/node_modules/long/umd/index.js"(e,t){!function(r,n){function i(e){return e.default||e}if("function"==typeof define&&define.amd)define([],function(){var e={};return n(e),i(e)});else if("object"==typeof e)n(e),"object"==typeof t&&(t.exports=i(e));else{var o;n(o={}),r.Long=i(o)}}("u">typeof globalThis?globalThis:"u">typeof self?self:e,function(e){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var t=null;try{t=new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0,97,115,109,1,0,0,0,1,13,2,96,0,1,127,96,4,127,127,127,127,1,127,3,7,6,0,1,1,1,1,1,6,6,1,127,1,65,0,11,7,50,6,3,109,117,108,0,1,5,100,105,118,95,115,0,2,5,100,105,118,95,117,0,3,5,114,101,109,95,115,0,4,5,114,101,109,95,117,0,5,8,103,101,116,95,104,105,103,104,0,0,10,191,1,6,4,0,35,0,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,126,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,127,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,128,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,129,34,4,66,32,135,167,36,0,32,4,167,11,36,1,1,126,32,0,173,32,1,173,66,32,134,132,32,2,173,32,3,173,66,32,134,132,130,34,4,66,32,135,167,36,0,32,4,167,11])),{}).exports}catch{}function r(e,t,r){this.low=0|e,this.high=0|t,this.unsigned=!!r}function n(e){return!0===(e&&e.__isLong__)}function i(e){var t=Math.clz32(e&-e);return e?31-t:t}r.prototype.__isLong__,Object.defineProperty(r.prototype,"__isLong__",{value:!0}),r.isLong=n;var o={},s={};function a(e,t){var r,n,i;if(t)return(e>>>=0,(i=0<=e&&e<256)&&(n=s[e]))?n:(r=l(e,0,!0),i&&(s[e]=r),r);return(e|=0,(i=-128<=e&&e<128)&&(n=o[e]))?n:(r=l(e,e<0?-1:0,!1),i&&(o[e]=r),r)}function u(e,t){if(isNaN(e))return t?y:b;if(t){if(e<0)return y;if(e>=f)return $}else{if(e<=-g)return T;if(e+1>=g)return w}return e<0?u(-e,t).neg():l(e%h|0,e/h|0,t)}function l(e,t,n){return new r(e,t,n)}r.fromInt=a,r.fromNumber=u,r.fromBits=l;var d=Math.pow;function p(e,t,r){if(0===e.length)throw Error("empty string");if("number"==typeof t?(r=t,t=!1):t=!!t,"NaN"===e||"Infinity"===e||"+Infinity"===e||"-Infinity"===e)return t?y:b;if((r=r||10)<2||36<r)throw RangeError("radix");if((n=e.indexOf("-"))>0)throw Error("interior hyphen");if(0===n)return p(e.substring(1),t,r).neg();for(var n,i=u(d(r,8)),o=b,s=0;s<e.length;s+=8){var a=Math.min(8,e.length-s),l=parseInt(e.substring(s,s+a),r);if(a<8){var c=u(d(r,a));o=o.mul(c).add(u(l))}else o=(o=o.mul(i)).add(u(l))}return o.unsigned=t,o}function c(e,t){return"number"==typeof e?u(e,t):"string"==typeof e?p(e,t):l(e.low,e.high,"boolean"==typeof t?t:e.unsigned)}r.fromString=p,r.fromValue=c;var h=0x100000000,f=0xffffffffffffffff,g=0x8000000000000000,m=a(0x1000000),b=a(0);r.ZERO=b;var y=a(0,!0);r.UZERO=y;var _=a(1);r.ONE=_;var v=a(1,!0);r.UONE=v;var x=a(-1);r.NEG_ONE=x;var w=l(-1,0x7fffffff,!1);r.MAX_VALUE=w;var $=l(-1,-1,!0);r.MAX_UNSIGNED_VALUE=$;var T=l(0,-0x80000000,!1);r.MIN_VALUE=T;var I=r.prototype;I.toInt=function(){return this.unsigned?this.low>>>0:this.low},I.toNumber=function(){return this.unsigned?(this.high>>>0)*h+(this.low>>>0):this.high*h+(this.low>>>0)},I.toString=function(e){if((e=e||10)<2||36<e)throw RangeError("radix");if(this.isZero())return"0";if(this.isNegative())if(!this.eq(T))return"-"+this.neg().toString(e);else{var t=u(e),r=this.div(t),n=r.mul(t).sub(this);return r.toString(e)+n.toInt().toString(e)}for(var i=u(d(e,6),this.unsigned),o=this,s="";;){var a=o.div(i),l=(o.sub(a.mul(i)).toInt()>>>0).toString(e);if((o=a).isZero())return l+s;for(;l.length<6;)l="0"+l;s=""+l+s}},I.getHighBits=function(){return this.high},I.getHighBitsUnsigned=function(){return this.high>>>0},I.getLowBits=function(){return this.low},I.getLowBitsUnsigned=function(){return this.low>>>0},I.getNumBitsAbs=function(){if(this.isNegative())return this.eq(T)?64:this.neg().getNumBitsAbs();for(var e=0!=this.high?this.high:this.low,t=31;t>0&&(e&1<<t)==0;t--);return 0!=this.high?t+33:t+1},I.isSafeInteger=function(){var e=this.high>>21;return!e||!this.unsigned&&-1===e&&(0!==this.low||-2097152!==this.high)},I.isZero=function(){return 0===this.high&&0===this.low},I.eqz=I.isZero,I.isNegative=function(){return!this.unsigned&&this.high<0},I.isPositive=function(){return this.unsigned||this.high>=0},I.isOdd=function(){return(1&this.low)==1},I.isEven=function(){return(1&this.low)==0},I.equals=function(e){return n(e)||(e=c(e)),(this.unsigned===e.unsigned||this.high>>>31!=1||e.high>>>31!=1)&&this.high===e.high&&this.low===e.low},I.eq=I.equals,I.notEquals=function(e){return!this.eq(e)},I.neq=I.notEquals,I.ne=I.notEquals,I.lessThan=function(e){return 0>this.comp(e)},I.lt=I.lessThan,I.lessThanOrEqual=function(e){return 0>=this.comp(e)},I.lte=I.lessThanOrEqual,I.le=I.lessThanOrEqual,I.greaterThan=function(e){return this.comp(e)>0},I.gt=I.greaterThan,I.greaterThanOrEqual=function(e){return this.comp(e)>=0},I.gte=I.greaterThanOrEqual,I.ge=I.greaterThanOrEqual,I.compare=function(e){if(n(e)||(e=c(e)),this.eq(e))return 0;var t=this.isNegative(),r=e.isNegative();return t&&!r?-1:!t&&r?1:this.unsigned?e.high>>>0>this.high>>>0||e.high===this.high&&e.low>>>0>this.low>>>0?-1:1:this.sub(e).isNegative()?-1:1},I.comp=I.compare,I.negate=function(){return!this.unsigned&&this.eq(T)?T:this.not().add(_)},I.neg=I.negate,I.add=function(e){n(e)||(e=c(e));var t,r,i=this.high>>>16,o=65535&this.high,s=this.low>>>16,a=65535&this.low,u=e.high>>>16,d=65535&e.high,p=e.low>>>16,h=65535&e.low,f=0,g=0;return t=0+((r=0+(a+h))>>>16),r&=65535,t+=s+p,g+=t>>>16,t&=65535,g+=o+d,f+=g>>>16,g&=65535,f+=i+u,l(t<<16|r,(f&=65535)<<16|g,this.unsigned)},I.subtract=function(e){return n(e)||(e=c(e)),this.add(e.neg())},I.sub=I.subtract,I.multiply=function(e){if(this.isZero())return this;if(n(e)||(e=c(e)),t)return l(t.mul(this.low,this.high,e.low,e.high),t.get_high(),this.unsigned);if(e.isZero())return this.unsigned?y:b;if(this.eq(T))return e.isOdd()?T:b;if(e.eq(T))return this.isOdd()?T:b;if(this.isNegative())if(e.isNegative())return this.neg().mul(e.neg());else return this.neg().mul(e).neg();if(e.isNegative())return this.mul(e.neg()).neg();if(this.lt(m)&&e.lt(m))return u(this.toNumber()*e.toNumber(),this.unsigned);var r,i,o=this.high>>>16,s=65535&this.high,a=this.low>>>16,d=65535&this.low,p=e.high>>>16,h=65535&e.high,f=e.low>>>16,g=65535&e.low,_=0,v=0;return r=0+((i=0+d*g)>>>16),i&=65535,r+=a*g,v+=r>>>16,r&=65535,r+=d*f,v+=r>>>16,r&=65535,v+=s*g,_+=v>>>16,v&=65535,v+=a*f,_+=v>>>16,v&=65535,v+=d*h,_+=v>>>16,v&=65535,_+=o*g+s*f+a*h+d*p,l(r<<16|i,(_&=65535)<<16|v,this.unsigned)},I.mul=I.multiply,I.divide=function(e){if(n(e)||(e=c(e)),e.isZero())throw Error("division by zero");if(t){var r,i,o;return this.unsigned||-0x80000000!==this.high||-1!==e.low||-1!==e.high?l((this.unsigned?t.div_u:t.div_s)(this.low,this.high,e.low,e.high),t.get_high(),this.unsigned):this}if(this.isZero())return this.unsigned?y:b;if(this.unsigned){if(e.unsigned||(e=e.toUnsigned()),e.gt(this))return y;if(e.gt(this.shru(1)))return v;o=y}else{if(this.eq(T))if(e.eq(_)||e.eq(x))return T;else return e.eq(T)?_:(r=this.shr(1).div(e).shl(1)).eq(b)?e.isNegative()?_:x:(i=this.sub(e.mul(r)),o=r.add(i.div(e)));if(e.eq(T))return this.unsigned?y:b;if(this.isNegative())return e.isNegative()?this.neg().div(e.neg()):this.neg().div(e).neg();if(e.isNegative())return this.div(e.neg()).neg();o=b}for(i=this;i.gte(e);){for(var s=Math.ceil(Math.log(r=Math.max(1,Math.floor(i.toNumber()/e.toNumber())))/Math.LN2),a=s<=48?1:d(2,s-48),p=u(r),h=p.mul(e);h.isNegative()||h.gt(i);)r-=a,h=(p=u(r,this.unsigned)).mul(e);p.isZero()&&(p=_),o=o.add(p),i=i.sub(h)}return o},I.div=I.divide,I.modulo=function(e){return(n(e)||(e=c(e)),t)?l((this.unsigned?t.rem_u:t.rem_s)(this.low,this.high,e.low,e.high),t.get_high(),this.unsigned):this.sub(this.div(e).mul(e))},I.mod=I.modulo,I.rem=I.modulo,I.not=function(){return l(~this.low,~this.high,this.unsigned)},I.countLeadingZeros=function(){return this.high?Math.clz32(this.high):Math.clz32(this.low)+32},I.clz=I.countLeadingZeros,I.countTrailingZeros=function(){return this.low?i(this.low):i(this.high)+32},I.ctz=I.countTrailingZeros,I.and=function(e){return n(e)||(e=c(e)),l(this.low&e.low,this.high&e.high,this.unsigned)},I.or=function(e){return n(e)||(e=c(e)),l(this.low|e.low,this.high|e.high,this.unsigned)},I.xor=function(e){return n(e)||(e=c(e)),l(this.low^e.low,this.high^e.high,this.unsigned)},I.shiftLeft=function(e){return(n(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?l(this.low<<e,this.high<<e|this.low>>>32-e,this.unsigned):l(0,this.low<<e-32,this.unsigned)},I.shl=I.shiftLeft,I.shiftRight=function(e){return(n(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?l(this.low>>>e|this.high<<32-e,this.high>>e,this.unsigned):l(this.high>>e-32,this.high>=0?0:-1,this.unsigned)},I.shr=I.shiftRight,I.shiftRightUnsigned=function(e){return(n(e)&&(e=e.toInt()),0==(e&=63))?this:e<32?l(this.low>>>e|this.high<<32-e,this.high>>>e,this.unsigned):32===e?l(this.high,0,this.unsigned):l(this.high>>>e-32,0,this.unsigned)},I.shru=I.shiftRightUnsigned,I.shr_u=I.shiftRightUnsigned,I.rotateLeft=function(e){var t;return(n(e)&&(e=e.toInt()),0==(e&=63))?this:32===e?l(this.high,this.low,this.unsigned):e<32?(t=32-e,l(this.low<<e|this.high>>>t,this.high<<e|this.low>>>t,this.unsigned)):(e-=32,t=32-e,l(this.high<<e|this.low>>>t,this.low<<e|this.high>>>t,this.unsigned))},I.rotl=I.rotateLeft,I.rotateRight=function(e){var t;return(n(e)&&(e=e.toInt()),0==(e&=63))?this:32===e?l(this.high,this.low,this.unsigned):e<32?(t=32-e,l(this.high<<t|this.low>>>e,this.low<<t|this.high>>>e,this.unsigned)):(e-=32,t=32-e,l(this.low<<t|this.high>>>e,this.high<<t|this.low>>>e,this.unsigned))},I.rotr=I.rotateRight,I.toSigned=function(){return this.unsigned?l(this.low,this.high,!1):this},I.toUnsigned=function(){return this.unsigned?this:l(this.low,this.high,!0)},I.toBytes=function(e){return e?this.toBytesLE():this.toBytesBE()},I.toBytesLE=function(){var e=this.high,t=this.low;return[255&t,t>>>8&255,t>>>16&255,t>>>24,255&e,e>>>8&255,e>>>16&255,e>>>24]},I.toBytesBE=function(){var e=this.high,t=this.low;return[e>>>24,e>>>16&255,e>>>8&255,255&e,t>>>24,t>>>16&255,t>>>8&255,255&t]},r.fromBytes=function(e,t,n){return n?r.fromBytesLE(e,t):r.fromBytesBE(e,t)},r.fromBytesLE=function(e,t){return new r(e[0]|e[1]<<8|e[2]<<16|e[3]<<24,e[4]|e[5]<<8|e[6]<<16|e[7]<<24,t)},r.fromBytesBE=function(e,t){return new r(e[4]<<24|e[5]<<16|e[6]<<8|e[7],e[0]<<24|e[1]<<16|e[2]<<8|e[3],t)},"function"==typeof BigInt&&(r.fromBigInt=function(e,t){return l(Number(BigInt.asIntN(32,e)),Number(BigInt.asIntN(32,e>>BigInt(32))),t)},r.fromValue=function(e,t){return"bigint"==typeof e?r.fromBigInt(e,t):c(e,t)},I.toBigInt=function(){var e=BigInt(this.low>>>0);return BigInt(this.unsigned?this.high>>>0:this.high)<<BigInt(32)|e}),e.default=r})}}),cy=dY({"web/node_modules/protobufjs/src/util/minimal.js"(e){"use strict";function t(e){return"__proto__"===e||"prototype"===e||"constructor"===e}function r(e){var r="boolean"==typeof arguments[arguments.length-1],n=r?arguments.length-1:arguments.length;r=r&&arguments[arguments.length-1];for(var i=1;i<n;++i){var o=arguments[i];if(o)for(var s=Object.keys(o),a=0;a<s.length;++a)t(s[a])||void 0!==e[s[a]]&&r||(e[s[a]]=o[s[a]])}return e}function n(e){function t(e,n){if(!(this instanceof t))return new t(e,n);Object.defineProperty(this,"message",{get:function(){return e}}),Error.captureStackTrace?Error.captureStackTrace(this,t):Object.defineProperty(this,"stack",{value:Error().stack||""}),n&&r(this,n)}return t.prototype=Object.create(Error.prototype,{constructor:{value:t,writable:!0,enumerable:!1,configurable:!0},name:{get:function(){return e},set:void 0,enumerable:!1,configurable:!0},toString:{value:function(){return this.name+": "+this.message},writable:!0,enumerable:!1,configurable:!0}}),t}e.asPromise=cl(),e.base64=cd(),e.EventEmitter=cp(),e.float=cc(),e.inquire=ch(),e.utf8=cf(),e.pool=cg(),e.LongBits=cm(),e.isUnsafeProperty=t,e.isNode=!!("u">typeof global&&global&&global.process&&global.process.versions&&global.process.versions.node),e.global=e.isNode&&global||"u">typeof window&&window||"u">typeof self&&self||e,e.emptyArray=Object.freeze?Object.freeze([]):[],e.emptyObject=Object.freeze?Object.freeze({}):{},e.isInteger=Number.isInteger||function(e){return"number"==typeof e&&isFinite(e)&&Math.floor(e)===e},e.isString=function(e){return"string"==typeof e||e instanceof String},e.isObject=function(e){return e&&"object"==typeof e},e.isset=e.isSet=function(e,t){var r=e[t];return!!(null!=r&&Object.hasOwnProperty.call(e,t))&&("object"!=typeof r||(Array.isArray(r)?r.length:Object.keys(r).length)>0)},e.Buffer=function(){try{var t=e.global.Buffer;return t.prototype.utf8Write?t:null}catch(e){return null}}(),e._Buffer_from=null,e._Buffer_allocUnsafe=null,e.newBuffer=function(t){return"number"==typeof t?e.Buffer?e._Buffer_allocUnsafe(t):new e.Array(t):e.Buffer?e._Buffer_from(t):"u"<typeof Uint8Array?t:new Uint8Array(t)},e.Array="u">typeof Uint8Array?Uint8Array:Array,e.Long=e.global.dcodeIO&&e.global.dcodeIO.Long||e.global.Long||function(){try{var e=cb();return e&&e.isLong?e:null}catch(e){return null}}(),e.key2Re=/^true|false|0|1$/,e.key32Re=/^-?(?:0|[1-9][0-9]*)$/,e.key64Re=/^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/,e.longToHash=function(t){return t?e.LongBits.from(t).toHash():e.LongBits.zeroHash},e.longFromHash=function(t,r){var n=e.LongBits.fromHash(t);return e.Long?e.Long.fromBits(n.lo,n.hi,r):n.toNumber(!!r)},e.merge=r,e.nestingLimit=32,e.recursionLimit=100,e.makeProp=function(e,t){Object.defineProperty(e,t,{enumerable:!0,configurable:!0,writable:!0})},e.lcFirst=function(e){return e.charAt(0).toLowerCase()+e.substring(1)},e.newError=n,e.ProtocolError=n("ProtocolError"),e.oneOfGetter=function(e){for(var t={},r=0;r<e.length;++r)t[e[r]]=1;return function(){for(var e=Object.keys(this),r=e.length-1;r>-1;--r)if(1===t[e[r]]&&void 0!==this[e[r]]&&null!==this[e[r]])return e[r]}},e.oneOfSetter=function(e){return function(t){for(var r=0;r<e.length;++r)e[r]!==t&&delete this[e[r]]}},e.toJSONOptions={longs:String,enums:String,bytes:String,json:!0},e._configure=function(){var t=e.Buffer;if(!t){e._Buffer_from=e._Buffer_allocUnsafe=null;return}e._Buffer_from=t.from!==Uint8Array.from&&t.from||function(e,r){return new t(e,r)},e._Buffer_allocUnsafe=t.allocUnsafe||function(e){return new t(e)}}}}),c_=dY({"web/node_modules/protobufjs/src/writer.js"(e,t){"use strict";t.exports=d;var r,n=cy(),i=n.LongBits,o=n.base64,s=n.utf8;function a(e,t,r){this.fn=e,this.len=t,this.next=void 0,this.val=r}function u(){}function l(e){this.head=e.head,this.tail=e.tail,this.len=e.len,this.next=e.states}function d(){this.len=0,this.head=new a(u,0,0),this.tail=this.head,this.states=null}var p=function(){return n.Buffer?function(){return(d.create=function(){return new r})()}:function(){return new d}};function c(e,t,r){t[r]=255&e}function h(e,t){this.len=e,this.next=void 0,this.val=t}function f(e,t,r){for(var n=e.lo,i=e.hi;i;)t[r++]=127&n|128,n=(n>>>7|i<<25)>>>0,i>>>=7;for(;n>127;)t[r++]=127&n|128,n>>>=7;t[r++]=n}function g(e,t,r){t[r]=255&e,t[r+1]=e>>>8&255,t[r+2]=e>>>16&255,t[r+3]=e>>>24}d.create=p(),d.alloc=function(e){return new n.Array(e)},n.Array!==Array&&(d.alloc=n.pool(d.alloc,n.Array.prototype.subarray)),d.prototype._push=function(e,t,r){return this.tail=this.tail.next=new a(e,t,r),this.len+=t,this},h.prototype=Object.create(a.prototype),h.prototype.fn=function(e,t,r){for(;e>127;)t[r++]=127&e|128,e>>>=7;t[r]=e},d.prototype.uint32=function(e){return this.len+=(this.tail=this.tail.next=new h((e>>>=0)<128?1:e<16384?2:e<2097152?3:e<0x10000000?4:5,e)).len,this},d.prototype.int32=function(e){return(e|=0)<0?this._push(f,10,i.fromNumber(e)):this.uint32(e)},d.prototype.sint32=function(e){return this.uint32((e<<1^e>>31)>>>0)},d.prototype.uint64=function(e){var t=i.from(e);return this._push(f,t.length(),t)},d.prototype.int64=d.prototype.uint64,d.prototype.sint64=function(e){var t=i.from(e).zzEncode();return this._push(f,t.length(),t)},d.prototype.bool=function(e){return this._push(c,1,+!!e)},d.prototype.fixed32=function(e){return this._push(g,4,e>>>0)},d.prototype.sfixed32=d.prototype.fixed32,d.prototype.fixed64=function(e){var t=i.from(e);return this._push(g,4,t.lo)._push(g,4,t.hi)},d.prototype.sfixed64=d.prototype.fixed64,d.prototype.float=function(e){return this._push(n.float.writeFloatLE,4,e)},d.prototype.double=function(e){return this._push(n.float.writeDoubleLE,8,e)};var m=n.Array.prototype.set?function(e,t,r){t.set(e,r)}:function(e,t,r){for(var n=0;n<e.length;++n)t[r+n]=e[n]};d.prototype.bytes=function(e){var t=e.length>>>0;if(!t)return this._push(c,1,0);if(n.isString(e)){var r=d.alloc(t=o.length(e));o.decode(e,r,0),e=r}return this.uint32(t)._push(m,t,e)},d.prototype.string=function(e){var t=s.length(e);return t?this.uint32(t)._push(s.write,t,e):this._push(c,1,0)},d.prototype.fork=function(){return this.states=new l(this),this.head=this.tail=new a(u,0,0),this.len=0,this},d.prototype.reset=function(){return this.states?(this.head=this.states.head,this.tail=this.states.tail,this.len=this.states.len,this.states=this.states.next):(this.head=this.tail=new a(u,0,0),this.len=0),this},d.prototype.ldelim=function(){var e=this.head,t=this.tail,r=this.len;return this.reset().uint32(r),r&&(this.tail.next=e.next,this.tail=t,this.len+=r),this},d.prototype.finish=function(){for(var e=this.head.next,t=this.constructor.alloc(this.len),r=0;e;)e.fn(e.val,t,r),r+=e.len,e=e.next;return t},d._configure=function(e){r=e,d.create=p(),r._configure()}}}),cv=dY({"web/node_modules/protobufjs/src/writer_buffer.js"(e,t){"use strict";t.exports=i;var r=c_();(i.prototype=Object.create(r.prototype)).constructor=i;var n=cy();function i(){r.call(this)}function o(e,t,r){e.length<40?n.utf8.write(e,t,r):t.utf8Write?t.utf8Write(e,r):t.write(e,r)}i._configure=function(){i.alloc=n._Buffer_allocUnsafe,i.writeBytesBuffer=n.Buffer&&n.Buffer.prototype instanceof Uint8Array&&"set"===n.Buffer.prototype.set.name?function(e,t,r){t.set(e,r)}:function(e,t,r){if(e.copy)e.copy(t,r,0,e.length);else for(var n=0;n<e.length;)t[r++]=e[n++]}},i.prototype.bytes=function(e){n.isString(e)&&(e=n._Buffer_from(e,"base64"));var t=e.length>>>0;return this.uint32(t),t&&this._push(i.writeBytesBuffer,t,e),this},i.prototype.string=function(e){var t=n.Buffer.byteLength(e);return this.uint32(t),t&&this._push(o,t,e),this},i._configure()}}),cx=dY({"web/node_modules/protobufjs/src/reader.js"(e,t){"use strict";t.exports=u;var r,n,i=cy(),o=i.LongBits,s=i.utf8;function a(e,t){return RangeError("index out of range: "+e.pos+" + "+(t||1)+" > "+e.len)}function u(e){this.buf=e,this.pos=0,this.len=e.length}var l="u">typeof Uint8Array?function(e){if(e instanceof Uint8Array||Array.isArray(e))return new u(e);throw Error("illegal buffer")}:function(e){if(Array.isArray(e))return new u(e);throw Error("illegal buffer")},d=function(){return i.Buffer?function(e){return(u.create=function(e){return i.Buffer.isBuffer(e)?new n(e):l(e)})(e)}:l};function p(){var e=new o(0,0),t=0;if(this.len-this.pos>4){for(;t<4;++t)if(e.lo=(e.lo|(127&this.buf[this.pos])<<7*t)>>>0,this.buf[this.pos++]<128)return e;if(e.lo=(e.lo|(127&this.buf[this.pos])<<28)>>>0,e.hi=(e.hi|(127&this.buf[this.pos])>>4)>>>0,this.buf[this.pos++]<128)return e;t=0}else{for(;t<3;++t){if(this.pos>=this.len)throw a(this);if(e.lo=(e.lo|(127&this.buf[this.pos])<<7*t)>>>0,this.buf[this.pos++]<128)return e}return e.lo=(e.lo|(127&this.buf[this.pos++])<<7*t)>>>0,e}if(this.len-this.pos>4){for(;t<5;++t)if(e.hi=(e.hi|(127&this.buf[this.pos])<<7*t+3)>>>0,this.buf[this.pos++]<128)return e}else for(;t<5;++t){if(this.pos>=this.len)throw a(this);if(e.hi=(e.hi|(127&this.buf[this.pos])<<7*t+3)>>>0,this.buf[this.pos++]<128)return e}throw Error("invalid varint encoding")}function c(e,t){return(e[t-4]|e[t-3]<<8|e[t-2]<<16|e[t-1]<<24)>>>0}function h(){if(this.pos+8>this.len)throw a(this,8);return new o(c(this.buf,this.pos+=4),c(this.buf,this.pos+=4))}u.create=d(),u.prototype._slice=i.Array.prototype.subarray||i.Array.prototype.slice,u.prototype.uint32=(r=0xffffffff,function(){if(r=(127&this.buf[this.pos])>>>0,this.buf[this.pos++]<128||(r=(r|(127&this.buf[this.pos])<<7)>>>0,this.buf[this.pos++]<128)||(r=(r|(127&this.buf[this.pos])<<14)>>>0,this.buf[this.pos++]<128)||(r=(r|(127&this.buf[this.pos])<<21)>>>0,this.buf[this.pos++]<128)||(r=(r|(15&this.buf[this.pos])<<28)>>>0,this.buf[this.pos++]<128))return r;if((this.pos+=5)>this.len)throw this.pos=this.len,a(this,10);return r}),u.prototype.int32=function(){return 0|this.uint32()},u.prototype.sint32=function(){var e=this.uint32();return e>>>1^-(1&e)},u.prototype.bool=function(){return 0!==this.uint32()},u.prototype.fixed32=function(){if(this.pos+4>this.len)throw a(this,4);return c(this.buf,this.pos+=4)},u.prototype.sfixed32=function(){if(this.pos+4>this.len)throw a(this,4);return 0|c(this.buf,this.pos+=4)},u.prototype.float=function(){if(this.pos+4>this.len)throw a(this,4);var e=i.float.readFloatLE(this.buf,this.pos);return this.pos+=4,e},u.prototype.double=function(){if(this.pos+8>this.len)throw a(this,4);var e=i.float.readDoubleLE(this.buf,this.pos);return this.pos+=8,e},u.prototype.bytes=function(){var e=this.uint32(),t=this.pos,r=this.pos+e;if(r>this.len)throw a(this,e);if(this.pos+=e,Array.isArray(this.buf))return this.buf.slice(t,r);if(t===r){var n=i.Buffer;return n?n.alloc(0):new this.buf.constructor(0)}return this._slice.call(this.buf,t,r)},u.prototype.string=function(){var e=this.bytes();return s.read(e,0,e.length)},u.prototype.skip=function(e){if("number"==typeof e){if(this.pos+e>this.len)throw a(this,e);this.pos+=e}else do if(this.pos>=this.len)throw a(this);while(128&this.buf[this.pos++])return this},u.recursionLimit=i.recursionLimit,u.prototype.skipType=function(e,t){if(void 0===t&&(t=0),t>u.recursionLimit)throw Error("maximum nesting depth exceeded");switch(e){case 0:this.skip();break;case 1:this.skip(8);break;case 2:this.skip(this.uint32());break;case 3:for(;4!=(e=7&this.uint32());)this.skipType(e,t+1);break;case 5:this.skip(4);break;default:throw Error("invalid wire type "+e+" at offset "+this.pos)}return this},u._configure=function(e){n=e,u.create=d(),n._configure();var t=i.Long?"toLong":"toNumber";i.merge(u.prototype,{int64:function(){return p.call(this)[t](!1)},uint64:function(){return p.call(this)[t](!0)},sint64:function(){return p.call(this).zzDecode()[t](!1)},fixed64:function(){return h.call(this)[t](!0)},sfixed64:function(){return h.call(this)[t](!1)}})}}}),cw=dY({"web/node_modules/protobufjs/src/reader_buffer.js"(e,t){"use strict";t.exports=i;var r=cx();(i.prototype=Object.create(r.prototype)).constructor=i;var n=cy();function i(e){r.call(this,e)}i._configure=function(){n.Buffer&&(i.prototype._slice=n.Buffer.prototype.slice)},i.prototype.string=function(){var e=this.uint32();return this.buf.utf8Slice?this.buf.utf8Slice(this.pos,this.pos=Math.min(this.pos+e,this.len)):this.buf.toString("utf-8",this.pos,this.pos=Math.min(this.pos+e,this.len))},i._configure()}}),c$=dY({"web/node_modules/protobufjs/src/rpc/service.js"(e,t){"use strict";t.exports=n;var r=cy();function n(e,t,n){if("function"!=typeof e)throw TypeError("rpcImpl must be a function");r.EventEmitter.call(this),this.rpcImpl=e,this.requestDelimited=!!t,this.responseDelimited=!!n}(n.prototype=Object.create(r.EventEmitter.prototype)).constructor=n,n.prototype.rpcCall=function e(t,n,i,o,s){if(!o)throw TypeError("request must be specified");var a=this;if(!s)return r.asPromise(e,a,t,n,i,o);if(!a.rpcImpl)return void setTimeout(function(){s(Error("already ended"))},0);try{return a.rpcImpl(t,n[a.requestDelimited?"encodeDelimited":"encode"](o).finish(),function(e,r){if(e)return a.emit("error",e,t),s(e);if(null===r)return void a.end(!0);if(!(r instanceof i))try{r=i[a.responseDelimited?"decodeDelimited":"decode"](r)}catch(e){return a.emit("error",e,t),s(e)}return a.emit("data",r,t),s(null,r)})}catch(e){a.emit("error",e,t),setTimeout(function(){s(e)},0);return}},n.prototype.end=function(e){return this.rpcImpl&&(e||this.rpcImpl(null,null,null),this.rpcImpl=null,this.emit("end").off()),this}}}),cT=dY({"web/node_modules/protobufjs/src/rpc.js"(e){"use strict";e.Service=c$()}}),cI=dY({"web/node_modules/protobufjs/src/roots.js"(e,t){"use strict";t.exports=Object.create(null)}}),cS=dY({"web/node_modules/protobufjs/src/index-minimal.js"(e){"use strict";function t(){e.util._configure(),e.Writer._configure(e.BufferWriter),e.Reader._configure(e.BufferReader)}e.build="minimal",e.Writer=c_(),e.BufferWriter=cv(),e.Reader=cx(),e.BufferReader=cw(),e.util=cy(),e.rpc=cT(),e.roots=cI(),e.configure=t,t()}}),cO=dY({"web/node_modules/protobufjs/minimal.js"(e,t){"use strict";t.exports=cS()}}),cE=dY({"web/lib/onnxjs/ort-schema/protobuf/onnx.js"(e,t){"use strict";var r,n,i,o,s,a=cO(),u=a.Reader,l=a.Writer,d=a.util,p=a.roots.default||(a.roots.default={});r={},(i=Object.create(n={}))[n[0]="_START_VERSION"]=0,i[n[1]="IR_VERSION_2017_10_10"]=1,i[n[2]="IR_VERSION_2017_10_30"]=2,i[n[3]="IR_VERSION_2017_11_3"]=3,i[n[4]="IR_VERSION_2019_1_22"]=4,i[n[5]="IR_VERSION_2019_3_18"]=5,i[n[6]="IR_VERSION_2019_9_19"]=6,i[n[7]="IR_VERSION_2020_5_8"]=7,i[n[8]="IR_VERSION_2021_7_30"]=8,i[n[9]="IR_VERSION"]=9,r.Version=i,r.AttributeProto=function(){var e,t;function r(e){if(this.floats=[],this.ints=[],this.strings=[],this.tensors=[],this.graphs=[],this.sparseTensors=[],this.typeProtos=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return r.prototype.name="",r.prototype.refAttrName="",r.prototype.docString="",r.prototype.type=0,r.prototype.f=0,r.prototype.i=d.Long?d.Long.fromBits(0,0,!1):0,r.prototype.s=d.newBuffer([]),r.prototype.t=null,r.prototype.g=null,r.prototype.sparseTensor=null,r.prototype.tp=null,r.prototype.floats=d.emptyArray,r.prototype.ints=d.emptyArray,r.prototype.strings=d.emptyArray,r.prototype.tensors=d.emptyArray,r.prototype.graphs=d.emptyArray,r.prototype.sparseTensors=d.emptyArray,r.prototype.typeProtos=d.emptyArray,r.create=function(e){return new r(e)},r.encode=function(e,t){if(t||(t=l.create()),null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(10).string(e.name),null!=e.f&&Object.hasOwnProperty.call(e,"f")&&t.uint32(21).float(e.f),null!=e.i&&Object.hasOwnProperty.call(e,"i")&&t.uint32(24).int64(e.i),null!=e.s&&Object.hasOwnProperty.call(e,"s")&&t.uint32(34).bytes(e.s),null!=e.t&&Object.hasOwnProperty.call(e,"t")&&p.onnx.TensorProto.encode(e.t,t.uint32(42).fork()).ldelim(),null!=e.g&&Object.hasOwnProperty.call(e,"g")&&p.onnx.GraphProto.encode(e.g,t.uint32(50).fork()).ldelim(),null!=e.floats&&e.floats.length){t.uint32(58).fork();for(var r=0;r<e.floats.length;++r)t.float(e.floats[r]);t.ldelim()}if(null!=e.ints&&e.ints.length){t.uint32(66).fork();for(var r=0;r<e.ints.length;++r)t.int64(e.ints[r]);t.ldelim()}if(null!=e.strings&&e.strings.length)for(var r=0;r<e.strings.length;++r)t.uint32(74).bytes(e.strings[r]);if(null!=e.tensors&&e.tensors.length)for(var r=0;r<e.tensors.length;++r)p.onnx.TensorProto.encode(e.tensors[r],t.uint32(82).fork()).ldelim();if(null!=e.graphs&&e.graphs.length)for(var r=0;r<e.graphs.length;++r)p.onnx.GraphProto.encode(e.graphs[r],t.uint32(90).fork()).ldelim();if(null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(106).string(e.docString),null!=e.tp&&Object.hasOwnProperty.call(e,"tp")&&p.onnx.TypeProto.encode(e.tp,t.uint32(114).fork()).ldelim(),null!=e.typeProtos&&e.typeProtos.length)for(var r=0;r<e.typeProtos.length;++r)p.onnx.TypeProto.encode(e.typeProtos[r],t.uint32(122).fork()).ldelim();if(null!=e.type&&Object.hasOwnProperty.call(e,"type")&&t.uint32(160).int32(e.type),null!=e.refAttrName&&Object.hasOwnProperty.call(e,"refAttrName")&&t.uint32(170).string(e.refAttrName),null!=e.sparseTensor&&Object.hasOwnProperty.call(e,"sparseTensor")&&p.onnx.SparseTensorProto.encode(e.sparseTensor,t.uint32(178).fork()).ldelim(),null!=e.sparseTensors&&e.sparseTensors.length)for(var r=0;r<e.sparseTensors.length;++r)p.onnx.SparseTensorProto.encode(e.sparseTensors[r],t.uint32(186).fork()).ldelim();return t},r.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},r.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.AttributeProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.name=e.string();break;case 21:n.refAttrName=e.string();break;case 13:n.docString=e.string();break;case 20:n.type=e.int32();break;case 2:n.f=e.float();break;case 3:n.i=e.int64();break;case 4:n.s=e.bytes();break;case 5:n.t=p.onnx.TensorProto.decode(e,e.uint32());break;case 6:n.g=p.onnx.GraphProto.decode(e,e.uint32());break;case 22:n.sparseTensor=p.onnx.SparseTensorProto.decode(e,e.uint32());break;case 14:n.tp=p.onnx.TypeProto.decode(e,e.uint32());break;case 7:if(n.floats&&n.floats.length||(n.floats=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.floats.push(e.float());else n.floats.push(e.float());break;case 8:if(n.ints&&n.ints.length||(n.ints=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.ints.push(e.int64());else n.ints.push(e.int64());break;case 9:n.strings&&n.strings.length||(n.strings=[]),n.strings.push(e.bytes());break;case 10:n.tensors&&n.tensors.length||(n.tensors=[]),n.tensors.push(p.onnx.TensorProto.decode(e,e.uint32()));break;case 11:n.graphs&&n.graphs.length||(n.graphs=[]),n.graphs.push(p.onnx.GraphProto.decode(e,e.uint32()));break;case 23:n.sparseTensors&&n.sparseTensors.length||(n.sparseTensors=[]),n.sparseTensors.push(p.onnx.SparseTensorProto.decode(e,e.uint32()));break;case 15:n.typeProtos&&n.typeProtos.length||(n.typeProtos=[]),n.typeProtos.push(p.onnx.TypeProto.decode(e,e.uint32()));break;default:e.skipType(7&i)}}return n},r.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},r.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.refAttrName&&e.hasOwnProperty("refAttrName")&&!d.isString(e.refAttrName))return"refAttrName: string expected";if(null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString))return"docString: string expected";if(null!=e.type&&e.hasOwnProperty("type"))switch(e.type){default:return"type: enum value expected";case 0:case 1:case 2:case 3:case 4:case 5:case 11:case 13:case 6:case 7:case 8:case 9:case 10:case 12:case 14:}if(null!=e.f&&e.hasOwnProperty("f")&&"number"!=typeof e.f)return"f: number expected";if(null!=e.i&&e.hasOwnProperty("i")&&!d.isInteger(e.i)&&!(e.i&&d.isInteger(e.i.low)&&d.isInteger(e.i.high)))return"i: integer|Long expected";if(null!=e.s&&e.hasOwnProperty("s")&&!(e.s&&"number"==typeof e.s.length||d.isString(e.s)))return"s: buffer expected";if(null!=e.t&&e.hasOwnProperty("t")){var t=p.onnx.TensorProto.verify(e.t);if(t)return"t."+t}if(null!=e.g&&e.hasOwnProperty("g")){var t=p.onnx.GraphProto.verify(e.g);if(t)return"g."+t}if(null!=e.sparseTensor&&e.hasOwnProperty("sparseTensor")){var t=p.onnx.SparseTensorProto.verify(e.sparseTensor);if(t)return"sparseTensor."+t}if(null!=e.tp&&e.hasOwnProperty("tp")){var t=p.onnx.TypeProto.verify(e.tp);if(t)return"tp."+t}if(null!=e.floats&&e.hasOwnProperty("floats")){if(!Array.isArray(e.floats))return"floats: array expected";for(var r=0;r<e.floats.length;++r)if("number"!=typeof e.floats[r])return"floats: number[] expected"}if(null!=e.ints&&e.hasOwnProperty("ints")){if(!Array.isArray(e.ints))return"ints: array expected";for(var r=0;r<e.ints.length;++r)if(!d.isInteger(e.ints[r])&&!(e.ints[r]&&d.isInteger(e.ints[r].low)&&d.isInteger(e.ints[r].high)))return"ints: integer|Long[] expected"}if(null!=e.strings&&e.hasOwnProperty("strings")){if(!Array.isArray(e.strings))return"strings: array expected";for(var r=0;r<e.strings.length;++r)if(!(e.strings[r]&&"number"==typeof e.strings[r].length||d.isString(e.strings[r])))return"strings: buffer[] expected"}if(null!=e.tensors&&e.hasOwnProperty("tensors")){if(!Array.isArray(e.tensors))return"tensors: array expected";for(var r=0;r<e.tensors.length;++r){var t=p.onnx.TensorProto.verify(e.tensors[r]);if(t)return"tensors."+t}}if(null!=e.graphs&&e.hasOwnProperty("graphs")){if(!Array.isArray(e.graphs))return"graphs: array expected";for(var r=0;r<e.graphs.length;++r){var t=p.onnx.GraphProto.verify(e.graphs[r]);if(t)return"graphs."+t}}if(null!=e.sparseTensors&&e.hasOwnProperty("sparseTensors")){if(!Array.isArray(e.sparseTensors))return"sparseTensors: array expected";for(var r=0;r<e.sparseTensors.length;++r){var t=p.onnx.SparseTensorProto.verify(e.sparseTensors[r]);if(t)return"sparseTensors."+t}}if(null!=e.typeProtos&&e.hasOwnProperty("typeProtos")){if(!Array.isArray(e.typeProtos))return"typeProtos: array expected";for(var r=0;r<e.typeProtos.length;++r){var t=p.onnx.TypeProto.verify(e.typeProtos[r]);if(t)return"typeProtos."+t}}return null},r.fromObject=function(e){if(e instanceof p.onnx.AttributeProto)return e;var t=new p.onnx.AttributeProto;switch(null!=e.name&&(t.name=String(e.name)),null!=e.refAttrName&&(t.refAttrName=String(e.refAttrName)),null!=e.docString&&(t.docString=String(e.docString)),e.type){default:"number"==typeof e.type&&(t.type=e.type);break;case"UNDEFINED":case 0:t.type=0;break;case"FLOAT":case 1:t.type=1;break;case"INT":case 2:t.type=2;break;case"STRING":case 3:t.type=3;break;case"TENSOR":case 4:t.type=4;break;case"GRAPH":case 5:t.type=5;break;case"SPARSE_TENSOR":case 11:t.type=11;break;case"TYPE_PROTO":case 13:t.type=13;break;case"FLOATS":case 6:t.type=6;break;case"INTS":case 7:t.type=7;break;case"STRINGS":case 8:t.type=8;break;case"TENSORS":case 9:t.type=9;break;case"GRAPHS":case 10:t.type=10;break;case"SPARSE_TENSORS":case 12:t.type=12;break;case"TYPE_PROTOS":case 14:t.type=14}if(null!=e.f&&(t.f=Number(e.f)),null!=e.i&&(d.Long?(t.i=d.Long.fromValue(e.i)).unsigned=!1:"string"==typeof e.i?t.i=parseInt(e.i,10):"number"==typeof e.i?t.i=e.i:"object"==typeof e.i&&(t.i=new d.LongBits(e.i.low>>>0,e.i.high>>>0).toNumber())),null!=e.s&&("string"==typeof e.s?d.base64.decode(e.s,t.s=d.newBuffer(d.base64.length(e.s)),0):e.s.length>=0&&(t.s=e.s)),null!=e.t){if("object"!=typeof e.t)throw TypeError(".onnx.AttributeProto.t: object expected");t.t=p.onnx.TensorProto.fromObject(e.t)}if(null!=e.g){if("object"!=typeof e.g)throw TypeError(".onnx.AttributeProto.g: object expected");t.g=p.onnx.GraphProto.fromObject(e.g)}if(null!=e.sparseTensor){if("object"!=typeof e.sparseTensor)throw TypeError(".onnx.AttributeProto.sparseTensor: object expected");t.sparseTensor=p.onnx.SparseTensorProto.fromObject(e.sparseTensor)}if(null!=e.tp){if("object"!=typeof e.tp)throw TypeError(".onnx.AttributeProto.tp: object expected");t.tp=p.onnx.TypeProto.fromObject(e.tp)}if(e.floats){if(!Array.isArray(e.floats))throw TypeError(".onnx.AttributeProto.floats: array expected");t.floats=[];for(var r=0;r<e.floats.length;++r)t.floats[r]=Number(e.floats[r])}if(e.ints){if(!Array.isArray(e.ints))throw TypeError(".onnx.AttributeProto.ints: array expected");t.ints=[];for(var r=0;r<e.ints.length;++r)d.Long?(t.ints[r]=d.Long.fromValue(e.ints[r])).unsigned=!1:"string"==typeof e.ints[r]?t.ints[r]=parseInt(e.ints[r],10):"number"==typeof e.ints[r]?t.ints[r]=e.ints[r]:"object"==typeof e.ints[r]&&(t.ints[r]=new d.LongBits(e.ints[r].low>>>0,e.ints[r].high>>>0).toNumber())}if(e.strings){if(!Array.isArray(e.strings))throw TypeError(".onnx.AttributeProto.strings: array expected");t.strings=[];for(var r=0;r<e.strings.length;++r)"string"==typeof e.strings[r]?d.base64.decode(e.strings[r],t.strings[r]=d.newBuffer(d.base64.length(e.strings[r])),0):e.strings[r].length>=0&&(t.strings[r]=e.strings[r])}if(e.tensors){if(!Array.isArray(e.tensors))throw TypeError(".onnx.AttributeProto.tensors: array expected");t.tensors=[];for(var r=0;r<e.tensors.length;++r){if("object"!=typeof e.tensors[r])throw TypeError(".onnx.AttributeProto.tensors: object expected");t.tensors[r]=p.onnx.TensorProto.fromObject(e.tensors[r])}}if(e.graphs){if(!Array.isArray(e.graphs))throw TypeError(".onnx.AttributeProto.graphs: array expected");t.graphs=[];for(var r=0;r<e.graphs.length;++r){if("object"!=typeof e.graphs[r])throw TypeError(".onnx.AttributeProto.graphs: object expected");t.graphs[r]=p.onnx.GraphProto.fromObject(e.graphs[r])}}if(e.sparseTensors){if(!Array.isArray(e.sparseTensors))throw TypeError(".onnx.AttributeProto.sparseTensors: array expected");t.sparseTensors=[];for(var r=0;r<e.sparseTensors.length;++r){if("object"!=typeof e.sparseTensors[r])throw TypeError(".onnx.AttributeProto.sparseTensors: object expected");t.sparseTensors[r]=p.onnx.SparseTensorProto.fromObject(e.sparseTensors[r])}}if(e.typeProtos){if(!Array.isArray(e.typeProtos))throw TypeError(".onnx.AttributeProto.typeProtos: array expected");t.typeProtos=[];for(var r=0;r<e.typeProtos.length;++r){if("object"!=typeof e.typeProtos[r])throw TypeError(".onnx.AttributeProto.typeProtos: object expected");t.typeProtos[r]=p.onnx.TypeProto.fromObject(e.typeProtos[r])}}return t},r.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.floats=[],r.ints=[],r.strings=[],r.tensors=[],r.graphs=[],r.typeProtos=[],r.sparseTensors=[]),t.defaults){if(r.name="",r.f=0,d.Long){var n=new d.Long(0,0,!1);r.i=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.i=t.longs===String?"0":0;t.bytes===String?r.s="":(r.s=[],t.bytes!==Array&&(r.s=d.newBuffer(r.s))),r.t=null,r.g=null,r.docString="",r.tp=null,r.type=t.enums===String?"UNDEFINED":0,r.refAttrName="",r.sparseTensor=null}if(null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),null!=e.f&&e.hasOwnProperty("f")&&(r.f=t.json&&!isFinite(e.f)?String(e.f):e.f),null!=e.i&&e.hasOwnProperty("i")&&("number"==typeof e.i?r.i=t.longs===String?String(e.i):e.i:r.i=t.longs===String?d.Long.prototype.toString.call(e.i):t.longs===Number?new d.LongBits(e.i.low>>>0,e.i.high>>>0).toNumber():e.i),null!=e.s&&e.hasOwnProperty("s")&&(r.s=t.bytes===String?d.base64.encode(e.s,0,e.s.length):t.bytes===Array?Array.prototype.slice.call(e.s):e.s),null!=e.t&&e.hasOwnProperty("t")&&(r.t=p.onnx.TensorProto.toObject(e.t,t)),null!=e.g&&e.hasOwnProperty("g")&&(r.g=p.onnx.GraphProto.toObject(e.g,t)),e.floats&&e.floats.length){r.floats=[];for(var i=0;i<e.floats.length;++i)r.floats[i]=t.json&&!isFinite(e.floats[i])?String(e.floats[i]):e.floats[i]}if(e.ints&&e.ints.length){r.ints=[];for(var i=0;i<e.ints.length;++i)"number"==typeof e.ints[i]?r.ints[i]=t.longs===String?String(e.ints[i]):e.ints[i]:r.ints[i]=t.longs===String?d.Long.prototype.toString.call(e.ints[i]):t.longs===Number?new d.LongBits(e.ints[i].low>>>0,e.ints[i].high>>>0).toNumber():e.ints[i]}if(e.strings&&e.strings.length){r.strings=[];for(var i=0;i<e.strings.length;++i)r.strings[i]=t.bytes===String?d.base64.encode(e.strings[i],0,e.strings[i].length):t.bytes===Array?Array.prototype.slice.call(e.strings[i]):e.strings[i]}if(e.tensors&&e.tensors.length){r.tensors=[];for(var i=0;i<e.tensors.length;++i)r.tensors[i]=p.onnx.TensorProto.toObject(e.tensors[i],t)}if(e.graphs&&e.graphs.length){r.graphs=[];for(var i=0;i<e.graphs.length;++i)r.graphs[i]=p.onnx.GraphProto.toObject(e.graphs[i],t)}if(null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),null!=e.tp&&e.hasOwnProperty("tp")&&(r.tp=p.onnx.TypeProto.toObject(e.tp,t)),e.typeProtos&&e.typeProtos.length){r.typeProtos=[];for(var i=0;i<e.typeProtos.length;++i)r.typeProtos[i]=p.onnx.TypeProto.toObject(e.typeProtos[i],t)}if(null!=e.type&&e.hasOwnProperty("type")&&(r.type=t.enums===String?void 0===p.onnx.AttributeProto.AttributeType[e.type]?e.type:p.onnx.AttributeProto.AttributeType[e.type]:e.type),null!=e.refAttrName&&e.hasOwnProperty("refAttrName")&&(r.refAttrName=e.refAttrName),null!=e.sparseTensor&&e.hasOwnProperty("sparseTensor")&&(r.sparseTensor=p.onnx.SparseTensorProto.toObject(e.sparseTensor,t)),e.sparseTensors&&e.sparseTensors.length){r.sparseTensors=[];for(var i=0;i<e.sparseTensors.length;++i)r.sparseTensors[i]=p.onnx.SparseTensorProto.toObject(e.sparseTensors[i],t)}return r},r.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},r.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.AttributeProto"},(t=Object.create(e={}))[e[0]="UNDEFINED"]=0,t[e[1]="FLOAT"]=1,t[e[2]="INT"]=2,t[e[3]="STRING"]=3,t[e[4]="TENSOR"]=4,t[e[5]="GRAPH"]=5,t[e[11]="SPARSE_TENSOR"]=11,t[e[13]="TYPE_PROTO"]=13,t[e[6]="FLOATS"]=6,t[e[7]="INTS"]=7,t[e[8]="STRINGS"]=8,t[e[9]="TENSORS"]=9,t[e[10]="GRAPHS"]=10,t[e[12]="SPARSE_TENSORS"]=12,t[e[14]="TYPE_PROTOS"]=14,r.AttributeType=t,r}(),r.ValueInfoProto=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.name="",e.prototype.type=null,e.prototype.docString="",e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(10).string(e.name),null!=e.type&&Object.hasOwnProperty.call(e,"type")&&p.onnx.TypeProto.encode(e.type,t.uint32(18).fork()).ldelim(),null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(26).string(e.docString),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.ValueInfoProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.name=e.string();break;case 2:n.type=p.onnx.TypeProto.decode(e,e.uint32());break;case 3:n.docString=e.string();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.type&&e.hasOwnProperty("type")){var t=p.onnx.TypeProto.verify(e.type);if(t)return"type."+t}return null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString)?"docString: string expected":null},e.fromObject=function(e){if(e instanceof p.onnx.ValueInfoProto)return e;var t=new p.onnx.ValueInfoProto;if(null!=e.name&&(t.name=String(e.name)),null!=e.type){if("object"!=typeof e.type)throw TypeError(".onnx.ValueInfoProto.type: object expected");t.type=p.onnx.TypeProto.fromObject(e.type)}return null!=e.docString&&(t.docString=String(e.docString)),t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.name="",r.type=null,r.docString=""),null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),null!=e.type&&e.hasOwnProperty("type")&&(r.type=p.onnx.TypeProto.toObject(e.type,t)),null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.ValueInfoProto"},e}(),r.NodeProto=function(){function e(e){if(this.input=[],this.output=[],this.attribute=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.input=d.emptyArray,e.prototype.output=d.emptyArray,e.prototype.name="",e.prototype.opType="",e.prototype.domain="",e.prototype.attribute=d.emptyArray,e.prototype.docString="",e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.input&&e.input.length)for(var r=0;r<e.input.length;++r)t.uint32(10).string(e.input[r]);if(null!=e.output&&e.output.length)for(var r=0;r<e.output.length;++r)t.uint32(18).string(e.output[r]);if(null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(26).string(e.name),null!=e.opType&&Object.hasOwnProperty.call(e,"opType")&&t.uint32(34).string(e.opType),null!=e.attribute&&e.attribute.length)for(var r=0;r<e.attribute.length;++r)p.onnx.AttributeProto.encode(e.attribute[r],t.uint32(42).fork()).ldelim();return null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(50).string(e.docString),null!=e.domain&&Object.hasOwnProperty.call(e,"domain")&&t.uint32(58).string(e.domain),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.NodeProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.input&&n.input.length||(n.input=[]),n.input.push(e.string());break;case 2:n.output&&n.output.length||(n.output=[]),n.output.push(e.string());break;case 3:n.name=e.string();break;case 4:n.opType=e.string();break;case 7:n.domain=e.string();break;case 5:n.attribute&&n.attribute.length||(n.attribute=[]),n.attribute.push(p.onnx.AttributeProto.decode(e,e.uint32()));break;case 6:n.docString=e.string();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.input&&e.hasOwnProperty("input")){if(!Array.isArray(e.input))return"input: array expected";for(var t=0;t<e.input.length;++t)if(!d.isString(e.input[t]))return"input: string[] expected"}if(null!=e.output&&e.hasOwnProperty("output")){if(!Array.isArray(e.output))return"output: array expected";for(var t=0;t<e.output.length;++t)if(!d.isString(e.output[t]))return"output: string[] expected"}if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.opType&&e.hasOwnProperty("opType")&&!d.isString(e.opType))return"opType: string expected";if(null!=e.domain&&e.hasOwnProperty("domain")&&!d.isString(e.domain))return"domain: string expected";if(null!=e.attribute&&e.hasOwnProperty("attribute")){if(!Array.isArray(e.attribute))return"attribute: array expected";for(var t=0;t<e.attribute.length;++t){var r=p.onnx.AttributeProto.verify(e.attribute[t]);if(r)return"attribute."+r}}return null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString)?"docString: string expected":null},e.fromObject=function(e){if(e instanceof p.onnx.NodeProto)return e;var t=new p.onnx.NodeProto;if(e.input){if(!Array.isArray(e.input))throw TypeError(".onnx.NodeProto.input: array expected");t.input=[];for(var r=0;r<e.input.length;++r)t.input[r]=String(e.input[r])}if(e.output){if(!Array.isArray(e.output))throw TypeError(".onnx.NodeProto.output: array expected");t.output=[];for(var r=0;r<e.output.length;++r)t.output[r]=String(e.output[r])}if(null!=e.name&&(t.name=String(e.name)),null!=e.opType&&(t.opType=String(e.opType)),null!=e.domain&&(t.domain=String(e.domain)),e.attribute){if(!Array.isArray(e.attribute))throw TypeError(".onnx.NodeProto.attribute: array expected");t.attribute=[];for(var r=0;r<e.attribute.length;++r){if("object"!=typeof e.attribute[r])throw TypeError(".onnx.NodeProto.attribute: object expected");t.attribute[r]=p.onnx.AttributeProto.fromObject(e.attribute[r])}}return null!=e.docString&&(t.docString=String(e.docString)),t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.input=[],r.output=[],r.attribute=[]),t.defaults&&(r.name="",r.opType="",r.docString="",r.domain=""),e.input&&e.input.length){r.input=[];for(var n=0;n<e.input.length;++n)r.input[n]=e.input[n]}if(e.output&&e.output.length){r.output=[];for(var n=0;n<e.output.length;++n)r.output[n]=e.output[n]}if(null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),null!=e.opType&&e.hasOwnProperty("opType")&&(r.opType=e.opType),e.attribute&&e.attribute.length){r.attribute=[];for(var n=0;n<e.attribute.length;++n)r.attribute[n]=p.onnx.AttributeProto.toObject(e.attribute[n],t)}return null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),null!=e.domain&&e.hasOwnProperty("domain")&&(r.domain=e.domain),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.NodeProto"},e}(),r.TrainingInfoProto=function(){function e(e){if(this.initializationBinding=[],this.updateBinding=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.initialization=null,e.prototype.algorithm=null,e.prototype.initializationBinding=d.emptyArray,e.prototype.updateBinding=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.initialization&&Object.hasOwnProperty.call(e,"initialization")&&p.onnx.GraphProto.encode(e.initialization,t.uint32(10).fork()).ldelim(),null!=e.algorithm&&Object.hasOwnProperty.call(e,"algorithm")&&p.onnx.GraphProto.encode(e.algorithm,t.uint32(18).fork()).ldelim(),null!=e.initializationBinding&&e.initializationBinding.length)for(var r=0;r<e.initializationBinding.length;++r)p.onnx.StringStringEntryProto.encode(e.initializationBinding[r],t.uint32(26).fork()).ldelim();if(null!=e.updateBinding&&e.updateBinding.length)for(var r=0;r<e.updateBinding.length;++r)p.onnx.StringStringEntryProto.encode(e.updateBinding[r],t.uint32(34).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TrainingInfoProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.initialization=p.onnx.GraphProto.decode(e,e.uint32());break;case 2:n.algorithm=p.onnx.GraphProto.decode(e,e.uint32());break;case 3:n.initializationBinding&&n.initializationBinding.length||(n.initializationBinding=[]),n.initializationBinding.push(p.onnx.StringStringEntryProto.decode(e,e.uint32()));break;case 4:n.updateBinding&&n.updateBinding.length||(n.updateBinding=[]),n.updateBinding.push(p.onnx.StringStringEntryProto.decode(e,e.uint32()));break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.initialization&&e.hasOwnProperty("initialization")){var t=p.onnx.GraphProto.verify(e.initialization);if(t)return"initialization."+t}if(null!=e.algorithm&&e.hasOwnProperty("algorithm")){var t=p.onnx.GraphProto.verify(e.algorithm);if(t)return"algorithm."+t}if(null!=e.initializationBinding&&e.hasOwnProperty("initializationBinding")){if(!Array.isArray(e.initializationBinding))return"initializationBinding: array expected";for(var r=0;r<e.initializationBinding.length;++r){var t=p.onnx.StringStringEntryProto.verify(e.initializationBinding[r]);if(t)return"initializationBinding."+t}}if(null!=e.updateBinding&&e.hasOwnProperty("updateBinding")){if(!Array.isArray(e.updateBinding))return"updateBinding: array expected";for(var r=0;r<e.updateBinding.length;++r){var t=p.onnx.StringStringEntryProto.verify(e.updateBinding[r]);if(t)return"updateBinding."+t}}return null},e.fromObject=function(e){if(e instanceof p.onnx.TrainingInfoProto)return e;var t=new p.onnx.TrainingInfoProto;if(null!=e.initialization){if("object"!=typeof e.initialization)throw TypeError(".onnx.TrainingInfoProto.initialization: object expected");t.initialization=p.onnx.GraphProto.fromObject(e.initialization)}if(null!=e.algorithm){if("object"!=typeof e.algorithm)throw TypeError(".onnx.TrainingInfoProto.algorithm: object expected");t.algorithm=p.onnx.GraphProto.fromObject(e.algorithm)}if(e.initializationBinding){if(!Array.isArray(e.initializationBinding))throw TypeError(".onnx.TrainingInfoProto.initializationBinding: array expected");t.initializationBinding=[];for(var r=0;r<e.initializationBinding.length;++r){if("object"!=typeof e.initializationBinding[r])throw TypeError(".onnx.TrainingInfoProto.initializationBinding: object expected");t.initializationBinding[r]=p.onnx.StringStringEntryProto.fromObject(e.initializationBinding[r])}}if(e.updateBinding){if(!Array.isArray(e.updateBinding))throw TypeError(".onnx.TrainingInfoProto.updateBinding: array expected");t.updateBinding=[];for(var r=0;r<e.updateBinding.length;++r){if("object"!=typeof e.updateBinding[r])throw TypeError(".onnx.TrainingInfoProto.updateBinding: object expected");t.updateBinding[r]=p.onnx.StringStringEntryProto.fromObject(e.updateBinding[r])}}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.initializationBinding=[],r.updateBinding=[]),t.defaults&&(r.initialization=null,r.algorithm=null),null!=e.initialization&&e.hasOwnProperty("initialization")&&(r.initialization=p.onnx.GraphProto.toObject(e.initialization,t)),null!=e.algorithm&&e.hasOwnProperty("algorithm")&&(r.algorithm=p.onnx.GraphProto.toObject(e.algorithm,t)),e.initializationBinding&&e.initializationBinding.length){r.initializationBinding=[];for(var n=0;n<e.initializationBinding.length;++n)r.initializationBinding[n]=p.onnx.StringStringEntryProto.toObject(e.initializationBinding[n],t)}if(e.updateBinding&&e.updateBinding.length){r.updateBinding=[];for(var n=0;n<e.updateBinding.length;++n)r.updateBinding[n]=p.onnx.StringStringEntryProto.toObject(e.updateBinding[n],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TrainingInfoProto"},e}(),r.ModelProto=function(){function e(e){if(this.opsetImport=[],this.metadataProps=[],this.trainingInfo=[],this.functions=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.irVersion=d.Long?d.Long.fromBits(0,0,!1):0,e.prototype.opsetImport=d.emptyArray,e.prototype.producerName="",e.prototype.producerVersion="",e.prototype.domain="",e.prototype.modelVersion=d.Long?d.Long.fromBits(0,0,!1):0,e.prototype.docString="",e.prototype.graph=null,e.prototype.metadataProps=d.emptyArray,e.prototype.trainingInfo=d.emptyArray,e.prototype.functions=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.irVersion&&Object.hasOwnProperty.call(e,"irVersion")&&t.uint32(8).int64(e.irVersion),null!=e.producerName&&Object.hasOwnProperty.call(e,"producerName")&&t.uint32(18).string(e.producerName),null!=e.producerVersion&&Object.hasOwnProperty.call(e,"producerVersion")&&t.uint32(26).string(e.producerVersion),null!=e.domain&&Object.hasOwnProperty.call(e,"domain")&&t.uint32(34).string(e.domain),null!=e.modelVersion&&Object.hasOwnProperty.call(e,"modelVersion")&&t.uint32(40).int64(e.modelVersion),null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(50).string(e.docString),null!=e.graph&&Object.hasOwnProperty.call(e,"graph")&&p.onnx.GraphProto.encode(e.graph,t.uint32(58).fork()).ldelim(),null!=e.opsetImport&&e.opsetImport.length)for(var r=0;r<e.opsetImport.length;++r)p.onnx.OperatorSetIdProto.encode(e.opsetImport[r],t.uint32(66).fork()).ldelim();if(null!=e.metadataProps&&e.metadataProps.length)for(var r=0;r<e.metadataProps.length;++r)p.onnx.StringStringEntryProto.encode(e.metadataProps[r],t.uint32(114).fork()).ldelim();if(null!=e.trainingInfo&&e.trainingInfo.length)for(var r=0;r<e.trainingInfo.length;++r)p.onnx.TrainingInfoProto.encode(e.trainingInfo[r],t.uint32(162).fork()).ldelim();if(null!=e.functions&&e.functions.length)for(var r=0;r<e.functions.length;++r)p.onnx.FunctionProto.encode(e.functions[r],t.uint32(202).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.ModelProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.irVersion=e.int64();break;case 8:n.opsetImport&&n.opsetImport.length||(n.opsetImport=[]),n.opsetImport.push(p.onnx.OperatorSetIdProto.decode(e,e.uint32()));break;case 2:n.producerName=e.string();break;case 3:n.producerVersion=e.string();break;case 4:n.domain=e.string();break;case 5:n.modelVersion=e.int64();break;case 6:n.docString=e.string();break;case 7:n.graph=p.onnx.GraphProto.decode(e,e.uint32());break;case 14:n.metadataProps&&n.metadataProps.length||(n.metadataProps=[]),n.metadataProps.push(p.onnx.StringStringEntryProto.decode(e,e.uint32()));break;case 20:n.trainingInfo&&n.trainingInfo.length||(n.trainingInfo=[]),n.trainingInfo.push(p.onnx.TrainingInfoProto.decode(e,e.uint32()));break;case 25:n.functions&&n.functions.length||(n.functions=[]),n.functions.push(p.onnx.FunctionProto.decode(e,e.uint32()));break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.irVersion&&e.hasOwnProperty("irVersion")&&!d.isInteger(e.irVersion)&&!(e.irVersion&&d.isInteger(e.irVersion.low)&&d.isInteger(e.irVersion.high)))return"irVersion: integer|Long expected";if(null!=e.opsetImport&&e.hasOwnProperty("opsetImport")){if(!Array.isArray(e.opsetImport))return"opsetImport: array expected";for(var t=0;t<e.opsetImport.length;++t){var r=p.onnx.OperatorSetIdProto.verify(e.opsetImport[t]);if(r)return"opsetImport."+r}}if(null!=e.producerName&&e.hasOwnProperty("producerName")&&!d.isString(e.producerName))return"producerName: string expected";if(null!=e.producerVersion&&e.hasOwnProperty("producerVersion")&&!d.isString(e.producerVersion))return"producerVersion: string expected";if(null!=e.domain&&e.hasOwnProperty("domain")&&!d.isString(e.domain))return"domain: string expected";if(null!=e.modelVersion&&e.hasOwnProperty("modelVersion")&&!d.isInteger(e.modelVersion)&&!(e.modelVersion&&d.isInteger(e.modelVersion.low)&&d.isInteger(e.modelVersion.high)))return"modelVersion: integer|Long expected";if(null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString))return"docString: string expected";if(null!=e.graph&&e.hasOwnProperty("graph")){var r=p.onnx.GraphProto.verify(e.graph);if(r)return"graph."+r}if(null!=e.metadataProps&&e.hasOwnProperty("metadataProps")){if(!Array.isArray(e.metadataProps))return"metadataProps: array expected";for(var t=0;t<e.metadataProps.length;++t){var r=p.onnx.StringStringEntryProto.verify(e.metadataProps[t]);if(r)return"metadataProps."+r}}if(null!=e.trainingInfo&&e.hasOwnProperty("trainingInfo")){if(!Array.isArray(e.trainingInfo))return"trainingInfo: array expected";for(var t=0;t<e.trainingInfo.length;++t){var r=p.onnx.TrainingInfoProto.verify(e.trainingInfo[t]);if(r)return"trainingInfo."+r}}if(null!=e.functions&&e.hasOwnProperty("functions")){if(!Array.isArray(e.functions))return"functions: array expected";for(var t=0;t<e.functions.length;++t){var r=p.onnx.FunctionProto.verify(e.functions[t]);if(r)return"functions."+r}}return null},e.fromObject=function(e){if(e instanceof p.onnx.ModelProto)return e;var t=new p.onnx.ModelProto;if(null!=e.irVersion&&(d.Long?(t.irVersion=d.Long.fromValue(e.irVersion)).unsigned=!1:"string"==typeof e.irVersion?t.irVersion=parseInt(e.irVersion,10):"number"==typeof e.irVersion?t.irVersion=e.irVersion:"object"==typeof e.irVersion&&(t.irVersion=new d.LongBits(e.irVersion.low>>>0,e.irVersion.high>>>0).toNumber())),e.opsetImport){if(!Array.isArray(e.opsetImport))throw TypeError(".onnx.ModelProto.opsetImport: array expected");t.opsetImport=[];for(var r=0;r<e.opsetImport.length;++r){if("object"!=typeof e.opsetImport[r])throw TypeError(".onnx.ModelProto.opsetImport: object expected");t.opsetImport[r]=p.onnx.OperatorSetIdProto.fromObject(e.opsetImport[r])}}if(null!=e.producerName&&(t.producerName=String(e.producerName)),null!=e.producerVersion&&(t.producerVersion=String(e.producerVersion)),null!=e.domain&&(t.domain=String(e.domain)),null!=e.modelVersion&&(d.Long?(t.modelVersion=d.Long.fromValue(e.modelVersion)).unsigned=!1:"string"==typeof e.modelVersion?t.modelVersion=parseInt(e.modelVersion,10):"number"==typeof e.modelVersion?t.modelVersion=e.modelVersion:"object"==typeof e.modelVersion&&(t.modelVersion=new d.LongBits(e.modelVersion.low>>>0,e.modelVersion.high>>>0).toNumber())),null!=e.docString&&(t.docString=String(e.docString)),null!=e.graph){if("object"!=typeof e.graph)throw TypeError(".onnx.ModelProto.graph: object expected");t.graph=p.onnx.GraphProto.fromObject(e.graph)}if(e.metadataProps){if(!Array.isArray(e.metadataProps))throw TypeError(".onnx.ModelProto.metadataProps: array expected");t.metadataProps=[];for(var r=0;r<e.metadataProps.length;++r){if("object"!=typeof e.metadataProps[r])throw TypeError(".onnx.ModelProto.metadataProps: object expected");t.metadataProps[r]=p.onnx.StringStringEntryProto.fromObject(e.metadataProps[r])}}if(e.trainingInfo){if(!Array.isArray(e.trainingInfo))throw TypeError(".onnx.ModelProto.trainingInfo: array expected");t.trainingInfo=[];for(var r=0;r<e.trainingInfo.length;++r){if("object"!=typeof e.trainingInfo[r])throw TypeError(".onnx.ModelProto.trainingInfo: object expected");t.trainingInfo[r]=p.onnx.TrainingInfoProto.fromObject(e.trainingInfo[r])}}if(e.functions){if(!Array.isArray(e.functions))throw TypeError(".onnx.ModelProto.functions: array expected");t.functions=[];for(var r=0;r<e.functions.length;++r){if("object"!=typeof e.functions[r])throw TypeError(".onnx.ModelProto.functions: object expected");t.functions[r]=p.onnx.FunctionProto.fromObject(e.functions[r])}}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.opsetImport=[],r.metadataProps=[],r.trainingInfo=[],r.functions=[]),t.defaults){if(d.Long){var n=new d.Long(0,0,!1);r.irVersion=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.irVersion=t.longs===String?"0":0;if(r.producerName="",r.producerVersion="",r.domain="",d.Long){var n=new d.Long(0,0,!1);r.modelVersion=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.modelVersion=t.longs===String?"0":0;r.docString="",r.graph=null}if(null!=e.irVersion&&e.hasOwnProperty("irVersion")&&("number"==typeof e.irVersion?r.irVersion=t.longs===String?String(e.irVersion):e.irVersion:r.irVersion=t.longs===String?d.Long.prototype.toString.call(e.irVersion):t.longs===Number?new d.LongBits(e.irVersion.low>>>0,e.irVersion.high>>>0).toNumber():e.irVersion),null!=e.producerName&&e.hasOwnProperty("producerName")&&(r.producerName=e.producerName),null!=e.producerVersion&&e.hasOwnProperty("producerVersion")&&(r.producerVersion=e.producerVersion),null!=e.domain&&e.hasOwnProperty("domain")&&(r.domain=e.domain),null!=e.modelVersion&&e.hasOwnProperty("modelVersion")&&("number"==typeof e.modelVersion?r.modelVersion=t.longs===String?String(e.modelVersion):e.modelVersion:r.modelVersion=t.longs===String?d.Long.prototype.toString.call(e.modelVersion):t.longs===Number?new d.LongBits(e.modelVersion.low>>>0,e.modelVersion.high>>>0).toNumber():e.modelVersion),null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),null!=e.graph&&e.hasOwnProperty("graph")&&(r.graph=p.onnx.GraphProto.toObject(e.graph,t)),e.opsetImport&&e.opsetImport.length){r.opsetImport=[];for(var i=0;i<e.opsetImport.length;++i)r.opsetImport[i]=p.onnx.OperatorSetIdProto.toObject(e.opsetImport[i],t)}if(e.metadataProps&&e.metadataProps.length){r.metadataProps=[];for(var i=0;i<e.metadataProps.length;++i)r.metadataProps[i]=p.onnx.StringStringEntryProto.toObject(e.metadataProps[i],t)}if(e.trainingInfo&&e.trainingInfo.length){r.trainingInfo=[];for(var i=0;i<e.trainingInfo.length;++i)r.trainingInfo[i]=p.onnx.TrainingInfoProto.toObject(e.trainingInfo[i],t)}if(e.functions&&e.functions.length){r.functions=[];for(var i=0;i<e.functions.length;++i)r.functions[i]=p.onnx.FunctionProto.toObject(e.functions[i],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.ModelProto"},e}(),r.StringStringEntryProto=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.key="",e.prototype.value="",e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.key&&Object.hasOwnProperty.call(e,"key")&&t.uint32(10).string(e.key),null!=e.value&&Object.hasOwnProperty.call(e,"value")&&t.uint32(18).string(e.value),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.StringStringEntryProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.key=e.string();break;case 2:n.value=e.string();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){return"object"!=typeof e||null===e?"object expected":null!=e.key&&e.hasOwnProperty("key")&&!d.isString(e.key)?"key: string expected":null!=e.value&&e.hasOwnProperty("value")&&!d.isString(e.value)?"value: string expected":null},e.fromObject=function(e){if(e instanceof p.onnx.StringStringEntryProto)return e;var t=new p.onnx.StringStringEntryProto;return null!=e.key&&(t.key=String(e.key)),null!=e.value&&(t.value=String(e.value)),t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.key="",r.value=""),null!=e.key&&e.hasOwnProperty("key")&&(r.key=e.key),null!=e.value&&e.hasOwnProperty("value")&&(r.value=e.value),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.StringStringEntryProto"},e}(),r.TensorAnnotation=function(){function e(e){if(this.quantParameterTensorNames=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.tensorName="",e.prototype.quantParameterTensorNames=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.tensorName&&Object.hasOwnProperty.call(e,"tensorName")&&t.uint32(10).string(e.tensorName),null!=e.quantParameterTensorNames&&e.quantParameterTensorNames.length)for(var r=0;r<e.quantParameterTensorNames.length;++r)p.onnx.StringStringEntryProto.encode(e.quantParameterTensorNames[r],t.uint32(18).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TensorAnnotation;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.tensorName=e.string();break;case 2:n.quantParameterTensorNames&&n.quantParameterTensorNames.length||(n.quantParameterTensorNames=[]),n.quantParameterTensorNames.push(p.onnx.StringStringEntryProto.decode(e,e.uint32()));break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.tensorName&&e.hasOwnProperty("tensorName")&&!d.isString(e.tensorName))return"tensorName: string expected";if(null!=e.quantParameterTensorNames&&e.hasOwnProperty("quantParameterTensorNames")){if(!Array.isArray(e.quantParameterTensorNames))return"quantParameterTensorNames: array expected";for(var t=0;t<e.quantParameterTensorNames.length;++t){var r=p.onnx.StringStringEntryProto.verify(e.quantParameterTensorNames[t]);if(r)return"quantParameterTensorNames."+r}}return null},e.fromObject=function(e){if(e instanceof p.onnx.TensorAnnotation)return e;var t=new p.onnx.TensorAnnotation;if(null!=e.tensorName&&(t.tensorName=String(e.tensorName)),e.quantParameterTensorNames){if(!Array.isArray(e.quantParameterTensorNames))throw TypeError(".onnx.TensorAnnotation.quantParameterTensorNames: array expected");t.quantParameterTensorNames=[];for(var r=0;r<e.quantParameterTensorNames.length;++r){if("object"!=typeof e.quantParameterTensorNames[r])throw TypeError(".onnx.TensorAnnotation.quantParameterTensorNames: object expected");t.quantParameterTensorNames[r]=p.onnx.StringStringEntryProto.fromObject(e.quantParameterTensorNames[r])}}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.quantParameterTensorNames=[]),t.defaults&&(r.tensorName=""),null!=e.tensorName&&e.hasOwnProperty("tensorName")&&(r.tensorName=e.tensorName),e.quantParameterTensorNames&&e.quantParameterTensorNames.length){r.quantParameterTensorNames=[];for(var n=0;n<e.quantParameterTensorNames.length;++n)r.quantParameterTensorNames[n]=p.onnx.StringStringEntryProto.toObject(e.quantParameterTensorNames[n],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TensorAnnotation"},e}(),r.GraphProto=function(){function e(e){if(this.node=[],this.initializer=[],this.sparseInitializer=[],this.input=[],this.output=[],this.valueInfo=[],this.quantizationAnnotation=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.node=d.emptyArray,e.prototype.name="",e.prototype.initializer=d.emptyArray,e.prototype.sparseInitializer=d.emptyArray,e.prototype.docString="",e.prototype.input=d.emptyArray,e.prototype.output=d.emptyArray,e.prototype.valueInfo=d.emptyArray,e.prototype.quantizationAnnotation=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.node&&e.node.length)for(var r=0;r<e.node.length;++r)p.onnx.NodeProto.encode(e.node[r],t.uint32(10).fork()).ldelim();if(null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(18).string(e.name),null!=e.initializer&&e.initializer.length)for(var r=0;r<e.initializer.length;++r)p.onnx.TensorProto.encode(e.initializer[r],t.uint32(42).fork()).ldelim();if(null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(82).string(e.docString),null!=e.input&&e.input.length)for(var r=0;r<e.input.length;++r)p.onnx.ValueInfoProto.encode(e.input[r],t.uint32(90).fork()).ldelim();if(null!=e.output&&e.output.length)for(var r=0;r<e.output.length;++r)p.onnx.ValueInfoProto.encode(e.output[r],t.uint32(98).fork()).ldelim();if(null!=e.valueInfo&&e.valueInfo.length)for(var r=0;r<e.valueInfo.length;++r)p.onnx.ValueInfoProto.encode(e.valueInfo[r],t.uint32(106).fork()).ldelim();if(null!=e.quantizationAnnotation&&e.quantizationAnnotation.length)for(var r=0;r<e.quantizationAnnotation.length;++r)p.onnx.TensorAnnotation.encode(e.quantizationAnnotation[r],t.uint32(114).fork()).ldelim();if(null!=e.sparseInitializer&&e.sparseInitializer.length)for(var r=0;r<e.sparseInitializer.length;++r)p.onnx.SparseTensorProto.encode(e.sparseInitializer[r],t.uint32(122).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.GraphProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.node&&n.node.length||(n.node=[]),n.node.push(p.onnx.NodeProto.decode(e,e.uint32()));break;case 2:n.name=e.string();break;case 5:n.initializer&&n.initializer.length||(n.initializer=[]),n.initializer.push(p.onnx.TensorProto.decode(e,e.uint32()));break;case 15:n.sparseInitializer&&n.sparseInitializer.length||(n.sparseInitializer=[]),n.sparseInitializer.push(p.onnx.SparseTensorProto.decode(e,e.uint32()));break;case 10:n.docString=e.string();break;case 11:n.input&&n.input.length||(n.input=[]),n.input.push(p.onnx.ValueInfoProto.decode(e,e.uint32()));break;case 12:n.output&&n.output.length||(n.output=[]),n.output.push(p.onnx.ValueInfoProto.decode(e,e.uint32()));break;case 13:n.valueInfo&&n.valueInfo.length||(n.valueInfo=[]),n.valueInfo.push(p.onnx.ValueInfoProto.decode(e,e.uint32()));break;case 14:n.quantizationAnnotation&&n.quantizationAnnotation.length||(n.quantizationAnnotation=[]),n.quantizationAnnotation.push(p.onnx.TensorAnnotation.decode(e,e.uint32()));break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.node&&e.hasOwnProperty("node")){if(!Array.isArray(e.node))return"node: array expected";for(var t=0;t<e.node.length;++t){var r=p.onnx.NodeProto.verify(e.node[t]);if(r)return"node."+r}}if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.initializer&&e.hasOwnProperty("initializer")){if(!Array.isArray(e.initializer))return"initializer: array expected";for(var t=0;t<e.initializer.length;++t){var r=p.onnx.TensorProto.verify(e.initializer[t]);if(r)return"initializer."+r}}if(null!=e.sparseInitializer&&e.hasOwnProperty("sparseInitializer")){if(!Array.isArray(e.sparseInitializer))return"sparseInitializer: array expected";for(var t=0;t<e.sparseInitializer.length;++t){var r=p.onnx.SparseTensorProto.verify(e.sparseInitializer[t]);if(r)return"sparseInitializer."+r}}if(null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString))return"docString: string expected";if(null!=e.input&&e.hasOwnProperty("input")){if(!Array.isArray(e.input))return"input: array expected";for(var t=0;t<e.input.length;++t){var r=p.onnx.ValueInfoProto.verify(e.input[t]);if(r)return"input."+r}}if(null!=e.output&&e.hasOwnProperty("output")){if(!Array.isArray(e.output))return"output: array expected";for(var t=0;t<e.output.length;++t){var r=p.onnx.ValueInfoProto.verify(e.output[t]);if(r)return"output."+r}}if(null!=e.valueInfo&&e.hasOwnProperty("valueInfo")){if(!Array.isArray(e.valueInfo))return"valueInfo: array expected";for(var t=0;t<e.valueInfo.length;++t){var r=p.onnx.ValueInfoProto.verify(e.valueInfo[t]);if(r)return"valueInfo."+r}}if(null!=e.quantizationAnnotation&&e.hasOwnProperty("quantizationAnnotation")){if(!Array.isArray(e.quantizationAnnotation))return"quantizationAnnotation: array expected";for(var t=0;t<e.quantizationAnnotation.length;++t){var r=p.onnx.TensorAnnotation.verify(e.quantizationAnnotation[t]);if(r)return"quantizationAnnotation."+r}}return null},e.fromObject=function(e){if(e instanceof p.onnx.GraphProto)return e;var t=new p.onnx.GraphProto;if(e.node){if(!Array.isArray(e.node))throw TypeError(".onnx.GraphProto.node: array expected");t.node=[];for(var r=0;r<e.node.length;++r){if("object"!=typeof e.node[r])throw TypeError(".onnx.GraphProto.node: object expected");t.node[r]=p.onnx.NodeProto.fromObject(e.node[r])}}if(null!=e.name&&(t.name=String(e.name)),e.initializer){if(!Array.isArray(e.initializer))throw TypeError(".onnx.GraphProto.initializer: array expected");t.initializer=[];for(var r=0;r<e.initializer.length;++r){if("object"!=typeof e.initializer[r])throw TypeError(".onnx.GraphProto.initializer: object expected");t.initializer[r]=p.onnx.TensorProto.fromObject(e.initializer[r])}}if(e.sparseInitializer){if(!Array.isArray(e.sparseInitializer))throw TypeError(".onnx.GraphProto.sparseInitializer: array expected");t.sparseInitializer=[];for(var r=0;r<e.sparseInitializer.length;++r){if("object"!=typeof e.sparseInitializer[r])throw TypeError(".onnx.GraphProto.sparseInitializer: object expected");t.sparseInitializer[r]=p.onnx.SparseTensorProto.fromObject(e.sparseInitializer[r])}}if(null!=e.docString&&(t.docString=String(e.docString)),e.input){if(!Array.isArray(e.input))throw TypeError(".onnx.GraphProto.input: array expected");t.input=[];for(var r=0;r<e.input.length;++r){if("object"!=typeof e.input[r])throw TypeError(".onnx.GraphProto.input: object expected");t.input[r]=p.onnx.ValueInfoProto.fromObject(e.input[r])}}if(e.output){if(!Array.isArray(e.output))throw TypeError(".onnx.GraphProto.output: array expected");t.output=[];for(var r=0;r<e.output.length;++r){if("object"!=typeof e.output[r])throw TypeError(".onnx.GraphProto.output: object expected");t.output[r]=p.onnx.ValueInfoProto.fromObject(e.output[r])}}if(e.valueInfo){if(!Array.isArray(e.valueInfo))throw TypeError(".onnx.GraphProto.valueInfo: array expected");t.valueInfo=[];for(var r=0;r<e.valueInfo.length;++r){if("object"!=typeof e.valueInfo[r])throw TypeError(".onnx.GraphProto.valueInfo: object expected");t.valueInfo[r]=p.onnx.ValueInfoProto.fromObject(e.valueInfo[r])}}if(e.quantizationAnnotation){if(!Array.isArray(e.quantizationAnnotation))throw TypeError(".onnx.GraphProto.quantizationAnnotation: array expected");t.quantizationAnnotation=[];for(var r=0;r<e.quantizationAnnotation.length;++r){if("object"!=typeof e.quantizationAnnotation[r])throw TypeError(".onnx.GraphProto.quantizationAnnotation: object expected");t.quantizationAnnotation[r]=p.onnx.TensorAnnotation.fromObject(e.quantizationAnnotation[r])}}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.node=[],r.initializer=[],r.input=[],r.output=[],r.valueInfo=[],r.quantizationAnnotation=[],r.sparseInitializer=[]),t.defaults&&(r.name="",r.docString=""),e.node&&e.node.length){r.node=[];for(var n=0;n<e.node.length;++n)r.node[n]=p.onnx.NodeProto.toObject(e.node[n],t)}if(null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),e.initializer&&e.initializer.length){r.initializer=[];for(var n=0;n<e.initializer.length;++n)r.initializer[n]=p.onnx.TensorProto.toObject(e.initializer[n],t)}if(null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),e.input&&e.input.length){r.input=[];for(var n=0;n<e.input.length;++n)r.input[n]=p.onnx.ValueInfoProto.toObject(e.input[n],t)}if(e.output&&e.output.length){r.output=[];for(var n=0;n<e.output.length;++n)r.output[n]=p.onnx.ValueInfoProto.toObject(e.output[n],t)}if(e.valueInfo&&e.valueInfo.length){r.valueInfo=[];for(var n=0;n<e.valueInfo.length;++n)r.valueInfo[n]=p.onnx.ValueInfoProto.toObject(e.valueInfo[n],t)}if(e.quantizationAnnotation&&e.quantizationAnnotation.length){r.quantizationAnnotation=[];for(var n=0;n<e.quantizationAnnotation.length;++n)r.quantizationAnnotation[n]=p.onnx.TensorAnnotation.toObject(e.quantizationAnnotation[n],t)}if(e.sparseInitializer&&e.sparseInitializer.length){r.sparseInitializer=[];for(var n=0;n<e.sparseInitializer.length;++n)r.sparseInitializer[n]=p.onnx.SparseTensorProto.toObject(e.sparseInitializer[n],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.GraphProto"},e}(),r.TensorProto=function(){var e,t,r,n;function i(e){if(this.dims=[],this.floatData=[],this.int32Data=[],this.stringData=[],this.int64Data=[],this.externalData=[],this.doubleData=[],this.uint64Data=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return i.prototype.dims=d.emptyArray,i.prototype.dataType=0,i.prototype.segment=null,i.prototype.floatData=d.emptyArray,i.prototype.int32Data=d.emptyArray,i.prototype.stringData=d.emptyArray,i.prototype.int64Data=d.emptyArray,i.prototype.name="",i.prototype.docString="",i.prototype.rawData=d.newBuffer([]),i.prototype.externalData=d.emptyArray,i.prototype.dataLocation=0,i.prototype.doubleData=d.emptyArray,i.prototype.uint64Data=d.emptyArray,i.create=function(e){return new i(e)},i.encode=function(e,t){if(t||(t=l.create()),null!=e.dims&&e.dims.length){t.uint32(10).fork();for(var r=0;r<e.dims.length;++r)t.int64(e.dims[r]);t.ldelim()}if(null!=e.dataType&&Object.hasOwnProperty.call(e,"dataType")&&t.uint32(16).int32(e.dataType),null!=e.segment&&Object.hasOwnProperty.call(e,"segment")&&p.onnx.TensorProto.Segment.encode(e.segment,t.uint32(26).fork()).ldelim(),null!=e.floatData&&e.floatData.length){t.uint32(34).fork();for(var r=0;r<e.floatData.length;++r)t.float(e.floatData[r]);t.ldelim()}if(null!=e.int32Data&&e.int32Data.length){t.uint32(42).fork();for(var r=0;r<e.int32Data.length;++r)t.int32(e.int32Data[r]);t.ldelim()}if(null!=e.stringData&&e.stringData.length)for(var r=0;r<e.stringData.length;++r)t.uint32(50).bytes(e.stringData[r]);if(null!=e.int64Data&&e.int64Data.length){t.uint32(58).fork();for(var r=0;r<e.int64Data.length;++r)t.int64(e.int64Data[r]);t.ldelim()}if(null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(66).string(e.name),null!=e.rawData&&Object.hasOwnProperty.call(e,"rawData")&&t.uint32(74).bytes(e.rawData),null!=e.doubleData&&e.doubleData.length){t.uint32(82).fork();for(var r=0;r<e.doubleData.length;++r)t.double(e.doubleData[r]);t.ldelim()}if(null!=e.uint64Data&&e.uint64Data.length){t.uint32(90).fork();for(var r=0;r<e.uint64Data.length;++r)t.uint64(e.uint64Data[r]);t.ldelim()}if(null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(98).string(e.docString),null!=e.externalData&&e.externalData.length)for(var r=0;r<e.externalData.length;++r)p.onnx.StringStringEntryProto.encode(e.externalData[r],t.uint32(106).fork()).ldelim();return null!=e.dataLocation&&Object.hasOwnProperty.call(e,"dataLocation")&&t.uint32(112).int32(e.dataLocation),t},i.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},i.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TensorProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:if(n.dims&&n.dims.length||(n.dims=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.dims.push(e.int64());else n.dims.push(e.int64());break;case 2:n.dataType=e.int32();break;case 3:n.segment=p.onnx.TensorProto.Segment.decode(e,e.uint32());break;case 4:if(n.floatData&&n.floatData.length||(n.floatData=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.floatData.push(e.float());else n.floatData.push(e.float());break;case 5:if(n.int32Data&&n.int32Data.length||(n.int32Data=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.int32Data.push(e.int32());else n.int32Data.push(e.int32());break;case 6:n.stringData&&n.stringData.length||(n.stringData=[]),n.stringData.push(e.bytes());break;case 7:if(n.int64Data&&n.int64Data.length||(n.int64Data=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.int64Data.push(e.int64());else n.int64Data.push(e.int64());break;case 8:n.name=e.string();break;case 12:n.docString=e.string();break;case 9:n.rawData=e.bytes();break;case 13:n.externalData&&n.externalData.length||(n.externalData=[]),n.externalData.push(p.onnx.StringStringEntryProto.decode(e,e.uint32()));break;case 14:n.dataLocation=e.int32();break;case 10:if(n.doubleData&&n.doubleData.length||(n.doubleData=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.doubleData.push(e.double());else n.doubleData.push(e.double());break;case 11:if(n.uint64Data&&n.uint64Data.length||(n.uint64Data=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.uint64Data.push(e.uint64());else n.uint64Data.push(e.uint64());break;default:e.skipType(7&i)}}return n},i.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},i.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.dims&&e.hasOwnProperty("dims")){if(!Array.isArray(e.dims))return"dims: array expected";for(var t=0;t<e.dims.length;++t)if(!d.isInteger(e.dims[t])&&!(e.dims[t]&&d.isInteger(e.dims[t].low)&&d.isInteger(e.dims[t].high)))return"dims: integer|Long[] expected"}if(null!=e.dataType&&e.hasOwnProperty("dataType")&&!d.isInteger(e.dataType))return"dataType: integer expected";if(null!=e.segment&&e.hasOwnProperty("segment")){var r=p.onnx.TensorProto.Segment.verify(e.segment);if(r)return"segment."+r}if(null!=e.floatData&&e.hasOwnProperty("floatData")){if(!Array.isArray(e.floatData))return"floatData: array expected";for(var t=0;t<e.floatData.length;++t)if("number"!=typeof e.floatData[t])return"floatData: number[] expected"}if(null!=e.int32Data&&e.hasOwnProperty("int32Data")){if(!Array.isArray(e.int32Data))return"int32Data: array expected";for(var t=0;t<e.int32Data.length;++t)if(!d.isInteger(e.int32Data[t]))return"int32Data: integer[] expected"}if(null!=e.stringData&&e.hasOwnProperty("stringData")){if(!Array.isArray(e.stringData))return"stringData: array expected";for(var t=0;t<e.stringData.length;++t)if(!(e.stringData[t]&&"number"==typeof e.stringData[t].length||d.isString(e.stringData[t])))return"stringData: buffer[] expected"}if(null!=e.int64Data&&e.hasOwnProperty("int64Data")){if(!Array.isArray(e.int64Data))return"int64Data: array expected";for(var t=0;t<e.int64Data.length;++t)if(!d.isInteger(e.int64Data[t])&&!(e.int64Data[t]&&d.isInteger(e.int64Data[t].low)&&d.isInteger(e.int64Data[t].high)))return"int64Data: integer|Long[] expected"}if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString))return"docString: string expected";if(null!=e.rawData&&e.hasOwnProperty("rawData")&&!(e.rawData&&"number"==typeof e.rawData.length||d.isString(e.rawData)))return"rawData: buffer expected";if(null!=e.externalData&&e.hasOwnProperty("externalData")){if(!Array.isArray(e.externalData))return"externalData: array expected";for(var t=0;t<e.externalData.length;++t){var r=p.onnx.StringStringEntryProto.verify(e.externalData[t]);if(r)return"externalData."+r}}if(null!=e.dataLocation&&e.hasOwnProperty("dataLocation"))switch(e.dataLocation){default:return"dataLocation: enum value expected";case 0:case 1:}if(null!=e.doubleData&&e.hasOwnProperty("doubleData")){if(!Array.isArray(e.doubleData))return"doubleData: array expected";for(var t=0;t<e.doubleData.length;++t)if("number"!=typeof e.doubleData[t])return"doubleData: number[] expected"}if(null!=e.uint64Data&&e.hasOwnProperty("uint64Data")){if(!Array.isArray(e.uint64Data))return"uint64Data: array expected";for(var t=0;t<e.uint64Data.length;++t)if(!d.isInteger(e.uint64Data[t])&&!(e.uint64Data[t]&&d.isInteger(e.uint64Data[t].low)&&d.isInteger(e.uint64Data[t].high)))return"uint64Data: integer|Long[] expected"}return null},i.fromObject=function(e){if(e instanceof p.onnx.TensorProto)return e;var t=new p.onnx.TensorProto;if(e.dims){if(!Array.isArray(e.dims))throw TypeError(".onnx.TensorProto.dims: array expected");t.dims=[];for(var r=0;r<e.dims.length;++r)d.Long?(t.dims[r]=d.Long.fromValue(e.dims[r])).unsigned=!1:"string"==typeof e.dims[r]?t.dims[r]=parseInt(e.dims[r],10):"number"==typeof e.dims[r]?t.dims[r]=e.dims[r]:"object"==typeof e.dims[r]&&(t.dims[r]=new d.LongBits(e.dims[r].low>>>0,e.dims[r].high>>>0).toNumber())}if(null!=e.dataType&&(t.dataType=0|e.dataType),null!=e.segment){if("object"!=typeof e.segment)throw TypeError(".onnx.TensorProto.segment: object expected");t.segment=p.onnx.TensorProto.Segment.fromObject(e.segment)}if(e.floatData){if(!Array.isArray(e.floatData))throw TypeError(".onnx.TensorProto.floatData: array expected");t.floatData=[];for(var r=0;r<e.floatData.length;++r)t.floatData[r]=Number(e.floatData[r])}if(e.int32Data){if(!Array.isArray(e.int32Data))throw TypeError(".onnx.TensorProto.int32Data: array expected");t.int32Data=[];for(var r=0;r<e.int32Data.length;++r)t.int32Data[r]=0|e.int32Data[r]}if(e.stringData){if(!Array.isArray(e.stringData))throw TypeError(".onnx.TensorProto.stringData: array expected");t.stringData=[];for(var r=0;r<e.stringData.length;++r)"string"==typeof e.stringData[r]?d.base64.decode(e.stringData[r],t.stringData[r]=d.newBuffer(d.base64.length(e.stringData[r])),0):e.stringData[r].length>=0&&(t.stringData[r]=e.stringData[r])}if(e.int64Data){if(!Array.isArray(e.int64Data))throw TypeError(".onnx.TensorProto.int64Data: array expected");t.int64Data=[];for(var r=0;r<e.int64Data.length;++r)d.Long?(t.int64Data[r]=d.Long.fromValue(e.int64Data[r])).unsigned=!1:"string"==typeof e.int64Data[r]?t.int64Data[r]=parseInt(e.int64Data[r],10):"number"==typeof e.int64Data[r]?t.int64Data[r]=e.int64Data[r]:"object"==typeof e.int64Data[r]&&(t.int64Data[r]=new d.LongBits(e.int64Data[r].low>>>0,e.int64Data[r].high>>>0).toNumber())}if(null!=e.name&&(t.name=String(e.name)),null!=e.docString&&(t.docString=String(e.docString)),null!=e.rawData&&("string"==typeof e.rawData?d.base64.decode(e.rawData,t.rawData=d.newBuffer(d.base64.length(e.rawData)),0):e.rawData.length>=0&&(t.rawData=e.rawData)),e.externalData){if(!Array.isArray(e.externalData))throw TypeError(".onnx.TensorProto.externalData: array expected");t.externalData=[];for(var r=0;r<e.externalData.length;++r){if("object"!=typeof e.externalData[r])throw TypeError(".onnx.TensorProto.externalData: object expected");t.externalData[r]=p.onnx.StringStringEntryProto.fromObject(e.externalData[r])}}switch(e.dataLocation){default:"number"==typeof e.dataLocation&&(t.dataLocation=e.dataLocation);break;case"DEFAULT":case 0:t.dataLocation=0;break;case"EXTERNAL":case 1:t.dataLocation=1}if(e.doubleData){if(!Array.isArray(e.doubleData))throw TypeError(".onnx.TensorProto.doubleData: array expected");t.doubleData=[];for(var r=0;r<e.doubleData.length;++r)t.doubleData[r]=Number(e.doubleData[r])}if(e.uint64Data){if(!Array.isArray(e.uint64Data))throw TypeError(".onnx.TensorProto.uint64Data: array expected");t.uint64Data=[];for(var r=0;r<e.uint64Data.length;++r)d.Long?(t.uint64Data[r]=d.Long.fromValue(e.uint64Data[r])).unsigned=!0:"string"==typeof e.uint64Data[r]?t.uint64Data[r]=parseInt(e.uint64Data[r],10):"number"==typeof e.uint64Data[r]?t.uint64Data[r]=e.uint64Data[r]:"object"==typeof e.uint64Data[r]&&(t.uint64Data[r]=new d.LongBits(e.uint64Data[r].low>>>0,e.uint64Data[r].high>>>0).toNumber(!0))}return t},i.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.dims=[],r.floatData=[],r.int32Data=[],r.stringData=[],r.int64Data=[],r.doubleData=[],r.uint64Data=[],r.externalData=[]),t.defaults&&(r.dataType=0,r.segment=null,r.name="",t.bytes===String?r.rawData="":(r.rawData=[],t.bytes!==Array&&(r.rawData=d.newBuffer(r.rawData))),r.docString="",r.dataLocation=t.enums===String?"DEFAULT":0),e.dims&&e.dims.length){r.dims=[];for(var n=0;n<e.dims.length;++n)"number"==typeof e.dims[n]?r.dims[n]=t.longs===String?String(e.dims[n]):e.dims[n]:r.dims[n]=t.longs===String?d.Long.prototype.toString.call(e.dims[n]):t.longs===Number?new d.LongBits(e.dims[n].low>>>0,e.dims[n].high>>>0).toNumber():e.dims[n]}if(null!=e.dataType&&e.hasOwnProperty("dataType")&&(r.dataType=e.dataType),null!=e.segment&&e.hasOwnProperty("segment")&&(r.segment=p.onnx.TensorProto.Segment.toObject(e.segment,t)),e.floatData&&e.floatData.length){r.floatData=[];for(var n=0;n<e.floatData.length;++n)r.floatData[n]=t.json&&!isFinite(e.floatData[n])?String(e.floatData[n]):e.floatData[n]}if(e.int32Data&&e.int32Data.length){r.int32Data=[];for(var n=0;n<e.int32Data.length;++n)r.int32Data[n]=e.int32Data[n]}if(e.stringData&&e.stringData.length){r.stringData=[];for(var n=0;n<e.stringData.length;++n)r.stringData[n]=t.bytes===String?d.base64.encode(e.stringData[n],0,e.stringData[n].length):t.bytes===Array?Array.prototype.slice.call(e.stringData[n]):e.stringData[n]}if(e.int64Data&&e.int64Data.length){r.int64Data=[];for(var n=0;n<e.int64Data.length;++n)"number"==typeof e.int64Data[n]?r.int64Data[n]=t.longs===String?String(e.int64Data[n]):e.int64Data[n]:r.int64Data[n]=t.longs===String?d.Long.prototype.toString.call(e.int64Data[n]):t.longs===Number?new d.LongBits(e.int64Data[n].low>>>0,e.int64Data[n].high>>>0).toNumber():e.int64Data[n]}if(null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),null!=e.rawData&&e.hasOwnProperty("rawData")&&(r.rawData=t.bytes===String?d.base64.encode(e.rawData,0,e.rawData.length):t.bytes===Array?Array.prototype.slice.call(e.rawData):e.rawData),e.doubleData&&e.doubleData.length){r.doubleData=[];for(var n=0;n<e.doubleData.length;++n)r.doubleData[n]=t.json&&!isFinite(e.doubleData[n])?String(e.doubleData[n]):e.doubleData[n]}if(e.uint64Data&&e.uint64Data.length){r.uint64Data=[];for(var n=0;n<e.uint64Data.length;++n)"number"==typeof e.uint64Data[n]?r.uint64Data[n]=t.longs===String?String(e.uint64Data[n]):e.uint64Data[n]:r.uint64Data[n]=t.longs===String?d.Long.prototype.toString.call(e.uint64Data[n]):t.longs===Number?new d.LongBits(e.uint64Data[n].low>>>0,e.uint64Data[n].high>>>0).toNumber(!0):e.uint64Data[n]}if(null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),e.externalData&&e.externalData.length){r.externalData=[];for(var n=0;n<e.externalData.length;++n)r.externalData[n]=p.onnx.StringStringEntryProto.toObject(e.externalData[n],t)}return null!=e.dataLocation&&e.hasOwnProperty("dataLocation")&&(r.dataLocation=t.enums===String?void 0===p.onnx.TensorProto.DataLocation[e.dataLocation]?e.dataLocation:p.onnx.TensorProto.DataLocation[e.dataLocation]:e.dataLocation),r},i.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},i.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TensorProto"},(t=Object.create(e={}))[e[0]="UNDEFINED"]=0,t[e[1]="FLOAT"]=1,t[e[2]="UINT8"]=2,t[e[3]="INT8"]=3,t[e[4]="UINT16"]=4,t[e[5]="INT16"]=5,t[e[6]="INT32"]=6,t[e[7]="INT64"]=7,t[e[8]="STRING"]=8,t[e[9]="BOOL"]=9,t[e[10]="FLOAT16"]=10,t[e[11]="DOUBLE"]=11,t[e[12]="UINT32"]=12,t[e[13]="UINT64"]=13,t[e[14]="COMPLEX64"]=14,t[e[15]="COMPLEX128"]=15,t[e[16]="BFLOAT16"]=16,t[e[17]="FLOAT8E4M3FN"]=17,t[e[18]="FLOAT8E4M3FNUZ"]=18,t[e[19]="FLOAT8E5M2"]=19,t[e[20]="FLOAT8E5M2FNUZ"]=20,i.DataType=t,i.Segment=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.begin=d.Long?d.Long.fromBits(0,0,!1):0,e.prototype.end=d.Long?d.Long.fromBits(0,0,!1):0,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.begin&&Object.hasOwnProperty.call(e,"begin")&&t.uint32(8).int64(e.begin),null!=e.end&&Object.hasOwnProperty.call(e,"end")&&t.uint32(16).int64(e.end),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TensorProto.Segment;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.begin=e.int64();break;case 2:n.end=e.int64();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){return"object"!=typeof e||null===e?"object expected":null!=e.begin&&e.hasOwnProperty("begin")&&!d.isInteger(e.begin)&&!(e.begin&&d.isInteger(e.begin.low)&&d.isInteger(e.begin.high))?"begin: integer|Long expected":null!=e.end&&e.hasOwnProperty("end")&&!d.isInteger(e.end)&&!(e.end&&d.isInteger(e.end.low)&&d.isInteger(e.end.high))?"end: integer|Long expected":null},e.fromObject=function(e){if(e instanceof p.onnx.TensorProto.Segment)return e;var t=new p.onnx.TensorProto.Segment;return null!=e.begin&&(d.Long?(t.begin=d.Long.fromValue(e.begin)).unsigned=!1:"string"==typeof e.begin?t.begin=parseInt(e.begin,10):"number"==typeof e.begin?t.begin=e.begin:"object"==typeof e.begin&&(t.begin=new d.LongBits(e.begin.low>>>0,e.begin.high>>>0).toNumber())),null!=e.end&&(d.Long?(t.end=d.Long.fromValue(e.end)).unsigned=!1:"string"==typeof e.end?t.end=parseInt(e.end,10):"number"==typeof e.end?t.end=e.end:"object"==typeof e.end&&(t.end=new d.LongBits(e.end.low>>>0,e.end.high>>>0).toNumber())),t},e.toObject=function(e,t){t||(t={});var r={};if(t.defaults){if(d.Long){var n=new d.Long(0,0,!1);r.begin=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.begin=t.longs===String?"0":0;if(d.Long){var n=new d.Long(0,0,!1);r.end=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.end=t.longs===String?"0":0}return null!=e.begin&&e.hasOwnProperty("begin")&&("number"==typeof e.begin?r.begin=t.longs===String?String(e.begin):e.begin:r.begin=t.longs===String?d.Long.prototype.toString.call(e.begin):t.longs===Number?new d.LongBits(e.begin.low>>>0,e.begin.high>>>0).toNumber():e.begin),null!=e.end&&e.hasOwnProperty("end")&&("number"==typeof e.end?r.end=t.longs===String?String(e.end):e.end:r.end=t.longs===String?d.Long.prototype.toString.call(e.end):t.longs===Number?new d.LongBits(e.end.low>>>0,e.end.high>>>0).toNumber():e.end),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TensorProto.Segment"},e}(),(n=Object.create(r={}))[r[0]="DEFAULT"]=0,n[r[1]="EXTERNAL"]=1,i.DataLocation=n,i}(),r.SparseTensorProto=function(){function e(e){if(this.dims=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.values=null,e.prototype.indices=null,e.prototype.dims=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.values&&Object.hasOwnProperty.call(e,"values")&&p.onnx.TensorProto.encode(e.values,t.uint32(10).fork()).ldelim(),null!=e.indices&&Object.hasOwnProperty.call(e,"indices")&&p.onnx.TensorProto.encode(e.indices,t.uint32(18).fork()).ldelim(),null!=e.dims&&e.dims.length){t.uint32(26).fork();for(var r=0;r<e.dims.length;++r)t.int64(e.dims[r]);t.ldelim()}return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.SparseTensorProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.values=p.onnx.TensorProto.decode(e,e.uint32());break;case 2:n.indices=p.onnx.TensorProto.decode(e,e.uint32());break;case 3:if(n.dims&&n.dims.length||(n.dims=[]),(7&i)==2)for(var o=e.uint32()+e.pos;e.pos<o;)n.dims.push(e.int64());else n.dims.push(e.int64());break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.values&&e.hasOwnProperty("values")){var t=p.onnx.TensorProto.verify(e.values);if(t)return"values."+t}if(null!=e.indices&&e.hasOwnProperty("indices")){var t=p.onnx.TensorProto.verify(e.indices);if(t)return"indices."+t}if(null!=e.dims&&e.hasOwnProperty("dims")){if(!Array.isArray(e.dims))return"dims: array expected";for(var r=0;r<e.dims.length;++r)if(!d.isInteger(e.dims[r])&&!(e.dims[r]&&d.isInteger(e.dims[r].low)&&d.isInteger(e.dims[r].high)))return"dims: integer|Long[] expected"}return null},e.fromObject=function(e){if(e instanceof p.onnx.SparseTensorProto)return e;var t=new p.onnx.SparseTensorProto;if(null!=e.values){if("object"!=typeof e.values)throw TypeError(".onnx.SparseTensorProto.values: object expected");t.values=p.onnx.TensorProto.fromObject(e.values)}if(null!=e.indices){if("object"!=typeof e.indices)throw TypeError(".onnx.SparseTensorProto.indices: object expected");t.indices=p.onnx.TensorProto.fromObject(e.indices)}if(e.dims){if(!Array.isArray(e.dims))throw TypeError(".onnx.SparseTensorProto.dims: array expected");t.dims=[];for(var r=0;r<e.dims.length;++r)d.Long?(t.dims[r]=d.Long.fromValue(e.dims[r])).unsigned=!1:"string"==typeof e.dims[r]?t.dims[r]=parseInt(e.dims[r],10):"number"==typeof e.dims[r]?t.dims[r]=e.dims[r]:"object"==typeof e.dims[r]&&(t.dims[r]=new d.LongBits(e.dims[r].low>>>0,e.dims[r].high>>>0).toNumber())}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.dims=[]),t.defaults&&(r.values=null,r.indices=null),null!=e.values&&e.hasOwnProperty("values")&&(r.values=p.onnx.TensorProto.toObject(e.values,t)),null!=e.indices&&e.hasOwnProperty("indices")&&(r.indices=p.onnx.TensorProto.toObject(e.indices,t)),e.dims&&e.dims.length){r.dims=[];for(var n=0;n<e.dims.length;++n)"number"==typeof e.dims[n]?r.dims[n]=t.longs===String?String(e.dims[n]):e.dims[n]:r.dims[n]=t.longs===String?d.Long.prototype.toString.call(e.dims[n]):t.longs===Number?new d.LongBits(e.dims[n].low>>>0,e.dims[n].high>>>0).toNumber():e.dims[n]}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.SparseTensorProto"},e}(),r.TensorShapeProto=function(){function e(e){if(this.dim=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.dim=d.emptyArray,e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.dim&&e.dim.length)for(var r=0;r<e.dim.length;++r)p.onnx.TensorShapeProto.Dimension.encode(e.dim[r],t.uint32(10).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TensorShapeProto;e.pos<r;){var i=e.uint32();i>>>3==1?(n.dim&&n.dim.length||(n.dim=[]),n.dim.push(p.onnx.TensorShapeProto.Dimension.decode(e,e.uint32()))):e.skipType(7&i)}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.dim&&e.hasOwnProperty("dim")){if(!Array.isArray(e.dim))return"dim: array expected";for(var t=0;t<e.dim.length;++t){var r=p.onnx.TensorShapeProto.Dimension.verify(e.dim[t]);if(r)return"dim."+r}}return null},e.fromObject=function(e){if(e instanceof p.onnx.TensorShapeProto)return e;var t=new p.onnx.TensorShapeProto;if(e.dim){if(!Array.isArray(e.dim))throw TypeError(".onnx.TensorShapeProto.dim: array expected");t.dim=[];for(var r=0;r<e.dim.length;++r){if("object"!=typeof e.dim[r])throw TypeError(".onnx.TensorShapeProto.dim: object expected");t.dim[r]=p.onnx.TensorShapeProto.Dimension.fromObject(e.dim[r])}}return t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.dim=[]),e.dim&&e.dim.length){r.dim=[];for(var n=0;n<e.dim.length;++n)r.dim[n]=p.onnx.TensorShapeProto.Dimension.toObject(e.dim[n],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TensorShapeProto"},e.Dimension=function(){var e;function t(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return t.prototype.dimValue=null,t.prototype.dimParam=null,t.prototype.denotation="",Object.defineProperty(t.prototype,"value",{get:d.oneOfGetter(e=["dimValue","dimParam"]),set:d.oneOfSetter(e)}),t.create=function(e){return new t(e)},t.encode=function(e,t){return t||(t=l.create()),null!=e.dimValue&&Object.hasOwnProperty.call(e,"dimValue")&&t.uint32(8).int64(e.dimValue),null!=e.dimParam&&Object.hasOwnProperty.call(e,"dimParam")&&t.uint32(18).string(e.dimParam),null!=e.denotation&&Object.hasOwnProperty.call(e,"denotation")&&t.uint32(26).string(e.denotation),t},t.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},t.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TensorShapeProto.Dimension;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.dimValue=e.int64();break;case 2:n.dimParam=e.string();break;case 3:n.denotation=e.string();break;default:e.skipType(7&i)}}return n},t.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},t.verify=function(e){if("object"!=typeof e||null===e)return"object expected";var t={};if(null!=e.dimValue&&e.hasOwnProperty("dimValue")&&(t.value=1,!d.isInteger(e.dimValue)&&!(e.dimValue&&d.isInteger(e.dimValue.low)&&d.isInteger(e.dimValue.high))))return"dimValue: integer|Long expected";if(null!=e.dimParam&&e.hasOwnProperty("dimParam")){if(1===t.value)return"value: multiple values";if(t.value=1,!d.isString(e.dimParam))return"dimParam: string expected"}return null!=e.denotation&&e.hasOwnProperty("denotation")&&!d.isString(e.denotation)?"denotation: string expected":null},t.fromObject=function(e){if(e instanceof p.onnx.TensorShapeProto.Dimension)return e;var t=new p.onnx.TensorShapeProto.Dimension;return null!=e.dimValue&&(d.Long?(t.dimValue=d.Long.fromValue(e.dimValue)).unsigned=!1:"string"==typeof e.dimValue?t.dimValue=parseInt(e.dimValue,10):"number"==typeof e.dimValue?t.dimValue=e.dimValue:"object"==typeof e.dimValue&&(t.dimValue=new d.LongBits(e.dimValue.low>>>0,e.dimValue.high>>>0).toNumber())),null!=e.dimParam&&(t.dimParam=String(e.dimParam)),null!=e.denotation&&(t.denotation=String(e.denotation)),t},t.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.denotation=""),null!=e.dimValue&&e.hasOwnProperty("dimValue")&&("number"==typeof e.dimValue?r.dimValue=t.longs===String?String(e.dimValue):e.dimValue:r.dimValue=t.longs===String?d.Long.prototype.toString.call(e.dimValue):t.longs===Number?new d.LongBits(e.dimValue.low>>>0,e.dimValue.high>>>0).toNumber():e.dimValue,t.oneofs&&(r.value="dimValue")),null!=e.dimParam&&e.hasOwnProperty("dimParam")&&(r.dimParam=e.dimParam,t.oneofs&&(r.value="dimParam")),null!=e.denotation&&e.hasOwnProperty("denotation")&&(r.denotation=e.denotation),r},t.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},t.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TensorShapeProto.Dimension"},t}(),e}(),r.TypeProto=function(){var e;function t(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return t.prototype.tensorType=null,t.prototype.sequenceType=null,t.prototype.mapType=null,t.prototype.optionalType=null,t.prototype.sparseTensorType=null,t.prototype.denotation="",Object.defineProperty(t.prototype,"value",{get:d.oneOfGetter(e=["tensorType","sequenceType","mapType","optionalType","sparseTensorType"]),set:d.oneOfSetter(e)}),t.create=function(e){return new t(e)},t.encode=function(e,t){return t||(t=l.create()),null!=e.tensorType&&Object.hasOwnProperty.call(e,"tensorType")&&p.onnx.TypeProto.Tensor.encode(e.tensorType,t.uint32(10).fork()).ldelim(),null!=e.sequenceType&&Object.hasOwnProperty.call(e,"sequenceType")&&p.onnx.TypeProto.Sequence.encode(e.sequenceType,t.uint32(34).fork()).ldelim(),null!=e.mapType&&Object.hasOwnProperty.call(e,"mapType")&&p.onnx.TypeProto.Map.encode(e.mapType,t.uint32(42).fork()).ldelim(),null!=e.denotation&&Object.hasOwnProperty.call(e,"denotation")&&t.uint32(50).string(e.denotation),null!=e.sparseTensorType&&Object.hasOwnProperty.call(e,"sparseTensorType")&&p.onnx.TypeProto.SparseTensor.encode(e.sparseTensorType,t.uint32(66).fork()).ldelim(),null!=e.optionalType&&Object.hasOwnProperty.call(e,"optionalType")&&p.onnx.TypeProto.Optional.encode(e.optionalType,t.uint32(74).fork()).ldelim(),t},t.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},t.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.tensorType=p.onnx.TypeProto.Tensor.decode(e,e.uint32());break;case 4:n.sequenceType=p.onnx.TypeProto.Sequence.decode(e,e.uint32());break;case 5:n.mapType=p.onnx.TypeProto.Map.decode(e,e.uint32());break;case 9:n.optionalType=p.onnx.TypeProto.Optional.decode(e,e.uint32());break;case 8:n.sparseTensorType=p.onnx.TypeProto.SparseTensor.decode(e,e.uint32());break;case 6:n.denotation=e.string();break;default:e.skipType(7&i)}}return n},t.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},t.verify=function(e){if("object"!=typeof e||null===e)return"object expected";var t={};if(null!=e.tensorType&&e.hasOwnProperty("tensorType")){t.value=1;var r=p.onnx.TypeProto.Tensor.verify(e.tensorType);if(r)return"tensorType."+r}if(null!=e.sequenceType&&e.hasOwnProperty("sequenceType")){if(1===t.value)return"value: multiple values";t.value=1;var r=p.onnx.TypeProto.Sequence.verify(e.sequenceType);if(r)return"sequenceType."+r}if(null!=e.mapType&&e.hasOwnProperty("mapType")){if(1===t.value)return"value: multiple values";t.value=1;var r=p.onnx.TypeProto.Map.verify(e.mapType);if(r)return"mapType."+r}if(null!=e.optionalType&&e.hasOwnProperty("optionalType")){if(1===t.value)return"value: multiple values";t.value=1;var r=p.onnx.TypeProto.Optional.verify(e.optionalType);if(r)return"optionalType."+r}if(null!=e.sparseTensorType&&e.hasOwnProperty("sparseTensorType")){if(1===t.value)return"value: multiple values";t.value=1;var r=p.onnx.TypeProto.SparseTensor.verify(e.sparseTensorType);if(r)return"sparseTensorType."+r}return null!=e.denotation&&e.hasOwnProperty("denotation")&&!d.isString(e.denotation)?"denotation: string expected":null},t.fromObject=function(e){if(e instanceof p.onnx.TypeProto)return e;var t=new p.onnx.TypeProto;if(null!=e.tensorType){if("object"!=typeof e.tensorType)throw TypeError(".onnx.TypeProto.tensorType: object expected");t.tensorType=p.onnx.TypeProto.Tensor.fromObject(e.tensorType)}if(null!=e.sequenceType){if("object"!=typeof e.sequenceType)throw TypeError(".onnx.TypeProto.sequenceType: object expected");t.sequenceType=p.onnx.TypeProto.Sequence.fromObject(e.sequenceType)}if(null!=e.mapType){if("object"!=typeof e.mapType)throw TypeError(".onnx.TypeProto.mapType: object expected");t.mapType=p.onnx.TypeProto.Map.fromObject(e.mapType)}if(null!=e.optionalType){if("object"!=typeof e.optionalType)throw TypeError(".onnx.TypeProto.optionalType: object expected");t.optionalType=p.onnx.TypeProto.Optional.fromObject(e.optionalType)}if(null!=e.sparseTensorType){if("object"!=typeof e.sparseTensorType)throw TypeError(".onnx.TypeProto.sparseTensorType: object expected");t.sparseTensorType=p.onnx.TypeProto.SparseTensor.fromObject(e.sparseTensorType)}return null!=e.denotation&&(t.denotation=String(e.denotation)),t},t.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.denotation=""),null!=e.tensorType&&e.hasOwnProperty("tensorType")&&(r.tensorType=p.onnx.TypeProto.Tensor.toObject(e.tensorType,t),t.oneofs&&(r.value="tensorType")),null!=e.sequenceType&&e.hasOwnProperty("sequenceType")&&(r.sequenceType=p.onnx.TypeProto.Sequence.toObject(e.sequenceType,t),t.oneofs&&(r.value="sequenceType")),null!=e.mapType&&e.hasOwnProperty("mapType")&&(r.mapType=p.onnx.TypeProto.Map.toObject(e.mapType,t),t.oneofs&&(r.value="mapType")),null!=e.denotation&&e.hasOwnProperty("denotation")&&(r.denotation=e.denotation),null!=e.sparseTensorType&&e.hasOwnProperty("sparseTensorType")&&(r.sparseTensorType=p.onnx.TypeProto.SparseTensor.toObject(e.sparseTensorType,t),t.oneofs&&(r.value="sparseTensorType")),null!=e.optionalType&&e.hasOwnProperty("optionalType")&&(r.optionalType=p.onnx.TypeProto.Optional.toObject(e.optionalType,t),t.oneofs&&(r.value="optionalType")),r},t.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},t.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto"},t.Tensor=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.elemType=0,e.prototype.shape=null,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.elemType&&Object.hasOwnProperty.call(e,"elemType")&&t.uint32(8).int32(e.elemType),null!=e.shape&&Object.hasOwnProperty.call(e,"shape")&&p.onnx.TensorShapeProto.encode(e.shape,t.uint32(18).fork()).ldelim(),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto.Tensor;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.elemType=e.int32();break;case 2:n.shape=p.onnx.TensorShapeProto.decode(e,e.uint32());break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.elemType&&e.hasOwnProperty("elemType")&&!d.isInteger(e.elemType))return"elemType: integer expected";if(null!=e.shape&&e.hasOwnProperty("shape")){var t=p.onnx.TensorShapeProto.verify(e.shape);if(t)return"shape."+t}return null},e.fromObject=function(e){if(e instanceof p.onnx.TypeProto.Tensor)return e;var t=new p.onnx.TypeProto.Tensor;if(null!=e.elemType&&(t.elemType=0|e.elemType),null!=e.shape){if("object"!=typeof e.shape)throw TypeError(".onnx.TypeProto.Tensor.shape: object expected");t.shape=p.onnx.TensorShapeProto.fromObject(e.shape)}return t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.elemType=0,r.shape=null),null!=e.elemType&&e.hasOwnProperty("elemType")&&(r.elemType=e.elemType),null!=e.shape&&e.hasOwnProperty("shape")&&(r.shape=p.onnx.TensorShapeProto.toObject(e.shape,t)),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto.Tensor"},e}(),t.Sequence=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.elemType=null,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.elemType&&Object.hasOwnProperty.call(e,"elemType")&&p.onnx.TypeProto.encode(e.elemType,t.uint32(10).fork()).ldelim(),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto.Sequence;e.pos<r;){var i=e.uint32();i>>>3==1?n.elemType=p.onnx.TypeProto.decode(e,e.uint32()):e.skipType(7&i)}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.elemType&&e.hasOwnProperty("elemType")){var t=p.onnx.TypeProto.verify(e.elemType);if(t)return"elemType."+t}return null},e.fromObject=function(e){if(e instanceof p.onnx.TypeProto.Sequence)return e;var t=new p.onnx.TypeProto.Sequence;if(null!=e.elemType){if("object"!=typeof e.elemType)throw TypeError(".onnx.TypeProto.Sequence.elemType: object expected");t.elemType=p.onnx.TypeProto.fromObject(e.elemType)}return t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.elemType=null),null!=e.elemType&&e.hasOwnProperty("elemType")&&(r.elemType=p.onnx.TypeProto.toObject(e.elemType,t)),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto.Sequence"},e}(),t.Map=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.keyType=0,e.prototype.valueType=null,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.keyType&&Object.hasOwnProperty.call(e,"keyType")&&t.uint32(8).int32(e.keyType),null!=e.valueType&&Object.hasOwnProperty.call(e,"valueType")&&p.onnx.TypeProto.encode(e.valueType,t.uint32(18).fork()).ldelim(),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto.Map;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.keyType=e.int32();break;case 2:n.valueType=p.onnx.TypeProto.decode(e,e.uint32());break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.keyType&&e.hasOwnProperty("keyType")&&!d.isInteger(e.keyType))return"keyType: integer expected";if(null!=e.valueType&&e.hasOwnProperty("valueType")){var t=p.onnx.TypeProto.verify(e.valueType);if(t)return"valueType."+t}return null},e.fromObject=function(e){if(e instanceof p.onnx.TypeProto.Map)return e;var t=new p.onnx.TypeProto.Map;if(null!=e.keyType&&(t.keyType=0|e.keyType),null!=e.valueType){if("object"!=typeof e.valueType)throw TypeError(".onnx.TypeProto.Map.valueType: object expected");t.valueType=p.onnx.TypeProto.fromObject(e.valueType)}return t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.keyType=0,r.valueType=null),null!=e.keyType&&e.hasOwnProperty("keyType")&&(r.keyType=e.keyType),null!=e.valueType&&e.hasOwnProperty("valueType")&&(r.valueType=p.onnx.TypeProto.toObject(e.valueType,t)),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto.Map"},e}(),t.Optional=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.elemType=null,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.elemType&&Object.hasOwnProperty.call(e,"elemType")&&p.onnx.TypeProto.encode(e.elemType,t.uint32(10).fork()).ldelim(),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto.Optional;e.pos<r;){var i=e.uint32();i>>>3==1?n.elemType=p.onnx.TypeProto.decode(e,e.uint32()):e.skipType(7&i)}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.elemType&&e.hasOwnProperty("elemType")){var t=p.onnx.TypeProto.verify(e.elemType);if(t)return"elemType."+t}return null},e.fromObject=function(e){if(e instanceof p.onnx.TypeProto.Optional)return e;var t=new p.onnx.TypeProto.Optional;if(null!=e.elemType){if("object"!=typeof e.elemType)throw TypeError(".onnx.TypeProto.Optional.elemType: object expected");t.elemType=p.onnx.TypeProto.fromObject(e.elemType)}return t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.elemType=null),null!=e.elemType&&e.hasOwnProperty("elemType")&&(r.elemType=p.onnx.TypeProto.toObject(e.elemType,t)),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto.Optional"},e}(),t.SparseTensor=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.elemType=0,e.prototype.shape=null,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.elemType&&Object.hasOwnProperty.call(e,"elemType")&&t.uint32(8).int32(e.elemType),null!=e.shape&&Object.hasOwnProperty.call(e,"shape")&&p.onnx.TensorShapeProto.encode(e.shape,t.uint32(18).fork()).ldelim(),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.TypeProto.SparseTensor;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.elemType=e.int32();break;case 2:n.shape=p.onnx.TensorShapeProto.decode(e,e.uint32());break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.elemType&&e.hasOwnProperty("elemType")&&!d.isInteger(e.elemType))return"elemType: integer expected";if(null!=e.shape&&e.hasOwnProperty("shape")){var t=p.onnx.TensorShapeProto.verify(e.shape);if(t)return"shape."+t}return null},e.fromObject=function(e){if(e instanceof p.onnx.TypeProto.SparseTensor)return e;var t=new p.onnx.TypeProto.SparseTensor;if(null!=e.elemType&&(t.elemType=0|e.elemType),null!=e.shape){if("object"!=typeof e.shape)throw TypeError(".onnx.TypeProto.SparseTensor.shape: object expected");t.shape=p.onnx.TensorShapeProto.fromObject(e.shape)}return t},e.toObject=function(e,t){t||(t={});var r={};return t.defaults&&(r.elemType=0,r.shape=null),null!=e.elemType&&e.hasOwnProperty("elemType")&&(r.elemType=e.elemType),null!=e.shape&&e.hasOwnProperty("shape")&&(r.shape=p.onnx.TensorShapeProto.toObject(e.shape,t)),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.TypeProto.SparseTensor"},e}(),t}(),r.OperatorSetIdProto=function(){function e(e){if(e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.domain="",e.prototype.version=d.Long?d.Long.fromBits(0,0,!1):0,e.create=function(t){return new e(t)},e.encode=function(e,t){return t||(t=l.create()),null!=e.domain&&Object.hasOwnProperty.call(e,"domain")&&t.uint32(10).string(e.domain),null!=e.version&&Object.hasOwnProperty.call(e,"version")&&t.uint32(16).int64(e.version),t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.OperatorSetIdProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.domain=e.string();break;case 2:n.version=e.int64();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){return"object"!=typeof e||null===e?"object expected":null!=e.domain&&e.hasOwnProperty("domain")&&!d.isString(e.domain)?"domain: string expected":null!=e.version&&e.hasOwnProperty("version")&&!d.isInteger(e.version)&&!(e.version&&d.isInteger(e.version.low)&&d.isInteger(e.version.high))?"version: integer|Long expected":null},e.fromObject=function(e){if(e instanceof p.onnx.OperatorSetIdProto)return e;var t=new p.onnx.OperatorSetIdProto;return null!=e.domain&&(t.domain=String(e.domain)),null!=e.version&&(d.Long?(t.version=d.Long.fromValue(e.version)).unsigned=!1:"string"==typeof e.version?t.version=parseInt(e.version,10):"number"==typeof e.version?t.version=e.version:"object"==typeof e.version&&(t.version=new d.LongBits(e.version.low>>>0,e.version.high>>>0).toNumber())),t},e.toObject=function(e,t){t||(t={});var r={};if(t.defaults)if(r.domain="",d.Long){var n=new d.Long(0,0,!1);r.version=t.longs===String?n.toString():t.longs===Number?n.toNumber():n}else r.version=t.longs===String?"0":0;return null!=e.domain&&e.hasOwnProperty("domain")&&(r.domain=e.domain),null!=e.version&&e.hasOwnProperty("version")&&("number"==typeof e.version?r.version=t.longs===String?String(e.version):e.version:r.version=t.longs===String?d.Long.prototype.toString.call(e.version):t.longs===Number?new d.LongBits(e.version.low>>>0,e.version.high>>>0).toNumber():e.version),r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.OperatorSetIdProto"},e}(),(s=Object.create(o={}))[o[0]="EXPERIMENTAL"]=0,s[o[1]="STABLE"]=1,r.OperatorStatus=s,r.FunctionProto=function(){function e(e){if(this.input=[],this.output=[],this.attribute=[],this.attributeProto=[],this.node=[],this.opsetImport=[],e)for(var t=Object.keys(e),r=0;r<t.length;++r)null!=e[t[r]]&&(this[t[r]]=e[t[r]])}return e.prototype.name="",e.prototype.input=d.emptyArray,e.prototype.output=d.emptyArray,e.prototype.attribute=d.emptyArray,e.prototype.attributeProto=d.emptyArray,e.prototype.node=d.emptyArray,e.prototype.docString="",e.prototype.opsetImport=d.emptyArray,e.prototype.domain="",e.create=function(t){return new e(t)},e.encode=function(e,t){if(t||(t=l.create()),null!=e.name&&Object.hasOwnProperty.call(e,"name")&&t.uint32(10).string(e.name),null!=e.input&&e.input.length)for(var r=0;r<e.input.length;++r)t.uint32(34).string(e.input[r]);if(null!=e.output&&e.output.length)for(var r=0;r<e.output.length;++r)t.uint32(42).string(e.output[r]);if(null!=e.attribute&&e.attribute.length)for(var r=0;r<e.attribute.length;++r)t.uint32(50).string(e.attribute[r]);if(null!=e.node&&e.node.length)for(var r=0;r<e.node.length;++r)p.onnx.NodeProto.encode(e.node[r],t.uint32(58).fork()).ldelim();if(null!=e.docString&&Object.hasOwnProperty.call(e,"docString")&&t.uint32(66).string(e.docString),null!=e.opsetImport&&e.opsetImport.length)for(var r=0;r<e.opsetImport.length;++r)p.onnx.OperatorSetIdProto.encode(e.opsetImport[r],t.uint32(74).fork()).ldelim();if(null!=e.domain&&Object.hasOwnProperty.call(e,"domain")&&t.uint32(82).string(e.domain),null!=e.attributeProto&&e.attributeProto.length)for(var r=0;r<e.attributeProto.length;++r)p.onnx.AttributeProto.encode(e.attributeProto[r],t.uint32(90).fork()).ldelim();return t},e.encodeDelimited=function(e,t){return this.encode(e,t).ldelim()},e.decode=function(e,t){e instanceof u||(e=u.create(e));for(var r=void 0===t?e.len:e.pos+t,n=new p.onnx.FunctionProto;e.pos<r;){var i=e.uint32();switch(i>>>3){case 1:n.name=e.string();break;case 4:n.input&&n.input.length||(n.input=[]),n.input.push(e.string());break;case 5:n.output&&n.output.length||(n.output=[]),n.output.push(e.string());break;case 6:n.attribute&&n.attribute.length||(n.attribute=[]),n.attribute.push(e.string());break;case 11:n.attributeProto&&n.attributeProto.length||(n.attributeProto=[]),n.attributeProto.push(p.onnx.AttributeProto.decode(e,e.uint32()));break;case 7:n.node&&n.node.length||(n.node=[]),n.node.push(p.onnx.NodeProto.decode(e,e.uint32()));break;case 8:n.docString=e.string();break;case 9:n.opsetImport&&n.opsetImport.length||(n.opsetImport=[]),n.opsetImport.push(p.onnx.OperatorSetIdProto.decode(e,e.uint32()));break;case 10:n.domain=e.string();break;default:e.skipType(7&i)}}return n},e.decodeDelimited=function(e){return e instanceof u||(e=new u(e)),this.decode(e,e.uint32())},e.verify=function(e){if("object"!=typeof e||null===e)return"object expected";if(null!=e.name&&e.hasOwnProperty("name")&&!d.isString(e.name))return"name: string expected";if(null!=e.input&&e.hasOwnProperty("input")){if(!Array.isArray(e.input))return"input: array expected";for(var t=0;t<e.input.length;++t)if(!d.isString(e.input[t]))return"input: string[] expected"}if(null!=e.output&&e.hasOwnProperty("output")){if(!Array.isArray(e.output))return"output: array expected";for(var t=0;t<e.output.length;++t)if(!d.isString(e.output[t]))return"output: string[] expected"}if(null!=e.attribute&&e.hasOwnProperty("attribute")){if(!Array.isArray(e.attribute))return"attribute: array expected";for(var t=0;t<e.attribute.length;++t)if(!d.isString(e.attribute[t]))return"attribute: string[] expected"}if(null!=e.attributeProto&&e.hasOwnProperty("attributeProto")){if(!Array.isArray(e.attributeProto))return"attributeProto: array expected";for(var t=0;t<e.attributeProto.length;++t){var r=p.onnx.AttributeProto.verify(e.attributeProto[t]);if(r)return"attributeProto."+r}}if(null!=e.node&&e.hasOwnProperty("node")){if(!Array.isArray(e.node))return"node: array expected";for(var t=0;t<e.node.length;++t){var r=p.onnx.NodeProto.verify(e.node[t]);if(r)return"node."+r}}if(null!=e.docString&&e.hasOwnProperty("docString")&&!d.isString(e.docString))return"docString: string expected";if(null!=e.opsetImport&&e.hasOwnProperty("opsetImport")){if(!Array.isArray(e.opsetImport))return"opsetImport: array expected";for(var t=0;t<e.opsetImport.length;++t){var r=p.onnx.OperatorSetIdProto.verify(e.opsetImport[t]);if(r)return"opsetImport."+r}}return null!=e.domain&&e.hasOwnProperty("domain")&&!d.isString(e.domain)?"domain: string expected":null},e.fromObject=function(e){if(e instanceof p.onnx.FunctionProto)return e;var t=new p.onnx.FunctionProto;if(null!=e.name&&(t.name=String(e.name)),e.input){if(!Array.isArray(e.input))throw TypeError(".onnx.FunctionProto.input: array expected");t.input=[];for(var r=0;r<e.input.length;++r)t.input[r]=String(e.input[r])}if(e.output){if(!Array.isArray(e.output))throw TypeError(".onnx.FunctionProto.output: array expected");t.output=[];for(var r=0;r<e.output.length;++r)t.output[r]=String(e.output[r])}if(e.attribute){if(!Array.isArray(e.attribute))throw TypeError(".onnx.FunctionProto.attribute: array expected");t.attribute=[];for(var r=0;r<e.attribute.length;++r)t.attribute[r]=String(e.attribute[r])}if(e.attributeProto){if(!Array.isArray(e.attributeProto))throw TypeError(".onnx.FunctionProto.attributeProto: array expected");t.attributeProto=[];for(var r=0;r<e.attributeProto.length;++r){if("object"!=typeof e.attributeProto[r])throw TypeError(".onnx.FunctionProto.attributeProto: object expected");t.attributeProto[r]=p.onnx.AttributeProto.fromObject(e.attributeProto[r])}}if(e.node){if(!Array.isArray(e.node))throw TypeError(".onnx.FunctionProto.node: array expected");t.node=[];for(var r=0;r<e.node.length;++r){if("object"!=typeof e.node[r])throw TypeError(".onnx.FunctionProto.node: object expected");t.node[r]=p.onnx.NodeProto.fromObject(e.node[r])}}if(null!=e.docString&&(t.docString=String(e.docString)),e.opsetImport){if(!Array.isArray(e.opsetImport))throw TypeError(".onnx.FunctionProto.opsetImport: array expected");t.opsetImport=[];for(var r=0;r<e.opsetImport.length;++r){if("object"!=typeof e.opsetImport[r])throw TypeError(".onnx.FunctionProto.opsetImport: object expected");t.opsetImport[r]=p.onnx.OperatorSetIdProto.fromObject(e.opsetImport[r])}}return null!=e.domain&&(t.domain=String(e.domain)),t},e.toObject=function(e,t){t||(t={});var r={};if((t.arrays||t.defaults)&&(r.input=[],r.output=[],r.attribute=[],r.node=[],r.opsetImport=[],r.attributeProto=[]),t.defaults&&(r.name="",r.docString="",r.domain=""),null!=e.name&&e.hasOwnProperty("name")&&(r.name=e.name),e.input&&e.input.length){r.input=[];for(var n=0;n<e.input.length;++n)r.input[n]=e.input[n]}if(e.output&&e.output.length){r.output=[];for(var n=0;n<e.output.length;++n)r.output[n]=e.output[n]}if(e.attribute&&e.attribute.length){r.attribute=[];for(var n=0;n<e.attribute.length;++n)r.attribute[n]=e.attribute[n]}if(e.node&&e.node.length){r.node=[];for(var n=0;n<e.node.length;++n)r.node[n]=p.onnx.NodeProto.toObject(e.node[n],t)}if(null!=e.docString&&e.hasOwnProperty("docString")&&(r.docString=e.docString),e.opsetImport&&e.opsetImport.length){r.opsetImport=[];for(var n=0;n<e.opsetImport.length;++n)r.opsetImport[n]=p.onnx.OperatorSetIdProto.toObject(e.opsetImport[n],t)}if(null!=e.domain&&e.hasOwnProperty("domain")&&(r.domain=e.domain),e.attributeProto&&e.attributeProto.length){r.attributeProto=[];for(var n=0;n<e.attributeProto.length;++n)r.attributeProto[n]=p.onnx.AttributeProto.toObject(e.attributeProto[n],t)}return r},e.prototype.toJSON=function(){return this.constructor.toObject(this,a.util.toJSONOptions)},e.getTypeUrl=function(e){return void 0===e&&(e="type.googleapis.com"),e+"/onnx.FunctionProto"},e}(),p.onnx=r,t.exports=p}});function cP(e,t){if(!e)throw Error("string"==typeof t?t:t())}function ck(e){return new TextDecoder().decode(e)}var cA=dQ({"web/lib/onnxjs/util.ts"(){"use strict";pO(),eb=d2(cE()),cj(),ey=class{static arraysEqual(e,t){if(e.length!==t.length)return!1;for(let r=0;r<e.length;r++)if(e[r]!==t[r])return!1;return!0}},e_=class{static preprocessInputShapes(e,t){return[1===e.length?[1,e[0]]:e,1===t.length?[t[0],1]:t]}static postprocessOutputShape(e,t,r){1===t&&e.splice(e.length-2,1),1===r&&e.pop()}static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},ev=class e{static calcShape(e,t,r=!1){let n=e.length,i=t.length;if(0===n)return t;if(0===i)return e;let o=Math.max(e.length,t.length),s=Array(o);if(r){if(n<2||i<2)return;let r=e_.calcMatMulShape([e[n-2],e[n-1]],[t[i-2],t[i-1]]);if(void 0===r)return;[s[o-2],s[o-1]]=r}for(let a=r?3:1;a<=o;a++){let r=n-a<0?1:e[n-a],u=i-a<0?1:t[i-a];if(r!==u&&r>1&&u>1)return;s[o-a]=Math.max(r,u)}return s}static index(t,r){let n=Array(r.length);return e.fillIndex(t,r,n),n}static fillIndex(e,t,r){let n=e.length-t.length;for(let i=0;i<t.length;i++)r[i]=e[n+i]%t[i]}static calc(t,r,n,i,o){let s=e.calcShape(t.dims,r.dims);if(s){if(i&&!eT.areEqual(s,t.dims))return;let a=eT.size(s),u=i?t:new eA(s,o||t.type);if(0===s.length)u.set([],n(t.get([]),r.get([])));else{let i,o=Array(s.length),l=Array(t.dims.length),d=Array(r.dims.length),p=0,c=0,h=!1,f=!1;0===t.dims.length&&(p=t.get([]),h=!0),0===r.dims.length&&(c=r.get([]),f=!0);for(let g=0;g<a;g++){i=g;for(let e=s.length-1;e>=0;e--)o[e]=i%s[e],i=Math.floor(i/s[e]);h||(e.fillIndex(o,t.dims,l),p=t.get(l)),f||(e.fillIndex(o,r.dims,d),c=r.get(d)),u.set(o,n(p,c))}}return u}}static isValidBroadcast(e,t){let r=e.length,n=t.length;if(r>n)return!1;for(let i=1;i<=r;i++)if(1!==e[r-i]&&e[r-i]!==t[n-i])return!1;return!0}static getBroadcastDims(e,t){let r=e.length,n=[];for(let i=0;i<r;i++){let o=r-1-i,s=e[o]||1;(t[t.length-1-i]||1)>1&&1===s&&n.unshift(o)}return n}},ex=class{static getShapeOfGemmResult(e,t,r,n,i){let o,s,a;if(2!==e.length||2!==r.length)throw Error("shape need to be of size 2");t?(o=e[1],s=e[0]):(o=e[0],s=e[1]);let u=-1;if(n?(a=r[0],u=1):(a=r[1],u=0),r[u]!==s)throw Error("dimension mismatch");if(o<=0||a<=0||s<=0)throw Error("invalid shape specified");if(i&&!ev.isValidBroadcast(i,[o,a]))throw Error("gemm: invalid bias shape for broadcast");return[o,a,s]}},ew=class e{static tensorDataTypeFromProto(e){switch(e){case eb.onnx.TensorProto.DataType.INT8:return"int8";case eb.onnx.TensorProto.DataType.UINT8:return"uint8";case eb.onnx.TensorProto.DataType.BOOL:return"bool";case eb.onnx.TensorProto.DataType.INT16:return"int16";case eb.onnx.TensorProto.DataType.UINT16:return"uint16";case eb.onnx.TensorProto.DataType.INT32:return"int32";case eb.onnx.TensorProto.DataType.UINT32:return"uint32";case eb.onnx.TensorProto.DataType.FLOAT:return"float32";case eb.onnx.TensorProto.DataType.DOUBLE:return"float64";case eb.onnx.TensorProto.DataType.STRING:return"string";case eb.onnx.TensorProto.DataType.INT64:return"int32";case eb.onnx.TensorProto.DataType.UINT64:return"uint32";default:throw Error(`unsupported data type: ${eb.onnx.TensorProto.DataType[e]}`)}}static tensorDataTypeStringToEnum(e){switch(e){case"int8":return eb.onnx.TensorProto.DataType.INT8;case"uint8":return eb.onnx.TensorProto.DataType.UINT8;case"bool":return eb.onnx.TensorProto.DataType.BOOL;case"int16":return eb.onnx.TensorProto.DataType.INT16;case"uint16":return eb.onnx.TensorProto.DataType.UINT16;case"int32":return eb.onnx.TensorProto.DataType.INT32;case"uint32":return eb.onnx.TensorProto.DataType.UINT32;case"float32":return eb.onnx.TensorProto.DataType.FLOAT;case"float64":return eb.onnx.TensorProto.DataType.DOUBLE;case"string":return eb.onnx.TensorProto.DataType.STRING;case"int64":return eb.onnx.TensorProto.DataType.INT64;case"uint64":return eb.onnx.TensorProto.DataType.UINT64;default:throw Error(`unsupported data type: ${e}`)}}static tensorDimsFromProto(e){return e.map(e=>eu.isLong(e)?e.toNumber():e)}static tensorValueTypeFromProto(t){return{tensorType:e.tensorDataTypeFromProto(t.elemType),shape:{dims:e.tensorDimsFromProto(t.shape.dim.map(e=>e.dimValue))}}}static tensorDimsFromORTFormat(e){let t=[];for(let r=0;r<e.dimsLength();r++)t.push(e$.longToNumber(e.dims(r)));return t}static tensorAttributesFromORTFormat(e){let t=[];for(let r=0;r<e.attributesLength();r++)t.push(e.attributes(r));return t}},e$=class{static longToNumber(e){return eu.isLong(e)?e.toNumber():"bigint"==typeof e?Number(e):e}static isLong(e){return eu.isLong(e)||"bigint"==typeof e}},eT=class e{static size(t){return e.getSizeFromDimensionRange(t,0,t.length)}static sizeFromDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(e,t,r){let n=1;for(let i=t;i<r;i++){if(e[i]<=0)throw Error("cannot get valid size from specified dimension range. Most likely the range contains 0 or negative values in them.");n*=e[i]}return n}static computeStrides(e){let t=e.length;if(0===t)return[];if(1===t)return[1];let r=Array(t);r[t-1]=1,r[t-2]=e[t-1];for(let n=t-3;n>=0;--n)r[n]=r[n+1]*e[n+1];return r}static transpose(e){return e.slice().reverse()}static indicesToOffset(e,t,r){void 0===r&&(r=e.length);let n=0;for(let i=0;i<r;++i)n+=t[i]*e[i];return n}static offsetToIndices(e,t){let r=t.length;if(0===r)return[];if(1===r)return[e*t[0]];let n=Array(t.length);for(let r=0;r<n.length-1;++r)n[r]=Math.floor(e/t[r]),e-=n[r]*t[r];return n[n.length-1]=e,n}static normalizeAxis(e,t){if(e<-t&&e>=t)throw Error("unsupported axis for this operation.");return e<0?e+t:e}static normalizeAxes(e,t){return e.map(e=>this.normalizeAxis(e,t))}static incrementIndex(e,t,r){if(0===t.length||0===e.length)throw Error("Index incrementing unsupported for scalar Tensor");if(void 0===r)r=t.length;else if(r<=0||r>t.length)throw Error("Incorrect axis to increment on");for(let n=r-1;n>=0&&(e[n]++,!(e[n]<t[n]));--n)e[n]=0}static calculateReshapedDims(t,r){if(0===r.length)if(0===t.length||1===e.size(t))return[];else throw Error("cannot reshape to a scalar Tensor");let n=r.length,i=Array(n),o=-1,s=1;for(let e=0;e<n;e++){if(r[e]<-1)throw Error("a dimension in shape hints cannot be less than -1");if(-1===r[e]){if(-1!==o)throw Error("at most one dimension in shape hints can be -1");o=e}else{if(0===r[e]){if(e>=t.length)throw Error("the dimension with value zero exceeds the dimension size of the input tensor");i[e]=t[e]}else i[e]=r[e];s*=i[e]}}let a=e.size(t);if(-1!==o){if(a%s!=0)throw Error(`the input tensor cannot be reshaped to the requested shape. Input shape: [${t}] Output shape: [${r}]`);i[o]=a/s}else if(s!==a)throw Error("reshapedDims and originalDims don't have matching sizes");return i}static sortBasedOnPerm(e,t){return t?t.map(t=>e[t]):e.slice().reverse()}static padShape(e,t){let r=e.length;return e.map((e,n)=>e+t[n]+t[n+r])}static areEqual(e,t){return e.length===t.length&&e.every((e,r)=>e===t[r])}static validateDimsAndCalcSize(e){if(e.length>6)throw TypeError("Only rank 0 to 6 is supported for tensor shape.");let t=1;for(let r of e){if(!Number.isInteger(r))throw TypeError(`Invalid shape: ${r} is not an integer`);if(r<0||r>0x7fffffff)throw TypeError(`Invalid shape: length ${r} is not allowed`);t*=r}return t}static flattenShape(e,t){t<0&&(t+=e.length);let r=e.reduce((e,t)=>e*t,1),n=e.slice(t).reduce((e,t)=>e*t,1);return[r/n,n]}static squeezeShape(t,r){let n=[];r=e.normalizeAxes(r,t.length);for(let e=0;e<t.length;e++){let i=r.indexOf(e)>=0;if(i&&1!==t[e])throw Error("squeeze an axis of size different than 1");(0===r.length&&t[e]>1||r.length>0&&!i)&&n.push(t[e])}return n}static unsqueezeShape(t,r){let n=Array(t.length+r.length);n.fill(0);for(let t=0;t<r.length;t++){let i=e.normalizeAxis(r[t],n.length);if(i>=n.length)throw Error("'axes' has an out of range axis");if(0!==n[i])throw Error("'axes' has a duplicate axis");n[i]=1}let i=0;for(let e=0;e<n.length;e++)0===n[e]&&(n[e]=t[i++]);if(i!==t.length)throw Error("the unsqueezed dimension could not be established");return n}},eI=class e{static splitShape(t,r,n,i){if(0===n.length){if(!i)throw Error("need to know number of outputs when the 'split' attribute is not specified");e.determineSplit(t[r],i,n)}let o=[],s=[0];for(let e=0;e<n.length;++e){0!==e&&s.push(s[e-1]+n[e-1]);let i=t.slice();i[r]=n[e],o.push(i)}return[o,s]}static determineSplit(e,t,r){if(e%t!=0)throw Error("cannot split tensor to equal sized parts");for(let n=0;n<t;++n)r.push(e/t)}},eS=class e{static adjustPoolAttributes(e,t,r,n,i,o){if(!e&&r.length!==t.length-2)throw Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(e)for(let e=0;e<t.length-2;e++)e>=r.length?r.push(t[e+2]):r[e]=t[e+2];for(let e=0;e<r.length;e++)if(e<n.length){if(n[e]<0)throw Error("strides should be greater than or equal to 1")}else n.push(1);for(let e=0;e<r.length;e++)if(e<i.length){if(i[e]<0)throw Error("dilations should be greater than or equal to 1")}else i.push(1);for(let e=0;e<2*r.length;e++)if(e<o.length){if(o[e]<0)throw Error("pad should be greater than or equal to 1")}else o.push(0);for(let e=0;e<r.length;e++){if(r[e]<=0)throw Error("kernel shapes need to be greater than 0");if(o[e]>=r[e]||o[e+r.length]>=r[e])throw Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,n,i,o,s){if(s){if(o.length!==2*(t.length-2))throw Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw Error("length of strides should be the length of data dimensions");if(i.length!==t.length-2)throw Error("length of kernel shapes should be the length of data dimensions");for(let a=0;a<t.length-2;a++)e.adjustPadAndReturnShape(t[a+2],r[a],n[a],i[a],o,a,a+t.length-2,s)}}static computePoolOutputShape(t,r,n,i,o,s,a,u=0){if(r.length<=0)throw Error("input shape must be of size greater than 0");let l=[r[0],r[1]];return e.computeShapeHelper(t,r,l,n,i,o,s,a,u),l}static computeConvOutputShape(t,r,n,i,o,s,a){if(t.length<=0||r.length<=0)throw Error("invalid input tensor dims or invalid filter tensor dims");let u=[t[0],r[0]];return e.computeShapeHelper(!1,t,u,n,i,o,s,a),u}static computeShapeHelper(t,r,n,i,o,s,a,u,l=0){if(t)for(let e=0;e<r.length-2;e++)n.push(1);else for(let t=0;t<r.length-2;t++)n.push(e.adjustPadAndReturnShape(r[t+2],i[t],o[t],s[t],a,t,t+r.length-2,u,l))}static computeOutputSize(e,t,r,n,i){let o=Math.floor(e/t)+1;return 1===i&&((o=Math.ceil(e/t)+1)-1)*t>=r+n&&(o-=1),o}static adjustPadAndReturnShape(t,r,n,i,o,s,a,u,l=0){let d=n*(i-1)+1;if(!u||"NOTSET"===u)return e.computeOutputSize(t+o[s]+o[a]-d,r,t,o[s],l);switch(u){case"VALID":return o[s]=0,o[a]=0,e.computeOutputSize(t-d,r,t,0,l);case"SAME_LOWER":case"SAME_UPPER":if(1!==n)throw Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let n=(Math.floor((t+r-1)/r)-1)*r+i-t;return o[s]="SAME_LOWER"===u?Math.floor((n+1)/2):Math.floor(n/2),o[a]=n-o[s],e.computeOutputSize(t+o[s]+o[a]-d,r,t,o[s],l)}default:throw Error("Unsupported AutoPad type")}}},eO=-34028234663852886e22,eE=34028234663852886e22}});function cD(e){switch(e){case ek.onnx.TensorProto.DataType.UINT8:case ek.onnx.TensorProto.DataType.INT8:case ek.onnx.TensorProto.DataType.BOOL:return 1;case ek.onnx.TensorProto.DataType.UINT16:case ek.onnx.TensorProto.DataType.INT16:return 2;case ek.onnx.TensorProto.DataType.FLOAT:case ek.onnx.TensorProto.DataType.INT32:case ek.onnx.TensorProto.DataType.UINT32:return 4;case ek.onnx.TensorProto.DataType.INT64:case ek.onnx.TensorProto.DataType.DOUBLE:case ek.onnx.TensorProto.DataType.UINT64:return 8;default:throw Error(`cannot calculate sizeof() on type ${ek.onnx.TensorProto.DataType[e]}`)}}function cz(e){switch(e){case"bool":case"uint8":return Uint8Array;case"int8":return Int8Array;case"int16":return Int16Array;case"uint16":return Uint16Array;case"int32":return Int32Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"float32":return Float32Array;case"float64":return Float64Array;default:throw Error("unspecified error")}}function cC(e,t){if(t===ek.onnx.TensorProto.DataType.INT64||t===ef.TensorDataType.INT64){if(e.greaterThanOrEqual(0x80000000)||e.lessThan(-0x80000000))throw TypeError("int64 is not supported")}else if(t===ek.onnx.TensorProto.DataType.UINT32||t===ef.TensorDataType.UINT32||t===ek.onnx.TensorProto.DataType.UINT64||t===ef.TensorDataType.UINT64){if(e.greaterThanOrEqual(0x100000000)||e.lessThan(0))throw TypeError("uint64 is not supported")}else throw TypeError(`not a LONG type: ${ek.onnx.TensorProto.DataType[t]}`);return e.toNumber()}function cN(e,t,r){switch(t){case ek.onnx.TensorProto.DataType.BOOL:case ek.onnx.TensorProto.DataType.UINT8:return e.getUint8(r);case ek.onnx.TensorProto.DataType.INT8:return e.getInt8(r);case ek.onnx.TensorProto.DataType.UINT16:return e.getUint16(r,!0);case ek.onnx.TensorProto.DataType.INT16:return e.getInt16(r,!0);case ek.onnx.TensorProto.DataType.FLOAT:return e.getFloat32(r,!0);case ek.onnx.TensorProto.DataType.INT32:return e.getInt32(r,!0);case ek.onnx.TensorProto.DataType.UINT32:return e.getUint32(r,!0);case ek.onnx.TensorProto.DataType.INT64:return cC(eu.fromBits(e.getUint32(r,!0),e.getUint32(r+4,!0),!1),t);case ek.onnx.TensorProto.DataType.DOUBLE:return e.getFloat64(r,!0);case ek.onnx.TensorProto.DataType.UINT64:return cC(eu.fromBits(e.getUint32(r,!0),e.getUint32(r+4,!0),!0),t);default:throw Error(`cannot read from DataView for type ${ek.onnx.TensorProto.DataType[t]}`)}}var cj=dQ({"web/lib/onnxjs/tensor.ts"(){"use strict";eP=d2(py()),pO(),cu(),ek=d2(cE()),cA(),eA=class e{constructor(e,t,r,n,i,o=eP.Guid.create()){this.dims=e,this.type=t,this.dataProvider=r,this.asyncDataProvider=n,this.cache=i,this.dataId=o,this.size=eT.validateDimsAndCalcSize(e);let s=this.size,a=void 0===r&&void 0===n&&void 0===i;if(void 0!==i&&i.length!==s)throw RangeError("Input dims doesn't match data length.");if("string"===t){if(void 0!==i&&(!Array.isArray(i)||!i.every(e=>"string"==typeof e)))throw TypeError("cache should be a string array");a&&(this.cache=Array(s))}else{if(void 0!==i){let e=cz(t);if(!(i instanceof e))throw TypeError(`cache should be type ${e.name}`)}if(a){let e=new ArrayBuffer(s*function(e){switch(e){case"bool":case"int8":case"uint8":return 1;case"int16":case"uint16":return 2;case"int32":case"uint32":case"float32":return 4;case"float64":return 8;default:throw Error(`cannot calculate sizeof() on type ${e}`)}}(t));this.cache=new(cz(t))(e)}}}get data(){if(void 0===this.cache){let e=this.dataProvider(this.dataId);if(e.length!==this.size)throw Error("Length of data provided by the Data Provider is inconsistent with the dims of this Tensor.");this.cache=e}return this.cache}get stringData(){if("string"!==this.type)throw TypeError("data type is not string");return this.data}get integerData(){switch(this.type){case"uint8":case"int8":case"uint16":case"int16":case"int32":case"uint32":case"bool":return this.data;default:throw TypeError("data type is not integer (uint8, int8, uint16, int16, int32, uint32, bool)")}}get floatData(){switch(this.type){case"float32":case"float64":return this.data;default:throw TypeError("data type is not float (float32, float64)")}}get numberData(){if("string"!==this.type)return this.data;throw TypeError("type cannot be non-number (string)")}get(e){return this.data[eT.indicesToOffset(e,this.strides)]}set(e,t){this.data[eT.indicesToOffset(e,this.strides)]=t}async getData(){return void 0===this.cache&&(this.cache=await this.asyncDataProvider(this.dataId)),this.cache}get strides(){return this._strides||(this._strides=eT.computeStrides(this.dims)),this._strides}static fromProto(t){if(!t)throw Error("cannot construct Value from an empty tensor");let r=ew.tensorDataTypeFromProto(t.dataType),n=new e(ew.tensorDimsFromProto(t.dims),r);if("string"===r)t.stringData.forEach((e,t)=>{n.data[t]=ck(e)});else if(t.rawData&&"number"==typeof t.rawData.byteLength&&t.rawData.byteLength>0){let e=n.data,r=new DataView(t.rawData.buffer,t.rawData.byteOffset,t.rawData.byteLength),i=cD(t.dataType),o=t.rawData.byteLength/i;if(t.rawData.byteLength%i!=0)throw Error("invalid buffer length");if(e.length!==o)throw Error("buffer length mismatch");for(let n=0;n<o;n++){let o=cN(r,t.dataType,n*i);e[n]=o}}else{let e;switch(t.dataType){case ek.onnx.TensorProto.DataType.FLOAT:e=t.floatData;break;case ek.onnx.TensorProto.DataType.INT32:case ek.onnx.TensorProto.DataType.INT16:case ek.onnx.TensorProto.DataType.UINT16:case ek.onnx.TensorProto.DataType.INT8:case ek.onnx.TensorProto.DataType.UINT8:case ek.onnx.TensorProto.DataType.BOOL:e=t.int32Data;break;case ek.onnx.TensorProto.DataType.INT64:e=t.int64Data;break;case ek.onnx.TensorProto.DataType.DOUBLE:e=t.doubleData;break;case ek.onnx.TensorProto.DataType.UINT32:case ek.onnx.TensorProto.DataType.UINT64:e=t.uint64Data;break;default:throw Error("unspecific error")}if(null==e)throw Error("failed to populate data from a tensorproto value");let r=n.data;if(r.length!==e.length)throw Error("array length mismatch");for(let n=0;n<e.length;n++){let i=e[n];eu.isLong(i)?r[n]=cC(i,t.dataType):r[n]=i}}return n}static fromData(t,r,n){return new e(r,n,void 0,void 0,t)}static fromOrtTensor(t){if(!t)throw Error("cannot construct Value from an empty tensor");let r=ew.tensorDimsFromORTFormat(t),n=ew.tensorDataTypeFromProto(t.dataType()),i=new e(r,n);if("string"===n)for(let e=0;e<t.stringDataLength();e++)i.data[e]=t.stringData(e);else if(t.rawDataArray()&&"number"==typeof t.rawDataLength()&&t.rawDataLength()>0){let e=i.data,r=new DataView(t.rawDataArray().buffer,t.rawDataArray().byteOffset,t.rawDataLength()),n=cD(t.dataType()),o=t.rawDataLength()/n;if(t.rawDataLength()%n!=0)throw Error("invalid buffer length");if(e.length!==o)throw Error("buffer length mismatch");for(let i=0;i<o;i++){let o=cN(r,t.dataType(),i*n);e[i]=o}}return i}}}});function cR(e){return 1===e?eD:ez}var cB=dQ({"web/lib/onnxjs/backends/webgl/glsl-source.ts"(){"use strict";eD={version:"",attribute:"attribute",varyingVertex:"varying",varyingFrag:"varying",texture2D:"texture2D",output:"gl_FragColor",outputDeclaration:""},ez={version:"#version 300 es",attribute:"in",varyingVertex:"out",varyingFrag:"in",texture2D:"texture",output:"outputColor",outputDeclaration:"out vec4 outputColor;"}}}),cM=dQ({"web/lib/onnxjs/backends/webgl/types.ts"(){}});async function cF(e,t=e=>0,r){return new Promise((n,i)=>{let o=0,s=()=>{if(e())return void n();let a=t(++o);null!=r&&o>=r?i():setTimeout(s,a)};s()})}function cL(e){return cP(void 0!==e&&0!==e.length,()=>"empty string found for sampler name"),"get"+e.charAt(0).toUpperCase()+e.slice(1)}function cV(e,t){JSON.parse(JSON.stringify(e));return t}function cU(e,t){return t.map(t=>e[t]).join(", ")}function cq(e){if(e<=1)return"int";if(2===e)return"ivec2";if(3===e)return"ivec3";if(4===e)return"ivec4";if(5===e)return"ivec5";else if(6===e)return"ivec6";else throw Error(`GPU for rank ${e} is not yet supported`)}function cG(e=6){return["x","y","z","w","u","v"].slice(0,e)}var cH=dQ({"web/lib/onnxjs/backends/webgl/utils.ts"(){"use strict";cA()}});function cW(e,t){return 1===t?[e]:cG(t).map(t=>`${e}.${t}`)}function cK(){return`
    float getChannel(vec4 frag, int dim) {
      int modCoord = imod(dim, 2);
      return modCoord == 0 ? frag.r : frag.g;
    }

    float getChannel(vec4 frag, vec2 innerDims) {
      vec2 modCoord = mod(innerDims, 2.);
      return modCoord.x == 0. ?
        (modCoord.y == 0. ? frag.r : frag.g) :
        (modCoord.y == 0. ? frag.b : frag.a);
    }
  `}var cX=dQ({"web/lib/onnxjs/backends/webgl/ops/packing-utils.ts"(){"use strict";cH()}}),cZ=dQ({"web/lib/onnxjs/backends/webgl/ops/pack.ts"(){"use strict";cB(),cM(),cH(),cX(),eC={name:"pack",inputNames:["A"],inputTypes:[1]},eN=(e,t)=>({...eC,get:()=>{var r,n;let i,o,s,a,u,l,d,p,c,h,f;return o=cR(e.session.backend.glContext.version),a=(s=t.dims).length,l=cq(u=t.dims.length),d=cW("rc",u),r=s[s.length-2],n=s[s.length-1],p=0===u||1===u?"":`
    int r = ${d[u-2]};
    int c = ${d[u-1]};
    int rp1 = ${d[u-2]} + 1;
    int cp1 = ${d[u-1]} + 1;
    bool rEdge = rp1 >= ${n};
    bool cEdge = cp1 >= ${r};
    `,i=0===a?[1,1]:1===a?[s[0],1]:[s[u-1],s[u-2]],c=function(e,t,r){if(0===e)return"false";if(1===e)return`rc > ${t[0]}`;let n="";for(let i=e-2;i<e;i++)n+=`${r[i]} >= ${t[i-e+2]}`,i<e-1&&(n+="||");return n}(u,i,d),h=function(e,t){let r=e.length;if(0===r)return"getA(), 0, 0, 0";if(1===r)return`getA(rc),
            rc + 1 >= ${e[0]} ? 0. : getA(rc + 1),
            0, 0`;let n="";if(r>2)for(let e=0;e<r-2;++e)n+=`${t[e]},`;return`getA(${n}r, c),
          rEdge ? 0. : getA(${n}rp1, c),
          cEdge ? 0. : getA(${n}r, cp1),
          rEdge || cEdge ? 0. : getA(${n}rp1, cp1)`}(s,d),f=`
        void main() {
          ${l} rc = getOutputCoords();

          if(${c}) {
            ${o.output} = vec4(0);
          } else {
            ${p}

            ${o.output} = vec4(${h});
          }
        }
      `,{...eC,hasMain:!0,output:{dims:t.dims,type:t.type,textureType:2},shaderSource:f}}})}});function cJ(e){if(0===e.length)return[1,1,1];let t=1;for(let r=0;r<e.length-2;++r)t*=e[r];return[t,e.length>1?e[e.length-2]:1,e[e.length-1]]}var cQ=dQ({"web/lib/onnxjs/backends/webgl/ops/reshape-packed.ts"(){"use strict";cA(),cB(),cM(),cX(),ej=(e,t,r)=>{let n={name:"Reshape (packed)",inputTypes:[2],inputNames:["A"],cacheHint:`${r}`};return{...n,get:()=>((e,t,r,n)=>{let i,o,s,a,u,l=t.dims,d="";for(let e=0;e<4;e++){let t="";switch(e){case 0:t="outputCoords = rc;";break;case 1:t="outputCoords = ivec3(rc.x, rc.y+1, rc.z);";break;case 2:t="outputCoords = ivec3(rc.x, rc.y, rc.z+1);";break;case 3:t="outputCoords = ivec3(rc.x, rc.y+1, rc.z+1);";break;default:throw Error()}d+=`
        ${t}
        ${e>0?"if(outputCoords.y < rows && outputCoords.z < cols){":""}
          int flattenedIndex = getFlattenedIndex(outputCoords);

          ivec3 inputRC = inputCoordsFromReshapedOutCoords(flattenedIndex);
          vec2 innerDims = vec2(float(inputRC.y),float(inputRC.z));

          result[${e}] = getChannel(getA(inputRC.x, inputRC.y, inputRC.z), innerDims);

        ${e>0?"}":""}
      `}let p=cR(e.session.backend.glContext.version),c=`
      ${(i=eT.computeStrides(l),o=["b","r","c"],s="index",a=i.map((e,t)=>{let r=`int ${o[t]} = ${s} / ${e}`,n=t===i.length-1?`int ${o[t+1]} = ${s} - ${o[t]} * ${e}`:`index -= ${o[t]} * ${e}`;return`${r}; ${n};`}).join(""),`
    ivec3 inputCoordsFromReshapedOutCoords(int index) {
      ${a}
      return ivec3(b, r, c);
    }
  `)}
      ${(u=eT.computeStrides(n),`
  int getFlattenedIndex(ivec3 coords) {
    // reverse y, z order
    return coords.x * ${u[0]} + coords.z * ${u[1]} + coords.y;
  }
`)}
      ${cK()}

      void main() {
        ivec3 rc = getOutputCoords();

        vec4 result = vec4(0.0);

        ivec3 outputCoords;
        int rows = ${n[2]};
        int cols = ${n[1]};

        ${d}
        ${p.output} = result;
      }
    `;return{...r,output:{dims:n,type:t.type,textureType:2},shaderSource:c,hasMain:!0}})(e,t,n,r)}}}}),cY=dQ({"web/lib/onnxjs/backends/webgl/ops/uint8-encode.ts"(){"use strict";cB(),cM(),eR=(e,t)=>{let r=t.shape,n=cR(e.session.backend.glContext.version),i=`
    const float FLOAT_MAX = 1.70141184e38;
    const float FLOAT_MIN = 1.17549435e-38;

    bool isNaN(float val) {
      return (val < 1.0 || 0.0 < val || val == 0.0) ? false : true;
    }

    highp vec4 encodeAsUint8(highp float v) {
      if (isNaN(v)) {
        return vec4(255, 255, 255, 255);
      }

      highp float av = abs(v);

      if(av < FLOAT_MIN) {
        return vec4(0.0, 0.0, 0.0, 0.0);
      } else if(v > FLOAT_MAX) {
        return vec4(0.0, 0.0, 128.0, 127.0) / 255.0;
      } else if(v < -FLOAT_MAX) {
        return vec4(0.0, 0.0,  128.0, 255.0) / 255.0;
      }

      highp vec4 c = vec4(0,0,0,0);

      highp float e = floor(log2(av));
      highp float m = exp2(fract(log2(av))) - 1.0;

      c[2] = floor(128.0 * m);
      m -= c[2] / 128.0;
      c[1] = floor(32768.0 * m);
      m -= c[1] / 32768.0;
      c[0] = floor(8388608.0 * m);

      highp float ebias = e + 127.0;
      c[3] = floor(ebias / 2.0);
      ebias -= c[3] * 2.0;
      c[2] += floor(ebias) * 128.0;

      c[3] += 128.0 * step(0.0, -v);

      return c / 255.0;
    }

    void main() {
      float value = ${n.texture2D}(X,TexCoords).r;
      ${n.output} = encodeAsUint8(value);
    }`,o={name:"Uint8Encode",inputTypes:[0],inputNames:["X"],output:{dims:r,type:t.tensor.type,textureType:3},shaderSource:i,hasMain:!0};return e.executeProgram(o,[t.tensor])}}}),c0=dQ({"web/lib/onnxjs/backends/webgl/ops/unpack.ts"(){"use strict";cB(),cM(),cH(),cX(),eB={name:"unpack",inputNames:["A"],inputTypes:[2]},eM=(e,t)=>({...eB,get:()=>{let r,n,i,o,s,a,u,l,d;return i=(n=cW("rc",r=t.dims.length)).slice(-2),o=cq(r),s=cK(),a=0===t.dims.length?"":function(e,t){if(1===e)return"rc";let r="";for(let n=0;n<e;n++)r+=t[n],n<e-1&&(r+=",");return r}(r,n),u=r<=1?"rc":`vec2(${i.join(",")})`,l=cR(e.session.backend.glContext.version),d=`
    ${s}
    void main() {
      ${o} rc = getOutputCoords();

       // Sample the texture with the coords to get the rgba channel value.
       vec4 packedInput = getA(${a});

       ${l.output} = vec4(getChannel(packedInput, ${u}), 0, 0, 0);
     }
   `,{...eB,hasMain:!0,output:{dims:t.dims,type:t.type,textureType:0},shaderSource:d}}})}}),c1=dQ({"web/lib/onnxjs/backends/webgl/texture-data-encoder.ts"(){"use strict";pm(),eF=class{constructor(e,t=1){if(1===t)this.internalFormat=e.R32F,this.format=e.RED,this.textureType=e.FLOAT,this.channelSize=t;else if(4===t)this.internalFormat=e.RGBA32F,this.format=e.RGBA,this.textureType=e.FLOAT,this.channelSize=t;else throw Error(`Invalid number of channels: ${t}`)}encode(e,t){let r,n;return e.constructor!==Float32Array&&(F.warning("Encoder","data was not of type Float32; creating new Float32Array"),n=new Float32Array(e)),t*this.channelSize>e.length?(F.warning("Encoder","Source data too small. Allocating larger array"),n=e,r=this.allocate(t*this.channelSize),n.forEach((e,t)=>r[t]=e)):r=n=e,r}allocate(e){return new Float32Array(4*e)}decode(e,t){return 1===this.channelSize?e.filter((e,t)=>t%4==0).subarray(0,t):e.subarray(0,t)}},eL=class{constructor(e,t=1,r){if(1!==t&&4!==t)throw Error(`Invalid number of channels: ${t}`);this.internalFormat=e.RGBA,this.format=e.RGBA,this.channelSize=t,this.textureType=r||e.FLOAT}encode(e,t){let r=e;return 1===this.channelSize&&(F.verbose("Encoder","Exploding into a larger array"),r=this.allocate(t),e.forEach((e,t)=>r[4*t]=e)),r}allocate(e){return new Float32Array(4*e)}decode(e,t){return 1===this.channelSize?e.filter((e,t)=>t%4==0).subarray(0,t):e.subarray(0,t)}},eV=class{constructor(e,t=1){if(this.channelSize=4,1===t)this.internalFormat=e.ALPHA,this.format=e.ALPHA,this.textureType=e.UNSIGNED_BYTE,this.channelSize=t;else if(4===t)this.internalFormat=e.RGBA,this.format=e.RGBA,this.textureType=e.UNSIGNED_BYTE,this.channelSize=t;else throw Error(`Invalid number of channels: ${t}`)}encode(e,t){return new Uint8Array(e.buffer,e.byteOffset,e.byteLength)}allocate(e){return new Uint8Array(e*this.channelSize)}decode(e,t){if(e instanceof Uint8Array)return e.subarray(0,t);throw Error(`Invalid array type: ${e.constructor}`)}}}}),c2=dQ({"web/lib/onnxjs/backends/webgl/texture-layout.ts"(){"use strict";cA(),cM(),eU=(e,t,r)=>{let n=4===r?t.length-1:void 0,i=4===r?t.map((e,r)=>r===t.length-1?4*e:e):void 0;return eG(e,t,0===r||1===r?1:4,i,{isPacked:2===r,reverseWH:1===r||2===r,breakAxis:n})},eq=(e,t,r)=>{let n=eU(e,t,r);return[n.width,n.height]},eG=(e,t,r=1,n,i)=>{let o=!!(i&&i.isPacked),[s,a]=e.computeTextureWH(o&&n||t,i),u=t.length,l=t.slice(0);if(0===u&&(l=[1]),1===r)n=t;else if(o){if(4!==r)throw Error("a packed texture must be 4-channel");n=t,u>0&&(l[u-1]=Math.ceil(l[u-1]/2)),u>1&&(l[u-2]=Math.ceil(l[u-2]/2))}else if(!n)throw Error("Unpacked shape is needed when using channels > 1");return{width:s,height:a,channels:r,isPacked:o,shape:l,strides:eT.computeStrides(l),unpackedShape:n,reversedWH:i&&i.reverseWH}}}}),c3=dQ({"web/lib/onnxjs/backends/webgl/inference-handler.ts"(){"use strict";pm(),cj(),cA(),cZ(),cQ(),cY(),c0(),c1(),c2(),cM(),eH=class{constructor(e){this.session=e,this.packedTextureDataCache=new Map,this.unpackedTextureDataCache=new Map}calculateTextureWidthAndHeight(e,t){return eq(this.session.layoutStrategy,e,t)}executeProgram(e,t){let r,n;if(t.length<e.inputNames.length)throw Error(`Input size mustn't be less than ${e.inputNames.length}.`);if(e.inputNames.length!==e.inputTypes.length)throw Error("input names size does not match input types");let i=[];for(let r=0;r<e.inputNames.length;++r)i[r]=this.getOrCreateTextureData(t[r],e.inputTypes[r]);let o=(r=i.map(e=>`${e.unpackedShape.join(",")};${e.width}x${e.height}`).join("_"),n=e.name,e.cacheHint&&(n+="["+e.cacheHint+"]"),n+=":"+r),s=this.session.programManager.getArtifact(o),a=s?s.programInfo:"function"==typeof e.get?e.get():e,u=eU(this.session.layoutStrategy,a.output.dims,a.output.textureType),l=this.createTextureData(u,a.output.type);return s||(s=this.session.programManager.build(a,i,l),this.session.programManager.setArtifact(o,s)),this.runProgram(s,i,l),l}run(e,t){return this.executeProgram(e,t).tensor}runProgram(e,t,r){for(let r=0;r<t.length;++r)if(!!t[r].isPacked!=(2===e.programInfo.inputTypes[r]))throw Error(`input[${r}] property packed inconsistent`);if(!!r.isPacked!=(2===e.programInfo.output.textureType))throw Error("output property packed inconsistent");this.session.programManager.run(e,t,r)}getOrCreateTextureData(e,t){let r=this.getTextureData(e.dataId,2===t);if(!r&&(r=this.getTextureData(e.dataId,2!==t)))if(2===t)return this.pack(r);else return this.unpack(r);if(!r){let n=eU(this.session.layoutStrategy,e.dims,t);if(4===t){let r=e.dims;if(4===r.length){let n=[r[0],Math.ceil(r[1]*r[2]*r[3]/4)],i=eU(this.session.layoutStrategy,n,t),o=e.numberData;if(r[1]*r[2]*r[3]%4!=0){let t=r[0],n=r[1]*r[2]*r[3],i=4*Math.ceil(n/4);o=new Float32Array(t*i);for(let r=0;r<t;++r){let t=r*n,s=r*i+r%1*n;o.set(e.numberData.subarray(t,t+n),s)}}return this.createTextureData(i,e.type,o,e,1)}}if(2===t){let t=eG(this.session.layoutStrategy,e.dims,1,[],{reverseWH:!0}),n=this.createTextureData(t,e.type,e.numberData,e,1);r=this.pack(n)}else r=this.createTextureData(n,e.type,e.numberData,e,1)}return r}createTextureDataFromLayoutBindTensor(e,t,r,n){return this.createTextureData(e,t,r,n,1)}createTextureData(e,t,r,n,i){F.verbose("InferenceHandler",`Creating TextureData: layout:[${JSON.stringify(e)}]`);let o=this.session.textureManager.createTextureFromLayout(t,e,r,i);return this.createTextureDataFromTexture(e,t,o,n)}reshapeUnpacked(e,t){let r=this.getOrCreateTextureData(e,0),n={channels:r.channels,height:r.height,width:r.width,shape:0!==t.length?t:[1],strides:eT.computeStrides(t),unpackedShape:t};return this.createTextureDataFromTexture(n,e.type,r.texture).tensor}reshapePacked(e,t){var r;let n=this.getOrCreateTextureData(e,2);if(r=e.dims,0===r.length||0===t.length||(r.length<2||t.length<2?r[r.length-1]===t[t.length-1]:r[r.length-1]===t[t.length-1]&&r[r.length-2]===t[t.length-2])){let r={channels:n.channels,height:n.height,width:n.width,shape:0!==t.length?t:[1],strides:eT.computeStrides(t),unpackedShape:t,isPacked:!0};return this.createTextureDataFromTexture(r,e.type,n.texture).tensor}let i=cJ(e.dims),o=cJ(t),s=this.reshapePacked(e,i),a=this.run(ej(this,s,o),[s]);return this.reshapePacked(a,t)}cast(e,t){let r=this.getOrCreateTextureData(e,0);return this.createTextureDataFromTexture(r,t,r.texture).tensor}createTextureDataFromTexture(e,t,r,n,i){let o={...e,tensor:n||new eA(e.unpackedShape,t,e=>this.readTexture(o),async e=>this.readTextureAsync(o),void 0,i),texture:r};return this.setTextureData(o.tensor.dataId,o,e.isPacked),o}getTextureData(e,t=!1){return this.session.isInitializer(e)?this.session.getTextureData(e,t):t?this.packedTextureDataCache.get(e):this.unpackedTextureDataCache.get(e)}setTextureData(e,t,r=!1){this.session.isInitializer(e)?this.session.setTextureData(e,t,r):(r?this.packedTextureDataCache:this.unpackedTextureDataCache).set(e,t)}isTextureLayoutCached(e,t=!1){return!!this.getTextureData(e.dataId,t)}dispose(){this.session.textureManager.clearActiveTextures(),this.packedTextureDataCache.forEach(e=>this.session.textureManager.releaseTexture(e)),this.packedTextureDataCache=new Map,this.unpackedTextureDataCache.forEach(e=>this.session.textureManager.releaseTexture(e)),this.unpackedTextureDataCache=new Map}readTexture(e){return e.isPacked?this.readTexture(this.unpack(e)):this.session.backend.glContext.isFloat32DownloadSupported?this.session.textureManager.readTexture(e,e.tensor.type,e.channels):this.session.textureManager.readUint8TextureAsFloat(eR(this,e))}async readTextureAsync(e){return e.isPacked?this.readTextureAsync(this.unpack(e)):this.session.backend.glContext.isFloat32DownloadSupported?this.session.textureManager.readTextureAsync(e,e.tensor.type,e.channels):this.session.textureManager.readUint8TextureAsFloat(eR(this,e))}pack(e){return this.executeProgram(eN(this,e.tensor),[e.tensor])}unpack(e){return this.executeProgram(eM(this,e.tensor),[e.tensor])}}}}),c4=dQ({"web/lib/onnxjs/attribute-with-cache-key.ts"(){"use strict";eW=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},eK=e=>new eW(e)}}),c6=dQ({"web/lib/onnxjs/backends/webgl/ops/batch-normalization.ts"(){"use strict";c4(),cB(),cM(),eX={name:"BatchNormalization",inputNames:["A","Scale","B","Mean","Variance"],inputTypes:[0,0,0,0,0]},eZ=(e,t,r)=>(eY(t),[e.run({...eX,cacheHint:r.cacheKey,get:()=>eQ(e,t,r)},t)]),eJ=e=>{let t=e.attributes.getFloat("epsilon",1e-5),r=e.attributes.getFloat("momentum",.9),n=e.attributes.getInt("spatial",1);return eK({epsilon:t,momentum:r,spatial:n})},eQ=(e,t,r)=>{let n=cR(e.session.backend.glContext.version),i=t[0].dims.length,[o,s]=e.calculateTextureWidthAndHeight(t[1].dims,0),a=`
  float process(int[${i}] indices) {
    vec2 position = offsetToCoords(indices[1], ${o}, ${s});
    float scale = getColorAsFloat(${n.texture2D}(Scale, position));
    float mean = getColorAsFloat(${n.texture2D}(Mean, position));
    float variance = getColorAsFloat(${n.texture2D}(Variance, position));
    float b = getColorAsFloat(${n.texture2D}(B, position));

    return scale * ( (_A(indices) - mean) / sqrt(variance + float(${r.epsilon})) ) + b;
  }`;return{...eX,output:{dims:t[0].dims,type:t[0].type,textureType:0},shaderSource:a}},eY=e=>{if(!e||5!==e.length)throw Error("BatchNormalization requires 5 inputs.");let t=e[0],r=e[1],n=e[2],i=e[3],o=e[4];if(t.dims.length<3||1!==r.dims.length||1!==n.dims.length||1!==i.dims.length||1!==o.dims.length||r.dims[0]!==t.dims[1]||n.dims[0]!==t.dims[1]||i.dims[0]!==t.dims[1]||o.dims[0]!==t.dims[1])throw Error("invalid input shape.");if("float32"!==t.type&&"float64"!==t.type||"float32"!==r.type&&"float64"!==r.type||"float32"!==n.type&&"float64"!==n.type||"float32"!==i.type&&"float64"!==i.type||"float32"!==o.type&&"float64"!==o.type)throw Error("invalid input tensor types.")}}}),c8=dQ({"web/lib/onnxjs/backends/webgl/glsl-definitions.ts"(){"use strict";e0=class{constructor(e,t,r,n){this.glContext=e,this.programInfo=t,this.inputTextureLayouts=r,this.outputTextureLayout=n}},e1=class{constructor(e){this.context=e}},e2=class{constructor(e,t){this.routineBody=e,this.dependencies=t}},e3=class{constructor(e,t,r){this.name=e,r?this.dependencies=r:this.dependencies=[],t&&(this.routineBody=t)}addDependency(e){e&&this.dependencies.push(e)}},e4=class{static returnOrderedNodes(e){if(!e||0===e.length)return[];if(1===e.length)return e;let t=new Set,r=new Set,n=[];return this.createOrderedNodes(e,t,r,n),n}static createOrderedNodes(e,t,r,n){for(let i=0;i<e.length;++i)this.dfsTraverse(e[i],t,r,n)}static dfsTraverse(e,t,r,n){if(!e||r.has(e.name))return;if(t.has(e.name))throw Error("Cyclic dependency detected. Can't topologically sort routines needed for shader.");t.add(e.name);let i=e.dependencies;if(i&&i.length>0)for(let e=0;e<i.length;++e)this.dfsTraverse(i[e],t,r,n);n.push(e),r.add(e.name),t.delete(e.name)}}}}),c5=dQ({"web/lib/onnxjs/backends/webgl/ops/binary-op.ts"(){"use strict";cA(),c8(),cB(),cM(),e6=(e,t,r,n=t[0].type,i)=>{let o=2*!!e.session.pack;return{name:r.name,inputNames:["A","B"],inputTypes:[o,o],cacheHint:i,get:()=>e8(e,t,r,n)}},e8=(e,t,r,n=t[0].type)=>{let i=2*!!e.session.pack,o=!eT.areEqual(t[0].dims,t[1].dims),s=t[0].dims,a=e.session.pack;if(o){let o=ev.calcShape(t[0].dims,t[1].dims,!1);if(!o)throw Error("Can't perform binary op on the given tensors");let u=(s=o).length,l=0!==t[0].dims.length?t[0].dims.length:1,d=0!==t[1].dims.length?t[1].dims.length:1,p=0!==t[0].dims.length?"bcastIndices_A(indices, aindices);":"aindices[0] = 0;",c=0!==t[1].dims.length?"bcastIndices_B(indices, bindices);":"bindices[0] = 0;",h=cR(e.session.backend.glContext.version),f=a?`
      ${r.body}
      void main() {
        vec4 a = getAAtOutCoords();
        vec4 b = getBAtOutCoords();
        vec4 result = ${r.name}(a, b);
        ${h.output} = result;
      }`:`
      ${r.body}
      float process(int indices[${u}]) {
        int aindices[${l}];
        int bindices[${d}];
        ${p}
        ${c}
        return ${r.name}(_A(aindices), _B(bindices));
      }`;return{name:r.name,inputNames:["A","B"],inputTypes:[i,i],output:{dims:s,type:n,textureType:i},shaderSource:f,hasMain:a}}let u=cR(e.session.backend.glContext.version),l=`
    ${r.body}
    void main() {
      vec4 v1 = ${u.texture2D}(A, TexCoords);
      vec4 v2 = ${u.texture2D}(B, TexCoords);
      vec4 result = ${r.name}(v1, v2);
      ${u.output} = result;
    }
    `;return{name:r.name,inputNames:["A","B"],inputTypes:[i,i],output:{dims:t[0].dims,type:n,textureType:i},shaderSource:l,hasMain:!0}},e5=(e,t)=>{let r;return[e.run(e6(e,t,(r="add_",{body:`
  float ${r}(float a, float b) {
    return a + b;
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return v1 + v2;
  }
  `,name:r,type:0})),t)]},e7=(e,t)=>{let r;return[e.run(e6(e,t,(r="and_",{body:`
  float ${r}(float a, float b) {
    return float( bool(a) && bool(b) );
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    bvec4 b1 = bvec4(v1);
    bvec4 b2 = bvec4(v2);
    return vec4( b1.r && b2.r ,
                b1.g && b2.g,
                b1.b && b2.b,
                b1.a && b2.a );
  }
  `,name:r,type:0}),"bool"),t)]},e9=(e,t)=>{let r;return[e.run(e6(e,t,(r="div_",{body:`
  float ${r}(float a, float b) {
    return a / b;
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return v1 / v2;
  }
  `,name:r,type:0})),t)]},te=(e,t)=>{let r;return[e.run(e6(e,t,(r="equal_",{body:`
  float ${r}(float a, float b) {
    return float(a == b);
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return vec4(equal(v1, v2));
  }
  `,name:r,type:0}),"bool"),t)]},tt=(e,t)=>{let r;return[e.run(e6(e,t,(r="greater_",{body:`
  float ${r}(float a, float b) {
    return float(a > b);
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return vec4( v1.r > v2.r ,
      v1.g > v2.g,
      v1.b > v2.b,
      v1.a > v2.a );
  }
  `,name:r,type:0}),"bool"),t)]},tr=(e,t)=>{let r;return[e.run(e6(e,t,(r="less_",{body:`
  float ${r}(float a, float b) {
    return float(a < b);
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return vec4( v1.r < v2.r ,
                v1.g < v2.g,
                v1.b < v2.b,
                v1.a < v2.a );
  }
  `,name:r,type:0}),"bool"),t)]},tn=(e,t)=>{let r;return[e.run(e6(e,t,(r="mul_",{body:`
  float ${r}(float a, float b) {
    return a * b;
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return v1 * v2;
  }
  `,name:r,type:0})),t)]},ti=(e,t)=>[e.run(e6(e,t,{body:`
  float or_(float a, float b) {
    return float( bool(a) || bool(b) );
  }
  vec4 or_(vec4 v1, vec4 v2) {
    bvec4 b1 = bvec4(v1);
    bvec4 b2 = bvec4(v2);
    return vec4( b1.r || b2.r ,
                b1.g || b2.g,
                b1.b || b2.b,
                b1.a || b2.a );
  }
  `,name:"or_",type:0},"bool"),t)],to=(e,t)=>{let r;return[e.run(e6(e,t,(r="pow_",{body:`
  float ${r}(float a, float b) {
    return pow(a, b);
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return pow(v1, v2);
  }
  `,name:r,type:0})),t)]},ts=(e,t)=>{let r;return[e.run(e6(e,t,(r="prelu_",{body:`
  float ${r}(float a, float b) {
    return a < 0.0 ? a * b: a;
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return vec4(
      v1.r < 0.0 ? v1.r * v2.r: v1.r,
      v1.g < 0.0 ? v1.g * v2.g: v1.g,
      v1.b < 0.0 ? v1.b * v2.b: v1.b,
      v1.a < 0.0 ? v1.a * v2.a: v1.a
      );
  }
  `,name:r,type:0})),t)]},ta=(e,t)=>{let r;return[e.run(e6(e,t,(r="sub_",{body:`
  float ${r}(float a, float b) {
    return a - b;
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    return v1 - v2;
  }
  `,name:r,type:0})),t)]},tu=(e,t)=>{let r;return[e.run(e6(e,t,(r="xor_",{body:`
  float ${r}(float a, float b) {
    return float( bool(a) ^^ bool(b) );
  }
  vec4 ${r}(vec4 v1, vec4 v2) {
    bvec4 b1 = bvec4(v1);
    bvec4 b2 = bvec4(v2);
    return vec4( b1.r ^^ b2.r ,
                b1.g ^^ b2.g,
                b1.b ^^ b2.b,
                b1.a ^^ b2.a );
  }
  `,name:r,type:0}),"bool"),t)]}}}),c7=dQ({"web/lib/onnxjs/backends/webgl/ops/cast.ts"(){"use strict";cA(),tl=(e,t,r)=>(tp(t),[e.cast(t[0],r)]),td=e=>ew.tensorDataTypeFromProto(e.attributes.getInt("to")),tp=e=>{if(!e||1!==e.length)throw Error("Cast requires 1 input.");if("string"===e[0].type)throw Error("Invalid input type.")}}}),c9=dQ({"web/lib/onnxjs/backends/webgl/ops/concat-packed.ts"(){"use strict";cB(),cM(),cH(),cX(),tc=(e,t,r)=>{let n,i,o=(n=t.length,i=r.cacheKey,{name:"Concat (packed)",inputNames:Array.from({length:n},(e,t)=>`X${t}`),inputTypes:Array(n).fill(2),cacheHint:i});return{...o,get:()=>((e,t,r,n)=>{let i=r[0].dims.slice();if(n>=i.length||n<-1*i.length)throw Error("axis specified for concat doesn't match input dimensionality");n<0&&(n=i.length+n);let o=i.slice(0);for(let e=1;e<r.length;e++){let t=r[e].dims.slice();for(let e=0;e<i.length;e++)if(e===n)o[n]+=t[e];else if(i[e]!==t[e])throw Error("non concat dimensions must match")}let s=o.length,a=cW("coords",s),u=cq(s),l=cK(),d=r.map(e=>e.dims),p=cG(s),c=Array(d.length-1);c[0]=d[0][n];for(let e=1;e<c.length;e++)c[e]=c[e-1]+d[e][n];let h=p[n],f=p.slice(-2),g=p.join(),m=`if (${h} < ${c[0]}) {
        return getChannel(
            getX0(${g}), vec2(${f.join()}));
        }`;for(let e=1;e<c.length;e++){let t=c[e-1];m+=`
            if (${h} < ${c[e]}  && ${h} >= ${c[e-1]}) {
              return getChannel(
                getX${e}(${th(p,h,t)}),
                vec2(${th(f,h,t)}));
            }`}let b=c.length,y=c[c.length-1];m+=`
            return getChannel(
              getX${b}(${th(p,h,y)}),
              vec2(${th(f,h,y)}));`;let _=cR(e.session.backend.glContext.version),v=`
          ${l}
          float getValue(${p.map(e=>"int "+e)}) {
            ${m}
          }

          void main() {
            ${u} coords = getOutputCoords();
            int lastDim = coords.${p[s-1]};
            coords.${p[s-1]} = coords.${p[s-2]};
            coords.${p[s-2]} = lastDim;

            vec4 result = vec4(getValue(${a}), 0., 0., 0.);

            ${a[s-1]} = ${a[s-1]} + 1;
            if (${a[s-1]} < ${o[s-1]}) {
              result.g = getValue(${a});
            }

            ${a[s-2]} = ${a[s-2]} + 1;
            if (${a[s-2]} < ${o[s-2]}) {
              result.a = getValue(${a});
            }

            ${a[s-1]} = ${a[s-1]} - 1;
            if (${a[s-2]} < ${o[s-2]} &&
                ${a[s-1]} < ${o[s-1]}) {
              result.b = getValue(${a});
            }
            ${_.output} = result;
          }
        `;return{...t,output:{dims:o,type:r[0].type,textureType:2},shaderSource:v,hasMain:!0}})(e,o,t,r.axis)}},th=(e,t,r)=>{let n=e.indexOf(t);return e.map((e,t)=>t===n?`${e} - ${r}`:e).join()}}}),he=dQ({"web/lib/onnxjs/backends/webgl/ops/concat.ts"(){"use strict";c4(),cM(),c9(),tf=(e,t,r)=>(tx(t),e.session.pack&&t[0].dims.length>1)?[e.run(tc(e,t,r),t)]:[e.run(tg(e,t,r),t)],tg=(e,t,r)=>{let n,i,o=(n=t.length,i=r.cacheKey,{name:"Concat",inputNames:Array.from({length:n},(e,t)=>`X${t}`),inputTypes:Array(n).fill(0),cacheHint:i});return{...o,get:()=>((e,t,r)=>{let n=t[0].dims.slice();if(r>=n.length||r<-1*n.length)throw Error("axis specified for concat doesn't match input dimensionality");r<0&&(r=n.length+r);let i=n.slice(0);for(let e=1;e<t.length;e++){let o=t[e].dims.slice();for(let e=0;e<n.length;e++)if(e===r)i[r]+=o[e];else if(n[e]!==o[e])throw Error("non concat dimensions must match")}let o=i.length,s=Array(t.length),a=0;for(let e=0;e<s.length;++e)a+=t[e].dims[r],s[e]=a;let u="";u=t.length<5?tm(s):tb(s);let l=ty(t.length,o),d=t_(s),p=`
        ${l}
        ${d}
        ${u}
        float process(int indices[${o}]) {
          int textureIndex = getTextureWhereDataResides (indices[${r}]);

          if(textureIndex != 0) {
            indices[${r}] = indices[${r}] - int(getSizeInConcatAxisValueFromIndex(textureIndex-int(1)));
          }

          return fetchDataFromCorrectTexture(textureIndex, indices);
        }`;return{...e,output:{dims:i,type:t[0].type,textureType:0},shaderSource:p}})(o,t,r.axis)}},tm=e=>{let t=e.map((e,t)=>`if(index<${e}) {return ${t};}
`);return`int getTextureWhereDataResides(int index) {
      ${t.join("")}
    }`},tb=e=>tm(e),ty=(e,t)=>{let r=[`float fetchDataFromCorrectTexture(int textureIndex, int indices[${t}]) {`];for(let t=0;t<e;++t)0===t?r.push(`	if (textureIndex == ${t}) { return _X${t}(indices); }`):t===e-1?r.push(`	else { return _X${t}(indices); }`):r.push(`	else if (textureIndex == ${t}) { return _X${t}(indices); }`);return r.push("	}"),r.join("\n")},t_=e=>{let t=["int getSizeInConcatAxisValueFromIndex(int index) {"];for(let r=0;r<e.length;++r)0===r?t.push(`	if (index == ${r}) { return ${e[r]}; }`):r===e.length-1?t.push(`	else { return ${e[r]}; }`):t.push(`	else if (index == ${r}) { return ${e[r]}; }`);return t.push("	}"),t.join("\n")},tv=e=>eK({axis:e.attributes.getInt("axis")}),tx=e=>{if(!e||e.length<1)throw Error("too few inputs");let t=e[0].type,r=e[0].dims.length;if("string"===t)throw Error("string tensor is not supported yet");for(let n of e){if(n.type!==t)throw Error("input tensors should be one type");if(n.dims.length!==r)throw Error("input tensors should have the same shape")}}}});function ht(e,t){let r="clip";return{body:`
  const float min = float(${e});
  const float max = float(${t});

  float ${r}_(float a) {
    return clamp(a, min, max);
  }
  vec4 ${r}_(vec4 v) {
    return clamp(v, min, max);
  }
  `,name:r,type:0}}function hr(){let e="relu";return{body:`
  float ${e}_(float a) {
    return max( a, 0.0 );
  }
  vec4 ${e}_(vec4 v) {
    return max( v, 0.0 );
  }
  `,name:e,type:0}}function hn(){let e="sigmoid";return{body:`
  float ${e}_(float a) {
    return 1.0 / (1.0 + exp(-a));
  }
  vec4 ${e}_(vec4 v) {
    return 1.0 / (1.0 + exp(-v));
  }
  `,name:e,type:0}}function hi(e){return{body:`
  float ${e}_(float a) {
    return ${e}(a);
  }
  vec4 ${e}_(vec4 v) {
    return ${e}(v);
  }
  `,name:e,type:0}}var ho=dQ({"web/lib/onnxjs/backends/webgl/ops/unary-op.ts"(){"use strict";c4(),cA(),c8(),cB(),cM(),tw=(e,t,r,n)=>{let i=2*!!e.session.pack,o={name:r.name,inputTypes:[i],inputNames:["A"],cacheHint:n};return{...o,get:()=>{let n,i;return n=2*!!e.session.pack,i=cR(e.session.backend.glContext.version),{...o,output:{dims:t.dims,type:t.type,textureType:n},shaderSource:`
     ${r.body}
     void main() {
       vec4 v = ${i.texture2D}(A, TexCoords);
       v = ${r.name}_(v);
       ${i.output} = v;
     }
     `,hasMain:!0}}}},t$=(e,t)=>[e.run(tw(e,t[0],hi("abs")),t)],tT=(e,t)=>[e.run(tw(e,t[0],hi("acos")),t)],tI=(e,t)=>[e.run(tw(e,t[0],hi("asin")),t)],tS=(e,t)=>[e.run(tw(e,t[0],hi("atan")),t)],tO=(e,t,r)=>[e.run(tw(e,t[0],ht(r.min,r.max),r.cacheKey),t)],tE=e=>eK({min:e.attributes.getFloat("min",eO),max:e.attributes.getFloat("max",eE)}),tP=(e,t)=>{let r=tk(e,t);return tO(e,[t[0]],r)},tk=(e,t)=>{if(t.length>=3&&(!e.session.isInitializer(t[1].dataId)||!e.session.isInitializer(t[2].dataId)))throw Error("dynamic clip attributes are not allowed");let r=t.length>=3?t[1].numberData[0]:eO,n=t.length>=3?t[2].numberData[0]:eE;return eK({min:r,max:n})},tA=(e,t)=>[e.run(tw(e,t[0],hi("ceil")),t)],tD=(e,t)=>[e.run(tw(e,t[0],hi("cos")),t)],tz=(e,t,r)=>{var n;return[e.run(tw(e,t[0],(n=r.alpha,{body:`
  const float alpha = float(${n});

  float elu_(float a) {
    return a >= 0.0 ? a: (exp(a) - 1.0) * alpha;
  }
  vec4 elu_(vec4 v) {
    return vec4(elu_(v.x), elu_(v.y), elu_(v.z), elu_(v.w));
  }
  `,name:"elu",type:0}),r.cacheKey),t)]},tC=e=>eK({alpha:e.attributes.getFloat("alpha",1)}),tN=(e,t)=>[e.run(tw(e,t[0],hi("exp")),t)],tj=(e,t)=>[e.run(tw(e,t[0],hi("floor")),t)],tR=(e,t)=>{let r;return[e.run(tw(e,t[0],(r="indentity",{body:`
  float ${r}_(float a) {
    return a;
  }
  vec4 ${r}_(vec4 v) {
    return v;
  }
  `,name:r,type:0})),t)]},tB=(e,t,r)=>{var n;let i;return[e.run(tw(e,t[0],(n=r.alpha,i="leakyRelu",{body:`
  const float alpha = float(${n});

  float ${i}_(float a) {
    return a < 0.0 ? a * alpha : a;
  }
  vec4 ${i}_(vec4 v) {
    return vec4(${i}_(v.x), ${i}_(v.y), ${i}_(v.z), ${i}_(v.w));
  }
  `,name:i,type:0}),r.cacheKey),t)]},tM=e=>eK({alpha:e.attributes.getFloat("alpha",.01)}),tF=(e,t)=>[e.run(tw(e,t[0],hi("log")),t)],tL=(e,t)=>[e.run(tw(e,t[0],{body:`
  float neg_(float a) {
    return -a;
  }
  vec4 neg_(vec4 v) {
    return -v;
  }
  `,name:"neg",type:0}),t)],tV=(e,t)=>[e.run(tw(e,t[0],{body:`
  float not_(float a) {
    return float( ! bool(a) );
  }
  bool not_(bool a) {
    return !a;
  }
  vec4 not_(vec4 v) {
    return vec4(!bool(v.x), !bool(v.y), !bool(v.z), !bool(v.w));
  }
  bvec4 not_(bvec4 v) {
    return bvec4(!v.x, !v.y, !v.z, !v.w);
  }
  `,name:"not",type:0}),t)],tU=(e,t)=>[e.run(tw(e,t[0],hr()),t)],tq=(e,t)=>[e.run(tw(e,t[0],hn()),t)],tG=(e,t)=>[e.run(tw(e,t[0],hi("sin")),t)],tH=(e,t)=>[e.run(tw(e,t[0],hi("sqrt")),t)],tW=(e,t)=>[e.run(tw(e,t[0],hi("tan")),t)],tK=(e,t)=>{let r;return[e.run(tw(e,t[0],(r="tanh",{body:`
  float ${r}_(float a) {
    a = clamp(a, -10., 10.);
    a = exp(2.*a);
    return (a - 1.) / (a + 1.);
  }
  vec4 ${r}_(vec4 v) {
    v = clamp(v, -10., 10.);
    v = exp(2.*v);
    return (v - 1.) / (v + 1.);
  }
  `,name:r,type:0})),t)]}}});function hs(e){let t;switch(e.activation){case"Relu":t=hr();break;case"Sigmoid":t=hn();break;case"Clip":t=ht(e.clipMin,e.clipMax);break;default:return{activationFunction:"",applyActivation:""}}let r=t.name;return{activationFunction:t.body,applyActivation:`value = ${r}_(value);`}}var ha=dQ({"web/lib/onnxjs/backends/webgl/ops/fuse-utils.ts"(){"use strict";cA(),ho(),tX=e=>{let t=e.getString("activation","");if("Clip"===t){let[r,n]=e.getFloats("activation_params",[eO,eE]);return{activation:t,clipMax:n,clipMin:r,activationCacheKey:`${t}:${r},${n}`}}return{activation:t,activationCacheKey:t}}}}),hu=dQ({"web/lib/onnxjs/backends/webgl/ops/conv-grouped.ts"(){"use strict";pm(),cB(),cM(),hb(),ha(),tZ=(e,t,r)=>{let n,i={name:"GroupedConv",inputNames:(n=t.length>2)?["X","W","Bias"]:["X","W"],inputTypes:n?[0,0,0]:[0,0],cacheHint:r.cacheKey};return{...i,get:()=>((e,t,r,n)=>{let i=t.length>2,o=t[0].dims.slice(),s=t[1].dims.slice(),a=s[0]/n.group;F.verbose("GroupedConv",`autpPad:${n.autoPad}, dilations:${n.dilations}, group:${n.group}, kernelShape:${n.kernelShape}, pads:${n.pads}, strides:${n.strides}`);let u=t5(o,s,n.dilations,n.pads,n.strides),l=cR(e.session.backend.glContext.version),{activationFunction:d,applyActivation:p}=hs(n),c=`
  const ivec2 strides = ivec2(${n.strides[0]}, ${n.strides[1]});
  const ivec2 pads = ivec2(${n.pads[0]}, ${n.pads[1]});
  ${d}
  void main() {
    ivec4 coords = getOutputCoords();
    int batch = coords.x;
    int output_channel = coords.y;
    ivec2 xRCCorner = coords.zw * strides - pads;
    int group_id = output_channel / ${a};

    float value = 0.0;
    for (int wInChannel = 0; wInChannel < ${s[1]}; wInChannel++) {
      int input_channel = group_id * ${s[1]} + wInChannel;
      for (int wHeight = 0; wHeight < ${s[2]}; wHeight++) {
        int xHeight = xRCCorner.x + wHeight * ${n.dilations[0]};

        if (xHeight < 0 || xHeight >= ${o[2]}) {
          continue;
        }

        for (int wWidth = 0; wWidth < ${s[3]}; wWidth++) {
          int xWidth = xRCCorner.y + wWidth * ${n.dilations[1]};
          if (xWidth < 0 || xWidth >= ${o[3]}) {
            continue;
          }

          float xVal = getX(batch, input_channel, xWidth, xHeight);
          float wVal = getW(output_channel, wInChannel, wWidth, wHeight);
          value += xVal*wVal;
        }
      }
    }
    ${i?"value += getBias(output_channel);":""}
    ${p}
    ${l.output} = vec4(value, .0, .0, .0);
  }
`;return{...r,output:{dims:u,type:t[0].type,textureType:0},shaderSource:c,hasMain:!0}})(e,t,i,r)}}}}),hl=dQ({"web/lib/onnxjs/backends/webgl/ops/im2col-pack.ts"(){"use strict";cB(),cM(),cX(),tJ=(e,t,r,n,i)=>{let o={name:"Im2Col (packed)",inputNames:["A"],inputTypes:[2],cacheHint:i.cacheKey};return{...o,get:()=>((e,t,r,n,i,o)=>{let s=r.dims,a=n.dims,u=i.length,l=[a[1]*a[2]*a[3],i[2]*i[3]],d=a[2]*a[3],p=cK(),c=cR(e.session.backend.glContext.version),h="";for(let e=0;e<=1;e++)for(let t=0;t<=1;t++)h+=`
            blockIndex = rc.x + ${t};
            pos = rc.y + ${e};

            if(blockIndex < ${l[1]} && pos < ${l[0]}) {
              offsetY = int(blockIndex / (${i[u-1]})) * ${o.strides[0]} -
                ${o.pads[0]};
              d0 = offsetY + ${o.dilations[0]} * (imod(pos, ${d}) / ${a[2]});

              if(d0 < ${s[2]} && d0 >= 0) {
                offsetX = imod(blockIndex, ${i[u-1]}) * ${o.strides[1]} -
                  ${o.pads[1]};
                d1 = offsetX + ${o.dilations[1]} * imod(imod(pos, ${d}), ${a[2]});

                if(d1 < ${s[3]} && d1 >= 0) {

                  ch = int(float(pos)/ ${d}.);
                    innerDims = vec2(d0, d1);
                    result[${2*e+t}] = getChannel(
                      getA(0, ch, int(innerDims.x),
                      int(innerDims.y)), innerDims);
                }
              }
            }

          `;let f=`
      ${p}

      void main() {
        ivec2 rc = getOutputCoords();
          vec4 result = vec4(0.0);
          int blockIndex, pos, offsetY, d0, offsetX, d1, ch;
          vec2 innerDims;
          ${h}
          ${c.output} = result;
      }
            `;return{...t,output:{dims:l,type:r.type,textureType:2},shaderSource:f,hasMain:!0}})(e,o,t,r,n,i)}}}});function hd(e,t){let r=t0(e.length>2,t.activationCacheKey);return{...r,get:()=>(function(e,t,r){let n=t[0].dims,i=t[1].dims,o=ev.calcShape(n,i,!0);if(!o)throw Error("Can't use matmul on the given tensors");let s=cq(o.length),a=cG(),{activationFunction:u,applyActivation:l}=hs(r),d=t.length>2,p=d?`${hp(s,a,t[2].dims,o,!1)}`:"",c=o.length,h=n.length,f=i.length,g=n[n.length-1],m=`
    ${u}
    ${p}
    float process(int indices[${c}]) {
        int a[${h}];
        int b[${f}];
        bcastMatmulIndices_A(indices, a);
        bcastMatmulIndices_B(indices, b);

        float value;
        for (int k=0; k<${g}; ++k) {
            a[${h-1}] = k;
            b[${f-2}] = k;
            value += _A(a) * _B(b);
        }
        ${d?"value += getBiasForMatmul();":""}
        ${l}
        return value;
    }`;return{...e,output:{dims:o,type:t[0].type,textureType:0},shaderSource:m}})(r,e,t)}}function hp(e,t,r,n,i){let o="",s=r.length,a=n.length,u=a-s;o=a<2&&s>0?"coords":r.map((e,r)=>`coords.${t[r+u]}`).join(", ");let l=ev.getBroadcastDims(r,n).map(e=>`coords.${t[e+u]} = 0;`).join("\n"),d=eT.size(r),p="vec4(outputValue.xx, outputValue.yy)";return 1===d&&(p="vec4(outputValue.x)"),i?`
vec4 getBiasForMatmul() {
  ${e} coords = getOutputCoords();
  ${l}
  vec4 outputValue = getBias(${o});
  return ${p};
}`:`
float getBiasForMatmul() {
  ${e} coords = getOutputCoords();
  ${l}
  return getBias(coords.x);
}`}var hc=dQ({"web/lib/onnxjs/backends/webgl/ops/matmul.ts"(){"use strict";cA(),cM(),cH(),ha(),hh(),tQ=(e,t,r)=>(t1(t),e.session.pack)?[e.run(t2(e,t,r),t)]:[e.run(hd(t,r),t)],tY=e=>tX(e.attributes),t0=(e,t)=>({name:"MatMul",inputNames:e?["A","B","Bias"]:["A","B"],inputTypes:e?[0,0,0]:[0,0],cacheHint:t}),t1=e=>{if(!e||2!==e.length)throw Error("MatMul requires 2 inputs.");if(e[0].dims[e[0].dims.length-1]!==e[1].dims[e[1].dims.length-2])throw Error("shared dimension does not match.");if("float32"!==e[0].type&&"float64"!==e[0].type||"float32"!==e[1].type&&"float64"!==e[1].type)throw Error("inputs should be float type");if(e[0].type!==e[1].type)throw Error("inputs types should match")}}}),hh=dQ({"web/lib/onnxjs/backends/webgl/ops/matmul-pack.ts"(){"use strict";cA(),cB(),cM(),cH(),ha(),hc(),t2=(e,t,r)=>{let n,i={name:"MatMul (packed)",inputNames:(n=t.length>2)?["A","B","Bias"]:["A","B"],inputTypes:n?[2,2,2]:[2,2],cacheHint:r.activationCacheKey};return{...i,get:()=>((e,t,r,n)=>{let i,o,s,a,u,l,d,p,c,h,f,g,m,b,y=r.length>2,_=r[0].dims,v=r[1].dims,x=ev.calcShape(_,v,!0),w=!eT.areEqual(r[0].dims,r[1].dims);if(!x)throw Error("Can't use matmul on the given tensors");let $=Math.ceil(_[_.length-1]/2),T=_.length,I=v.length,S=cR(e.session.backend.glContext.version),O=cq(x.length),E=x.length,P=cG(),{activationFunction:k,applyActivation:A}=hs(n),D=y?`${hp(O,P,r[2].dims,x,!0)}`:"",z=w?`${i=[],o=[],s=r[0].dims,a=r[1].dims,u=s.length,l=a.length,p=(d=x.length)-u,c=d-l,(i=s.map((e,t)=>`coords.${P[t+p]}`))[u-1]="i*2",i.join(", "),(o=a.map((e,t)=>`coords.${P[t+c]}`))[l-2]="i*2",o.join(", "),h=ev.getBroadcastDims(s,x),f=ev.getBroadcastDims(a,x),g=h.map(e=>`coords.${P[e+p]} = 0;`).join("\n"),m=f.map(e=>`coords.${P[e+c]} = 0;`).join("\n"),b=`int lastDim = coords.${P[d-1]};
  coords.${P[d-1]} = coords.${P[d-2]};
  coords.${P[d-2]} = lastDim;`,`
vec4 getAAtOutCoordsMatmul(int i) {
  ${O} coords = getOutputCoords();
  ${b}
  ${g}
  vec4 outputValue = getA(${i});
  return outputValue;
}

vec4 getBAtOutCoordsMatmul(int i) {
  ${O} coords = getOutputCoords();
  ${b}
  ${m}
  vec4 outputValue = getB(${o});
  return outputValue;
}`}`:"",C=w?"getAAtOutCoordsMatmul(i)":`getA(${function(e,t){let r="";for(let n=0;n<t-2;n++)r+=`rc.${e[n]}, `;return r+`rc.${e[t-2]}, i*2`}(P,T)})`,N=w?"getBAtOutCoordsMatmul(i)":`getB(${function(e,t){let r="";for(let n=0;n<t-2;n++)r+=`rc.${e[n]}, `;return r+`i*2, rc.${e[t-1]}`}(P,I)})`,j=w?"":`${O} rc =
          getOutputCoords(); int lastDim = rc.${P[E-1]}; rc.${P[E-1]} =
          rc.${P[E-2]}; rc.${P[E-2]} = lastDim;
      `,R=`
            ${z}
            ${D}
            ${k}
            void main() {
              ${j}

              vec4 value = vec4(0);
              for (int i = 0; i < ${$}; i++) {
                vec4 a = ${C};
                vec4 b = ${N};

                value += (a.rrbb * b.rgrg);
                value += (a.ggaa * b.baba);
              }
              ${y?"value += getBiasForMatmul();":""}
              ${A}
              ${S.output} = value;
            }`;return{...t,output:{dims:x,type:r[0].type,textureType:2},shaderSource:R,hasMain:!0}})(e,i,t,r)}}}}),hf=dQ({"web/lib/onnxjs/backends/webgl/ops/conv-pack.ts"(){"use strict";hb(),hl(),hh(),t3=(e,t,r)=>{let n=t[0].dims,i=t[1].dims,o=t5(n,i,r.dilations,r.pads,r.strides),s=e.run(tJ(e,t[0],t[1],o,r),[t[0]]),a=e.reshapePacked(t[1],[i[0],i[1]*i[2]*i[3]]),u=3===t.length?[a,s,t[2]]:[a,s],l=e.run(t2(e,u,r),u);return e.reshapePacked(l,o)}}}),hg=dQ({"web/lib/onnxjs/backends/webgl/ops/im2col.ts"(){"use strict";cM(),t4=(e,t,r,n,i)=>{let o={name:"Im2Col",inputNames:["X"],inputTypes:[0],cacheHint:i.cacheKey};return{...o,get:()=>{let e,s,a,u,l;return e=t.dims,s=r.dims,a=n.length,u=t6(e,s,n,4),l=`
        const int XC = ${e[1]};
        const int XH = ${e[2]};
        const int XW = ${e[3]};
        const int KH = ${i.kernelShape[0]};
        const int KW = ${i.kernelShape[1]};
        const int dilationH = ${i.dilations[0]};
        const int dilationW = ${i.dilations[1]};
        const int strideH = ${i.strides[0]};
        const int strideW = ${i.strides[1]};
        const int padH = ${i.pads[0]};
        const int padW = ${i.pads[1]};
        const int KHKW = KH*KW;
        const int XCKHKW = XC * KHKW;
        const int outputChannels = 4;
        vec4 process(int indices[${a}]) {
          int b  = indices[0]; // batch size
          int oh = indices[1] * strideH - padH; //output height
          int ow = indices[2] * strideW - padW; //output width
          int p = indices[3] * outputChannels; //patch
          vec4 value = vec4(0.0);
          for(int i=0; i < outputChannels; ++i) {
            if(p < XCKHKW) {
              int patchC = p / KHKW;
              int patchH = (p - patchC*KHKW) / KW;
              int patchW = (p - patchC*KHKW) - patchH * KW;
              int xh2 = oh + patchH * dilationH;
              int xw2 = ow + patchW * dilationW;
              int x[${e.length}];
              x[0] = b;
              x[1] = patchC;
              x[2] = xh2;
              x[3] = xw2;
              if(xh2 >= 0 &&
                  xh2 < XH &&
                  xw2 >= 0 &&
                  xw2 < XW) {
                value[i] = _X(x);
              }
            }
            ++p;
          }
          return value;
        }
        `,{...o,output:{dims:u,type:t.type,textureType:4},shaderSource:l}}}},t6=(e,t,r,n=4)=>[r[0],r[2],r[3],Math.ceil(e[1]*t[2]*t[3]/n)]}}),hm=dQ({"web/lib/onnxjs/backends/webgl/ops/dot-product.ts"(){"use strict";cA(),cB(),cM(),ha(),hg(),t8=(e,t,r,n)=>{let i,o={name:"ConvDotProduct",inputNames:(i=t.length>2)?["Im2Col","K","B"]:["Im2Col","K"],inputTypes:i?[0,4,0]:[0,4],cacheKey:n.activationCacheKey};return{...o,get:()=>((e,t,r,n,i)=>{let o=r[0].dims,s=r[1].dims,a=[s[0],Math.ceil(o[1]*s[2]*s[3]/4)],u=t6(o,s,n),[l,d]=e.calculateTextureWidthAndHeight(a,4),p=eT.computeStrides(u),[c,h]=e.calculateTextureWidthAndHeight(u,4),f=n.length,g=r.length<3?"0.0":"_B(b)",m=Math.ceil(o[1]*s[2]*s[3]/4),{activationFunction:b,applyActivation:y}=hs(i),_=cR(e.session.backend.glContext.version),v=`
${b}
float process(int indices[${f}]) {
  int b[1];
  b[0] = indices[1];
  int im2col[4];
  im2col[0] = indices[0];
  im2col[1] = indices[2];
  im2col[2] = indices[3];
  int im2colOffset = im2col[0] * ${p[0]} + im2col[1] * ${p[1]} + im2col[2] * ${p[2]};
  int kernelOffset = indices[1] * ${a[1]};
  float value = ${g};
  for (int i = 0; i < ${m}; ++i) {
    vec2 im2colCoords = offsetToCoords(im2colOffset, ${c}, ${h});
    vec2 kernelCoords = offsetToCoords(kernelOffset, ${l}, ${d});
    value += dot(${_.texture2D}(Im2Col, im2colCoords), ${_.texture2D}(K, kernelCoords));
    ++im2colOffset;
    ++kernelOffset;
  }
  ${y}
  return value;
}`;return{...t,output:{dims:n,type:r[0].type,textureType:0},shaderSource:v}})(e,o,t,r,n)}}}}),hb=dQ({"web/lib/onnxjs/backends/webgl/ops/conv.ts"(){"use strict";c4(),cA(),hu(),hf(),hm(),ha(),hg(),hc(),t5=(e,t,r,n,i)=>{let o=e[0],s=e.slice(2),a=s.length,u=t[0],l=t.slice(2).map((e,t)=>e+(e-1)*(r[t]-1));return[o,u].concat(...s.map((e,t)=>e+n[t]+n[t+a]).map((e,t)=>Math.floor((e-l[t]+i[t])/i[t])))},t7=(e,t,r)=>(ri(t,r),t9(e,t,r)),t9=(e,t,r)=>{let n=rr(r,t),i=e.session.pack,o=1===n.kernelShape[0]&&1===n.kernelShape[1];return n.group>1?[e.run(tZ(e,t,n),t)]:o&&i?[re(e,t,n)]:i&&4===t[0].dims.length&&1===t[0].dims[0]&&!o?[t3(e,t,n)]:[rt(e,t,n)]},re=(e,t,r)=>{let n=t[0].dims,i=t[1].dims,o=t5(n,i,r.dilations,r.pads,r.strides),s=e.reshapeUnpacked(t[0],[n[1],n[2]*n[3]]),a=e.reshapeUnpacked(t[1],[i[0],i[1]]),u=t.length>2?[a,s,t[2]]:[a,s],l=e.run(hd(u,r),u);return e.reshapeUnpacked(l,o)},rt=(e,t,r)=>{let n=t[0].dims,i=t[1].dims,o=t5(n,i,r.dilations,r.pads,r.strides),s=e.run(t4(e,t[0],t[1],o,r),[t[0]]),a=3===t.length?[s,t[1],t[2]]:[s,t[1]];return e.run(t8(e,t,o,r),a)},rr=(e,t)=>{let r=e.kernelShape.slice();if(0===e.kernelShape.length)for(let e=2;e<t[1].dims.length;++e)r.push(t[1].dims[e]);let n=e.pads.slice();eS.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,n,e.autoPad);let i=Object.assign({},e);return Object.assign(i,{kernelShape:r,pads:n,cacheKey:e.cacheKey}),i},rn=e=>{let t=e.attributes,r=tX(t),n=t.getString("auto_pad","NOTSET"),i=t.getInts("dilations",[1,1]),o=t.getInt("group",1),s=t.getInts("kernel_shape",[]),a=t.getInts("pads",[0,0,0,0]),u=t.getInts("strides",[1,1]);return eK({autoPad:n,dilations:i,group:o,kernelShape:s,pads:a,strides:u,...r})},ri=(e,t)=>{if(!e||2!==e.length&&3!==e.length)throw Error("Conv requires 2 or 3 inputs");if(4!==e[0].dims.length||4!==e[1].dims.length)throw Error("currently only support 2-dimensional conv");if(e[0].dims[1]!==e[1].dims[1]*t.group)throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(3===e.length&&(1!==e[2].dims.length||e[1].dims[0]!==e[2].dims[0]))throw Error("invalid bias");let r=e[0].dims.length-2;if(t.dilations.length!==r)throw Error(`dilations should be ${r}D`);if(t.strides.length!==r)throw Error(`strides should be ${r}D`);if(t.pads.length!==2*r)throw Error(`pads should be ${2*r}D`);if(0!==t.kernelShape.length&&t.kernelShape.length!==e[1].dims.length-2)throw Error("invalid kernel shape");if("float32"!==e[0].type||"float32"!==e[1].type)throw Error("Conv input(X,W) should be float tensor");if(3===e.length&&"float32"!==e[2].type)throw Error("Conv input(bias) should be float tensor")}}}),hy=dQ({"web/lib/onnxjs/backends/webgl/ops/conv-transpose.ts"(){"use strict";c4(),cB(),cM(),ha(),ro=(e,t,r,n,i,o)=>(e-1)*t+r+(n-1)*i+1-o,rs=(e,t,r,n,i)=>{let o=Math.floor(e/2);"SAME_UPPER"===t?(r[n]=o,r[i]=e-o):"SAME_LOWER"===t&&(r[n]=e-o,r[i]=o)},ra=(e,t,r)=>(rc(t,r),ru(e,t,r)),ru=(e,t,r)=>{let n=rd(r,t);return[rl(e,t,n)]},rl=(e,t,r)=>{let n,i;return e.run({...i={name:"ConvTranspose",inputNames:(n=t.length>2)?["X","W","B"]:["X","W"],inputTypes:n?[0,0,0]:[0,0],cacheHint:r.cacheKey},get:()=>((e,t,r,n)=>{let i=t.length>2,o=t[0].dims,s=t[1].dims,a=s[1],u=s[0]/n.group,l=[t[0].dims[0],t[1].dims[1]*n.group,...n.outputShape],d=cR(e.session.backend.glContext.version),{activationFunction:p,applyActivation:c}=hs(n),h=`
  const ivec2 strides = ivec2(${n.strides[0]}, ${n.strides[1]});
  const ivec2 pads = ivec2(${n.pads[0]}, ${n.pads[1]});
  ${p}
  void main() {
    ivec4 coords = getOutputCoords();
    int batch = coords.x;
    int output_channel = coords.y;

    ivec2 loc = coords.zw + pads;

    int group_id = output_channel / ${a};
    int wOutChannel = output_channel - group_id * ${a};

    float value = ${i?"getB(output_channel)":"0.0"};
    for (int inChannelOffset = 0; inChannelOffset < ${u}; inChannelOffset++) {
      int input_channel = group_id * ${u} + inChannelOffset;
      for (int wWOff = 0; wWOff < ${s[2]}; wWOff++) {
        for (int wHOff = 0; wHOff < ${s[3]}; wHOff++) {
          ivec2 wOff = ivec2(wWOff * ${n.dilations[0]}, wHOff * ${n.dilations[1]});
          ivec2 wLoc = loc - wOff;
          ivec2 wLocIn = wLoc / strides;
          if (
            wLocIn * strides == wLoc &&
            wLocIn.x >= 0 && wLocIn.x < ${o[2]} &&
            wLocIn.y >= 0 && wLocIn.y < ${o[3]}
          ) {
            float xVal = getX(batch, input_channel, wLocIn.y, wLocIn.x);
            float wVal = getW(input_channel, wOutChannel, wHOff, wWOff);
            value += xVal * wVal;
          }
        }
      }
    }
    ${c}
    ${d.output} = vec4(value, .0, .0, .0);
  }
`;return{...r,output:{dims:l,type:t[0].type,textureType:0},shaderSource:h,hasMain:!0}})(e,t,i,r)},t)},rd=(e,t)=>{let r=e.kernelShape.slice();if(0===e.kernelShape.length)for(let e=2;e<t[1].dims.length;++e)r.push(t[1].dims[e]);let n=e.pads.slice(),i=e.outputShape.slice();((e,t,r,n,i,o,s,a)=>{let u=e.length-2,l=0===a.length;for(let d=0;d<u;++d){let p=l?e[d+2]*o[d]:a[d];rs(ro(e[d+2],o[d],i[d],t[d],r[d],p),n,i,d,d+u),l&&a.push(o[d]*(e[d+2]-1)+s[d]+(t[d]-1)*r[d]+1-i[d]-i[d+u])}})(t[0].dims,r,e.dilations,e.autoPad,n,e.strides,e.outputPadding,i);let o=Object.assign({},e);return Object.assign(o,{kernelShape:r,pads:n,outputShape:i,cacheKey:e.cacheKey}),o},rp=e=>{let t=e.attributes,r=tX(t),n=t.getString("auto_pad","NOTSET"),i=t.getInts("dilations",[1,1]),o=t.getInt("group",1),s=t.getInts("kernel_shape",[]),a=t.getInts("output_padding",[0,0]),u=t.getInts("output_shape",[]),l=t.getInts("pads",[0,0,0,0]),d=t.getInts("strides",[1,1]);return eK({autoPad:n,dilations:i,group:o,kernelShape:s,outputPadding:a,outputShape:u,pads:l,strides:d,...r})},rc=(e,t)=>{if(!e||2!==e.length&&3!==e.length)throw Error("Conv requires 2 or 3 inputs");if(4!==e[0].dims.length||4!==e[1].dims.length)throw Error("currently only support 2-dimensional conv");if(e[0].dims[1]!==e[1].dims[0])throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let r=e[1].dims[1]*t.group;if(3===e.length&&(1!==e[2].dims.length||e[2].dims[0]!==r))throw Error("invalid bias");let n=e[0].dims.length-2;if(t.dilations.length!==n)throw Error(`dilations should be ${n}D`);if(t.strides.length!==n)throw Error(`strides should be ${n}D`);if(t.pads.length!==2*n)throw Error(`pads should be ${2*n}D`);if(t.outputPadding.length!==n)throw Error(`output_padding should be ${n}D`);if(0!==t.kernelShape.length&&t.kernelShape.length!==e[1].dims.length-2)throw Error("invalid kernel shape");if(0!==t.outputShape.length&&t.outputShape.length!==e[0].dims.length-2)throw Error("invalid output shape");if("float32"!==e[0].type||"float32"!==e[1].type)throw Error("ConvTranspose input(X,W) should be float tensor");if(3===e.length&&"float32"!==e[2].type)throw Error("ConvTranspose input(bias) should be float tensor")}}}),h_=dQ({"web/lib/onnxjs/backends/webgl/ops/transpose.ts"(){"use strict";c4(),cA(),cM(),rh={name:"Transpose",inputNames:["A"],inputTypes:[0]},rf=(e,t,r)=>(rv(t),[e.run({...rh,cacheHint:r.cacheKey,get:()=>rm(e,t[0],r.perm)},t)]),rg=e=>eK({perm:e.attributes.getInts("perm",[])}),rm=(e,t,r)=>{let n=t.dims;r=rb(n,r);let i=ry(n,r),o=n.length,s=`
      ${r_("perm",r,o)}
      float process(int indices[${o}]) {
        int a[${o}];
        perm(a, indices);
        return _A(a);
      }`;return{...rh,output:{dims:i,type:t.type,textureType:0},shaderSource:s}},rb=(e,t)=>(t&&t.length!==e.length&&(t=[...e.keys()].reverse()),t),ry=(e,t)=>(t=rb(e,t),eT.sortBasedOnPerm(e,t)),r_=(e,t,r)=>{let n=[];n.push(`void ${e}(out int a[${r}], int src[${r}]) {`);for(let e=0;e<r;++e)n.push(`	a[${t[e]}]=src[${e}];`);return n.push("	}"),n.join("\n")},rv=e=>{if(!e||1!==e.length)throw Error("Transpose requires 1 input.");if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("input should be float tensor")}}}),hv=dQ({"web/lib/onnxjs/backends/webgl/ops/depth-to-space.ts"(){"use strict";h_(),rx=(e,t,r)=>{r$(t);let n=r.blocksize,i=n*n,o="DCR"===r.mode?[0,3,4,1,5,2]:[0,1,4,2,5,3],s="DCR"===r.mode?[t[0].dims[0],n,n,t[0].dims[1]/i,t[0].dims[2],t[0].dims[3]]:[t[0].dims[0],t[0].dims[1]/i,n,n,t[0].dims[2],t[0].dims[3]],a=e.reshapeUnpacked(t[0],s),u={perm:o,cacheKey:`${o}`},[l]=rf(e,[a],u),d=[t[0].dims[0],t[0].dims[1]/i,t[0].dims[2]*n,t[0].dims[3]*n];return[e.reshapeUnpacked(l,d)]},rw=e=>{let t=e.attributes.getInt("blocksize");if(t<1)throw Error(`blocksize must be >= 1, but got : ${t} for DepthToSpace`);let r=e.attributes.getString("mode","DCR");if("DCR"!==r&&"CRD"!==r)throw Error(`unrecognized mode: ${r} for DepthToSpace`);return{mode:r,blocksize:t}},r$=e=>{if(1!==e.length)throw Error(`DepthToSpace expect 1 inputs, but got ${e.length}`);if("string"===e[0].type||4!==e[0].dims.length)throw TypeError("DepthToSpace input should be a 4-D numeric tensor")}}}),hx=dQ({"web/lib/onnxjs/backends/webgl/ops/flatten.ts"(){"use strict";cA(),rT=(e,t,r)=>{rS(t,r);let n=eT.flattenShape(t[0].dims,r);return[e.reshapeUnpacked(t[0],n)]},rI=e=>e.attributes.getInt("axis",1),rS=(e,t)=>{if(!e||1!==e.length)throw Error("Flatten requires 1 input.");let r=e[0].dims.length;if(0===r)throw Error("scalar tensor is not supported.");if(t<-r||t>r)throw Error("Invalid axis");if("string"===e[0].type)throw Error("string tensor is not supported.")}}}),hw=dQ({"web/lib/onnxjs/operators.ts"(){"use strict";rO=["float32","float64","int32","int16","int8","uint16","uint32","uint8"]}}),h$=dQ({"web/lib/onnxjs/backends/webgl/ops/gather.ts"(){"use strict";c4(),hw(),cA(),cM(),rE=(e,t,r)=>(rD(t,r.axis),[e.run(rA(e,t,r),t)]),rP=e=>eK({axis:e.attributes.getInt("axis",0)}),rk={name:"Gather",inputNames:["A","B"],inputTypes:[0,0]},rA=(e,t,r)=>{let n={...rk,cacheHint:r.cacheKey};return{...n,get:()=>((e,t,r)=>{let n=t[0].dims.slice(),i=t[1].dims.slice(),o=Array(n.length+i.length-1);r=eT.normalizeAxis(r,n.length);let s=[];for(let e=0;e<o.length;e++)e<r?(o[e]=n[e],s.push(`inputIdx[${e}] = outputIdx[${e}];`)):e<r+i.length?(o[e]=i[e-r],s.push(`indexDataIdx[${e-r}] = outputIdx[${e}];`)):(o[e]=n[e-i.length+1],s.push(`inputIdx[${e-i.length+1}] = outputIdx[${e}];`));let a=o.length||1,u=n.length,l=i.length||1,d=`
      float process(int outputIdx[${a}]) {
        int inputIdx[${u}];
        int indexDataIdx[${l}];
        indexDataIdx[0] = 0;
        ${s.join("\n        ")}
        int idx = int(_B(indexDataIdx));
        inputIdx[${r}] = idx < 0 ? idx + ${n[r]} : idx;
        return _A(inputIdx);
      }`;return{...e,output:{dims:o,type:t[0].type,textureType:0},shaderSource:d}})(n,t,r.axis)}},rD=(e,t)=>{if(!e||2!==e.length)throw Error("Gather requires 2 inputs.");let r=e[0].dims.length;if(r<1)throw Error("Invalid input shape.");if(t<-r||t>r-1)throw Error("Invalid axis.");if(-1===rO.indexOf(e[0].type)||"int32"!==e[1].type&&"int16"!==e[1].type)throw Error("Invaid input type.")}}}),hT=dQ({"web/lib/onnxjs/backends/webgl/ops/gemm.ts"(){"use strict";c4(),cA(),cM(),rz=(e,t,r)=>(rM(t,r),[e.run(rR(t,r),t)]),rC=(e,t)=>{let r=0!==e.attributes.getInt("transA",0),n=0!==e.attributes.getInt("transB",0),i=e.attributes.getFloat("alpha",1),o=e.attributes.getFloat("beta",1);return eK({transA:r,transB:n,alpha:i,beta:o,isOptionalC:t})},rN=e=>rC(e,!1),rj=e=>rC(e,!0),rR=(e,t)=>{let r={name:"Gemm",inputNames:3===e.length?["A","B","C"]:["A","B"],inputTypes:3===e.length?[0,0,0]:[0,0],key:t.cacheKey};return{...r,get:()=>rB(r,e,t)}},rB=(e,t,r)=>{let n=t[0].dims.slice(),i=t[1].dims.slice(),[o,s]=ex.getShapeOfGemmResult(n,r.transA,i,r.transB,3===t.length?t[2].dims:void 0),a=[o,s];if(!a)throw Error("Can't use gemm on the given tensors");let u=n[n.length-1],l="";r.transA&&(u=n[0]),r.transA&&r.transB?l="value += _A_T(a) * _B_T(b);":r.transA&&!r.transB?l="value += _A_T(a) * _B(b);":!r.transA&&r.transB?l="value += _A(a) * _B_T(b);":r.transA||r.transB||(l="value += _A(a) * _B(b);");let d=a.length,p=3===t.length?`int c[${t[2].dims.length}];`:"",c=3===t.length?"bcastIndices_C(indices, c);":"",h=3===t.length?"value += beta * _C(c);":"",f=`
      float process(int indices[${d}]) {
          int a[${d}];
          int b[${d}];
          ${p}

          copyVec(indices, a);
          copyVec(indices, b);
          ${c}

          float value = 0.0;
          for (int k=0; k<${u}; ++k) {
              a[${d-1}] = k;
              b[${d-2}] = k;
              ${l}
          }

          value = value * alpha;
          ${h}
          return value;
      }`;return{...e,output:{dims:a,type:t[0].type,textureType:0},variables:[{name:"alpha",type:"float",data:r.alpha},{name:"beta",type:"float",data:r.beta}],shaderSource:f}},rM=(e,t)=>{if(!e)throw Error("Input is missing");if(t.isOptionalC&&(e.length<2||e.length>3))throw Error("Invaid input shape.");if(!t.isOptionalC&&3!==e.length)throw Error("Gemm requires 3 inputs");if(3===e.length&&1!==e[2].dims.length&&2!==e[2].dims.length)throw Error("Invalid input shape of C");if("float32"!==e[0].type&&"float64"!==e[0].type||"float32"!==e[1].type&&"float64"!==e[1].type||3===e.length&&"float32"!==e[2].type&&"float64"!==e[2].type)throw Error("Invalid input type.");if(e[0].type!==e[1].type||3===e.length&&e[0].type!==e[2].type)throw Error("Input types are mismatched")}}}),hI=dQ({"web/lib/onnxjs/backends/webgl/ops/image-scaler.ts"(){"use strict";c4(),cM(),rF=(e,t,r)=>(rG(t),[e.run(rU(e,t,r),t)]),rL=e=>{let t=e.attributes.getFloat("scale"),r=e.attributes.getFloats("bias");return eK({scale:t,bias:r})},rV={name:"ImageScaler",inputNames:["X"],inputTypes:[0]},rU=(e,t,r)=>{let n={...rV,cacheHint:r.cacheKey};return{...n,get:()=>{let e,i,o,s;return i=(e=t[0].dims.slice()).length,o=rq(r.bias.length),s=`
      ${o}
      float process(int indices[${i}]) {
        return _X(indices) * scale + getBias(bias, indices[1]);
      }`,{...n,output:{dims:e,type:t[0].type,textureType:0},variables:[{name:"bias",type:"float",arrayLength:r.bias.length,data:r.bias},{name:"scale",type:"float",data:r.scale}],shaderSource:s}}}},rq=e=>{let t=[`float getBias(float bias[${e}], int channel) {`];for(let r=0;r<e;++r)0===r?t.push(`	if (channel == ${r}) { return bias[${r}]; }`):r===e-1?t.push(`	else { return bias[${r}]; }`):t.push(`	else if (channel == ${r}) { return bias[${r}]; }`);return t.push("	}"),t.join("\n")},rG=e=>{if(!e||1!==e.length)throw Error("ImageScaler requires 1 input.");if(4!==e[0].dims.length)throw Error("Invalid input shape.");if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("Invalid input type.")}}}),hS=dQ({"web/lib/onnxjs/backends/webgl/ops/instance-normalization.ts"(){"use strict";cB(),cM(),rH=(e,t,r)=>{rQ(t);let n=e.run(rX(t[0]),t);return[e.run(rJ(e,t[0],r,n.dims),[t[0],n,t[1],t[2]])]},rW=e=>e.attributes.getFloat("epsilon",1e-5),rK={name:"InstanceNormalization_MeanAndVariance",inputNames:["X"],inputTypes:[0]},rX=e=>({...rK,get:()=>{let t,r,n,i,o;return r=(t=e.dims.slice())[1],n=t[2]*t[3],i=[t[0],r],o=`
      vec4 process(int[2] indices) {
        vec4 v = vec4(0.0);
        int a[4];
        a[0] = indices[0];
        a[1] = indices[1];
        float temp = 0.0;
        for(int a2=0; a2<${t[2]}; a2++) {
          a[2] = a2;
          for(int a3=0; a3<${t[3]}; a3++) {
            a[3] = a3;
            float x = _X(a);
            temp += x;
          }
        }
        float mean = temp / float(${n});
        temp = 0.0;
        for(int a2=0; a2<${t[2]}; a2++) {
          a[2] = a2;
          for(int a3=0; a3<${t[3]}; a3++) {
            a[3] = a3;
            float x = _X(a);
            temp += (x - mean) * (x - mean);
          }
        }
        v.r = mean;
        v.g = temp / float(${n});

        return v;
      }`,{...rK,output:{dims:i,type:e.type,textureType:4},shaderSource:o}}}),rZ={name:"InstanceNormalization_ComputeOutput",inputNames:["X","MeanAndVariance","Scale","B"],inputTypes:[0,4,0,0]},rJ=(e,t,r,n)=>{let i={...rZ,cacheHint:`${r}`};return{...i,get:()=>((e,t,r,n,i)=>{let o=cR(e.session.backend.glContext.version),[s,a]=e.calculateTextureWidthAndHeight(i,4),[u,l]=[s/4,a],d=`
      vec4 get_MeanAndVariance(int[2] mv) {
        int offset = indicesToOffset_MeanAndVariance(mv);
        vec2 coords = offsetToCoords(offset, ${u}, ${l});
        return ${o.texture2D}(MeanAndVariance, coords);
      }

      float process(int[4] indices) {
        int mv[2];
        mv[0] = indices[0];
        mv[1] = indices[1];
        vec4 mean_and_variance = get_MeanAndVariance(mv);
        float mean = mean_and_variance.r;
        float variance = mean_and_variance.g;

        int sb[1];
        sb[0] = indices[1];
        float scale = _Scale(sb);
        float b = _B(sb);

        return scale * (_X(indices) - mean) / sqrt(variance + epsilon) + b;
      }`;return{...t,output:{dims:r.dims,type:r.type,textureType:0},variables:[{name:"epsilon",type:"float",data:n}],shaderSource:d}})(e,i,t,r,n)}},rQ=e=>{if(!e||3!==e.length)throw Error("InstanceNormalization requires 3 inputs.");let t=e[0],r=e[1],n=e[2];if(t.dims.length<3||1!==r.dims.length||1!==n.dims.length)throw Error("Invalid input shape.");if(r.dims[0]!==t.dims[1]||n.dims[0]!==t.dims[1])throw Error("Input shapes are mismatched.");if("float32"!==t.type&&"float64"!==t.type||"float32"!==r.type&&"float64"!==r.type||"float32"!==n.type&&"float64"!==n.type)throw Error("Invalid input type.");if(4!==e[0].dims.length)throw Error("Only support 4-D input shape.")}}}),hO=dQ({"web/lib/onnxjs/backends/webgl/ops/lrn.ts"(){"use strict";c4(),cM(),rY=(e,t,r)=>(r2(t),[e.run({...r1,cacheHint:r.cacheKey,get:()=>{let e,n,i,o,s,a,u,l;return e=t[0].dims[1],n=t[0].dims.length,i=-Math.floor((r.size-1)/2),o=Math.ceil((r.size-1)/2),s=`float(${r.alpha}) / float(${r.size})`,a=`float(${r.bias})`,u=`float(${r.beta})`,l=`
    float process(int indices[${n}]) {
        int c = indices[1];
        float x = _X(indices);
        float square_sum = 0.0;

        for (int i = ${i}; i <= ${o}; i++) {
          int idx = c + i;
          if (c >= 0 && c < ${e}) {
            indices[1] = idx;
            float j = _X(indices);
            square_sum += j * j;
          }
        }
        return x / pow(${a} + ${s} * square_sum, ${u});
    }`,{...r1,cacheHint:r.cacheKey,output:{dims:t[0].dims,type:t[0].type,textureType:0},shaderSource:l}}},t)]),r0=e=>{let t=e.attributes.getFloat("alpha",1e-4),r=e.attributes.getFloat("beta",.75),n=e.attributes.getFloat("bias",1),i=e.attributes.getInt("size");return eK({alpha:t,beta:r,bias:n,size:i})},r1={name:"LRN",inputNames:["X"],inputTypes:[0]},r2=e=>{if(!e||1!==e.length)throw Error("LRN requires 1 input.");if(4!==e[0].dims.length)throw Error('currently only support LRN for input with "NCHW" format');if("float32"!==e[0].type)throw Error("input should be float type")}}}),hE=dQ({"web/lib/onnxjs/backends/webgl/ops/pad.ts"(){"use strict";c4(),cA(),cB(),cM(),r3={name:"Pad",inputNames:["A"],inputTypes:[0]},r4=(e,t,r)=>(ne(t),[e.run({...r3,cacheHint:r.cacheKey,get:()=>r9(e,t[0],r)},t)]),r6=e=>{let t=e.attributes.getString("mode","constant"),r=e.attributes.getFloat("value",0),n=e.attributes.getInts("pads");return eK({mode:t,value:r,pads:n})},r8=(e,t,r)=>{nt(t);let n=r7(e,t,r);return r4(e,[t[0]],n)},r5=e=>e.attributes.getString("mode","constant"),r7=(e,t,r)=>{if(!e.session.isInitializer(t[1].dataId)||t.length>=3&&!e.session.isInitializer(t[2].dataId))throw Error("dynamic pad attributes are not allowed");let n=Array.from(t[1].integerData),i=t.length>=3?t[2].floatData[0]:0;return eK({mode:r,pads:n,value:i})},r9=(e,t,r)=>{let n=eT.padShape(t.dims.slice(),r.pads),i=n.length,o=nr(e,t,r),s=`
      ${o}
      float process(int[${i}] indices) {
          return padA(indices);
      }`;return{name:"Pad",inputNames:["A"],inputTypes:[0],output:{dims:n,type:t.type,textureType:0},shaderSource:s}},ne=e=>{if(!e||1!==e.length)throw Error("Pad requires 1 input");if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("Invalid input type.")},nt=e=>{if(!e||2!==e.length&&3!==e.length)throw Error("Pad requires 2 or 3 inputs");if("int32"!==e[1].type||e.length>=3&&"string"===e[2].type)throw Error("Invalid input type.")},nr=(e,t,r)=>{let n=cR(e.session.backend.glContext.version),[i,o]=e.calculateTextureWidthAndHeight(t.dims,0),s=eT.computeStrides(t.dims);switch(r.mode){case"constant":return nn(n,t.dims,s,i,o,r.pads,r.value);case"reflect":return ni(n,t.dims,s,i,o,r.pads);case"edge":return no(n,t.dims,s,i,o,r.pads);default:throw Error("Invalid mode")}},nn=(e,t,r,n,i,o,s)=>{let a=t.length,u="";for(let e=a-1;e>=0;--e)u+=`
        k = m[${e}] - ${o[e]};
        if (k < 0)  return constant;
        if (k >= ${t[e]}) return constant;
        offset += k * ${r[e]};
        `;return`
      float padA(int m[${a}]) {
        const float constant = float(${s});
        int offset = 0;
        int k = 0;
        ${u}
        vec2 coords = offsetToCoords(offset, ${n}, ${i});
        float value = getColorAsFloat(${e.texture2D}(A, coords));
        return value;
      }
      `},ni=(e,t,r,n,i,o)=>{let s=t.length,a="";for(let e=s-1;e>=0;--e)a+=`
        k = m[${e}] - ${o[e]};
        if (k < 0) { k = -k; }
        {
          const int _2n_1 = ${2*(t[e]-1)};
          k = int( mod( float(k), float(_2n_1) ) ) ;
          if(k >= ${t[e]}) { k = _2n_1 - k; }
        }
        offset += k * ${r[e]};
        `;return`
      float padA(int m[${s}]) {
        int offset = 0;
        int k = 0;
        ${a}
        vec2 coords = offsetToCoords(offset, ${n}, ${i});
        float value = getColorAsFloat(${e.texture2D}(A, coords));
        return value;
      }
      `},no=(e,t,r,n,i,o)=>{let s=t.length,a="";for(let e=s-1;e>=0;--e)a+=`
        k = m[${e}] - ${o[e]};
        if (k < 0)  k = 0;
        if (k >= ${t[e]}) k = ${t[e]-1};
        offset += k * ${r[e]};
      `;return`
      float padA(int m[${s}]) {
        int offset = 0;
        int k = 0;
        ${a}
        vec2 coords = offsetToCoords(offset, ${n}, ${i});
        float value = getColorAsFloat(${e.texture2D}(A, coords));
        return value;
      }
      `}}}),hP=dQ({"web/lib/onnxjs/backends/webgl/ops/pool.ts"(){"use strict";c4(),cA(),cM(),ns=(e,t,r)=>{ny(t);let n={name:"AveragePool",inputNames:["X"],inputTypes:[0],cacheHint:r.cacheKey};return[e.run({...n,get:()=>nu(t,n,!1,r)},t)]},na=e=>{let t=e.attributes.getString("auto_pad","NOTSET"),r=e.attributes.getInt("ceil_mode",0),n=0!==e.attributes.getInt("count_include_pad",0),i=e.attributes.getInts("kernel_shape"),o=e.attributes.getInts("strides",[]),s=e.attributes.getInts("pads",[]);if(0!==r)throw Error("using ceil() in shape computation is not yet supported for AveragePool");return eK({autoPad:t,ceilMode:r,countIncludePad:n,kernelShape:i,strides:o,pads:s})},nu=(e,t,r,n)=>{let[i,o]=nf(e,n,r),s=eT.size(i.kernelShape),a="";i.countIncludePad?a+=`value /= float(${s});`:a+=`value /= float(${s} - pad);`;let u=n_(e[0].dims,i,"value += _X(x);",a,"0.0"),l=`
        ${u}
      `;return{...t,output:{dims:o,type:e[0].type,textureType:0},shaderSource:l}},nl=(e,t,r)=>{ny(t);let n={name:"GlobalAveragePool",inputNames:["X"],inputTypes:[0],cacheHint:`${r.countIncludePad}`};return[e.run({...n,get:()=>nu(t,n,!0,r)},t)]},nd=e=>{let t=0!==e.attributes.getInt("count_include_pad",0);return eK({autoPad:"",ceilMode:0,countIncludePad:t,kernelShape:[],strides:[],pads:[]})},np=(e,t,r)=>{ny(t);let n={name:"MaxPool",inputNames:["X"],inputTypes:[0],cacheHint:r.cacheKey};return[e.run({...n,get:()=>nh(t,n,!1,r)},t)]},nc=e=>{let t=e.attributes.getString("auto_pad","NOTSET"),r=e.attributes.getInt("ceil_mode",0),n=e.attributes.getInts("kernel_shape"),i=e.attributes.getInts("strides",[]),o=e.attributes.getInts("pads",[]),s=e.attributes.getInt("storage_order",0),a=e.attributes.getInts("dilations",[]);if(0!==s)throw Error("column major storage order is not yet supported for MaxPool");if(0!==r)throw Error("using ceil() in shape computation is not yet supported for MaxPool");return eK({autoPad:t,ceilMode:r,countIncludePad:!1,kernelShape:n,strides:i,pads:o,storageOrder:s,dilations:a})},nh=(e,t,r,n)=>{let[i,o]=nf(e,n,r),s=`
      value = max(_X(x), value);
    `,a=n_(e[0].dims,i,s,"","-1e5"),u=`
      ${a}
    `;return{...t,output:{dims:o,type:e[0].type,textureType:0},shaderSource:u}},nf=(e,t,r)=>{let n=e[0].dims.slice(),i=Object.hasOwnProperty.call(t,"dilations"),o=t.kernelShape.slice(),s=t.strides.slice(),a=i?t.dilations.slice():[],u=t.pads.slice();eS.adjustPoolAttributes(r,n,o,s,a,u);let l=eS.computePoolOutputShape(r,n,s,a,o,u,t.autoPad),d=Object.assign({},t);return i?Object.assign(d,{kernelShape:o,strides:s,pads:u,dilations:a,cacheKey:t.cacheKey}):Object.assign(d,{kernelShape:o,strides:s,pads:u,cacheKey:t.cacheKey}),[d,l]},ng={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[],cacheKey:""},nm={name:"GlobalMaxPool",inputNames:["X"],inputTypes:[0]},nb=(e,t)=>(ny(t),[e.run({...nm,get:()=>nh(t,nm,!0,ng)},t)]),ny=e=>{if(!e||1!==e.length)throw Error("Pool ops requires 1 input.");if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("Invalid input type.")},n_=(e,t,r,n,i)=>{let o=e.length;if(t.kernelShape.length<=2){let s=t.kernelShape[t.kernelShape.length-1],a=t.strides[t.strides.length-1],u=t.pads[t.pads.length/2-1],l=t.pads[t.pads.length-1],d=e[o-1],p="",c="",h="";if(p=u+l!==0?`
          for (int i = 0; i < ${s}; i++) {
            x[${o} - 1] = indices[${o} - 1] * ${a} - ${u} + i;
            if (x[${o} - 1] < 0 || x[${o} - 1] >= ${d}) {
              pad++;
              continue;
            }
            ${r}
          }`:`
          for (int i = 0; i < ${s}; i++) {
            x[${o} - 1] = indices[${o} - 1] * ${a} - ${u} + i;
            ${r}
          }`,2===t.kernelShape.length){let r=t.kernelShape[t.kernelShape.length-2],n=t.strides[t.strides.length-2],i=t.pads[t.pads.length/2-2],a=t.pads[t.pads.length-2],u=e[o-2];c=i+a!==0?`
            for (int j = 0; j < ${r}; j++) {
              x[${o} - 2] = indices[${o} - 2] * ${n} - ${i} + j;
              if (x[${o} - 2] < 0 || x[${o} - 2] >= ${u}) {
                pad+= ${s};
                continue;
              }
          `:`
            for (int j = 0; j < ${r}; j++) {
              x[${o} - 2] = indices[${o} - 2] * ${n} - ${i} + j;
            `,h=`
          }
        `}return`
        float process(int indices[${o}]) {
          int x[${o}];
          copyVec(indices, x);

          float value = ${i};
          int pad = 0;
          ${c}
          ${p}
          ${h}
          ${n}
          return value;
        }
      `}{let s=eT.size(t.kernelShape),a=eT.computeStrides(t.kernelShape),u=a.length,l=t.pads.length,d=nx(u),p=nv(e,"inputDims"),c=nv(t.pads,"pads"),h=nv(a,"kernelStrides"),f=nv(t.strides,"strides"),g=t.pads.reduce((e,t)=>e+t),m="";return m=g?`
            if (x[j] >= inputDims[j] || x[j] < 0) {
              pad++;
              isPad = true;
              break;
            }
          }
          if (!isPad) {
            ${r}
          }`:`
          }
          ${r}
        `,`
        ${d}
        float process(int indices[${o}]) {
          int x[${o}];
          copyVec(indices, x);
          int offset[${u}];
          int pads[${l}];
          int inputDims[${o}];
          int kernelStrides[${u}];
          int strides[${u}];
          ${c}
          ${p}
          ${f}
          ${h}

          float value = ${i};
          int pad = 0;
          bool isPad = false;
          for (int i = 0; i < ${s}; i++) {
            offsetToIndices(i, kernelStrides, offset);
            isPad = false;
            for (int j = ${o} - ${u}; j < ${o}; j++) {
              x[j] = indices[j] * strides[j - ${o} + ${u}]
                + offset[j - ${o} + ${u}] - pads[j - 2];
              ${m}
          }
          ${n}

          return value;
        }
      `}},nv=(e,t)=>{let r="";for(let n=0;n<e.length;n++)r+=`
      ${t}[${n}] = ${e[n]};
    `;return r},nx=e=>`
  void offsetToIndices(int offset, int[${e}] strides, out int[${e}] indices) {
    if (${e} == 0) {
      return;
    }
    for (int i = 0; i < ${e} - 1; ++i) {
      indices[i] = offset / strides[i];
      offset -= indices[i] * strides[i];
    }
    indices[${e} - 1] = offset;
  }`}}),hk=dQ({"web/lib/onnxjs/backends/webgl/ops/reduce.ts"(){"use strict";c4(),hw(),cA(),cM(),nw=(e,t,r,n,i)=>{nI(t);let o={name:n,inputNames:["A"],inputTypes:[0]};return[e.run({...o,cacheHint:r.cacheKey,get:()=>nT(e,t,r,n,i,o)},t)]},n$=e=>{let t=e.attributes.getInts("axes",[]),r=1===e.attributes.getInt("keepdims",1);return eK({axes:t,keepDims:r})},nT=(e,t,r,n,i,o)=>{let s=[],a=t[0].dims.length||1,u=[],l=eT.normalizeAxes(r.axes,t[0].dims.length),d=i(t,l),p=d[1];for(let e=0;e<t[0].dims.length;e++)l.indexOf(e)>=0||0===l.length?(r.keepDims&&s.push(1),p=`
          for(int j${e} = 0; j${e} < ${t[0].dims[e]}; j${e}++) {
            inputIdx[${e}] = j${e};
            ${p}
          }`):(u.push(`inputIdx[${e}] = outputIdx[${s.length}];`),s.push(t[0].dims[e]));let c=s.length||1,h=`
      float process(int outputIdx[${c}]) {
        float value;                 // final result
        int inputIdx[${a}];      // addressing input data
        ${u.join("\n")}
        ${d[0]}       // init ops for reduce max/min
        ${p}
        ${d[2]}       // final computation for reduce mean
        return value;
      }`;return{...o,output:{dims:s,type:t[0].type,textureType:0},shaderSource:h}},nI=e=>{if(!e||1!==e.length)throw Error("Reduce op requires 1 input.");if(-1===rO.indexOf(e[0].type))throw Error("Invalid input type.")},nS=(e,t,r)=>nw(e,t,r,"ReduceSum",()=>["value = 0.0;","value += _A(inputIdx);",""]),nO=(e,t,r)=>nw(e,t,r,"ReduceMean",(e,t)=>{let r=1;for(let n=0;n<e[0].dims.length;n++)(t.indexOf(n)>=0||0===t.length)&&(r*=e[0].dims[n]);return["value = 0.0;","value += _A(inputIdx);",`value /= ${r}.;`]}),nE=(e,t,r)=>nw(e,t,r,"ReduceMax",(e,t)=>{let r=[];for(let n=0;n<e[0].dims.length;n++)(t.indexOf(n)>=0||0===t.length)&&r.push(`inputIdx[${n}] = 0;`);return[`${r.join("\n")}
value = _A(inputIdx);`,"value = max(value, _A(inputIdx));",""]}),nP=(e,t,r)=>nw(e,t,r,"ReduceMin",(e,t)=>{let r=[];for(let n=0;n<e[0].dims.length;n++)(t.indexOf(n)>=0||0===t.length)&&r.push(`inputIdx[${n}] = 0;`);return[`${r.join("\n")}
value = _A(inputIdx);`,"value = min(value, _A(inputIdx));",""]}),nk=(e,t,r)=>nw(e,t,r,"ReduceProd",()=>["value = 1.0;","value *= _A(inputIdx);",""]),nA=(e,t,r)=>nw(e,t,r,"ReduceLogSum",()=>["value = 0.0;","value += _A(inputIdx);","value = log(value);"]),nD=(e,t,r)=>nw(e,t,r,"ReduceLogSumSquare",()=>["float t; value = 0.0;","t = _A(inputIdx); value += t * t;",""])}}),hA=dQ({"web/lib/onnxjs/backends/webgl/ops/reshape.ts"(){"use strict";cA(),nz=(e,t)=>{let r=eT.calculateReshapedDims(t[0].dims,t[1].integerData);return e.session.pack?[e.reshapePacked(t[0],r)]:[e.reshapeUnpacked(t[0],r)]}}}),hD=dQ({"web/lib/onnxjs/backends/webgl/ops/upsample.ts"(){"use strict";c4(),cB(),cM(),nC={name:"Upsample",inputNames:["X"],inputTypes:[0]},nN=(e,t,r)=>(nF(t,r),[e.run({...nC,cacheHint:r.cacheKey,get:()=>nM(e,t,r)},t)]),nj=e=>nB(e,7),nR=e=>nB(e,9),nB=(e,t)=>{let r=t>=10,n=e.attributes.getString("mode","nearest");if("nearest"!==n&&"linear"!==n&&(t<11||"cubic"!==n))throw Error(`unrecognized mode: ${n}`);let i=[];t<9&&(i=e.attributes.getFloats("scales"),nL(i,n,r));let o=e.attributes.getFloat("extrapolation_value",0),s=t>10?e.attributes.getString("coordinate_transformation_mode","half_pixel"):"asymmetric";if(-1===["asymmetric","pytorch_half_pixel","tf_half_pixel_for_nn","align_corners","tf_crop_and_resize","half_pixel"].indexOf(s))throw Error(`coordinate_transform_mode '${s}' is not supported`);let a="tf_crop_and_resize"===s,u="nearest"===n&&t>=11?e.attributes.getString("nearest_mode","round_prefer_floor"):"";if(-1===["round_prefer_floor","round_prefer_ceil","floor","ceil",""].indexOf(u))throw Error(`nearest_mode '${u}' is not supported`);let l=e.attributes.getFloat("cubic_coeff_a",-.75),d=0!==e.attributes.getInt("exclude_outside",0);if(d&&"cubic"!==n)throw Error("exclude_outside can be set to 1 only when mode is CUBIC.");let p=t<11||"nearest"===n&&"asymmetric"===s&&"floor"===u,c=0,h=0,f=0;return t>10?e.inputs.length>2?(c=1,h=2,f=3):(h=1,f=2):9===t&&(h=1),eK({opset:t,isResize:r,mode:n,scales:i,extrapolationValue:o,coordinateTransformMode:s,useExtrapolation:a,needRoiInput:a,nearestMode:u,cubicCoefficientA:l,excludeOutside:d,useNearest2xOptimization:p,roiInputIdx:c,scalesInputIdx:h,sizesInputIdx:f})},nM=(e,t,r)=>{let n=cR(e.session.backend.glContext.version),[i,o]=e.calculateTextureWidthAndHeight(t[0].dims,0),s=t[0].dims.map((e,t)=>Math.floor(e*r.scales[t])),[a,u]=e.calculateTextureWidthAndHeight(s,0),l=s.length,d=Array(l),p=Array(l),c=`
      int output_pitches[${l}];
      int input_pitches[${l}];
      `;for(let e=l-1;e>=0;e--)d[e]=e===l-1?1:d[e+1]*s[e+1],p[e]=e===l-1?1:p[e+1]*t[0].dims[e+1],c+=`
        output_pitches[${e}] = ${d[e]};
        input_pitches[${e}] = ${p[e]};
        `;let h=`
      float getInputFloat(int index) {
        vec2 coords = offsetToCoords(index, ${i}, ${o});
        float value = getColorAsFloat(${n.texture2D}(X, coords));
        return value;
      }
      `,f="nearest"===r.mode?`
    ${h}
    float process(int indices[${l}]) {
      int input_index = 0;
      int output_index = coordsToOffset(TexCoords, ${a}, ${u});

      ${c}

      int d, m;
      for (int dim = 0; dim < ${l}; ++dim) {
        d = output_index / output_pitches[dim];
        m = output_index - d * output_pitches[dim];
        output_index = m;

        if (scales[dim] != 1 && d > 0) {
          int d2 = d / scales[dim];
          m = d - d2 * scales[dim];
          d = d2;
        }
        input_index += input_pitches[dim] * d;
      }

      return getInputFloat(input_index);
    }`:4===l?`
    ${h}
    float process(int indices[4]) {
      int input_index = 0;
      int output_index = coordsToOffset(TexCoords, ${a}, ${u});

      ${c}

      int m;
      int index_of_dim0, index_of_dim1, index_of_dim2, index_of_dim3;
      index_of_dim0 = output_index / output_pitches[0];
      m = output_index - index_of_dim0 * output_pitches[0];
      index_of_dim1 = m / output_pitches[1];
      m = m - index_of_dim1 * output_pitches[1];
      index_of_dim2 = m / output_pitches[2];
      m = m - index_of_dim2 * output_pitches[2];
      index_of_dim3 = m;

      int index_of_input_dim2, index_of_input_dim3, x_offset, y_offset;
      index_of_input_dim2 = index_of_dim2 / scales[2];
      y_offset = index_of_dim2 - index_of_input_dim2 * scales[2];
      index_of_input_dim3 = index_of_dim3 / scales[3];
      x_offset = index_of_dim3 - index_of_input_dim3 * scales[3];

      input_index = index_of_dim0 * input_pitches[0] +
            index_of_dim1 * input_pitches[1] +
            index_of_input_dim2 * input_pitches[2] +
            index_of_input_dim3;

      float x00 = getInputFloat(input_index);
      float x10, x01, x11;

      bool end_of_dim2 = false;
      if (index_of_input_dim2 == (${t[0].dims[2]} - 1)) {
        // It's the end in dimension 2
        x01 = x00;
        end_of_dim2 = true;
      } else {
        x01 = getInputFloat(input_index + input_pitches[2]);
      }

      if (index_of_input_dim3 == (input_pitches[2] - 1)) {
        // It's the end in dimension 3
        x10 = x00;
        x11 = x01;
      }
      else {
        x10 = getInputFloat(input_index + 1);
        x11 = end_of_dim2 ? x10 : getInputFloat(input_index + input_pitches[2] + 1);
      }

      float y0 = x00 + float(y_offset) * (x01 - x00) / float(scales[2]);
      float y1 = x10 + float(y_offset) * (x11 - x10) / float(scales[2]);
      return y0 + float(x_offset) * (y1 - y0) / float(scales[3]);
    }`:`
    ${h}
    float process(int indices[2]) {
      int input_index = 0;
      int output_index = coordsToOffset(TexCoords, ${a}, ${u});

      ${c}

      int m;
      int index_of_dim0, index_of_dim1;
      index_of_dim0 = output_index / output_pitches[0];
      m = output_index - index_of_dim0 * output_pitches[0];
      index_of_dim1 = m;

      int index_of_input_dim0, index_of_input_dim1, x_offset, y_offset;
      index_of_input_dim0 = index_of_dim0 / scales[0];
      y_offset = index_of_dim0 - index_of_input_dim0 * scales[0];
      index_of_input_dim1 = index_of_dim1 / scales[1];
      x_offset = index_of_dim1 - index_of_input_dim1 * scales[1];

      input_index = index_of_input_dim0 * input_pitches[0] + index_of_input_dim1;

      float x00 = getInputFloat(input_index);
      float x10, x01, x11;

      bool end_of_dim0 = false;
      if (index_of_input_dim0 == (${t[0].dims[0]} - 1)) {
        // It's the end in dimension 0
        x01 = x00;
        end_of_dim0 = true;
      } else {
        x01 = getInputFloat(input_index + input_pitches[0]);
      }

      if (index_of_input_dim1 == (input_pitches[0] - 1)) {
        // It's the end in dimension 1
        x10 = x00;
        x11 = x01;
      }
      else {
        x10 = getInputFloat(input_index + 1);
        x11 = end_of_dim0 ? x10 : getInputFloat(input_index + input_pitches[0] + 1);
      }

      float y0 = x00 + float(y_offset) * (x01 - x00) / float(scales[0]);
      float y1 = x10 + float(y_offset) * (x11 - x10) / float(scales[0]);
      return y0 + float(x_offset) * (y1 - y0) / float(scales[1]);
    }`;return{...nC,output:{dims:s,type:t[0].type,textureType:0},shaderSource:f,variables:[{name:"scales",type:"int",arrayLength:r.scales.length,data:r.scales.map(e=>Math.ceil(e))}]}},nF=(e,t)=>{if(!e||t.opset<9&&1!==e.length||t.opset>=9&&t.opset<11&&2!==e.length||t.opset>=11&&e.length<2)throw Error("invalid inputs.");if(t.scales.length>0&&e[0].dims.length!==t.scales.length)throw Error("Invalid input shape.");if("string"===e[0].type)throw Error("Invalid input tensor types.")},nL=(e,t,r)=>{if(r){for(let t of e)if(t<=0)throw Error("Scale value should be greater than 0.")}else for(let t of e)if(t<1)throw Error("Scale value should be greater than or equal to 1.");if(("linear"===t||"cubic"===t)&&2!==e.length&&(4!==e.length||1!==e[0]||1!==e[1]))throw Error(`'Linear' mode and 'Cubic' mode only support 2-D inputs ('Bilinear', 'Bicubic')         or 4-D inputs with the corresponding outermost 2 scale values being 1         in the ${r?"Resize":"Upsample"} opeartor.`)}}}),hz=dQ({"web/lib/onnxjs/backends/webgl/ops/resize-packed.ts"(){"use strict";cB(),cM(),cH(),cX(),hD(),nV={name:"Resize",inputNames:["A"],inputTypes:[2]},nU=(e,t,r)=>(nF(t,r),[e.run({...nV,cacheHint:r.cacheKey,get:()=>nH(e,t,r)},t)]),nq=e=>nB(e,10),nG=e=>nB(e,11),nH=(e,t,r)=>{let n=cR(e.session.backend.glContext.version),[i,o]=nW(t,r);if(i.every(e=>1===e)&&"tf_crop_and_resize"!==r.coordinateTransformMode)return{...nV,output:{dims:o,type:t[0].type,textureType:2},hasMain:!0,shaderSource:`void main() {
                    vec4 v = ${n.texture2D}(X, TexCoords);
                    ${n.output} = v;
                }`};let s=o.length;if(s<2)throw Error(`output dimension should be at least 2, but got ${s}`);let a=o[s-2],u=o[s-1],l=t[0].dims;if(s!==l.length)throw Error(`output dimension should match input ${l.length}, but got ${s}`);let d=l[s-2],p=l[s-1],c=i[s-2],h=i[s-1],f="";if("linear"!==r.mode)throw Error(`resize (packed) does not support mode: '${r.mode}'`);switch(r.coordinateTransformMode){case"asymmetric":f=`
                    vec4 getSourceFracIndex(ivec4 coords) {
                        return vec4(coords) / scaleWHWH;
                    }
                `;break;case"half_pixel":f=`
                    vec4 getSourceFracIndex(ivec4 coords) {
                        return (vec4(coords) + 0.5) / scaleWHWH - 0.5;
                    }
                `;break;case"pytorch_half_pixel":f=`
                    vec4 getSourceFracIndex(ivec4 coords) {
                        vec4 fcoords = vec4(coords);
                        return vec4(
                            ${u}.0 > 1.0 ? (fcoords.x + 0.5) / scaleWHWH.x - 0.5 : 0.0,
                            ${a}.0 > 1.0 ? (fcoords.y + 0.5) / scaleWHWH.y - 0.5 : 0.0,
                            ${u}.0 > 1.0 ? (fcoords.z + 0.5) / scaleWHWH.z - 0.5 : 0.0,
                            ${a}.0 > 1.0 ? (fcoords.w + 0.5) / scaleWHWH.w - 0.5 : 0.0
                          );
                    }
                `;break;case"align_corners":f=`
                    vec4 getSourceFracIndex(ivec4 coords) {
                        vec4 resized = vec4(${u}.0 - 1.0, ${a}.0 - 1.0, ${u}.0 - 1.0,
                            ${a}.0 - 1.0);
                        vec4 original = vec4(${p}.0 - 1.0, ${d}.0 - 1.0, ${p}.0 - 1.0,
                            ${d}.0 - 1.0);
                        vec4 new_scale = original / resized;
                        return vec4(coords) * new_scale;
                    }
                `;break;default:throw Error(`resize (packed) does not support coordinateTransformMode:                                 '${r.coordinateTransformMode}'`)}let g=cq(s),m=cK(),b=`
            const vec2 inputWH = vec2(${d}.0, ${p}.0);
            const vec4 scaleWHWH = vec4(float(${c}), float(${h}), float(${c}), float(${h}));
            ${m}
            ${f}
            float getAValue(int x10, int r, int c, int d) {
                return getChannel(getA(x10, r, c, d), vec2(c, d));
            }
            void main() {
                ${g} rc = getOutputCoords();

                int batch = rc[0];
                int depth = rc[1];

                // retrieve the 4 coordinates that is used in the 4 packed output values.
                ivec4 coords = ivec4(rc.wz, rc.w + 1, rc.z + 1);

                // calculate the source index in fraction
                vec4 sourceFrac = getSourceFracIndex(coords);

                // get the lower and upper bound of the 4 values that will be packed into one texel.
                ivec4 x00 = ivec4(max(sourceFrac.xy, vec2(0.0)), min(inputWH - 1.0, ceil(sourceFrac.xy)));
                ivec4 x01 = ivec4(max(sourceFrac.xw, vec2(0.0)), min(inputWH - 1.0, ceil(sourceFrac.xw)));
                ivec4 x10 = ivec4(max(sourceFrac.zy, vec2(0.0)), min(inputWH - 1.0, ceil(sourceFrac.zy)));
                ivec4 x11 = ivec4(max(sourceFrac.zw, vec2(0.0)), min(inputWH - 1.0, ceil(sourceFrac.zw)));

                bool hasNextRow = rc.w < ${a-1};
                bool hasNextCol = rc.z < ${u-1};

                // pack x00, x01, x10, x11's top-left corner into one vec4 structure
                vec4 topLeft = vec4(
                    getAValue(batch, depth, x00.x, x00.y),
                    hasNextCol ? getAValue(batch, depth, x01.x, x01.y) : 0.0,
                    hasNextRow ? getAValue(batch, depth, x10.x, x10.y) : 0.0,
                    (hasNextRow && hasNextCol) ? getAValue(batch, depth, x11.x, x11.y) : 0.0);

                // pack x00, x01, x10, x11's top-right corner into one vec4 structure
                vec4 topRight = vec4(
                    getAValue(batch, depth, x00.x, x00.w),
                    hasNextCol ? getAValue(batch, depth, x01.x, x01.w) : 0.0,
                    hasNextRow ? getAValue(batch, depth, x10.x, x10.w) : 0.0,
                    (hasNextRow && hasNextCol) ? getAValue(batch, depth, x11.x, x11.w) : 0.0);

                // pack x00, x01, x10, x11's bottom-left corner into one vec4 structure
                vec4 bottomLeft = vec4(
                    getAValue(batch, depth, x00.z, x00.y),
                    hasNextCol ? getAValue(batch, depth, x01.z, x01.y) : 0.0,
                    hasNextRow ? getAValue(batch, depth, x10.z, x10.y) : 0.0,
                    (hasNextRow && hasNextCol) ? getAValue(batch, depth, x11.z, x11.y) : 0.0);

                // pack x00, x01, x10, x11's bottom-right corner into one vec4 structure
                vec4 bottomRight = vec4(
                    getAValue(batch, depth, x00.z, x00.w),
                    hasNextCol ? getAValue(batch, depth, x01.z, x01.w) : 0.0,
                    hasNextRow ? getAValue(batch, depth, x10.z, x10.w) : 0.0,
                    (hasNextRow && hasNextCol) ? getAValue(batch, depth, x11.z, x11.w) : 0.0);

                // calculate the interpolation fraction on u and v direction
                vec4 frac = vec4(sourceFrac) - floor(sourceFrac);
                vec4 clampFrac = clamp(frac, vec4(0.0), vec4(1.0));

                vec4 top = mix(topLeft, topRight, clampFrac.ywyw);
                vec4 bottom = mix(bottomLeft, bottomRight, clampFrac.ywyw);
                vec4 newValue = mix(top, bottom, clampFrac.xxzz);

                ${n.output} = vec4(newValue);
            }
        `;return{...nV,output:{dims:o,type:t[0].type,textureType:2},hasMain:!0,shaderSource:b}},nW=(e,t)=>{let r,n=e[0].dims,i=t.scales;if(0===i.length){let o=e[t.scalesInputIdx];if(o&&0!==o.size){if(e[t.sizesInputIdx])throw Error("Only one of scales or sizes must be provided as input.");i=nK(o,t.mode,t.isResize)}else{let o=e[t.sizesInputIdx];if(!o||0===o.size)throw Error("Either scales or sizes MUST be provided as input.");r=Array.from(o.integerData),i=nX(r,n,t.mode,t.isResize)}}else if(e[t.sizesInputIdx])throw Error("Only one of scales or sizes must be provided as input.");let o=r||n.map((e,t)=>Math.floor(e*i[t]));return[i,o]},nK=(e,t,r)=>{let n=Array.from(e.floatData);return nL(n,t,r),n},nX=(e,t,r,n)=>{let i=t.length,o=Array(i);for(let r=0;r<i;r++)if(0===t[r]){if(0!==e[r])throw Error("Input dim is zero but required output dim is non-zero.");o[r]=1}else o[r]=e[r]/t[r];return nL(o,r,n),o}}}),hC=dQ({"web/lib/onnxjs/backends/webgl/ops/shape.ts"(){"use strict";cj(),nZ=(e,t)=>(nJ(t),[new eA([t[0].dims.length],"int32",void 0,void 0,new Int32Array(t[0].dims))]),nJ=e=>{if(!e||1!==e.length)throw Error("Shape requires 1 input.")}}}),hN=dQ({"web/lib/onnxjs/backends/webgl/ops/slice.ts"(){"use strict";c4(),hw(),cA(),cM(),nQ={name:"Slice",inputNames:["A"],inputTypes:[0]},nY=(e,t,r)=>(n2(t),[e.run({...nQ,cacheHint:r.cacheKey,get:()=>n1(e,t[0],r)},t)]),n0=e=>{let t=e.attributes.getInts("starts"),r=e.attributes.getInts("ends"),n=e.attributes.getInts("axes",[]);return eK({starts:t,ends:r,axes:n})},n1=(e,t,r)=>{let n=0===r.axes.length?t.dims.slice(0).map((e,t)=>t):r.axes,i=eT.normalizeAxes(n,t.dims.length),o=r.starts.map((e,r)=>e>t.dims[i[r]]-1?t.dims[i[r]]:eT.normalizeAxis(e,t.dims[i[r]])),s=r.ends.map((e,r)=>e>t.dims[i[r]]-1?t.dims[i[r]]:eT.normalizeAxis(e,t.dims[i[r]])),a=t.dims.slice(),u=[];for(let e=0;e<i.length;e++)a[i[e]]=s[e]-o[e],o[e]>0&&u.push(`outputIdx[${i[e]}] += ${o[e]};`);let l=a.length,d=`
      float process(int outputIdx[${l}]) {
        ${u.join("\n      ")}
        return _A(outputIdx);
      }`;return{...nQ,output:{dims:a,type:t.type,textureType:0},shaderSource:d}},n2=e=>{if(!e||1!==e.length)throw Error("Slice requires 1 input.");if(-1===rO.indexOf(e[0].type))throw Error("Invalid input type.")},n3=(e,t)=>{n6(t);let r=n4(e,t);return[e.run({...nQ,cacheHint:r.cacheKey,get:()=>n1(e,t[0],r)},[t[0]])]},n4=(e,t)=>{if(!e.session.isInitializer(t[1].dataId)||!e.session.isInitializer(t[2].dataId)||t.length>=4&&!e.session.isInitializer(t[3].dataId)||t.length>=5&&!e.session.isInitializer(t[4].dataId))throw Error("dynamic slice attributes are not allowed");if(t.length>=5&&t[4].integerData.some(e=>1!==e))throw Error("currently non-1 steps is not supported for Slice");let r=Array.from(t[1].integerData),n=Array.from(t[2].integerData),i=t.length>=4?Array.from(t[3].integerData):[],o=`${i};${r};${n}`;return{starts:r,ends:n,axes:i,cacheKey:o}},n6=e=>{if(!e||e.length<3||e.length>5)throw Error("Invalid input number.");if("int32"!==e[1].type||1!==e[1].dims.length||"int32"!==e[2].type||1!==e[2].dims.length||e.length>=4&&("int32"!==e[3].type||1!==e[3].dims.length)||e.length>=5&&("int32"!==e[4].type||1!==e[4].dims.length))throw Error("Invalid input type.")}}}),hj=dQ({"web/lib/onnxjs/backends/webgl/ops/softmax.ts"(){"use strict";c4(),cA(),cB(),cM(),h_(),n8={name:"SoftmaxComputeMax",inputNames:["A"],inputTypes:[0]},n5={name:"SoftmaxComputeScale",inputNames:["A","Max"],inputTypes:[0,0]},n7={name:"SoftMax",inputNames:["A","Max","Norm"],inputTypes:[0,0,0]},n9=(e,t,r)=>{iu(t);let n=t[0].dims.slice(),i=eT.normalizeAxis(r.axis,n.length),o=eT.sizeToDimension(n,i),s=eT.sizeFromDimension(n,i);return ii(e,t,r,o,s)},ie=e=>eK({axis:e.attributes.getInt("axis",1)}),it=e=>eK({axis:e.attributes.getInt("axis",-1)}),ir=(e,t,r)=>{let n;iu(t);let i=t[0].dims.slice(),o=eT.normalizeAxis(r.axis,i.length),s=i.length,a=o!==s-1,u=[],l=[],d=[];a&&((l=Array.from({length:s}).map((e,t)=>t))[o]=s-1,l[s-1]=o,l.map(e=>u.push(i[e])),n=eK({perm:l}),d=rf(e,t,n));let p=a?eT.sizeToDimension(u,s-1):eT.sizeToDimension(i,s-1),c=a?eT.sizeFromDimension(u,s-1):eT.sizeFromDimension(i,s-1),h=ii(e,a?d:t,r,p,c);return a?rf(e,h,n):h},ii=(e,t,r,n,i)=>{let o=io(e,t[0],n,i,[n]),s=e.run({...n8,cacheHint:r.cacheKey,get:()=>o},t),a=is(e,t[0],n,i,o.output.dims,[n]),u=e.run({...n5,cacheHint:r.cacheKey,get:()=>a},[t[0],s]),l=ia(e,t[0],n,i,o.output.dims,a.output.dims);return[e.run({...n7,cacheHint:r.cacheKey,get:()=>l},[t[0],s,u])]},io=(e,t,r,n,i)=>{let[o,s]=e.calculateTextureWidthAndHeight(t.dims,0),a=i.length;if(r<1||n<1)throw Error("Logical row count N and feature count D must be greater than or equal to 1");if(1!==i.length)throw Error("Dimensionality of the output should be 1");if(i[0]!==r)throw Error("Shape of the output should be equal to logical row count");let u=cR(e.session.backend.glContext.version),l=`
      float process(int[${a}] indices) {
        int logical_row_start_offset = indices[0] * ${n};

        float max = getColorAsFloat(${u.texture2D}(A, offsetToCoords(logical_row_start_offset, ${o},
        ${s} )));
        for(int i=1; i<${n}; ++i)
        {
          float current = getColorAsFloat(${u.texture2D}(A, offsetToCoords(logical_row_start_offset + i,
            ${o}, ${s})));
          if(current > max)
          max = current;
        }

        return max;
      }`;return{...n8,output:{dims:i,type:t.type,textureType:0},shaderSource:l}},is=(e,t,r,n,i,o)=>{let[s,a]=e.calculateTextureWidthAndHeight(t.dims,0),u=o.length;if(r<1||n<1)throw Error("Logical row count N and feature count D must be greater than or equal to 1");if(1!==o.length)throw Error("Dimensionality of the output should be 1");if(o[0]!==r)throw Error("Shape of the output should be equal to logical row count");if(1!==i.length)throw Error("Dimensionality of the intermediate results should be 1");if(i[0]!==r)throw Error("Shape of the intermediate results should be equal to logical row count");let l=cR(e.session.backend.glContext.version),d=`
      float process(int[${u}] indices) {
        int logical_row_start_offset = indices[0] * ${n};

        float norm_factor = 0.0;
        float max = _Max(indices);
        for(int i=0; i<${n}; ++i)
        {
          norm_factor += exp(getColorAsFloat(${l.texture2D}(A, offsetToCoords(logical_row_start_offset + i,
            ${s}, ${a}))) - max);
        }

        return norm_factor;
      }`;return{...n5,output:{dims:o,type:t.type,textureType:0},shaderSource:d}},ia=(e,t,r,n,i,o)=>{let[s,a]=e.calculateTextureWidthAndHeight(t.dims,0),u=t.dims.length;if(r<1||n<1)throw Error("Logical row count N and feature count D must be greater than or equal to 1");if(1!==i.length||1!==o.length)throw Error("Dimensionality of the intermediate results should be 1");if(i[0]!==r||o[0]!==r)throw Error("Shape of the intermediate results should be equal to logical row count");let l=`
      float process(int[${u}] indices) {

      // get offset of current logical tensor index from the 2-D texture coordinates (TexCoords)
      int offset = coordsToOffset(TexCoords, ${s}, ${a});

      //determine the logical row for this index
      int logical_row_index[1];
      logical_row_index[0] = offset / ${n};

      float norm_factor = _Norm(logical_row_index);

      // avoid possible division by 0
      // if norm_facor is 0, all elements are zero
      // if so, return 0
      if(norm_factor == 0.0)
        return 0.0;

      return exp(_A(indices) - _Max(logical_row_index)) / norm_factor;
    }`;return{...n7,output:{dims:t.dims,type:t.type,textureType:0},shaderSource:l}},iu=e=>{if(!e||1!==e.length)throw Error("Softmax requires 1 input.");if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("Invalid input type")}}}),hR=dQ({"web/lib/onnxjs/backends/webgl/ops/split.ts"(){"use strict";c4(),cA(),cM(),il={name:"Split",inputNames:["A"],inputTypes:[0]},id=(e,t,r)=>{ig(t);let n=eT.normalizeAxis(r.axis,t[0].dims.length),i=ic(e,t,n,r),o=[];for(let s=0;s<i;++s)o.push(e.run({...il,cacheHint:`${r.cacheKey};${s}`,get:()=>ih(e,t[0],r,n,s)},t));return o},ip=e=>{let t=e.attributes.getInt("axis",0),r=e.attributes.getInts("split",[]),n=e.outputs.length;return eK({axis:t,split:r,numOutputs:n})},ic=(e,t,r,n)=>{let[,i]=eI.splitShape(t[0].dims,r,n.split,n.numOutputs);return i.length},ih=(e,t,r,n,i)=>{let[o,s]=eI.splitShape(t.dims,n,r.split,r.numOutputs),a=s[i],u=o[i],l=u.length,d=`
      float process(int indices[${l}]) {
        indices[${n}] += ${a};
        return _A(indices);
      }
    `;return{...il,cacheHint:`${r.cacheKey}:${i}`,output:{dims:u,type:t.type,textureType:0},shaderSource:d}},ig=e=>{if(!e||1!==e.length)throw Error("Split requires one input.");if("int8"!==e[0].type&&"uint8"!==e[0].type&&"int16"!==e[0].type&&"uint16"!==e[0].type&&"int32"!==e[0].type&&"uint32"!==e[0].type&&"float32"!==e[0].type&&"float64"!==e[0].type&&"bool"!==e[0].type)throw Error("Invalid input type.")}}}),hB=dQ({"web/lib/onnxjs/backends/webgl/ops/squeeze.ts"(){"use strict";cA(),im=(e,t,r)=>{i_(t);let n=eT.squeezeShape(t[0].dims,r);return[e.reshapeUnpacked(t[0],n)]},ib=(e,t)=>(iv(t),im(e,[t[0]],Array.from(t[1].integerData))),iy=e=>e.attributes.getInts("axes"),i_=e=>{if(!e||1!==e.length)throw Error("Squeeze requires 1 input.");if("string"===e[0].type)throw Error("invalid input tensor types.")},iv=e=>{if(!e||2!==e.length)throw Error("Squeeze requires 2 inputs.");if("int32"!==e[1].type)throw Error("Invalid input type.")}}}),hM=dQ({"web/lib/onnxjs/backends/webgl/ops/sum.ts"(){"use strict";cB(),cM(),ix=(e,t)=>{i$(t);let r={name:"Sum",inputNames:t.map((e,t)=>`X${t}`),inputTypes:Array(t.length).fill(0)};return[e.run({...r,get:()=>iw(e,t,r)},t)]},iw=(e,t,r)=>{let n=cR(e.session.backend.glContext.version),i=t[0].dims.slice(),o=t.map((e,t)=>`${n.texture2D}(X${t},TexCoords)`).join(" + "),s=`
      void main() {
        vec4 result = ${o};
        ${n.output} = result;
      }
    `;return{...r,output:{dims:i,type:t[0].type,textureType:0},hasMain:!0,shaderSource:s}},i$=e=>{if(!e||0===e.length)throw Error("Sum requires inputs.");let t=e[0].dims.length;for(let r=1;r<e.length;r++){if(t!==e[r].dims.length)throw Error("Input shapes are mismatched.");for(let n=0;n<t;n++)if(e[0].dims[n]!==e[r].dims[n])throw Error("Input shapes are not matched.")}if("float32"!==e[0].type&&"float64"!==e[0].type)throw Error("Invalid input type.");for(let t=1;t<e.length;t++)if(e[0].type!==e[t].type)throw Error("Input types are not matched.")}}}),hF=dQ({"web/lib/onnxjs/backends/webgl/ops/tile.ts"(){"use strict";hw(),cM(),iT=(e,t)=>{iS(t);let r={name:"Tile",inputNames:["A"],inputTypes:[0]};return[e.run({...r,get:()=>iI(e,t,r)},t)]},iI=(e,t,r)=>{let n=t[0].dims.slice(),i=Array(n.length),o=[];for(let e=0;e<n.length;e++)i[e]=n[e]*t[1].numberData[e],o.push(`inputIdx[${e}] = int(mod(float(outputIdx[${e}]), ${n[e]}.));`);let s=i.length,a=`
      float process(int outputIdx[${s}]) {
        int inputIdx[${s}];
        ${o.join("\n")}
        return _A(inputIdx);
      }
    `;return{...r,output:{dims:i,type:t[0].type,textureType:0},shaderSource:a}},iS=e=>{if(!e||2!==e.length)throw Error("Tile requires 2 input.");if(1!==e[1].dims.length)throw Error("The second input shape must 1 dimension.");if(e[1].dims[0]!==e[0].dims.length)throw Error("Invalid input shape.");if(-1===rO.indexOf(e[0].type))throw Error("Invalid input type.");if("int32"!==e[1].type&&"int16"!==e[1].type)throw Error("Invalid repeat type.")}}}),hL=dQ({"web/lib/onnxjs/backends/webgl/ops/unsqueeze.ts"(){"use strict";cA(),iO=(e,t,r)=>{ik(t);let n=eT.unsqueezeShape(t[0].dims,r);return[e.reshapeUnpacked(t[0],n)]},iE=(e,t)=>(iA(t),iO(e,[t[0]],Array.from(t[1].integerData))),iP=e=>e.attributes.getInts("axes"),ik=e=>{if(!e||1!==e.length)throw Error("Unsqueeze requires 1 input.");if("string"===e[0].type)throw Error("invalid input tensor types.")},iA=e=>{if(!e||2!==e.length)throw Error("Unsqueeze requires 2 inputs.");if("int32"!==e[1].type)throw Error("Invalid input type.")}}}),hV=dQ({"web/lib/onnxjs/backends/webgl/op-resolve-rules.ts"(){"use strict";c6(),c5(),c7(),he(),hb(),hy(),hv(),hx(),h$(),hT(),hI(),hS(),hO(),hc(),hE(),hP(),hk(),hA(),hz(),hC(),hN(),hj(),hR(),hB(),hM(),hF(),h_(),ho(),hL(),hD(),iD=[["Abs","","6+",t$],["Acos","","7+",tT],["Add","","7+",e5],["And","","7+",e7],["Asin","","7+",tI],["Atan","","7+",tS],["AveragePool","","7+",ns,na],["BatchNormalization","","7+",eZ,eJ],["Cast","","6+",tl,td],["Ceil","","6+",tA],["Clip","","6-10",tO,tE],["Clip","","11+",tP],["Concat","","4+",tf,tv],["Conv","","1+",t7,rn],["ConvTranspose","","1+",ra,rp],["Cos","","7+",tD],["Div","","7+",e9],["Dropout","","7+",tR],["DepthToSpace","","1+",rx,rw],["Equal","","7+",te],["Elu","","6+",tz,tC],["Exp","","6+",tN],["Flatten","","1+",rT,rI],["Floor","","6+",tj],["FusedConv","com.microsoft","1+",t7,rn],["Gather","","1+",rE,rP],["Gemm","","7-10",rz,rN],["Gemm","","11+",rz,rj],["GlobalAveragePool","","1+",nl,nd],["GlobalMaxPool","","1+",nb],["Greater","","7+",tt],["Identity","","1+",tR],["ImageScaler","","1+",rF,rL],["InstanceNormalization","","6+",rH,rW],["LeakyRelu","","6+",tB,tM],["Less","","7+",tr],["LRN","","1+",rY,r0],["Log","","6+",tF],["MatMul","","1+",tQ,tY],["MaxPool","","1+",np,nc],["Mul","","7+",tn],["Neg","","6+",tL],["Not","","1+",tV],["Or","","7+",ti],["Pad","","2-10",r4,r6],["Pad","","11+",r8,r5],["Pow","","7+",to],["PRelu","","7+",ts],["ReduceLogSum","","1+",nA,n$],["ReduceMax","","1+",nE,n$],["ReduceMean","","1+",nO,n$],["ReduceMin","","1+",nP,n$],["ReduceProd","","1+",nk,n$],["ReduceSum","","1-12",nS,n$],["ReduceSumSquare","","1+",nD,n$],["Relu","","6+",tU],["Reshape","","5+",nz],["Resize","","10",nU,nq],["Resize","","11+",nU,nG],["Shape","","1+",nZ],["Sigmoid","","6+",tq],["Sin","","7+",tG],["Slice","","10+",n3],["Slice","","1-9",nY,n0],["Softmax","","1-12",n9,ie],["Softmax","","13+",ir,it],["Split","","2-12",id,ip],["Sqrt","","6+",tH],["Squeeze","","1-12",im,iy],["Squeeze","","13+",ib],["Sub","","7+",ta],["Sum","","6+",ix],["Tan","","7+",tW],["Tanh","","6+",tK],["Tile","","6+",iT],["Transpose","","1+",rf,rg],["Upsample","","7-8",nN,nj],["Upsample","","9",nN,nR],["Unsqueeze","","1-12",iO,iP],["Unsqueeze","","13+",iE],["Xor","","7+",tu]]}}),hU=dQ({"web/lib/onnxjs/backends/webgl/glsl-function-inliner.ts"(){"use strict";iz=/@inline[\s\n\r]+(\w+)[\s\n\r]+([0-9a-zA-Z_]+)\s*\(([^)]*)\)\s*{(([^}]|[\n\r])*)}/gm,iC="(\\w+)?\\s+([_0-9a-zA-Z]+)\\s+=\\s+__FUNC__\\((.*)\\)\\s*;"}});function hq(e,t){var r,n;let i,o=[],s=[],a=null!=t&&Array.isArray(t)&&0===t.length,u=null==t||a?null:(r=t,i=(n=e).length,cP((r=null==r?n.map((e,t)=>t):[].concat(r)).every(e=>e>=-i&&e<i),()=>`All values in axis param must be in range [-${i}, ${i}) but got axis ${r}`),cP(r.every(hG),()=>`All values in axis param must be integers but got axis ${r}`),r.map(e=>e<0?i+e:e)).sort(),l=0;for(let t=0;t<e.length;++t){if(null!=u){if(u[l]===t&&1!==e[t])throw Error(`Can't squeeze axis ${t} since its dim '${e[t]}' is not 1`);(null==u[l]||u[l]>t)&&1===e[t]&&(o.push(e[t]),s.push(t)),u[l]<=t&&l++}1!==e[t]&&(o.push(e[t]),s.push(t))}return{newShape:o,keptDims:s}}function hG(e){return e%1==0}function hH(e){let t=Math.ceil(Math.sqrt(e));return[t,Math.ceil(e/t)]}var hW=dQ({"web/lib/onnxjs/backends/webgl/texture-layout-strategy.ts"(){"use strict";pm(),cA(),iN=class{constructor(e){this.maxTextureSize=e}computeTextureWH(e,t){let r=this.computeTexture(e,t);return(t&&t.isPacked&&(r[0]/=2,r[1]/=2),t&&t.reverseWH)?[r[1],r[0]]:r}computeTexture(e,t){let r=t&&t.isPacked;if(0===e.length)return r?[2,2]:[1,1];let n=this.maxTextureSize;if(t&&void 0!==t.breakAxis){let r=t.breakAxis>=e.length?1:e.slice(t.breakAxis).reduce((e,t)=>e*t),i=t.breakAxis<=0?1:e.slice(0,t.breakAxis).reduce((e,t)=>e*t);if(!(r>n)&&!(i>n))return[r,i];F.verbose("TextureLayout",`Given width/height preferences were unattainable: shape:${e}, breakAxis:${t.breakAxis}`)}let i=e.slice(0);r&&(n*=2,1===(i=i.map((e,t)=>t>=i.length-2?i[t]%2==0?i[t]:i[t]+1:i[t])).length&&(i=[2,i[0]])),2!==i.length&&(i=hq(i).newShape);let o=function(e){if(0===e.length)return 1;let t=e[0];for(let r=1;r<e.length;r++)t*=e[r];return t}(i);return i.length<=1&&o<=n?[1,o]:2===i.length&&i[0]<=n&&i[1]<=n?i:3===i.length&&i[0]*i[1]<=n&&i[2]<=n?[i[0]*i[1],i[2]]:3===i.length&&i[0]<=n&&i[1]*i[2]<=n?[i[0],i[1]*i[2]]:4===i.length&&i[0]*i[1]*i[2]<=n&&i[3]<=n?[i[0]*i[1]*i[2],i[3]]:4===i.length&&i[0]<=n&&i[1]*i[2]*i[3]<=n?[i[0],i[1]*i[2]*i[3]]:r?hH(o/4).map(e=>2*e):hH(o)}}}}),hK=dQ({"web/lib/onnxjs/backends/webgl/glsl-coordinate-lib.ts"(){"use strict";cA(),c8(),cB(),hW(),cH(),ij=class extends e1{constructor(e){super(e)}getFunctions(){return{...this.offsetToCoords(),...this.coordsToOffset(),...this.toVec(),...this.valueFrom(),...this.getCommonUtilFuncs(),...this.getInputsSamplingSnippets(),...this.getOutputSamplingSnippet()}}getCustomTypes(){return{}}offsetToCoords(){return{offsetToCoords:new e2(`
      vec2 offsetToCoords(int offset, int width, int height) {
        int t = offset / width;
        int s = offset - t*width;
        vec2 coords = (vec2(s,t) + vec2(0.5,0.5)) / vec2(width, height);
        return coords;
      }
      `)}}coordsToOffset(){return{coordsToOffset:new e2(`
      int coordsToOffset(vec2 coords, int width, int height) {
        float s = coords.s * float(width);
        float t = coords.t * float(height);
        int offset = int(t) * width + int(s);
        return offset;
      }
      `)}}getOutputSamplingSnippet(){let e=this.context.outputTextureLayout;return e.isPacked?this.getPackedOutputSamplingSnippet(e):this.getUnpackedOutputSamplingSnippet(e)}getPackedOutputSamplingSnippet(e){let t=e.unpackedShape,r=[e.width,e.height],n={},i="getOutputCoords";switch(t.length){case 0:n[i]=this.getOutputScalarCoords();break;case 1:n[i]=this.getOutputPacked1DCoords(t,r);break;case 2:n[i]=this.getOutputPacked2DCoords(t,r);break;case 3:n[i]=this.getOutputPacked3DCoords(t,r);break;default:n[i]=this.getOutputPackedNDCoords(t,r)}let o=cR(this.context.glContext.version),s=`
      void setOutput(vec4 val) {
        ${o.output} = val;
      }
    `;return n.floatTextureSetRGBA=new e2(s),n}getUnpackedOutputSamplingSnippet(e){let t=e.unpackedShape,r=[e.width,e.height],n={},i="getOutputCoords";switch(t.length){case 0:n[i]=this.getOutputScalarCoords();break;case 1:n[i]=this.getOutputUnpacked1DCoords(t,r);break;case 2:n[i]=this.getOutputUnpacked2DCoords(t,r);break;case 3:n[i]=this.getOutputUnpacked3DCoords(t,r);break;case 4:n[i]=this.getOutputUnpacked4DCoords(t,r);break;case 5:n[i]=this.getOutputUnpacked5DCoords(t,r);break;case 6:n[i]=this.getOutputUnpacked6DCoords(t,r);break;default:throw Error(`Unsupported output dimensionality: ${t.length}`)}let o=cR(this.context.glContext.version),s=`
        void setOutput(float val) {
          ${o.output} = vec4(val, 0, 0, 0);
        }
    `;return n.floatTextureSetR=new e2(s),n}getOutputScalarCoords(){return new e2(`
      int getOutputCoords() {
        return 0;
      }
    `)}getOutputPacked1DCoords(e,t){let r="";return 1===t[0]?r=`
          int getOutputCoords() {
            return 2 * int(TexCoords.y * ${t[1]}.0);
          }
        `:1===t[1]?r=`
          int getOutputCoords() {
            return 2 * int(TexCoords.x * ${t[0]}.0);
          }
        `:r=`
        int getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                 vec2(${t[0]}, ${t[1]}));
          return 2 * (resTexRC.y * ${t[0]} + resTexRC.x);
        }
      `,new e2(r)}getOutputPacked2DCoords(e,t){let r="";if(ey.arraysEqual(e,t))return r=`
        ivec2 getOutputCoords() {
          return 2 * ivec2(TexCoords.xy * vec2(${t[0]}, ${t[1]}));
        }
      `,new e2(r);let n=Math.ceil(e[1]/2);return r=`
        ivec2 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));

          int index = resTexRC.y * ${t[0]} + resTexRC.x;

          // reverse r and c order for packed texture
          int r = imod(index, ${n}) * 2;
          int c = 2 * (index / ${n});

          return ivec2(r, c);
        }
      `,new e2(r)}getOutputPacked3DCoords(e,t){let r=[t[0],t[1]],n=Math.ceil(e[2]/2),i=n*Math.ceil(e[1]/2),o=`
        ivec3 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${r[0]}, ${r[1]}));
          int index = resTexRC.y * ${r[0]} + resTexRC.x;

          int b = index / ${i};
          index -= b * ${i};

          // reverse r and c order for packed texture
          int r = imod(index, ${n}) * 2;
          int c = 2 * (index / ${n});

          return ivec3(b, r, c);
        }
      `;return new e2(o)}getOutputPackedNDCoords(e,t){let r=[t[0],t[1]],n=Math.ceil(e[e.length-1]/2),i=n*Math.ceil(e[e.length-2]/2),o=i,s="",a="b, r, c";for(let t=2;t<e.length-1;t++)o*=e[e.length-t-1],s=`
      int b${t} = index / ${o};
      index -= b${t} * ${o};
    `+s,a=`b${t}, `+a;let u=`
      ivec${e.length} getOutputCoords() {
        ivec2 resTexRC = ivec2(TexCoords.xy *
                              vec2(${r[0]}, ${r[1]}));
        int index = resTexRC.y * ${r[0]} + resTexRC.x;

        ${s}

        int b = index / ${i};
        index -= b * ${i};

        // reverse r and c order for packed texture
        int r = imod(index, ${n}) * 2;
        int c = 2 * (index / ${n});

        return ivec${e.length}(${a});
      }
    `;return new e2(u)}getOutputUnpacked1DCoords(e,t){let r=`
        int getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));
          return resTexRC.y * ${t[0]} + resTexRC.x;
        }
      `;return new e2(r)}getOutputUnpacked2DCoords(e,t){let r=`
        ivec2 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));
          int index = resTexRC.y * ${t[0]} + resTexRC.x;
          int r = index / ${e[1]};
          int c = index - r * ${e[1]};
          return ivec2(r, c);
        }
      `;return new e2(r)}getOutputUnpacked3DCoords(e,t){let r="",n=e.length,i=null;n<2&&(i=[]),(i=Array(n-1))[n-2]=e[n-1];for(let t=n-3;t>=0;--t)i[t]=i[t+1]*e[t+1];let o=["r","c","d"],s=i.map((e,t)=>{let r=`int ${o[t]} = index / ${e}`,n=t===i.length-1?`int ${o[t+1]} = index - ${o[t]} * ${e}`:`index -= ${o[t]} * ${e}`;return`${r}; ${n};`}).join("");return r=`
        ivec3 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));
          int index = resTexRC.y * ${t[0]} + resTexRC.x;
          ${s}
          return ivec3(r, c, d);
        }
      `,new e2(r)}getOutputUnpacked4DCoords(e,t){let r="",n=e.length,i=null;n<2&&(i=[]),(i=Array(n-1))[n-2]=e[n-1];for(let t=n-3;t>=0;--t)i[t]=i[t+1]*e[t+1];let o=["r","c","d","d2"],s=i.map((e,t)=>{let r=`int ${o[t]} = index / ${e}`,n=t===i.length-1?`int ${o[t+1]} = index - ${o[t]} * ${e}`:`index -= ${o[t]} * ${e}`;return`${r}; ${n};`}).join("");return r=`
      ivec4 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));
          int index = resTexRC.y * ${t[0]} + resTexRC.x;
          ${s}
          return ivec4(r, c, d, d2);
        }
      `,new e2(r)}getOutputUnpacked5DCoords(e,t){let r="",n=e.length,i=null;n<2&&(i=[]),(i=Array(n-1))[n-2]=e[n-1];for(let t=n-3;t>=0;--t)i[t]=i[t+1]*e[t+1];let o=["r","c","d","d2","d3"],s=i.map((e,t)=>{let r=`int ${o[t]} = index / ${e}`,n=t===i.length-1?`int ${o[t+1]} = index - ${o[t]} * ${e}`:`index -= ${o[t]} * ${e}`;return`${r}; ${n};`}).join("");return r=`
      ivec5 getOutputCoords() {
          ivec2 resTexRC = ivec2(TexCoords.xy *
                                vec2(${t[0]}, ${t[1]}));
          int index = resTexRC.y * ${t[0]} + resTexRC.x;
          ${s}
          return ivec5(r, c, d, d2, d3);
        }
      `,new e2(r)}getOutputUnpacked6DCoords(e,t){let r="",n=e.length,i=null;n<2&&(i=[]),(i=Array(n-1))[n-2]=e[n-1];for(let t=n-3;t>=0;--t)i[t]=i[t+1]*e[t+1];let o=["r","c","d","d2","d3","d4"],s=i.map((e,t)=>{let r=`int ${o[t]} = index / ${e}`,n=t===i.length-1?`int ${o[t+1]} = index - ${o[t]} * ${e}`:`index -= ${o[t]} * ${e}`;return`${r}; ${n};`}).join("");return r=`
     ivec6 getOutputCoords() {
         ivec2 resTexRC = ivec2(TexCoords.xy *
                               vec2(${t[0]}, ${t[1]}));
         int index = resTexRC.y * ${t[0]} + resTexRC.x;
         ${s}
         return ivec6(r, c, d, d2, d3, d4);
       }
     `,new e2(r)}getCommonUtilFuncs(){let e={},t="uvFromFlat";e[t]=new e2(`
    vec2 uvFromFlat(int texNumR, int texNumC, int index) {
      int texC = index / texNumR;
      int texR = index - texC * texNumR;
      // TODO: swap texR, texC order in following function so row is corresponding to u and column is corresponding to
      //       v.
      return (vec2(texR, texC) + halfCR) / vec2(texNumR, texNumC);
    }
    `),e[t="packedUVfrom1D"]=new e2(`
      vec2 packedUVfrom1D(int texNumR, int texNumC, int index) {
        int texelIndex = index / 2;
        int texR = texelIndex / texNumC;
        int texC = texelIndex - texR * texNumC;
        return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
      }
      `),e[t="packedUVfrom2D"]=new e2(`
      vec2 packedUVfrom2D(int texNumR, int texNumC, int texelsInLogicalRow, int row, int col) {
        int texelIndex = (row / 2) * texelsInLogicalRow + (col / 2);
        int texR = texelIndex / texNumC;
        int texC = texelIndex - texR * texNumC;
        return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
      }
      `),e[t="packedUVfrom3D"]=new e2(`
      vec2 packedUVfrom3D(int texNumR, int texNumC,
          int texelsInBatch, int texelsInLogicalRow, int b,
          int row, int col) {
        int index = b * texelsInBatch + (row / 2) * texelsInLogicalRow + (col / 2);
        int texR = index / texNumC;
        int texC = index - texR * texNumC;
        return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
      }
      `),t="sampleTexture";let r=cR(this.context.glContext.version);return e[t]=new e2(`
        float sampleTexture(sampler2D textureSampler, vec2 uv) {
            return ${r.texture2D}(textureSampler, uv).r;
        }`),e}getInputsSamplingSnippets(){let e={},t=this.context.outputTextureLayout;return this.context.programInfo.inputNames.forEach((r,n)=>{let i=this.context.inputTextureLayouts[n],o=cL(r);i.isPacked?e[o]=this.getPackedSamplerFromInput(o,r,i):e[o]=this.getUnpackedSamplerFromInput(o,r,i);let s=(cP(void 0!==r&&0!==r.length,()=>"empty string found for sampler name"),"get"+r.charAt(0).toUpperCase()+r.slice(1)+"AtOutCoords");i.unpackedShape.length<=t.unpackedShape.length&&(i.isPacked?e[s]=this.getPackedSamplerAtOutputCoords(s,i,t,r):e[s]=this.getUnpackedSamplerAtOutputCoords(s,i,t,r))}),e}getPackedSamplerAtOutputCoords(e,t,r,n){let i,o=t.unpackedShape,s=r.unpackedShape,a=cL(n),u=o.length,l=s.length,d=ev.getBroadcastDims(o,s),p=cq(l),c=l-u,h=cG();i=0===u?"":l<2&&d.length>=1?"coords = 0;":d.map(e=>`coords.${h[e+c]} = 0;`).join("\n");let f="";f=l<2&&u>0?"coords":o.map((e,t)=>`coords.${h[t+c]}`).join(", ");let g="return outputValue;",m=1===eT.size(o),b=1===eT.size(s);if(1!==u||m||b){if(m&&!b)g=1===l?`
          return vec4(outputValue.x, outputValue.x, 0., 0.);
        `:`
          return vec4(outputValue.x);
        `;else if(d.length){let e=u-2,t=u-1;d.indexOf(e)>-1&&d.indexOf(t)>-1?g="return vec4(outputValue.x);":d.indexOf(e)>-1?g="return vec4(outputValue.x, outputValue.y, outputValue.x, outputValue.y);":d.indexOf(t)>-1&&(g="return vec4(outputValue.xx, outputValue.zz);")}}else g=`
        return vec4(outputValue.xy, outputValue.xy);
      `;let y=`
        int lastDim = coords.${h[l-1]};
        coords.${h[l-1]} = coords.${h[l-2]};
        coords.${h[l-2]} = lastDim;
      `,_=`
      vec4 ${e}() {
        ${p} coords = getOutputCoords();
        ${y}
        ${i}
        vec4 outputValue = ${a}(${f});
        ${g}
      }
    `;return new e2(_,["coordinates.getOutputCoords"])}getUnpackedSamplerAtOutputCoords(e,t,r,n){let i,o=[r.width,r.height],s=[t.width,t.height],a=t.unpackedShape.length,u=r.unpackedShape.length,l=t.unpackedShape,d=r.unpackedShape,p=cL(n);if(a===u&&ey.arraysEqual(s,o)){let t=`
          float ${e}() {
            return sampleTexture(${n}, TexCoords);
          }
        `;return new e2(t,["coordinates.sampleTexture"])}let c=cq(u),h=ev.getBroadcastDims(l,d),f=u-a,g=cG();i=0===a?"":u<2&&h.length>=1?"coords = 0;":h.map(e=>`coords.${g[e+f]} = 0;`).join("\n");let m="";m=u<2&&a>0?"coords":t.unpackedShape.map((e,t)=>`coords.${g[t+f]}`).join(", ");let b=`
        float ${e}() {
          ${c} coords = getOutputCoords();
          ${i}
          return ${p}(${m});
        }
      `;return new e2(b,["coordinates.getOutputCoords"])}getPackedSamplerFromInput(e,t,r){switch(r.unpackedShape.length){case 0:return this.getPackedSamplerScalar(e,t);case 1:return this.getPackedSampler1D(e,t,r);case 2:return this.getPackedSampler2D(e,t,r);case 3:return this.getPackedSampler3D(e,t,r);default:return this.getPackedSamplerND(e,t,r)}}getUnpackedSamplerFromInput(e,t,r){let n=r.unpackedShape;switch(n.length){case 0:return this.getUnpackedSamplerScalar(e,t,r);case 1:return this.getUnpackedSampler1D(e,t,r);case 2:return this.getUnpackedSampler2D(e,t,r);case 3:return this.getUnpackedSampler3D(e,t,r);case 4:return this.getUnpackedSampler4D(e,t,r);case 5:return this.getUnpackedSampler5D(e,t,r);case 6:return this.getUnpackedSampler6D(e,t,r);default:throw Error(`Unsupported dimension ${n.length}-D`)}}getPackedSamplerScalar(e,t){let r=cR(this.context.glContext.version),n=`
          vec4 ${e}() {
            return ${r.texture2D}(${t}, halfCR);
          }
        `;return new e2(n)}getPackedSampler1D(e,t,r){let n=[r.width,r.height],i=[n[1],n[0]],o=cR(this.context.glContext.version),s=`vec4 ${e}(int index) {
      vec2 uv = packedUVfrom1D(
      ${i[0]}, ${i[1]}, index);
      return ${o.texture2D}(${t}, uv);
    }`;return new e2(s,["coordinates.packedUVfrom1D"])}getPackedSampler2D(e,t,r){let n=r.unpackedShape,i=[r.width,r.height],o=cR(this.context.glContext.version),s=i[0],a=i[1];if(null!=i&&ey.arraysEqual(n,i)){let r=`vec4 ${e}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${a}.0, ${s}.0);
        return ${o.texture2D}(${t}, uv);
      }`;return new e2(r)}let u=Math.ceil(n[1]/2),l=`vec4 ${e}(int row, int col) {
      vec2 uv = packedUVfrom2D(${i[1]}, ${i[0]}, ${u}, row, col);
      return ${o.texture2D}(${t}, uv);
    }`;return new e2(l,["coordinates.packedUVfrom2D"])}getPackedSampler3D(e,t,r){let n=r.unpackedShape,i=[r.width,r.height],o=[i[0],i[1]],s=cR(this.context.glContext.version);if(1===n[0]){let i=n.slice(1),o=cV(n,i),s=JSON.parse(JSON.stringify(r));s.unpackedShape=o;let a=this.getPackedSamplerFromInput(e,t,s),u=`${a.routineBody}
      vec4 ${e}(int b, int row, int col) {
        return ${e}(${cU(["b","row","col"],[1,2])});
      } `;return new e2(u,a.dependencies)}let a=o[0],u=o[1],l=Math.ceil(n[2]/2),d=l*Math.ceil(n[1]/2),p=`vec4 ${e}(int b, int row, int col) {
      vec2 uv = packedUVfrom3D(
        ${u}, ${a}, ${d}, ${l}, b, row, col);
      return ${s.texture2D}(${t}, uv);}`;return new e2(p,["coordinates.packedUVfrom3D"])}getPackedSamplerND(e,t,r){let n=r.unpackedShape,i=n.length,o=[r.width,r.height],s=cR(this.context.glContext.version),a=[o[0],o[1]],u=a[1],l=a[0],d=Math.ceil(n[i-1]/2),p=d*Math.ceil(n[i-2]/2),c="int b, int row, int col",h=`b * ${p} + (row / 2) * ${d} + (col / 2)`;for(let e=2;e<i-1;e++)c=`int b${e}, `+c,p*=n[i-e-1],h=`b${e} * ${p} + `+h;let f=`vec4 ${e}(${c}) {
      int index = ${h};
      int texR = index / ${l};
      int texC = index - texR * ${l};
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${l}, ${u});
      return ${s.texture2D}(${t}, uv);
    }`;return new e2(f)}getUnpackedSamplerScalar(e,t,r){let[n,i]=[r.width,r.height];if(1===n&&1===i){let r=`
          float ${e}() {
            return sampleTexture(${t}, halfCR);
          }
        `;return new e2(r,["coordinates.sampleTexture"])}let o=`
        float ${e}() {
          int offset_${t} = coordsToOffset(TexCoords, ${n}, ${i});
          vec2 uv = uvFromFlat(${n}, ${i}, offset_${t});
          return sampleTexture(${t}, uv);
        }
      `;return new e2(o,["coordinates.uvFromFlat","coordinates.sampleTexture","coordinates.coordsToOffset"])}getUnpackedSampler1D(e,t,r){let n=r.width,i=r.height;if(1===i&&1===n){let r=`
        float ${e}(int index) {
          return sampleTexture(${t}, halfCR);
        }
      `;return new e2(r,["coordinates.sampleTexture"])}if(1===i){let r=`
          float ${e}(int index) {
            vec2 uv = vec2((float(index) + 0.5) / ${n}.0, 0.5);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(r,["coordinates.sampleTexture"])}if(1===n){let r=`
          float ${e}(int index) {
            vec2 uv = vec2(0.5, (float(index) + 0.5) / ${i}.0);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(r,["coordinates.sampleTexture"])}let o=`
        float ${e}(int index) {
          vec2 uv = uvFromFlat(${n}, ${i}, index);
          return sampleTexture(${t}, uv);
        }
      `;return new e2(o,["coordinates.uvFromFlat","coordinates.sampleTexture"])}getUnpackedSampler2D(e,t,r){let n=r.unpackedShape,i=[r.height,r.width];if(null!=i&&ey.arraysEqual(n,i)){let r=i[1],n=i[0],o=`
          float ${e}(int row, int col) {
            vec2 uv = (vec2(row, col) + halfCR) / vec2(${r}.0, ${n}.0);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(o,["coordinates.sampleTexture"])}let{newShape:o,keptDims:s}=hq(n);if(o.length<n.length){let i=cV(n,o),a=JSON.parse(JSON.stringify(r));a.unpackedShape=i;let u=`
          ${this.getUnpackedSamplerFromInput(e,t,a).routineBody}
          float ${e}(int row, int col) {
            return ${e}(${cU(["col","row"],s)});
          }
        `;return new e2(u,["coordinates.sampleTexture"])}let a=i[1],u=i[0];if(1===u){let r=`
          float ${e}(int row, int col) {
            int offset_${t} = coordsToOffset(TexCoords, ${a}, ${u});
            float index = dot(vec3(row, col, offset_${t}), vec3(${n[1]}, 1, 1));
            vec2 uv = vec2(0.5, (index + 0.5) / ${a}.0);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(r,["coordinates.sampleTexture","coordinates.coordsToOffset"])}if(1===a){let r=`
          float ${e}(int row, int col) {
            int offset_${t} = coordsToOffset(TexCoords, ${a}, ${u});
            float index = dot(vec3(row, col, offset_${t}), vec3(${n[1]}, 1, 1));
            vec2 uv = vec2((index + 0.5) / ${u}.0, 0.5);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(r,["coordinates.sampleTexture","coordinates.coordsToOffset"])}let l=`
        float ${e}(int row, int col) {
          int index = col * ${n[1]} + row;
          vec2 uv = uvFromFlat(${a}, ${u}, index);
          return sampleTexture(${t}, uv);
        }
      `;return new e2(l,["coordinates.uvFromFlat","coordinates.sampleTexture","coordinates.coordsToOffset"])}getUnpackedSampler3D(e,t,r){let n=r.unpackedShape,i=n[1]*n[2],o=n[2],{newShape:s,keptDims:a}=hq(n);if(s.length<n.length){let i=cV(n,s),o=JSON.parse(JSON.stringify(r));o.unpackedShape=i;let u=this.getUnpackedSamplerFromInput(e,t,o),l=a.reverse(),d=`
          ${u.routineBody}
          float ${e}(int batch, int row, int col) {
            return ${e}(${cU(["batch","col","row"],l)});
          }
        `;return new e2(d,u.dependencies)}let u=r.width,l=r.height,d=`
          float ${e}(int depth, int row, int col) {
            // Explicitly use integer operations as dot() only works on floats.
            int index = depth * ${i} + col * ${o} + row;
            vec2 uv = uvFromFlat(${u}, ${l}, index);
            return sampleTexture(${t}, uv);
          }
      `;return new e2(d,["coordinates.uvFromFlat","coordinates.sampleTexture","coordinates.coordsToOffset"])}getUnpackedSampler4D(e,t,r){let n=r.unpackedShape,i=n[3],o=n[2]*i,s=n[1]*o,a=r.width,u=r.height,l=`
        float ${e}(int row, int col, int depth, int depth2) {
          int index = row * ${s} + col * ${o} +
              depth2 * ${i} + depth;
          vec2 uv = uvFromFlat(${a}, ${u}, index);
          return sampleTexture(${t}, uv);
        }
      `;return new e2(l,["coordinates.uvFromFlat","coordinates.sampleTexture"])}getUnpackedSampler5D(e,t,r){let n=r.unpackedShape,i=n[4],o=n[3]*i,s=n[2]*o,a=n[1]*s,{newShape:u,keptDims:l}=hq(n);if(u.length<n.length){let i=cV(n,u),o=JSON.parse(JSON.stringify(r));o.unpackedShape=i;let s=`
          ${this.getUnpackedSamplerFromInput(e,t,o).routineBody}
          float ${e}(int row, int col, int depth, int depth2, int depth3) {
            return ${e}(${cU(["row","col","depth","depth2","depth3"],l)});
          }
        `;return new e2(s,["coordinates.sampleTexture","coordinates.uvFromFlat"])}let d=r.width,p=r.height,c=`
        float ${e}(int row, int col, int depth, int depth2, int depth3) {
          int index = row * ${a} + col * ${s} + depth * ${o} +
          depth3 * ${i} + depth2;
          vec2 uv = uvFromFlat(${d}, ${p}, index);
          return sampleTexture(${t}, uv);
        }
      `;return new e2(c,["coordinates.sampleTexture","coordinates.uvFromFlat"])}getUnpackedSampler6D(e,t,r){let n=r.unpackedShape,i=n[5],o=n[4]*i,s=n[3]*o,a=n[2]*s,u=n[1]*a,{newShape:l,keptDims:d}=hq(n);if(l.length<n.length){let i=cV(n,l),o=JSON.parse(JSON.stringify(r));o.unpackedShape=i;let s=`
            ${this.getUnpackedSamplerFromInput(e,t,o).routineBody}
            float ${e}(int row, int col, int depth,
              int depth2, int depth3, int depth4) {
              return ${e}(${cU(["row","col","depth","depth2","depth3","depth4"],d)});
            }
          `;return new e2(s,["coordinates.sampleTexture","coordinates.uvFromFlat"])}let p=r.width,c=r.height,h=`
          float ${e}(int row, int col, int depth,
            int depth2, int depth3, int depth4) {
            int index = row * ${u} + col * ${a} + depth * ${s} +
            depth2 * ${o} + depth3 * ${i} + depth4;
            vec2 uv = uvFromFlat(${p}, ${c}, index);
            return sampleTexture(${t}, uv);
          }
        `;return new e2(h,["coordinates.uvFromFlat","coordinates.sampleTexture","coordinates.coordsToOffset"])}toVec(){let e=this.context.outputTextureLayout,t=e.shape.length,r=e.strides,n=e.width,i=e.height,o=[];for(let e=0;e<t-1;++e)o.push(`
        c[${e}] = offset / ${r[e]};`),o.push(`
        offset -= c[${e}] * ${r[e]};`);o.push(`
        c[${t-1}] = offset;`);let s=`
      void toVec(vec2 texCoords, out int c[${t}]) {
        int offset = coordsToOffset(texCoords, ${n}, ${i});
        ${o.join("")}
      }
      void toVec(int offset, out int c[${t}]) {
        ${o.join("")}
      }
    `;return{toVec:new e2(s,["coordinates.coordsToOffset"])}}valueFrom(){let e={};return this.context.programInfo.inputNames.forEach((t,r)=>{let n=this.context.inputTextureLayouts[r],i=(n.unpackedShape.length>0?n.unpackedShape:n.shape).length,o=`_${t}`;e[o]=new e2(this.getValueFromSingle(t,i,n.width,n.height,!1),[`shapeUtils.indicesToOffset${o}`,"coordinates.offsetToCoords","fragcolor.getColorAsFloat"]),e[o+="_T"]=new e2(this.getValueFromSingle(t,i,n.width,n.height,!0),[`shapeUtils.indicesToOffset${o}`,"coordinates.offsetToCoords","fragcolor.getColorAsFloat"])}),e}getValueFromSingle(e,t,r,n,i){let o=`_${e}`;i&&(o+="_T");let s=cR(this.context.glContext.version);return`
        float ${o}(int m[${t}]) {
          int offset = indicesToOffset${o}(m);
          vec2 coords = offsetToCoords(offset, ${r}, ${n});
          float value = getColorAsFloat(${s.texture2D}(${e}, coords));
          return value;
        }
        `}getPackedValueFrom(e,t,r,n,i){let o=`_${e}_Pack`;i&&(o+="_T");let s=cR(this.context.glContext.version);return`
        vec4 ${o}(int m[${t}]) {
          int offset = indicesToOffset_${e}(m);
          vec2 coords = offsetToCoords(offset, ${r}, ${n});
          return ${s.texture2D}(${e}, coords);
        }
        `}}}}),hX=dQ({"web/lib/onnxjs/backends/webgl/glsl-encoding-lib.ts"(){"use strict";c8(),iR=class e extends e1{constructor(e){super(e)}getFunctions(){return{...this.encodeFloat32(),...this.decodeFloat32()}}getCustomTypes(){return{}}encodeFloat32(){return{encode:new e2(`highp vec4 encode(highp float f) {
        return vec4(f, 0.0, 0.0, 0.0);
      }
        `)}}decodeFloat32(){return{decode:new e2(`highp float decode(highp vec4 rgba) {
        return rgba.r;
      }
        `)}}encodeUint8(){let t=e.isLittleEndian()?"rgba.rgba=rgba.abgr;":"";return{encode:new e2(`
      highp vec4 encode(highp float f) {
        highp float F = abs(f);
        highp float Sign = step(0.0,-f);
        highp float Exponent = floor(log2(F));
        highp float Mantissa = (exp2(- Exponent) * F);
        Exponent = floor(log2(F) + 127.0) + floor(log2(Mantissa));
        highp vec4 rgba;
        rgba[0] = 128.0 * Sign  + floor(Exponent*exp2(-1.0));
        rgba[1] = 128.0 * mod(Exponent,2.0) + mod(floor(Mantissa*128.0),128.0);
        rgba[2] = floor(mod(floor(Mantissa*exp2(23.0 -8.0)),exp2(8.0)));
        rgba[3] = floor(exp2(23.0)*mod(Mantissa,exp2(-15.0)));
        ${t}
        rgba = rgba / 255.0; // values need to be normalized to [0,1]
        return rgba;
    }
        `)}}decodeUint8(){let t=e.isLittleEndian()?"rgba.rgba=rgba.abgr;":"";return{decode:new e2(`
        highp float decode(highp vec4 rgba) {
          rgba = rgba * 255.0; // values need to be de-normalized from [0,1] to [0,255]
          ${t}
          highp float Sign = 1.0 - step(128.0,rgba[0])*2.0;
          highp float Exponent = 2.0 * mod(rgba[0],128.0) + step(128.0,rgba[1]) - 127.0;
          highp float Mantissa = mod(rgba[1],128.0)*65536.0 + rgba[2]*256.0 +rgba[3] + float(0x800000);
          highp float Result =  Sign * exp2(Exponent) * (Mantissa * exp2(-23.0 ));
          return Result;
      }
        `)}}static isLittleEndian(){let e=new ArrayBuffer(4),t=new Uint32Array(e),r=new Uint8Array(e);if(t[0]=0xdeadbeef,239===r[0])return!0;if(222===r[0])return!1;throw Error("unknown endianness")}}}}),hZ=dQ({"web/lib/onnxjs/backends/webgl/glsl-fragcolor-lib.ts"(){"use strict";c8(),cB(),iB=class extends e1{constructor(e){super(e)}getFunctions(){return{...this.setFragColor(),...this.getColorAsFloat()}}getCustomTypes(){return{}}setFragColor(){let e=cR(this.context.glContext.version);return{setFragColor:new e2(`
        void setFragColor(float value) {
            ${e.output} = encode(value);
        }
        `,["encoding.encode"])}}getColorAsFloat(){return{getColorAsFloat:new e2(`
        float getColorAsFloat(vec4 color) {
            return decode(color);
        }
        `,["encoding.decode"])}}}}}),hJ=dQ({"web/lib/onnxjs/backends/webgl/glsl-shape-utils-lib.ts"(){"use strict";c8(),iM=class e extends e1{constructor(e){super(e)}getFunctions(){return{...this.bcastIndex(),...this.bcastMatmulIndex(),...this.offsetToIndices(),...this.indicesToOffset(),...this.incrementIndices()}}getCustomTypes(){return{}}bcastIndex(){let e=this.context.outputTextureLayout.shape.length,t={};return this.context.programInfo.inputNames.forEach((r,n)=>{let i=this.context.inputTextureLayouts[n].unpackedShape;if(i.length<=e){let n=i.length,o=e-n,s=`bcastIndices_${r}`,a="";for(let e=0;e<n;++e)a+=`
          realIndices[${e}] = int( mod(float(bcastedIndices[${o+e}]), ${i[e]}.0) );
          `;let u=`
        void ${s} (int bcastedIndices[${e}], out int realIndices[${n}]) {
          ${a}
        }
        `;t[s]=new e2(u)}}),t}bcastMatmulIndex(){let e=this.context.outputTextureLayout.shape.length,t={};return this.context.programInfo.inputNames.forEach((r,n)=>{let i=this.context.inputTextureLayouts[n].shape;if(!(i.length<2||i.length>e)){let n=i.length,o=e-n,s=`bcastMatmulIndices_${r}`,a="";for(let e=0;e<n-2;++e)a+=`
          realIndices[${e}] = int( mod(float(bcastedIndices[${o+e}]), ${i[e]}.0) );
          `;let u=`
        void ${s}(int bcastedIndices[${e}], out int realIndices[${n}]) {
          ${a}
          realIndices[${n-1}] = bcastedIndices[${e-1}];
          realIndices[${n-2}] = bcastedIndices[${e-2}];
        }
        `;t[s]=new e2(u)}}),t}indicesToOffset(){let t={};return this.context.programInfo.inputNames.forEach((r,n)=>{let i=this.context.inputTextureLayouts[n].shape,o=this.context.inputTextureLayouts[n].strides,s=i.length,a=`indicesToOffset_${r}`;t[a]=new e2(e.indexToOffsetSingle(a,s,o)),t[a=`indicesToOffset_${r}_T`]=new e2(e.indexToOffsetSingle(a,s,o.slice().reverse()))}),t}static indexToOffsetSingle(e,t,r){let n="";for(let e=t-1;e>=0;--e)n+=`
        offset += indices[${e}] * ${r[e]};
        `;return`
      int ${e}(int indices[${t}]) {
        int offset = 0;
        ${n}
        return offset;
      }
      `}offsetToIndices(){let t={};return this.context.programInfo.inputNames.forEach((r,n)=>{let i=this.context.inputTextureLayouts[n].shape,o=this.context.inputTextureLayouts[n].strides,s=i.length,a=`offsetToIndices_${r}`;t[a]=new e2(e.offsetToIndicesSingle(a,s,o)),t[a=`offsetToIndices_${r}_T`]=new e2(e.offsetToIndicesSingle(a,s,o.slice().reverse()))}),t}static offsetToIndicesSingle(e,t,r){let n=[];for(let e=0;e<t-1;++e)n.push(`
      indices[${e}] = offset / ${r[e]};`),n.push(`
        offset -= indices[${e}] * ${r[e]};`);return n.push(`
      indices[${t-1}] = offset;`),`
      void ${e}(int offset, out int indices[${t}]) {
        ${n.join("")}
      }
      `}incrementIndices(){let e={};return this.context.programInfo.inputNames.forEach((t,r)=>{let n=this.context.inputTextureLayouts[r].shape,i=n.length,o=`incrementIndices_${t}`,s="";for(let e=0;e<i;++e)s+=`
        shape[${e}] = ${n[e]};`;let a=`
        void ${o}(int axis, out int indices[${i}]) {
          int shape[${i}];
          ${s};
          for(int i = ${i} -1 ; i >= 0; --i) {
            if(i > axis) continue;
            indices[i] += 1;
            if(indices[i] < shape[i]) {
              break;
            }
            indices[i] = 0;
          }
        }
        `;e[o]=new e2(a)}),e}}}}),hQ=dQ({"web/lib/onnxjs/backends/webgl/glsl-vec-lib.ts"(){"use strict";c8(),iF=class extends e1{constructor(e){super(e)}getCustomTypes(){return{}}getFunctions(){return{...this.binaryVecFunctions(),...this.copyVec(),...this.setVecItem(),...this.getVecItem()}}binaryVecFunctions(){let e=this.context.outputTextureLayout.shape.length,t={add:"+=",sub:"-=",mul:"*=",div:"/="},r={};for(let n in t){let i=`${n}Vec`,o="";for(let r=0;r<e;++r)o+=`
          dest[${r}] ${t[n]} src[${r}];
          `;let s=`
        void ${i}(int src[${e}], out int dest[${e}]) {
          ${o}
        }
        `;r[i]=new e2(s)}return r}copyVec(){let e=this.context.outputTextureLayout.shape.length,t="";for(let r=0;r<e;++r)t+=`
        dest[${r}] = src[${r}];
        `;let r=`
      void copyVec(int src[${e}], out int dest[${e}]) {
        ${t}
      }
      `;return{copyVec:new e2(r)}}setVecItem(){let e=this.context.outputTextureLayout.shape.length,t=`
        if(index < 0)
            index =${e} + index;
        if (index == 0)
            m[0] = value;
        `;for(let r=1;r<e-1;++r)t+=`
        else if (index == ${r})
            m[${r}] = value;
            `;t+=`
        else
            m[${e-1}] = value;
        `;let r=`
      void setVecItem(out int m[${e}], int index, int value) {
        ${t}
      }
        `;return{setVecItem:new e2(r)}}getVecItem(){let e=this.context.outputTextureLayout.shape.length,t=`
        if(index < 0)
            index = ${e} + index;
        if (index == 0)
            return m[0];
      `;for(let r=1;r<e-1;++r)t+=`
        else if (index == ${r})
            return m[${r}];
      `;t+=`
        else
            return m[${e-1}];
        `;let r=`
      int getVecItem(int m[${e}], int index) {
        ${t}
      }
    `;return{getVecItem:new e2(r)}}}}}),hY=dQ({"web/lib/onnxjs/backends/webgl/glsl-registered-libs.ts"(){"use strict";hK(),hX(),hZ(),hJ(),hQ(),iL={encoding:iR,fragcolor:iB,vec:iF,shapeUtils:iM,coordinates:ij}}}),h0=dQ({"web/lib/onnxjs/backends/webgl/glsl-preprocessor.ts"(){"use strict";c8(),hU(),hY(),cB(),iV=class{constructor(e,t,r,n){this.libs={},this.glslLibRoutineDependencyGraph={},this.context=new e0(e,t,r,n),Object.keys(iL).forEach(e=>{let t=new iL[e](this.context);this.libs[e]=t});let i=this.glslLibRoutineDependencyGraph;for(let e in this.libs){let t=this.libs[e].getFunctions();for(let r in t){let n,o=e+"."+r;i[o]?(n=i[o]).routineBody=t[r].routineBody:(n=new e3(o,t[r].routineBody),i[o]=n);let s=t[r].dependencies;if(s)for(let e=0;e<s.length;++e)if(i[s[e]])n.addDependency(i[s[e]]);else{let t=new e3(s[e]);i[s[e]]=t,n.addDependency(t)}}}}preprocess(){var e,t;let r,n,i=this.context.programInfo,o=i.shaderSource;return this.context.programInfo.hasMain||(o=`${o}
      ${e=this.context.glContext.version,t=this.context.outputTextureLayout.shape.length,r=cR(e),`
  void main() {
    int indices[${t}];
    toVec(TexCoords, indices);
    vec4 result = vec4(process(indices));
    ${r.output} = result;
  }
  `}`),o=function(e){let t,r={};for(;null!==(t=iz.exec(e));){let e=t[3].split(",").map(e=>{let t=e.trim().split(" ");return t&&2===t.length?{type:t[0],name:t[1]}:null}).filter(e=>null!==e);r[t[2]]={params:e,body:t[4]}}for(let n in r){let i=RegExp(iC.replace("__FUNC__",n),"gm");for(;null!==(t=i.exec(e));){let i=t[1],o=t[2],s=t[3].split(","),a=i?`${i} ${o};`:"",u=r[n].body,l="";r[n].params.forEach((e,t)=>{e&&(l+=`${e.type} ${e.name} = ${s[t]};
`)}),u=(u=`${l}
 ${u}`).replace("return",`${o} = `);let d=`
      ${a}
      {
        ${u}
      }
      `;e=e.replace(t[0],d)}}return e.replace(iz,"")}(o),`${n=cR(this.context.glContext.version),`${n.version}
    precision highp float;
    precision highp int;
    precision highp sampler2D;
    ${n.varyingFrag} vec2 TexCoords;
    ${n.outputDeclaration}
    const vec2 halfCR = vec2(0.5, 0.5);

    // Custom vector types to handle higher dimenalities.
    struct ivec5
    {
      int x;
      int y;
      int z;
      int w;
      int u;
    };

    struct ivec6
    {
      int x;
      int y;
      int z;
      int w;
      int u;
      int v;
    };

    int imod(int x, int y) {
      return x - y * (x / y);
    }

    `}
    ${this.getUniforms(i.inputNames,i.variables)}
    ${this.getImports(o)}
    ${o}`}getImports(e){let t=this.selectGlslLibRoutinesToBeIncluded(e);if(0===t.length)return"";let r="";for(let e=0;e<t.length;++e)if(t[e].routineBody)r+=t[e].routineBody+"\n";else throw Error(`Missing body for the Glsl Library routine: ${t[e].name}`);return r}selectGlslLibRoutinesToBeIncluded(e){let t=[];return Object.keys(this.glslLibRoutineDependencyGraph).forEach(r=>{let n=r.split(".")[1];-1!==e.indexOf(n)&&t.push(this.glslLibRoutineDependencyGraph[r])}),e4.returnOrderedNodes(t)}getUniforms(e,t){let r=[];if(e)for(let t of e)r.push(`uniform sampler2D ${t};`);if(t)for(let e of t)r.push(`uniform ${e.type} ${e.name}${e.arrayLength?`[${e.arrayLength}]`:""};`);return r.join("\n")}}}}),h1=dQ({"web/lib/onnxjs/backends/webgl/program-manager.ts"(){"use strict";ph(),pm(),h0(),cB(),iU=class{constructor(e,t,r){this.profiler=e,this.glContext=t,this.textureLayoutStrategy=r,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r){this.profiler.event("op",`ProgramManager.run ${e.programInfo.name??"unknown kernel"}`,()=>{let n=this.glContext.gl,i=e.program;n.useProgram(i);try{this.bindOutput(r),this.attributesBound||this.bindAttributes(e.attribLocations),this.bindUniforms(e.uniformLocations,e.programInfo.variables??[],t)}catch(t){throw F.error("ProgramManager",e.programInfo.shaderSource),t}this.profiler.event("backend","GlContext.draw()",()=>{this.glContext.draw()})},this.glContext)}dispose(){this.vertexShader&&this.glContext.deleteShader(this.vertexShader),this.repo.forEach(e=>this.glContext.deleteProgram(e.program))}build(e,t,r){return this.profiler.event("backend","ProgramManager.build",()=>{let n=new iV(this.glContext,e,t,r),i=n.preprocess(),o=this.compile(i);return{programInfo:e,program:o,uniformLocations:this.getUniformLocations(o,n.context.programInfo.inputNames,n.context.programInfo.variables),attribLocations:this.getAttribLocations(o)}})}compile(e){if(!this.vertexShader){let e;F.verbose("ProrgramManager","Compiling and caching Vertex shader for the first time");let t=(e=cR(this.glContext.version),`${e.version}
      precision highp float;
      ${e.attribute} vec3 position;
      ${e.attribute} vec2 textureCoord;

      ${e.varyingVertex} vec2 TexCoords;

      void main()
      {
          gl_Position = vec4(position, 1.0);
          TexCoords = textureCoord;
      }`);this.vertexShader=this.glContext.compileShader(t,this.glContext.gl.VERTEX_SHADER)}l.debug&&F.verbose("ProrgramManager",`FragShader:
${e}
`);let t=this.glContext.compileShader(e,this.glContext.gl.FRAGMENT_SHADER),r=this.glContext.createProgram(this.vertexShader,t);return this.glContext.deleteShader(t),r}bindOutput(e){let t=e.width,r=e.height;F.verbose("ProrgramManager",`Binding output texture to Framebuffer: w/h=${t}/${r}, shape=${e.shape}, type=${e.tensor.type}`),this.glContext.attachFramebuffer(e.texture,t,r)}bindAttributes(e){let t=e.position,r=e.textureCoord;this.glContext.setVertexAttributes(t,r),this.attributesBound=!0}bindUniforms(e,t,r){let n=this.glContext.gl,i=0;for(let{name:o,type:s,location:a,arrayLength:u}of e){let e=t.find(e=>e.name===o)?.data;if("sampler2D"!==s&&!e)throw Error(`variable '${o}' does not have data defined in program info`);switch(s){case"sampler2D":this.bindTexture(r[i],a,i),i++;break;case"float":u?n.uniform1fv(a,e):n.uniform1f(a,e);break;case"int":u?n.uniform1iv(a,e):n.uniform1i(a,e);break;default:throw Error(`Uniform not implemented: ${s}`)}}}bindTexture(e,t,r){this.glContext.bindTextureToUniform(e.texture,r,t)}getAttribLocations(e){return{position:this.getAttribLocation(e,"position"),textureCoord:this.getAttribLocation(e,"textureCoord")}}getUniformLocations(e,t,r){let n=[];if(t)for(let r of t)n.push({name:r,type:"sampler2D",location:this.getUniformLocation(e,r)});if(r)for(let t of r)n.push({...t,location:this.getUniformLocation(e,t.name)});return n}getUniformLocation(e,t){let r=this.glContext.gl.getUniformLocation(e,t);if(null===r)throw Error(`Uniform ${t} not found.`);return r}getAttribLocation(e,t){return this.glContext.gl.getAttribLocation(e,t)}}}}),h2=dQ({"web/lib/onnxjs/backends/webgl/texture-manager.ts"(){"use strict";pm(),c1(),iq=class{constructor(e,t,r,n){this.glContext=e,this.layoutStrategy=t,this.profiler=r,this.config=n,this.pendingRead=new Map,n.reuseTextures&&(this.inUseTextures=new Map,this.idleTextures=new Map,this.textureLookup=new Map)}createTextureFromLayout(e,t,r,n){let i,o,s=this.toEncoderType(e),a=this.glContext.getEncoder(s,t.channels||1,n);if(t.isPacked&&1===n)throw Error("not implemented");let u=t.width,l=t.height;if(this.config.reuseTextures){i=`${u}x${l}_${a.format}_${a.internalFormat}_${a.textureType}`,(o=this.inUseTextures.get(i))||(o=[],this.inUseTextures.set(i,o));let t=this.idleTextures.get(i);if(t&&t.length>0){let i=t.pop();return o.push(i),1===n&&this.glContext.updateTexture(i,u,l,a,this.toTextureData(e,r)),i}}F.verbose("TextureManager",`Creating new texture of size ${t.width}x${t.height}`);let d=this.glContext.allocateTexture(u,l,a,this.toTextureData(e,r));return this.config.reuseTextures&&(o.push(d),this.textureLookup.set(d,i)),d}readTexture(e,t,r){return r||(r=1),this.profiler.event("backend","TextureManager.readTexture",()=>{let n=e.shape.reduce((e,t)=>e*t)*r,i=this.glContext.readTexture(e.texture,e.width,e.height,n,this.toEncoderType(t),r);return this.toTensorData(t,i)})}async readTextureAsync(e,t,r){let n=e.tensor.dataId;if(r||(r=1),this.pendingRead.has(n)){let e=this.pendingRead.get(n);return new Promise(t=>e?.push(t))}return this.profiler.event("backend","TextureManager.readTextureAsync",async()=>{this.pendingRead.set(n,[]);let i=e.shape.reduce((e,t)=>e*t)*r;await this.glContext.createAndWaitForFence();let o=this.glContext.readTexture(e.texture,e.width,e.height,i,this.toEncoderType(t),r),s=this.toTensorData(t,o),a=this.pendingRead.get(n);return this.pendingRead.delete(n),a?.forEach(e=>e(s)),s})}readUint8TextureAsFloat(e){return this.profiler.event("backend","TextureManager.readUint8TextureAsFloat",()=>{let t=e.shape.reduce((e,t)=>e*t),r=this.glContext.readTexture(e.texture,e.width,e.height,4*t,"byte",4);return new Float32Array(r.buffer,r.byteOffset,t)})}releaseTexture(e,t){let r;if(this.config.reuseTextures&&(r=this.textureLookup.get(e.texture))){t&&this.textureLookup.delete(r);let n=this.inUseTextures.get(r);if(n){let t=n.indexOf(e.texture);if(-1!==t){n.splice(t,1);let i=this.idleTextures.get(r);i||(i=[],this.idleTextures.set(r,i)),i.push(e.texture)}}}(!r||t)&&(F.verbose("TextureManager",`Deleting texture of size ${e.width}x${e.height}`),this.glContext.deleteTexture(e.texture))}toTensorData(e,t){switch(e){case"int16":return t instanceof Int16Array?t:Int16Array.from(t);case"int32":return t instanceof Int32Array?t:Int32Array.from(t);case"int8":return t instanceof Int8Array?t:Int8Array.from(t);case"uint16":return t instanceof Uint16Array?t:Uint16Array.from(t);case"uint32":return t instanceof Uint32Array?t:Uint32Array.from(t);case"uint8":case"bool":return t instanceof Uint8Array?t:Uint8Array.from(t);case"float32":return t instanceof Float32Array?t:Float32Array.from(t);case"float64":return t instanceof Float64Array?t:Float64Array.from(t);default:throw Error(`TensorData type ${e} is not supported`)}}toTextureData(e,t){if(t)return t instanceof Float32Array?t:new Float32Array(t)}toEncoderType(e){return"float"}clearActiveTextures(){this.glContext.clearActiveTextures()}}}}),h3=dQ({"web/lib/onnxjs/backends/webgl/session-handler.ts"(){"use strict";pm(),pb(),c3(),hV(),h1(),hW(),h2(),iG=class{constructor(e,t){this.backend=e,this.context=t,this.layoutStrategy=new iN(e.glContext.maxTextureSize),this.programManager=new iU(this.context.profiler,e.glContext,this.layoutStrategy),this.textureManager=new iq(e.glContext,this.layoutStrategy,this.context.profiler,{reuseTextures:"full"===e.textureCacheMode}),this.packedTextureDataCache=new Map,this.unpackedTextureDataCache=new Map,this.pack=e.pack,this.pack2unpackMap=new Map,this.unpack2packMap=new Map}createInferenceHandler(){return new eH(this)}onGraphInitialized(e){let t=e.getValues().filter(e=>-1===e.from&&e.tensor).map(e=>e.tensor.dataId);this.initializers=new Set(t)}isInitializer(e){return!!this.initializers&&this.initializers.has(e)}addInitializer(e){this.initializers.add(e)}getTextureData(e,t){return t?this.packedTextureDataCache.get(e):this.unpackedTextureDataCache.get(e)}setTextureData(e,t,r=!1){F.verbose("WebGLSessionHandler","Storing Texture data in cache"),r?this.packedTextureDataCache.set(e,t):this.unpackedTextureDataCache.set(e,t)}dispose(){this.programManager.dispose(),this.textureManager.clearActiveTextures(),this.packedTextureDataCache.forEach(e=>this.textureManager.releaseTexture(e,!0)),this.packedTextureDataCache=new Map,this.unpackedTextureDataCache.forEach(e=>this.textureManager.releaseTexture(e,!0)),this.unpackedTextureDataCache=new Map}resolve(e,t,r){let n=function(e,t,r){for(let n of r){let r=n[0],i=n[1],o=n[2],s=n[3],a=n[4];if(e.opType===r){for(let e of t)if((e.domain===i||"ai.onnx"===e.domain&&""===i)&&function(e,t){if(t.endsWith("+")){let r=Number.parseInt(t.substring(0,t.length-1),10);return!isNaN(r)&&r<=e}if(2!==t.split("-").length)return Number.parseInt(t,10)===e;{let r=t.split("-"),n=Number.parseInt(r[0],10),i=Number.parseInt(r[1],10);return!isNaN(n)&&!isNaN(i)&&n<=e&&e<=i}}(e.version,o))return{opImpl:s,opInit:a}}}throw TypeError(`cannot resolve operator '${e.opType}' with opsets: ${t.map(e=>`${e.domain||"ai.onnx"} v${e.version}`).join(", ")}`)}(e,t,iD);return{impl:n.opImpl,context:n.opInit?n.opInit(e,r):e}}}}}),h4=dQ({"web/lib/onnxjs/backends/webgl/webgl-context.ts"(){"use strict";ph(),c1(),c1(),cH(),iH=class{constructor(e,t){this.frameBufferBound=!1,this.itemsToPoll=[],this.gl=e,this.version=t,this.getExtensions(),this.vertexbuffer=this.createVertexbuffer(),this.framebuffer=this.createFramebuffer(),this.queryVitalParameters()}allocateTexture(e,t,r,n){let i=this.gl,o=i.createTexture();i.bindTexture(i.TEXTURE_2D,o),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MAG_FILTER,i.NEAREST),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE);let s=n?r.encode(n,e*t):null;return i.texImage2D(i.TEXTURE_2D,0,r.internalFormat,e,t,0,r.format,r.textureType,s),this.checkError(),o}updateTexture(e,t,r,n,i){let o=this.gl;o.bindTexture(o.TEXTURE_2D,e);let s=n.encode(i,t*r);o.texSubImage2D(o.TEXTURE_2D,0,0,0,t,r,n.format,n.textureType,s),this.checkError()}attachFramebuffer(e,t,r){let n=this.gl;n.bindTexture(n.TEXTURE_2D,e),n.bindFramebuffer(n.FRAMEBUFFER,this.framebuffer),n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,e,0),this.checkError(),n.viewport(0,0,t,r),n.scissor(0,0,t,r)}readTexture(e,t,r,n,i,o){let s=this.gl;o||(o=1),this.frameBufferBound||this.attachFramebuffer(e,t,r);let a=this.getEncoder(i,o),u=a.allocate(t*r);return s.bindTexture(s.TEXTURE_2D,e),s.framebufferTexture2D(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,e,0),s.readPixels(0,0,t,r,s.RGBA,a.textureType,u),this.checkError(),a.decode(u,n)}isFramebufferReady(){return!0}getActiveTexture(){let e=this.gl,t=e.getParameter(this.gl.ACTIVE_TEXTURE);return`TEXTURE${t-e.TEXTURE0}`}getTextureBinding(){return this.gl.getParameter(this.gl.TEXTURE_BINDING_2D)}getFramebufferBinding(){return this.gl.getParameter(this.gl.FRAMEBUFFER_BINDING)}setVertexAttributes(e,t){let r=this.gl;r.vertexAttribPointer(e,3,r.FLOAT,!1,20,0),r.enableVertexAttribArray(e),-1!==t&&(r.vertexAttribPointer(t,2,r.FLOAT,!1,20,12),r.enableVertexAttribArray(t)),this.checkError()}createProgram(e,t){let r=this.gl,n=r.createProgram();return r.attachShader(n,e),r.attachShader(n,t),r.linkProgram(n),n}compileShader(e,t){let r=this.gl,n=r.createShader(t);if(!n)throw Error(`createShader() returned null with type ${t}`);if(r.shaderSource(n,e),r.compileShader(n),!1===r.getShaderParameter(n,r.COMPILE_STATUS))throw Error(`Failed to compile shader: ${r.getShaderInfoLog(n)}
Shader source:
${e}`);return n}deleteShader(e){this.gl.deleteShader(e)}bindTextureToUniform(e,t,r){let n=this.gl;n.activeTexture(n.TEXTURE0+t),this.checkError(),n.bindTexture(n.TEXTURE_2D,e),this.checkError(),n.uniform1i(r,t),this.checkError()}draw(){this.gl.drawArrays(this.gl.TRIANGLE_STRIP,0,4),this.checkError()}checkError(){if(l.debug){let e=this.gl,t=e.getError(),r="";switch(t){case e.NO_ERROR:return;case e.INVALID_ENUM:r="INVALID_ENUM";break;case e.INVALID_VALUE:r="INVALID_VALUE";break;case e.INVALID_OPERATION:r="INVALID_OPERATION";break;case e.INVALID_FRAMEBUFFER_OPERATION:r="INVALID_FRAMEBUFFER_OPERATION";break;case e.OUT_OF_MEMORY:r="OUT_OF_MEMORY";break;case e.CONTEXT_LOST_WEBGL:r="CONTEXT_LOST_WEBGL";break;default:r=`Unknown WebGL Error: ${t.toString(16)}`}throw Error(r)}}deleteTexture(e){this.gl.deleteTexture(e)}deleteProgram(e){this.gl.deleteProgram(e)}getEncoder(e,t,r=0){if(2===this.version)return new eF(this.gl,t);switch(e){case"float":if(1===r||this.isRenderFloat32Supported)return new eL(this.gl,t);return new eL(this.gl,t,this.textureHalfFloatExtension.HALF_FLOAT_OES);case"int":throw Error("not implemented");case"byte":return new eV(this.gl,t);default:throw Error(`Invalid dataType: ${e}`)}}clearActiveTextures(){let e=this.gl;for(let t=0;t<this.maxTextureImageUnits;++t)e.activeTexture(e.TEXTURE0+t),e.bindTexture(e.TEXTURE_2D,null)}dispose(){if(this.disposed)return;let e=this.gl;e.bindFramebuffer(e.FRAMEBUFFER,null),e.deleteFramebuffer(this.framebuffer),e.bindBuffer(e.ARRAY_BUFFER,null),e.deleteBuffer(this.vertexbuffer),e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,null),e.finish(),this.disposed=!0}createDefaultGeometry(){return new Float32Array([-1,1,0,0,1,-1,-1,0,0,0,1,1,0,1,1,1,-1,0,1,0])}createVertexbuffer(){let e=this.gl,t=e.createBuffer();if(!t)throw Error("createBuffer() returned null");let r=this.createDefaultGeometry();return e.bindBuffer(e.ARRAY_BUFFER,t),e.bufferData(e.ARRAY_BUFFER,r,e.STATIC_DRAW),this.checkError(),t}createFramebuffer(){let e=this.gl.createFramebuffer();if(!e)throw Error("createFramebuffer returned null");return e}queryVitalParameters(){let e=this.gl;if(this.isFloatTextureAttachableToFrameBuffer=this.checkFloatTextureAttachableToFrameBuffer(),this.isRenderFloat32Supported=this.checkRenderFloat32(),this.isFloat32DownloadSupported=this.checkFloat32Download(),1===this.version&&!this.textureHalfFloatExtension&&!this.isRenderFloat32Supported)throw Error("both float32 and float16 TextureType are not supported");this.isBlendSupported=!this.isRenderFloat32Supported||this.checkFloat32Blend(),this.maxTextureSize=e.getParameter(e.MAX_TEXTURE_SIZE),this.maxTextureImageUnits=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),this.version}getExtensions(){2===this.version?(this.colorBufferFloatExtension=this.gl.getExtension("EXT_color_buffer_float"),this.disjointTimerQueryWebgl2Extension=this.gl.getExtension("EXT_disjoint_timer_query_webgl2")):(this.textureFloatExtension=this.gl.getExtension("OES_texture_float"),this.textureHalfFloatExtension=this.gl.getExtension("OES_texture_half_float"))}checkFloatTextureAttachableToFrameBuffer(){let e=this.gl,t=e.createTexture();e.bindTexture(e.TEXTURE_2D,t);let r=2===this.version?e.RGBA32F:e.RGBA;e.texImage2D(e.TEXTURE_2D,0,r,1,1,0,e.RGBA,e.FLOAT,null);let n=e.createFramebuffer();e.bindFramebuffer(e.FRAMEBUFFER,n),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0);let i=e.checkFramebufferStatus(e.FRAMEBUFFER)===e.FRAMEBUFFER_COMPLETE;return e.bindTexture(e.TEXTURE_2D,null),e.bindFramebuffer(e.FRAMEBUFFER,null),e.deleteTexture(t),e.deleteFramebuffer(n),i}checkRenderFloat32(){if(2===this.version){if(!this.colorBufferFloatExtension)return!1}else if(!this.textureFloatExtension)return!1;return this.isFloatTextureAttachableToFrameBuffer}checkFloat32Download(){if(2===this.version){if(!this.colorBufferFloatExtension)return!1}else if(!this.textureFloatExtension||!this.gl.getExtension("WEBGL_color_buffer_float"))return!1;return this.isFloatTextureAttachableToFrameBuffer}checkFloat32Blend(){let e,t,r,n,i,o=this.gl;try{e=o.createTexture(),t=o.createFramebuffer(),o.bindTexture(o.TEXTURE_2D,e);let s=2===this.version?o.RGBA32F:o.RGBA;if(o.texImage2D(o.TEXTURE_2D,0,s,1,1,0,o.RGBA,o.FLOAT,null),o.bindFramebuffer(o.FRAMEBUFFER,t),o.framebufferTexture2D(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,e,0),o.enable(o.BLEND),!(r=o.createShader(o.VERTEX_SHADER))||(o.shaderSource(r,"void main(){}"),o.compileShader(r),!(n=o.createShader(o.FRAGMENT_SHADER)))||(o.shaderSource(n,"precision highp float;void main(){gl_FragColor=vec4(0.5);}"),o.compileShader(n),!(i=o.createProgram())))return!1;return o.attachShader(i,r),o.attachShader(i,n),o.linkProgram(i),o.useProgram(i),o.drawArrays(o.POINTS,0,1),o.getError()===o.NO_ERROR}finally{o.disable(o.BLEND),i&&o.deleteProgram(i),r&&o.deleteShader(r),n&&o.deleteShader(n),t&&(o.bindFramebuffer(o.FRAMEBUFFER,null),o.deleteFramebuffer(t)),e&&(o.bindTexture(o.TEXTURE_2D,null),o.deleteTexture(e))}}beginTimer(){if(2===this.version&&this.disjointTimerQueryWebgl2Extension){let e=this.gl,t=this.disjointTimerQueryWebgl2Extension,r=e.createQuery();return e.beginQuery(t.TIME_ELAPSED_EXT,r),r}throw Error("WebGL1 profiling currently not supported.")}endTimer(){if(2===this.version&&this.disjointTimerQueryWebgl2Extension){let e=this.gl,t=this.disjointTimerQueryWebgl2Extension;e.endQuery(t.TIME_ELAPSED_EXT);return}throw Error("WebGL1 profiling currently not supported")}isTimerResultAvailable(e){let t=!1,r=!1;if(2===this.version&&this.disjointTimerQueryWebgl2Extension){let n=this.gl,i=this.disjointTimerQueryWebgl2Extension;t=n.getQueryParameter(e,n.QUERY_RESULT_AVAILABLE),r=n.getParameter(i.GPU_DISJOINT_EXT)}else throw Error("WebGL1 profiling currently not supported");return t&&!r}getTimerResult(e){let t=0;if(2===this.version){let r=this.gl;t=r.getQueryParameter(e,r.QUERY_RESULT),r.deleteQuery(e)}else throw Error("WebGL1 profiling currently not supported");return t/1e6}async waitForQueryAndGetTime(e){return await cF(()=>this.isTimerResultAvailable(e)),this.getTimerResult(e)}async createAndWaitForFence(){let e=this.createFence(this.gl);return this.pollFence(e)}createFence(e){let t,r=e.fenceSync(e.SYNC_GPU_COMMANDS_COMPLETE,0);return e.flush(),t=null===r?()=>!0:()=>{let t=e.clientWaitSync(r,0,0);return t===e.ALREADY_SIGNALED||t===e.CONDITION_SATISFIED},{query:r,isFencePassed:t}}async pollFence(e){return new Promise(t=>{this.addItemToPoll(()=>e.isFencePassed(),()=>t())})}pollItems(){let e=function(e){let t=0;for(;t<e.length&&e[t]();++t);return t-1}(this.itemsToPoll.map(e=>e.isDoneFn));for(let t=0;t<=e;++t){let{resolveFn:e}=this.itemsToPoll[t];e()}this.itemsToPoll=this.itemsToPoll.slice(e+1)}async addItemToPoll(e,t){this.itemsToPoll.push({isDoneFn:e,resolveFn:t}),this.itemsToPoll.length>1||await cF(()=>(this.pollItems(),0===this.itemsToPoll.length))}}}});function h6(e,t){let r,n={alpha:!1,depth:!1,antialias:!1,stencil:!1,preserveDrawingBuffer:!1,premultipliedAlpha:!1,failIfMajorPerformanceCaveat:!1};if((!t||"webgl2"===t)&&(r=e.getContext("webgl2",n)))try{return new iH(r,2)}catch(e){F.warning("GlContextFactory",`failed to create WebGLContext using contextId 'webgl2'. Error: ${e}`)}if((!t||"webgl"===t)&&(r=e.getContext("webgl",n)||e.getContext("experimental-webgl",n)))try{return new iH(r,1)}catch(e){F.warning("GlContextFactory",`failed to create WebGLContext using contextId 'webgl' or 'experimental-webgl'. Error: ${e}`)}throw Error("WebGL is not supported")}var h8=dQ({"web/lib/onnxjs/backends/webgl/webgl-context-factory.ts"(){"use strict";pm(),h4(),iW={}}}),h5=dQ({"web/lib/onnxjs/backends/backend-webgl.ts"(){"use strict";ph(),pm(),h3(),h8(),iK=class{get contextId(){return l.webgl.contextId}set contextId(e){l.webgl.contextId=e}get matmulMaxBatchSize(){return l.webgl.matmulMaxBatchSize}set matmulMaxBatchSize(e){l.webgl.matmulMaxBatchSize=e}get textureCacheMode(){return l.webgl.textureCacheMode}set textureCacheMode(e){l.webgl.textureCacheMode=e}get pack(){return l.webgl.pack}set pack(e){l.webgl.pack=e}get async(){return l.webgl.async}set async(e){l.webgl.async=e}initialize(){try{return this.glContext=function e(t){let r;if((!t||"webgl2"===t)&&"webgl2"in iW?r=iW.webgl2:(!t||"webgl"===t)&&"webgl"in iW&&(r=iW.webgl),!r)try{let e=function(){if("u"<typeof OffscreenCanvas)throw TypeError("failed to create offscreen canvas: OffscreenCanvas is not supported");return new OffscreenCanvas(1,1)}();r=h6(e,t)}catch{r=h6(function(){if("u"<typeof document)throw TypeError("failed to create canvas: document is not supported");let e=document.createElement("canvas");return e.width=1,e.height=1,e}(),t)}t=t||1===r.version?"webgl":"webgl2";let n=r.gl;return(iW[t]=r,n.isContextLost())?(delete iW[t],e(t)):(n.disable(n.DEPTH_TEST),n.disable(n.STENCIL_TEST),n.disable(n.BLEND),n.disable(n.DITHER),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SAMPLE_COVERAGE),n.enable(n.SCISSOR_TEST),n.enable(n.CULL_FACE),n.cullFace(n.BACK),r)}(this.contextId),"number"!=typeof this.matmulMaxBatchSize&&(this.matmulMaxBatchSize=16),"string"!=typeof this.textureCacheMode&&(this.textureCacheMode="full"),"boolean"!=typeof this.pack&&(this.pack=!1),"boolean"!=typeof this.async&&(this.async=!1),F.setWithEnv(l),l.webgl.context||Object.defineProperty(l.webgl,"context",{value:this.glContext.gl}),F.verbose("WebGLBackend",`Created WebGLContext: ${typeof this.glContext} with matmulMaxBatchSize: ${this.matmulMaxBatchSize}; textureCacheMode: ${this.textureCacheMode}; pack: ${this.pack}; async: ${this.async}.`),!0}catch(e){return F.warning("WebGLBackend",`Unable to initialize WebGLBackend. ${e}`),!1}}createSessionHandler(e){return new iG(this,e)}dispose(){this.glContext.dispose()}}}});async function h7(e){if(!e)return h7(["webgl"]);for(let t of"string"==typeof e?[e]:e){let e=iX.get(t);if(e)return e;let r=await h9(t);if(r)return r}throw Error("no available backend to use")}async function h9(e){var t;let r=iZ;if(void 0!==r[e]&&"initialize"in(t=r[e])&&"function"==typeof t.initialize&&"createSessionHandler"in t&&"function"==typeof t.createSessionHandler&&"dispose"in t&&"function"==typeof t.dispose){let t=r[e],n=t.initialize();if("object"==typeof n&&"then"in n&&(n=await n),n)return iX.set(e,t),t}}var fe=dQ({"web/lib/onnxjs/backend.ts"(){"use strict";h5(),iX=new Map,iZ={webgl:new iK}}}),ft=dQ({"web/lib/onnxjs/execution-plan.ts"(){"use strict";pm(),iJ=class{constructor(e,t){this.op=e,this.node=t}},iQ=class{constructor(e,t,r){this.graph=e,this.profiler=r,this.initialize(t)}initialize(e){this.profiler.event("session","ExecutionPlan.initialize",()=>{let t=this.graph.getNodes();if(t.length!==e.length)throw Error("The size of nodes and OPs do not match.");this._ops=e.map((e,r)=>new iJ(e,t[r])),this.reset(),this._starter=[],this._ops.forEach((e,t)=>{let r=!0;for(let t of e.node.inputs)if(!this._values[t]&&-1===this.graph.getInputIndices().indexOf(t)){r=!1;break}r&&this._starter.push(t)})})}reset(){this._values=this.graph.getValues().map(e=>e.tensor)}async execute(e,t){return this.profiler.event("session","ExecutionPlan.execute",async()=>{this.reset();let r=e.createInferenceHandler(),n=this.graph.getInputIndices();if(t.length!==n.length)throw Error(`number of input tensors don't match the number of inputs to the model: actual: ${t.length} expected: ${n.length}`);t.forEach((e,t)=>{let r=n[t];this._values[r]=e});let i=this._starter.slice(0),o=this.graph.getValues(),s=this.graph.getNodes(),a=0;for(;a<i.length;){let e=i[a++],t=this._ops[e],n=t.node.inputs.map(e=>this._values[e]);if(-1!==n.indexOf(void 0))throw Error(`unresolved input detected: op: ${t.node}`);F.verbose("ExecPlan",`Running op:${t.node.name} (${n.map((e,r)=>`'${t.node.inputs[r]}': ${e.type}[${e.dims.join(",")}]`).join(", ")})`);let u=await this.profiler.event("node",t.node.name,async()=>t.op.impl(r,n,t.op.context));if(u.length!==t.node.outputs.length)throw Error("the size of output does not match model definition.");u.forEach((e,r)=>{let n=t.node.outputs[r];if(this._values[n])throw Error(`output [${n}] already has value: op:${t.node.name}`);this._values[n]=e});let l=new Set;u.forEach((e,r)=>{for(let e of o[t.node.outputs[r]].to){let t=s[e],r=!0;for(let e of t.inputs)if(!this._values[e]){r=!1;break}r&&l.add(e)}}),i.push(...l)}let u=[];for(let e=0;e<this.graph.getOutputIndices().length;e++){let t=this.graph.getOutputIndices()[e],r=this._values[t];if(void 0===r)throw Error(`required output [${t}] does not have value`);0===t?await r.getData():r.data,u.push(r)}return F.verbose("ExecPlan","disposing of inferenceHandler"),r.dispose(),u})}}}}),fr=dQ({"web/lib/onnxjs/attribute.ts"(){"use strict";cu(),iY=d2(cE()),cj(),cA(),i0=class e{constructor(t){if(this._attributes=new Map,null!=t){for(let r of t)r instanceof iY.onnx.AttributeProto?this._attributes.set(r.name,[e.getValue(r),e.getType(r)]):r instanceof el.Attribute&&this._attributes.set(r.name(),[e.getValue(r),e.getType(r)]);if(this._attributes.size<t.length)throw Error("duplicated attribute names")}}set(e,t,r){this._attributes.set(e,[r,t])}delete(e){this._attributes.delete(e)}getFloat(e,t){return this.get(e,"float",t)}getInt(e,t){return this.get(e,"int",t)}getString(e,t){return this.get(e,"string",t)}getTensor(e,t){return this.get(e,"tensor",t)}getFloats(e,t){return this.get(e,"floats",t)}getInts(e,t){return this.get(e,"ints",t)}getStrings(e,t){return this.get(e,"strings",t)}getTensors(e,t){return this.get(e,"tensors",t)}get(e,t,r){let n=this._attributes.get(e);if(void 0===n){if(void 0!==r)return r;throw Error(`required attribute not found: ${e}`)}if(n[1]!==t)throw Error(`type mismatch: expected ${t} but got ${n[1]}`);return n[0]}static getType(e){let t=e instanceof iY.onnx.AttributeProto?e.type:e.type();switch(t){case iY.onnx.AttributeProto.AttributeType.FLOAT:return"float";case iY.onnx.AttributeProto.AttributeType.INT:return"int";case iY.onnx.AttributeProto.AttributeType.STRING:return"string";case iY.onnx.AttributeProto.AttributeType.TENSOR:return"tensor";case iY.onnx.AttributeProto.AttributeType.FLOATS:return"floats";case iY.onnx.AttributeProto.AttributeType.INTS:return"ints";case iY.onnx.AttributeProto.AttributeType.STRINGS:return"strings";case iY.onnx.AttributeProto.AttributeType.TENSORS:return"tensors";default:throw Error(`attribute type is not supported yet: ${iY.onnx.AttributeProto.AttributeType[t]}`)}}static getValue(e){let t=e instanceof iY.onnx.AttributeProto?e.type:e.type();if(t===iY.onnx.AttributeProto.AttributeType.GRAPH||t===iY.onnx.AttributeProto.AttributeType.GRAPHS)throw Error("graph attribute is not supported yet");let r=this.getValueNoCheck(e);if(t===iY.onnx.AttributeProto.AttributeType.INT&&e$.isLong(r))return e$.longToNumber(r);if(t===iY.onnx.AttributeProto.AttributeType.INTS){let e=Array(r.length);for(let t=0;t<r.length;t++){let n=r[t];e[t]=e$.longToNumber(n)}return e}if(t===iY.onnx.AttributeProto.AttributeType.TENSOR)return e instanceof iY.onnx.AttributeProto?eA.fromProto(r):eA.fromOrtTensor(r);if(t===iY.onnx.AttributeProto.AttributeType.TENSORS){if(e instanceof iY.onnx.AttributeProto)return r.map(e=>eA.fromProto(e));else if(e instanceof el.Attribute)return r.map(e=>eA.fromOrtTensor(e))}return t===iY.onnx.AttributeProto.AttributeType.STRING&&e instanceof iY.onnx.AttributeProto?ck(r):t===iY.onnx.AttributeProto.AttributeType.STRINGS&&e instanceof iY.onnx.AttributeProto?r.map(ck):r}static getValueNoCheck(e){return e instanceof iY.onnx.AttributeProto?this.getValueNoCheckFromOnnxFormat(e):this.getValueNoCheckFromOrtFormat(e)}static getValueNoCheckFromOnnxFormat(e){switch(e.type){case iY.onnx.AttributeProto.AttributeType.FLOAT:return e.f;case iY.onnx.AttributeProto.AttributeType.INT:return e.i;case iY.onnx.AttributeProto.AttributeType.STRING:return e.s;case iY.onnx.AttributeProto.AttributeType.TENSOR:return e.t;case iY.onnx.AttributeProto.AttributeType.GRAPH:return e.g;case iY.onnx.AttributeProto.AttributeType.FLOATS:return e.floats;case iY.onnx.AttributeProto.AttributeType.INTS:return e.ints;case iY.onnx.AttributeProto.AttributeType.STRINGS:return e.strings;case iY.onnx.AttributeProto.AttributeType.TENSORS:return e.tensors;case iY.onnx.AttributeProto.AttributeType.GRAPHS:return e.graphs;default:throw Error(`unsupported attribute type: ${iY.onnx.AttributeProto.AttributeType[e.type]}`)}}static getValueNoCheckFromOrtFormat(e){switch(e.type()){case ed.AttributeType.FLOAT:return e.f();case ed.AttributeType.INT:return e.i();case ed.AttributeType.STRING:return e.s();case ed.AttributeType.TENSOR:return e.t();case ed.AttributeType.GRAPH:return e.g();case ed.AttributeType.FLOATS:return e.floatsArray();case ed.AttributeType.INTS:{let t=[];for(let r=0;r<e.intsLength();r++)t.push(e.ints(r));return t}case ed.AttributeType.STRINGS:{let t=[];for(let r=0;r<e.stringsLength();r++)t.push(e.strings(r));return t}case ed.AttributeType.TENSORS:{let t=[];for(let r=0;r<e.tensorsLength();r++)t.push(e.tensors(r));return t}default:throw Error(`unsupported attribute type: ${ed.AttributeType[e.type()]}`)}}}}}),fn=dQ({"web/lib/onnxjs/graph.ts"(){"use strict";fr(),cu(),i1=d2(cE()),cj(),cA(),i2={from:(e,t)=>new i6(e,t)},i3=class{constructor(e){this._from=void 0,this._to=[],this.tensor=void 0,this.type=void 0,e&&(this.type=ew.tensorValueTypeFromProto(e.type.tensorType))}get from(){return this._from}get to(){return this._to}},i4=class{constructor(e,t){e instanceof i1.onnx.NodeProto?(this.name=e.name,this.opType=e.opType,this.attributes=new i0(e.attribute)):e instanceof eh.Node&&(this.name=t??e.name(),this.opType=e.opType(),this.attributes=new i0(ew.tensorAttributesFromORTFormat(e))),this.inputs=[],this.outputs=[],this.executeNode=!0}},i6=class{constructor(e,t){if(!e)throw TypeError("graph is empty");this.buildGraph(e),this.transformGraph(t),this.checkIsAcyclic()}getInputIndices(){return this._allInputIndices}getInputNames(){return this._allInputNames}getOutputIndices(){return this._allOutputIndices}getOutputNames(){return this._allOutputNames}getValues(){return this._allData}getNodes(){return this._nodes}buildGraph(e){if(e instanceof i1.onnx.GraphProto)this.buildGraphFromOnnxFormat(e);else if(e instanceof ep.Graph)this.buildGraphFromOrtFormat(e);else throw TypeError("Graph type is not supported.")}buildGraphFromOnnxFormat(e){let t=new Map;this._allData=[],this._allInputIndices=[],this._allInputNames=[],this._allOutputIndices=[],this._allOutputNames=[],this._nodes=[];let r=new Map;if(!e.input)throw Error("missing information in graph: input");let n=[];for(let r of e.input){if(t.has(r.name))throw Error(`duplicated input name: ${r.name}`);let e=this._allData.push(new i3(r))-1;t.set(r.name,e),n.push(r.name)}if(!e.initializer)throw Error("missing information in graph: initializer");for(let r of e.initializer){let e=t.get(r.name);if(void 0===e){let n=new i3;n.type={shape:{dims:ew.tensorDimsFromProto(r.dims)},tensorType:ew.tensorDataTypeFromProto(r.dataType)},e=this._allData.push(n)-1,t.set(r.name,e)}this._allData[e]._from=-1,this._allData[e].tensor=eA.fromProto(r)}for(let e=0;e<this._allData.length;e++)this._allData[e].tensor||(this._allInputIndices.push(e),this._allInputNames.push(n[e]));if(!e.output)throw Error("missing information in graph: output");for(let r of e.output){if(t.has(r.name))throw Error(`duplicated output name: ${r.name}`);let e=this._allData.push(new i3(r))-1;t.set(r.name,e),this._allOutputIndices.push(e),this._allOutputNames.push(r.name)}if(!e.node)throw Error("missing information in graph: node");for(let t of e.node){if(!t.name)for(let e=0;;e++){let n=`unnamed_${t.opType}_${e}`;if(!r.has(n)){t.name=n;break}}if(r.has(t.name))throw Error(`duplicated node name: ${t.name}`);let e=this._nodes.push(new i4(t))-1;r.set(t.name,e)}for(let r=0;r<this._nodes.length;r++){let n=this._nodes[r],i=e.node[r];if(!i.output)throw Error(`missing output for node: ${i.name}`);for(let e of i.output){let o=t.get(e);if(void 0===o&&(o=this._allData.push(new i3)-1,t.set(e,o)),n.outputs.push(o),void 0!==this._allData[o]._from)throw Error(`multiple nodes output to one data value: ${o}`);if(this._allData[o]._from=r,"Constant"===i.opType){if(!i.attribute||1!==i.attribute.length||!i.attribute[0].t)throw Error("missing attributes or missing tensor value in attributes for this Constant operator");if(!i.output||1!==i.output.length)throw Error("missing output or incorrect number of outputs for this Constant operator");n.outputs.pop(),n.executeNode=!1,this._allData[o]._from=-1,this._allData[o].tensor=eA.fromProto(i.attribute[0].t)}}}for(let r=0;r<this._nodes.length;r++){let n=this._nodes[r],i=e.node[r];if(!i.input)throw Error(`missing input for node: ${i.name}`);for(let e of i.input){let o=t.get(e);if(void 0===o){if(""===e&&(3===i.input.length||4===i.input.length)&&"Resize"===i.opType)continue;throw Error(`unrecognized input '${e}' for node: ${i.name}`)}n.inputs.push(o),this._allData[o]._to.push(r)}}return!0}buildGraphFromOrtFormat(e){let t=new Map;this._allData=[],this._allInputIndices=[],this._allInputNames=[],this._allOutputIndices=[],this._allOutputNames=[],this._nodes=[];let r=new Map,n=[];for(let r=0;r<e.inputsLength();r++){let i=e.inputs(r);if(t.has(i))throw Error(`duplicated input name: ${i}`);for(let r=0;r<e.nodeArgsLength();r++)if(e.nodeArgs(r)?.name()===i){let o=new i3;if(e.nodeArgs(r)?.type()?.valueType()!==em.TypeInfoValue.tensor_type)throw Error("Unexpected value type for the nodeArg.");let s=e.nodeArgs(r).type().value(new eg.TensorTypeAndShape),a=ew.tensorDataTypeFromProto(s.elemType()),u=s.shape(),l=[];for(let e=0;e<u.dimLength();e++)l.push(e$.longToNumber(u.dim(e).value().dimValue()));o.type={shape:{dims:l},tensorType:a};let d=this._allData.push(o)-1;t.set(i,d),n.push(i)}}for(let r=0;r<e.initializersLength();r++){let n=e.initializers(r),i=t.get(n.name());if(void 0===i){let e=new i3;e.type={shape:{dims:ew.tensorDimsFromORTFormat(n)},tensorType:ew.tensorDataTypeFromProto(n.dataType())},i=this._allData.push(e)-1,t.set(n.name(),i)}this._allData[i]._from=-1,this._allData[i].tensor=eA.fromOrtTensor(n)}for(let e=0;e<this._allData.length;e++)this._allData[e].tensor||(this._allInputIndices.push(e),this._allInputNames.push(n[e]));for(let r=0;r<e.outputsLength();r++){let n=e.outputs(r);if(t.has(n))throw Error(`duplicated output name: ${n}`);let i=this._allData.push(new i3)-1;t.set(n,i),this._allOutputIndices.push(i),this._allOutputNames.push(n)}if(!e.nodes)throw Error("missing information in graph: node");for(let t=0;t<e.nodesLength();t++){let n=e.nodes(t),i=n.name();if(!i)for(let e=0;i=`unnamed_${n.opType()}_${e}`,r.has(i);e++);if(r.has(i))throw Error(`duplicated node name: ${i}`);let o=this._nodes.push(new i4(n,i))-1;r.set(i,o)}for(let r=0;r<this._nodes.length;r++){let n=this._nodes[r],i=e.nodes(r);if(null==i)throw Error(`No node exists at index ${r}`);if(i?.outputsLength()===0)throw Error(`missing output for node: ${i.name}`);for(let e=0;e<i?.outputsLength();e++){let o=i?.outputs(e),s=t.get(o);if(void 0===s&&(s=this._allData.push(new i3)-1,t.set(o,s)),n.outputs.push(s),void 0!==this._allData[s]._from)throw Error(`multiple nodes output to one data value: ${s}`);if(this._allData[s]._from=r,"Constant"===i.opType()){if(1!==i.attributesLength()||!i.attributes(0).t())throw Error("missing attributes or missing tensor value in attributes for this Constant operator");if(1!==i.outputsLength())throw Error("missing output or incorrect number of outputs for this Constant operator");n.outputs.pop(),n.executeNode=!1,this._allData[s]._from=-1,this._allData[s].tensor=eA.fromOrtTensor(i.attributes(0).t())}}}for(let r=0;r<this._nodes.length;r++){let n=this._nodes[r],i=e.nodes(r);if(0===i.inputsLength())throw Error(`missing input for node: ${i.name}`);for(let e=0;e<i.inputsLength();e++){let o=i.inputs(e),s=t.get(o);if(void 0===s)throw Error(`unrecognized input '${o}' for node: ${i.name()}`);n.inputs.push(s),this._allData[s]._to.push(r)}}}checkIsAcyclic(){let e=new Set;this._allInputIndices.forEach(t=>{this._allData[t]._to.forEach(t=>{e.add(t)})});let t=Array.from(e),r=Array(this._nodes.length).fill("white");for(;t.length>0;){let e=t.pop();"gray"===r[e]?r[e]="black":(t.push(e),r[e]="gray",this._nodes[e].outputs.forEach(n=>{let i=this._allData[n];if(void 0!==i.tensor)throw Error("node outputs should not be initialized");if(i._from!==e)throw Error("from property of the Value object doesn't match index of Node being processed");i._to.forEach(e=>{if("gray"===r[e])throw Error("model graph is cyclic");"white"===r[e]&&t.push(e)})}))}}transformGraph(e){this.removeAllIdentityNodes(),this.removeAllDropoutNodes(),this.fuseConvActivationNodes(),e&&e.transformGraph(this),this.finalizeGraph()}finalizeGraph(){let e=0,t=[this._nodes.length,0],r=0;for(let e=0;e<this._nodes.length;e++)t[e]=r,this._nodes[e].executeNode?(r!==e&&(this._nodes[r]=this._nodes[e]),r++):this._nodes[e].outputs.forEach(e=>{this._allData[e]._from=-2});this._nodes.splice(r,this._nodes.length-r);for(let e=0;e<this._allData.length;e++){let r=this._allData[e];void 0!==r._from&&-1!==r._from&&-2!==r._from&&(r._from=t[r._from]);for(let e=0;e<r._to.length;e++)if(r._to[e]>=0)r._to[e]=t[r._to[e]];else throw Error("Trying to update a removed node")}e=0;for(let t=0;t<this._allData.length;t++){if(-2===this._allData[t].from&&-1===this._allOutputIndices.indexOf(t+e)){e++,this._allData.splice(t,1),t--;continue}if(e>0){let r=-1;void 0!==this._allData[t].from&&-1!==this._allData[t].from?-1!==(r=this._nodes[this._allData[t].from].outputs.indexOf(t+e))&&(this._nodes[this._allData[t].from].outputs[r]=t):-1!==(r=this._allInputIndices.indexOf(t+e))&&(this._allInputIndices[r]=t),this._allData[t].to.forEach(n=>{-1!==(r=this._nodes[n].inputs.indexOf(t+e))&&(this._nodes[n].inputs[r]=t)}),0===this._allData[t].to.length&&-1!==(r=this._allOutputIndices.indexOf(t+e))&&(this._allOutputIndices[r]=t)}}}deleteNode(e){let t=this._nodes[e];if(t.outputs.length>1){for(let e=1;e<t.outputs.length;e++)if(this._allData[t.outputs[e]].to.length>0)throw Error("Node deletion with more than one output connected to other nodes is not supported. ")}t.executeNode=!1;let r=t.inputs[0],n=t.outputs[0],i=this._allData[n].to;for(let r=0;r<t.inputs.length;r++){let n=this._allData[t.inputs[r]].to.indexOf(e);if(-1===n)throw Error("The Value object doesn't have the current Node in it's 'to' property ");this._allData[t.inputs[r]].to.splice(n,1)}this._allData[n]._to=[];let o=this._allOutputIndices.indexOf(n);if(-1!==o&&(this._allOutputIndices[o]=r),i&&i.length>0)for(let e of i){let t=this._nodes[e].inputs.indexOf(n);if(-1===t)throw Error("The Node object doesn't have the output Value in it's 'inputs' property ");this._nodes[e].inputs[t]=r,this._allData[r].to.push(e)}}removeAllDropoutNodes(){let e=0;for(let t of this._nodes){if("Dropout"===t.opType){if(1!==t.inputs.length)throw Error("Dropout nodes should only contain one input. ");if(1!==t.outputs.length&&2!==t.outputs.length)throw Error("Dropout nodes should contain either 1 or 2 output(s)");if(2===t.outputs.length&&0!==this._allData[t.outputs[1]]._to.length)throw Error("Dropout nodes's second output should not be referenced by other nodes");this.deleteNode(e)}e++}}removeAllIdentityNodes(){let e=0;for(let t of this._nodes)"Identity"===t.opType&&this.deleteNode(e),e++}isActivation(e){switch(e.opType){case"Relu":case"Sigmoid":case"Clip":return!0;default:return!1}}fuseConvActivationNodes(){for(let e of this._nodes)if("Conv"===e.opType){let t=this._allData[e.outputs[0]]._to;if(1===t.length&&this.isActivation(this._nodes[t[0]])){let r=this._nodes[t[0]];if("Clip"===r.opType)if(1===r.inputs.length)try{e.attributes.set("activation_params","floats",[r.attributes.getFloat("min"),r.attributes.getFloat("max")])}catch{e.attributes.set("activation_params","floats",[eO,eE])}else{if(!(r.inputs.length>=3)||void 0===this._allData[r.inputs[1]].tensor||void 0===this._allData[r.inputs[2]].tensor)continue;e.attributes.set("activation_params","floats",[this._allData[r.inputs[1]].tensor.floatData[0],this._allData[r.inputs[2]].tensor.floatData[0]])}e.attributes.set("activation","string",r.opType),this.deleteNode(t[0])}}}}}}),fi=dQ({"web/lib/onnxjs/model.ts"(){"use strict";i8=d2(pC()),fn(),cu(),i5=d2(cE()),cA(),i7=class{load(e,t,r){let n;if(!r)try{this.loadFromOnnxFormat(e,t);return}catch(e){if(void 0!==r)throw e;n=e}try{this.loadFromOrtFormat(e,t)}catch(e){if(void 0!==r)throw e;throw Error(`Failed to load model as ONNX format: ${n}
as ORT format: ${e}`)}}loadFromOnnxFormat(e,t){let r=i5.onnx.ModelProto.decode(e);if(3>e$.longToNumber(r.irVersion))throw Error("only support ONNX model with IR_VERSION>=3");this._opsets=r.opsetImport.map(e=>({domain:e.domain,version:e$.longToNumber(e.version)})),this._graph=i2.from(r.graph,t)}loadFromOrtFormat(e,t){let r=new i8.ByteBuffer(e),n=ec.InferenceSession.getRootAsInferenceSession(r).model();if(3>e$.longToNumber(n.irVersion()))throw Error("only support ONNX model with IR_VERSION>=3");this._opsets=[];for(let e=0;e<n.opsetImportLength();e++){let t=n.opsetImport(e);this._opsets.push({domain:t?.domain(),version:e$.longToNumber(t.version())})}this._graph=i2.from(n.graph(),t)}get graph(){return this._graph}get opsets(){return this._opsets}}}}),fo=dQ({"web/lib/onnxjs/session.ts"(){"use strict";fe(),ft(),pm(),fi(),i9=class{constructor(e={}){this._initialized=!1,this.backendHint=e.backendHint,this.profiler=U.create(e.profiler),this.context={profiler:this.profiler,graphInputTypes:[],graphInputDims:[]}}get inputNames(){return this._model.graph.getInputNames()}get outputNames(){return this._model.graph.getOutputNames()}startProfiling(){this.profiler.start()}endProfiling(){this.profiler.stop()}async loadModel(e,t,r){await this.profiler.event("session","Session.loadModel",async()=>{let n=await h7(this.backendHint);if(this.sessionHandler=n.createSessionHandler(this.context),this._model=new i7,"string"==typeof e){let t=e.endsWith(".ort");{let r=await fetch(e),n=await r.arrayBuffer();this.initialize(new Uint8Array(n),t)}}else if(ArrayBuffer.isView(e))this.initialize(e);else{let n=new Uint8Array(e,t||0,r||e.byteLength);this.initialize(n)}})}initialize(e,t){if(this._initialized)throw Error("already initialized");this.profiler.event("session","Session.initialize",()=>{let r=this.sessionHandler.transformGraph?this.sessionHandler:void 0;this._model.load(e,r,t),this.sessionHandler.onGraphInitialized&&this.sessionHandler.onGraphInitialized(this._model.graph),this.initializeOps(this._model.graph),this._executionPlan=new iQ(this._model.graph,this._ops,this.profiler)}),this._initialized=!0}async run(e){if(!this._initialized)throw Error("session not initialized yet");return this.profiler.event("session","Session.run",async()=>{let t=this.normalizeAndValidateInputs(e),r=await this._executionPlan.execute(this.sessionHandler,t);return this.createOutput(r)})}normalizeAndValidateInputs(e){let t=this._model.graph.getInputNames();if(Array.isArray(e)){if(e.length!==t.length)throw Error(`incorrect input array length: expected ${t.length} but got ${e.length}`)}else{if(e.size!==t.length)throw Error(`incorrect input map size: expected ${t.length} but got ${e.size}`);let r=Array(e.size),n=0;for(let i=0;i<t.length;++i){let o=e.get(t[i]);if(!o)throw Error(`missing input tensor for: '${name}'`);r[n++]=o}e=r}if(this.context.graphInputTypes&&0!==this.context.graphInputTypes.length&&this.context.graphInputDims&&0!==this.context.graphInputDims.length)this.validateInputTensorDims(this.context.graphInputDims,e,!1);else{let t=this._model.graph.getInputIndices(),r=this._model.graph.getValues(),n=Array(t.length);for(let i=0;i<t.length;++i){let o=r[t[i]];n[i]=o.type.shape.dims,this.context.graphInputTypes.push(o.type.tensorType),this.context.graphInputDims.push(e[i].dims)}this.validateInputTensorDims(n,e,!0)}return this.validateInputTensorTypes(this.context.graphInputTypes,e),e}validateInputTensorTypes(e,t){for(let r=0;r<t.length;r++){let n=e[r],i=t[r].type;if(n!==i)throw Error(`input tensor[${r}] check failed: expected type '${n}' but got ${i}`)}}validateInputTensorDims(e,t,r){for(let n=0;n<t.length;n++){let i=e[n],o=t[n].dims;if(!this.compareTensorDims(i,o,r))throw Error(`input tensor[${n}] check failed: expected shape '[${i.join(",")}]' but got [${o.join(",")}]`)}}compareTensorDims(e,t,r){if(e.length!==t.length)return!1;for(let n=0;n<e.length;++n)if(e[n]!==t[n]&&(!r||0!==e[n]))return!1;return!0}createOutput(e){let t=this._model.graph.getOutputNames();if(e.length!==t.length)throw Error("expected number of outputs do not match number of generated outputs");let r=new Map;for(let n=0;n<t.length;++n)r.set(t[n],e[n]);return r}initializeOps(e){let t=e.getNodes();this._ops=Array(t.length);for(let r=0;r<t.length;r++)this._ops[r]=this.sessionHandler.resolve(t[r],this._model.opsets,e)}}}}),fs=dQ({"web/lib/onnxjs/session-handler-inference.ts"(){"use strict";ph(),cj(),oe=class{constructor(e){this.session=e,this.inputNames=this.session.inputNames,this.outputNames=this.session.outputNames}get inputMetadata(){throw Error("Getting model metadata is not supported in webgl backend.")}get outputMetadata(){throw Error("Getting model metadata is not supported in webgl backend.")}async dispose(){}async run(e,t,r){let n=new Map;for(let t in e)if(Object.hasOwnProperty.call(e,t)){let r=e[t];n.set(t,new eA(r.dims,r.type,void 0,void 0,r.data))}let i=await this.session.run(n),o={};return i.forEach((e,t)=>{o[t]=new I(e.type,e.data,e.dims)}),o}startProfiling(){this.session.startProfiling()}endProfiling(){this.session.endProfiling()}}}}),fa={};d0(fa,{onnxjsBackend:()=>ot});var fu=dQ({"web/lib/backend-onnxjs.ts"(){"use strict";fo(),fs(),ot=new class{async init(){}async createInferenceSessionHandler(e,t){let r=new i9(t);return await r.loadModel(e),new oe(r)}}}}),fl=dQ({"web/lib/wasm/wasm-utils-env.ts"(){"use strict";or=!1}}),fd={};d0(fd,{default:()=>oi});var fp=dQ({"web/lib/wasm/proxy-worker/main.ts"(){"use strict";g$(),fh(),fc(),(on=globalThis.self?.name==="ort-wasm-proxy-worker")&&(self.onmessage=e=>{let{type:t,in:r}=e.data;try{switch(t){case"init-wasm":ov(r.wasm).then(()=>{dd(r).then(()=>{postMessage({type:t})},e=>{postMessage({type:t,err:e})})},e=>{postMessage({type:t,err:e})});break;case"init-ep":{let{epName:e,env:n}=r;dp(n,e).then(()=>{postMessage({type:t})},e=>{postMessage({type:t,err:e})});break}case"copy-from":{let{buffer:e}=r,n=df(e);postMessage({type:t,out:n});break}case"create":{let{model:e,options:n}=r;dg(e,n).then(e=>{postMessage({type:t,out:e})},e=>{postMessage({type:t,err:e})});break}case"release":dm(r),postMessage({type:t});break;case"run":{let{sessionId:e,inputIndices:n,inputs:i,outputIndices:o,options:s}=r;dy(e,n,i,o,Array(o.length).fill(null),s).then(e=>{e.some(e=>"cpu"!==e[3])?postMessage({type:t,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:t,out:e},dv([...i,...e]))},e=>{postMessage({type:t,err:e})});break}case"end-profiling":d_(r),postMessage({type:t})}}catch(e){postMessage({type:t,err:e})}}),oi=on?null:e=>new Worker(e??oa,{type:"module",name:"ort-wasm-proxy-worker"})}}),fc=dQ({"web/lib/wasm/wasm-utils-import.ts"(){"use strict";fl(),oo=or||"u"<typeof location?void 0:location.origin,os=import.meta.url>"file:"&&import.meta.url<"file;",oa=(()=>{if(!or){if(os){let e=URL;return new URL(new e("ort.all.mjs",import.meta.url).href,oo).href}return import.meta.url}})(),ou=()=>{if(oa&&!oa.startsWith("blob:"))return oa.substring(0,oa.lastIndexOf("/")+1)},ol=(e,t)=>{try{let r=t??oa;return(r?new URL(e,r):new URL(e)).origin===oo}catch{return!1}},od=async e=>{let t=await fetch(e,{credentials:"same-origin"}),r=await t.blob();return URL.createObjectURL(r)},op=async e=>(await import(e)).default,oc=(fp(),d3(fd)).default,oh=async()=>{if(!oa)throw Error("Failed to load proxy worker: cannot determine the script source URL.");if(ol(oa))return[void 0,oc()];let e=await od(oa);return[e,oc(e)]},of=void 0,og=async(e,t,r,n)=>{let i=of&&!(e||t);if(i)if(oa)i=ol(oa)||n&&!r;else if(n&&!r)i=!0;else throw Error("cannot determine the script source URL.");if(i)return[void 0,of];{let n="ort-wasm-simd-threaded.jsep.mjs",i=e??((e,t)=>{let r=t??oa;try{return(r?new URL(e,r):new URL(e)).href}catch{return}})(n,t),o=!or&&r&&i&&!ol(i,t),s=o?await od(i):i??`${t??"./"}${n}`;return[o?s:void 0,await op(s)]}}}}),fh=dQ({"web/lib/wasm/wasm-factory.ts"(){"use strict";fc(),ob=!1,oy=!1,o_=!1,ov=async e=>{if(ob)return Promise.resolve();if(oy)throw Error("multiple calls to 'initializeWebAssembly()' detected.");if(o_)throw Error("previous call to 'initializeWebAssembly()' failed.");oy=!0;let t=e.initTimeout,r=e.numThreads;if(!1===e.simd);else if("relaxed"===e.simd){if(!(()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,19,1,17,0,65,1,253,15,65,2,253,15,65,3,253,15,253,147,2,11]))}catch{return!1}})())throw Error("Relaxed WebAssembly SIMD is not supported in the current environment.")}else if(!(()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}})())throw Error("WebAssembly SIMD is not supported in the current environment.");let n=(()=>{if("u"<typeof SharedArrayBuffer)return!1;try{return"u">typeof MessageChannel&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}})();r>1&&!n&&("u">typeof self&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let i=e.wasmPaths,o="string"==typeof i?i:void 0,s=i?.mjs,a=s?.href??s,u=i?.wasm,l=u?.href??u,d=e.wasmBinary,[p,c]=await og(a,o,r>1,!!d||!!l),h=!1,f=[];if(t>0&&f.push(new Promise(e=>{setTimeout(()=>{h=!0,e()},t)})),f.push(new Promise((e,t)=>{let n={numThreads:r};if(d)n.wasmBinary=d,n.locateFile=e=>e;else if(l||o)n.locateFile=e=>l??o+e;else if(a&&0!==a.indexOf("blob:"))n.locateFile=e=>new URL(e,a).href;else if(p){let e=ou();e&&(n.locateFile=t=>e+t)}c(n).then(t=>{oy=!1,ob=!0,om=t,e(),p&&URL.revokeObjectURL(p)},e=>{oy=!1,o_=!0,t(e)})})),await Promise.race(f),h)throw Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},ox=()=>{if(ob&&om)return om;throw Error("WebAssembly is not initialized yet.")}}}),ff=dQ({"web/lib/wasm/wasm-utils.ts"(){"use strict";fh(),ow=(e,t)=>{let r=ox(),n=r.lengthBytesUTF8(e)+1,i=r._malloc(n);return r.stringToUTF8(e,i,n),t.push(i),i},o$=(e,t,r,n)=>{if("object"==typeof e&&null!==e)if(r.has(e))throw Error("Circular reference in options");else r.add(e);Object.entries(e).forEach(([e,i])=>{let o=t?t+e:e;if("object"==typeof i)o$(i,o+".",r,n);else if("string"==typeof i||"number"==typeof i)n(o,i.toString());else if("boolean"==typeof i)n(o,i?"1":"0");else throw Error(`Can't handle extra config type: ${typeof i}`)})},oT=e=>{let t=ox(),r=t.stackSave();try{let r=t.PTR_SIZE,n=t.stackAlloc(2*r);t._OrtGetLastError(n,n+r);let i=Number(t.getValue(n,4===r?"i32":"i64")),o=t.getValue(n+r,"*"),s=o?t.UTF8ToString(o):"";throw Error(`${e} ERROR_CODE: ${i}, ERROR_MESSAGE: ${s}`)}finally{t.stackRestore(r)}}}}),fg=dQ({"web/lib/wasm/run-options.ts"(){"use strict";fh(),ff(),oI=e=>{let t=ox(),r=0,n=[],i=e||{};try{if(e?.logSeverityLevel===void 0)i.logSeverityLevel=2;else if("number"!=typeof e.logSeverityLevel||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw Error(`log severity level is not valid: ${e.logSeverityLevel}`);if(e?.logVerbosityLevel===void 0)i.logVerbosityLevel=0;else if("number"!=typeof e.logVerbosityLevel||!Number.isInteger(e.logVerbosityLevel))throw Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);e?.terminate===void 0&&(i.terminate=!1);let o=0;return e?.tag!==void 0&&(o=ow(e.tag,n)),r=t._OrtCreateRunOptions(i.logSeverityLevel,i.logVerbosityLevel,!!i.terminate,o),0===r&&oT("Can't create run options."),e?.extra!==void 0&&o$(e.extra,"",new WeakSet,(e,i)=>{let o=ow(e,n),s=ow(i,n);0!==t._OrtAddRunConfigEntry(r,o,s)&&oT(`Can't set a run config entry: ${e} - ${i}.`)}),[r,n]}catch(e){throw 0!==r&&t._OrtReleaseRunOptions(r),n.forEach(e=>t._free(e)),e}}}}),fm=dQ({"web/lib/wasm/session-options.ts"(){"use strict";fh(),ff(),oS=(e,t,r,n)=>{let i=ow(t,n),o=ow(r,n);0!==ox()._OrtAddSessionConfigEntry(e,i,o)&&oT(`Can't set a session config entry: ${t} - ${r}.`)},oO=async(e,t,r)=>{for(let n of t.executionProviders){let t="string"==typeof n?n:n.name,i=[];switch(t){case"webnn":if(t="WEBNN",oS(e,"session.disable_quant_qdq","1",r),oS(e,"session.disable_qdq_constant_folding","1",r),"string"!=typeof n){let t=n?.deviceType;t&&oS(e,"deviceType",t,r)}break;case"webgpu":if(t="JS","string"!=typeof n&&n?.preferredLayout){if("NCHW"!==n.preferredLayout&&"NHWC"!==n.preferredLayout)throw Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${n.preferredLayout}`);oS(e,"preferredLayout",n.preferredLayout,r)}break;case"wasm":case"cpu":continue;default:throw Error(`not supported execution provider: ${t}`)}let o=ow(t,r),s=i.length,a=0,u=0;if(s>0){a=ox()._malloc(s*ox().PTR_SIZE),r.push(a),u=ox()._malloc(s*ox().PTR_SIZE),r.push(u);for(let e=0;e<s;e++)ox().setValue(a+e*ox().PTR_SIZE,i[e][0],"*"),ox().setValue(u+e*ox().PTR_SIZE,i[e][1],"*")}await ox()._OrtAppendExecutionProvider(e,o,a,u,s)!==0&&oT(`Can't append execution provider: ${t}.`)}},oE=async e=>{let t,r=ox(),n=0,i=[],o=e||{};o.extra||(o.extra={}),o.extra.session||(o.extra.session={}),(t=o.extra.session).use_ort_model_bytes_directly||(t.use_ort_model_bytes_directly="1"),o.executionProviders&&o.executionProviders.some(e=>("string"==typeof e?e:e.name)==="webgpu")&&(o.enableMemPattern=!1);try{let e=(e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"layout":return 3;case"all":return 99;default:throw Error(`unsupported graph optimization level: ${e}`)}})(o.graphOptimizationLevel??"all"),t=(e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw Error(`unsupported execution mode: ${e}`)}})(o.executionMode??"sequential"),s="string"==typeof o.logId?ow(o.logId,i):0,a=o.logSeverityLevel??2;if(!Number.isInteger(a)||a<0||a>4)throw Error(`log severity level is not valid: ${a}`);let u=o.logVerbosityLevel??0;if(!Number.isInteger(u)||u<0||u>4)throw Error(`log verbosity level is not valid: ${u}`);let l="string"==typeof o.optimizedModelFilePath?ow(o.optimizedModelFilePath,i):0;if(n=r._OrtCreateSessionOptions(e,!!o.enableCpuMemArena,!!o.enableMemPattern,t,!!o.enableProfiling,0,s,a,u,l),0===n&&oT("Can't create session options."),o.executionProviders&&await oO(n,o,i),void 0!==o.enableGraphCapture){if("boolean"!=typeof o.enableGraphCapture)throw Error(`enableGraphCapture must be a boolean value: ${o.enableGraphCapture}`);oS(n,"enableGraphCapture",o.enableGraphCapture.toString(),i)}if(o.freeDimensionOverrides)for(let[e,t]of Object.entries(o.freeDimensionOverrides)){if("string"!=typeof e)throw Error(`free dimension override name must be a string: ${e}`);if("number"!=typeof t||!Number.isInteger(t)||t<0)throw Error(`free dimension override value must be a non-negative integer: ${t}`);let o=ow(e,i);0!==r._OrtAddFreeDimensionOverride(n,o,t)&&oT(`Can't set a free dimension override: ${e} - ${t}.`)}return void 0!==o.extra&&o$(o.extra,"",new WeakSet,(e,t)=>{oS(n,e,t,i)}),[n,i]}catch(e){throw 0!==n&&0!==r._OrtReleaseSessionOptions(n)&&oT("Can't release session options."),i.forEach(e=>r._free(e)),e}}}}),fb=dQ({"web/lib/wasm/wasm-common.ts"(){"use strict";oP=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw Error(`unsupported data type: ${e}`)}},ok=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw Error(`unsupported data type: ${e}`)}},oA=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],n="number"==typeof t?t:t.reduce((e,t)=>e*t,1);return r>0?Math.ceil(n*r):void 0},oD=e=>{switch(e){case"float16":return"u">typeof Float16Array?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":case"bool":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw Error(`unsupported type: ${e}`)}},oz=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw Error(`unsupported logging level: ${e}`)}},oC=e=>"float32"===e||"float16"===e||"int32"===e||"int64"===e||"uint32"===e||"uint8"===e||"bool"===e||"uint4"===e||"int4"===e,oN=e=>"float32"===e||"float16"===e||"int32"===e||"int64"===e||"uint32"===e||"uint64"===e||"int8"===e||"uint8"===e||"bool"===e||"uint4"===e||"int4"===e,oj=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw Error(`unsupported data location: ${e}`)}}}}),fy=dQ({"web/lib/wasm/wasm-utils-load-file.ts"(){"use strict";fl(),oR=async e=>{if("string"==typeof e)if(or)try{let{readFile:t}=dJ("node:fs/promises");return new Uint8Array(await t(e))}catch(t){if("ERR_FS_FILE_TOO_LARGE"===t.code){let{createReadStream:t}=dJ("node:fs"),r=t(e),n=[];for await(let e of r)n.push(e);return new Uint8Array(Buffer.concat(n))}throw t}else{let t=await fetch(e);if(!t.ok)throw Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),n=r?parseInt(r,10):0;if(n<0x40000000)return new Uint8Array(await t.arrayBuffer());{let r;if(!t.body)throw Error(`failed to load external data file: ${e}, no response body.`);let i=t.body.getReader();try{r=new ArrayBuffer(n)}catch(e){if(e instanceof RangeError){let e=Math.ceil(n/65536);r=new WebAssembly.Memory({initial:e,maximum:e}).buffer}else throw e}let o=0;for(;;){let{done:e,value:t}=await i.read();if(e)break;let n=t.byteLength;new Uint8Array(r,o,n).set(t),o+=n}return new Uint8Array(r,0,n)}}return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e)}}}),f_=dQ({"web/lib/wasm/jsep/log.ts"(){"use strict";fb(),oB=["V","I","W","E","F"],oL=(e,t)=>{oM=e,oF=t},oV=(...e)=>{oF&&((e,t)=>{var r;let n=oz(e);n>=oz(oM)&&(r="function"==typeof t?t():t,console.log(`[${oB[n]},${(new Date).toISOString()}]${r}`))})(...e)}}}),fv=dQ({"web/lib/wasm/jsep/util.ts"(){"use strict";oU=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},oq=class{static calcShape(e,t,r=!1){let n=e.length,i=t.length;if(0===n)return t;if(0===i)return e;let o=Math.max(e.length,t.length),s=Array(o);if(r){if(n<2||i<2)return;let r=oU.calcMatMulShape([e[n-2],e[n-1]],[t[i-2],t[i-1]]);if(void 0===r)return;[s[o-2],s[o-1]]=r}for(let a=r?3:1;a<=o;a++){let r=n-a<0?1:e[n-a],u=i-a<0?1:t[i-a];if(r!==u&&r>1&&u>1)return;let l=Math.max(r,u);if(r&&u)s[o-a]=Math.max(r,u);else{if(l>1)return;s[o-a]=0}}return s}static isValidBroadcast(e,t){let r=e.length,n=t.length;if(r>n)return!1;for(let i=1;i<=r;i++)if(1!==e[r-i]&&e[r-i]!==t[n-i])return!1;return!0}},oG=class e{static size(t){return e.getSizeFromDimensionRange(t,0,t.length)}static convertShape(e,t=4){let r=e.length;if(0===r)return[];let n=Array(r),i=r-1;for(;i>=0;){if(e[i]%t==0){n[i]=e[i]/t;break}if(t%e[i]!=0)throw Error("cannot convert shape");n[i]=1,t/=e[i],i--}for(i--;i>=0;i--)n[i]=e[i];return n}static sizeFromDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(e,t,r){let n=1;for(let i=t;i<r;i++){if(e[i]<0)throw Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");n*=Number(e[i])}return n}static computeStrides(e){let t=e.length;if(0===t)return[];if(1===t)return[1];let r=Array(t);r[t-1]=1,r[t-2]=e[t-1];for(let n=t-3;n>=0;--n)r[n]=r[n+1]*e[n+1];return r}static normalizeAxis(e,t){if(e<-t&&e>=t)throw Error("unsupported axis for this operation.");return e<0?e+t:e}static normalizeAxes(e,t){return e.map(r=>this.normalizeAxis(r,t??e.length))}static sortBasedOnPerm(e,t){return t?t.map(t=>e[t]):e.slice().reverse()}static padShape(e,t){let r=e.length;return e.map((e,n)=>e+t[n]+t[n+r])}static areEqual(e,t){return e.length===t.length&&e.every((e,r)=>e===t[r])}},oH=class e{static adjustPoolAttributes(e,t,r,n,i,o){if(!e&&r.length!==t.length-2)throw Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(e)for(let e=0;e<t.length-2;e++)e>=r.length?r.push(t[e+2]):r[e]=t[e+2];for(let e=0;e<r.length;e++)if(e<n.length){if(n[e]<0)throw Error("strides should be greater than or equal to 1")}else n.push(1);for(let e=0;e<r.length;e++)if(e<i.length){if(i[e]<0)throw Error("dilations should be greater than or equal to 1")}else i.push(1);for(let e=0;e<2*r.length;e++)if(e<o.length){if(o[e]<0)throw Error("pad should be greater than or equal to 1")}else o.push(0);for(let e=0;e<r.length;e++){if(r[e]<=0)throw Error("kernel shapes need to be greater than 0");if(o[e]>=r[e]||o[e+r.length]>=r[e])throw Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,n,i,o,s,a){if(a){if(o.length!==2*(t.length-2))throw Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw Error("length of strides should be the length of data dimensions");if(i.length!==t.length-2)throw Error("length of kernel shapes should be the length of data dimensions");for(let u=0;u<t.length-2;u++)e.adjustPadAndReturnShape(t[u+(s?1:2)],r[u],n[u],i[u],o,u,u+t.length-2,a)}}static computePoolOutputShape(t,r,n,i,o,s,a,u=0){if(r.length<=0)throw Error("input shape must be of size greater than 0");let l=[r[0],r[1]];return e.computeShapeHelper(t,r,l,n,i,o,s,a,u),l}static computeConvOutputShape(t,r,n,i,o,s,a){if(t.length<=0||r.length<=0)throw Error("invalid input tensor dims or invalid filter tensor dims");let u=[t[0],r[0]];return e.computeShapeHelper(!1,t,u,n,i,o,s,a),u}static computeShapeHelper(t,r,n,i,o,s,a,u,l=0){if(t)for(let e=0;e<r.length-2;e++)n.push(1);else for(let t=0;t<r.length-2;t++)n.push(e.adjustPadAndReturnShape(r[t+2],i[t],o[t],s[t],a,t,t+r.length-2,u,l))}static computeOutputSize(e,t,r,n,i){let o=Math.floor(e/t)+1;return 1===i&&((o=Math.ceil(e/t)+1)-1)*t>=r+n&&(o-=1),o}static adjustPadAndReturnShape(t,r,n,i,o,s,a,u,l=0){let d=n*(i-1)+1;if(!u||"NOTSET"===u)return e.computeOutputSize(t+o[s]+o[a]-d,r,t,o[s],l);switch(u){case"VALID":return o[s]=0,o[a]=0,e.computeOutputSize(t-d,r,t,0,l);case"SAME_LOWER":case"SAME_UPPER":if(1!==n)throw Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let n=(Math.floor((t+r-1)/r)-1)*r+i-t;return o[s]="SAME_LOWER"===u?Math.floor((n+1)/2):Math.floor(n/2),o[a]=n-o[s],e.computeOutputSize(t+o[s]+o[a]-d,r,t,o[s],l)}default:throw Error("Unsupported AutoPad type")}}},oW=class{static getShapeOfGemmResult(e,t,r,n,i){let o,s,a;if(2!==e.length||2!==r.length)throw Error("shape need to be of size 2");t?(o=e[1],s=e[0]):(o=e[0],s=e[1]);let u=-1;if(n?(a=r[0],u=1):(a=r[1],u=0),r[u]!==s)throw Error("dimension mismatch");if(o<=0||a<=0||s<=0)throw Error("invalid shape specified");if(i&&!oq.isValidBroadcast(i,[o,a]))throw Error("gemm: invalid bias shape for broadcast");return[o,a,s]}},oK=-34028234663852886e22,oX=34028234663852886e22}}),fx=dQ({"web/lib/wasm/jsep/tensor-view.ts"(){"use strict";fb(),oZ=(e,t)=>new(oD(t))(e)}}),fw=dQ({"web/lib/wasm/jsep/webnn/tensor-manager.ts"(){"use strict";fb(),f_(),oJ=new Map([["float32",32],["float16",16],["int32",32],["uint32",32],["int64",64],["uint64",64],["int8",8],["uint8",8],["int4",4],["uint4",4]]),oQ=(e,t)=>{if("int32"===t)return e;if(e.byteLength%4!=0)throw Error("Invalid Uint8Array length - must be a multiple of 4 (int32).");let r=e.byteLength/4,n=new Int32Array(e.buffer,e.byteOffset,r);switch(t){case"int64":return new Uint8Array(BigInt64Array.from(n,BigInt).buffer);case"uint64":if(n.some(e=>e<0))throw Error("Can not convert int32 data to uin64 - negative value found.");return new Uint8Array(BigUint64Array.from(n,BigInt).buffer);case"int8":if(n.some(e=>e<-128||e>127))throw Error("Can not convert int32 data to int8 - value out of range.");return new Uint8Array(Int8Array.from(n,Number).buffer);case"uint8":if(n.some(e=>e<0||e>255))throw Error("Can not convert int32 data to uint8 - value out of range.");return Uint8Array.from(n,Number);case"uint32":if(n.some(e=>e<0))throw Error("Can not convert int32 data to uint32 - negative value found.");return new Uint8Array(Uint32Array.from(n,Number).buffer);default:throw Error(`Unsupported data conversion from 'int32' to ${t}`)}},oY=1,o0=()=>oY++,o1=new Map([["int8","int32"],["uint8","int32"],["uint32","int32"],["int64","int32"]]),o2=(e,t)=>{let r=oJ.get(e);if(!r)throw Error(`WebNN backend does not support data type: ${e}`);return t.length>0?Math.ceil(t.reduce((e,t)=>e*t)*r/8):0},o3=class{constructor(e){this.isDataConverted=!1;let{sessionId:t,context:r,tensor:n,dataType:i,shape:o,fallbackDataType:s}=e;this.sessionId=t,this.mlContext=r,this.mlTensor=n,this.dataType=i,this.tensorShape=o,this.fallbackDataType=s}get tensor(){return this.mlTensor}get type(){return this.dataType}get fallbackType(){return this.fallbackDataType}get shape(){return this.tensorShape}get byteLength(){return o2(this.dataType,this.tensorShape)}destroy(){oV("verbose",()=>"[WebNN] TensorWrapper.destroy"),this.mlTensor.destroy()}write(e){this.mlContext.writeTensor(this.mlTensor,e)}async read(e){if(!this.fallbackDataType)return e?this.mlContext.readTensor(this.mlTensor,e):this.mlContext.readTensor(this.mlTensor);{let t=oQ(new Uint8Array(await this.mlContext.readTensor(this.mlTensor)),this.dataType);return e?void(e instanceof ArrayBuffer?new Uint8Array(e):new Uint8Array(e.buffer,e.byteOffset,e.byteLength)).set(t):new Uint8Array(t).buffer}}canReuseTensor(e,t,r){return this.mlContext===e&&this.dataType===t&&this.tensorShape.length===r.length&&this.tensorShape.every((e,t)=>e===r[t])}setIsDataConverted(e){this.isDataConverted=e}},o4=class{constructor(e,t){this.tensorManager=e,this.wrapper=t}get tensorWrapper(){return this.wrapper}releaseTensor(){this.tensorWrapper&&(this.tensorManager.releaseTensor(this.tensorWrapper),this.wrapper=void 0)}async ensureTensor(e,t,r,n){let i,o=this.tensorManager.getMLContext(e),s=this.tensorManager.getMLOpSupportLimits(e);if(!s?.input.dataTypes.includes(t)){if(!(i=o1.get(t))||!s?.input.dataTypes.includes(i))throw Error(`WebNN backend does not support data type: ${t}`);oV("verbose",()=>`[WebNN] TensorIdTracker.ensureTensor: fallback dataType from ${t} to ${i}`)}if(this.wrapper)if(this.wrapper.canReuseTensor(o,t,r))return this.wrapper.tensor;else{if(n){if(this.wrapper.byteLength!==o2(t,r))throw Error("Unable to copy data to tensor with different size.");this.activeUpload=new Uint8Array(await this.wrapper.read())}this.tensorManager.releaseTensor(this.wrapper)}let a="u"<typeof MLTensorUsage?void 0:MLTensorUsage.READ|MLTensorUsage.WRITE;return this.wrapper=await this.tensorManager.getCachedTensor(e,t,r,a,!0,!0,i),n&&this.activeUpload&&(this.wrapper.write(this.activeUpload),this.activeUpload=void 0),this.wrapper.tensor}upload(e){let t=e;if(this.wrapper){if(this.wrapper.fallbackType)if("int32"===this.wrapper.fallbackType)t=((e,t)=>{if("int32"===t)return e;let r=oJ.get(t);if(!r)throw Error(`WebNN backend does not support data type: ${t}`);let n=r/8;if(e.byteLength%n!=0)throw Error(`Invalid Uint8Array length - must be a multiple of ${n}.`);let i=e.byteLength/n,o=new(oD(t))(e.buffer,e.byteOffset,i);switch(t){case"int64":case"uint64":{let e=new Int32Array(i);for(let t=0;t<i;t++){let r=o[t];if(r>2147483647n||r<-2147483648n)throw Error("Can not convert int64 data to int32 - value out of range.");e[t]=Number(r)}return new Uint8Array(e.buffer)}case"int8":case"uint8":case"uint32":if("uint32"===t&&o.some(e=>e>0x7fffffff))throw Error("Can not convert uint32 data to int32 - value out of range.");return new Uint8Array(Int32Array.from(o,Number).buffer);default:throw Error(`Unsupported data conversion from ${t} to 'int32'`)}})(e,this.wrapper.type),this.wrapper.setIsDataConverted(!0);else throw Error(`Unsupported fallback data type: ${this.wrapper.fallbackType}`);if(e.byteLength===this.wrapper.byteLength)return void this.wrapper.write(t);oV("verbose",()=>"Data size does not match tensor size. Releasing tensor."),this.releaseTensor()}this.activeUpload?this.activeUpload.set(t):this.activeUpload=new Uint8Array(t)}async download(e){if(this.activeUpload){let t=this.wrapper?.isDataConverted?oQ(this.activeUpload,this.wrapper?.type):this.activeUpload;return e?void(e instanceof ArrayBuffer?new Uint8Array(e).set(t):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(t)):t.buffer}if(!this.wrapper)throw Error("Tensor has not been created.");return e?this.wrapper.read(e):this.wrapper.read()}},o6=class{constructor(e){this.backend=e,this.tensorTrackersById=new Map,this.freeTensors=[],this.externalTensors=new Set}getMLContext(e){let t=this.backend.getMLContext(e);if(!t)throw Error("MLContext not found for session.");return t}getMLOpSupportLimits(e){return this.backend.getMLOpSupportLimits(e)}reserveTensorId(){let e=o0();return this.tensorTrackersById.set(e,new o4(this)),e}releaseTensorId(e){let t=this.tensorTrackersById.get(e);t&&(this.tensorTrackersById.delete(e),t.tensorWrapper&&this.releaseTensor(t.tensorWrapper))}async ensureTensor(e,t,r,n,i){oV("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${t}, dataType: ${r}, shape: ${n}, copyOld: ${i}}`);let o=this.tensorTrackersById.get(t);if(!o)throw Error("Tensor not found.");return o.ensureTensor(e,r,n,i)}upload(e,t){let r=this.tensorTrackersById.get(e);if(!r)throw Error("Tensor not found.");r.upload(t)}async download(e,t){oV("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t?.byteLength}}`);let r=this.tensorTrackersById.get(e);if(!r)throw Error("Tensor not found.");return r.download(t)}releaseTensorsForSession(e){for(let t of this.freeTensors)t.sessionId===e&&t.destroy();this.freeTensors=this.freeTensors.filter(t=>t.sessionId!==e)}registerTensor(e,t,r,n){let i=this.getMLContext(e),o=o0(),s=new o3({sessionId:e,context:i,tensor:t,dataType:r,shape:n});return this.tensorTrackersById.set(o,new o4(this,s)),this.externalTensors.add(s),o}async getCachedTensor(e,t,r,n,i,o,s){let a=this.getMLContext(e);for(let[n,i]of this.freeTensors.entries())if(i.canReuseTensor(a,t,r)){oV("verbose",()=>`[WebNN] Reusing tensor {dataType: ${t}, ${s?`fallbackDataType: ${s},`:""} shape: ${r}`);let i=this.freeTensors.splice(n,1)[0];return i.sessionId=e,i}oV("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${t}, ${s?`fallbackDataType: ${s},`:""} shape: ${r}}`);let u=await a.createTensor({dataType:s??t,shape:r,dimensions:r,usage:n,writable:i,readable:o});return new o3({sessionId:e,context:a,tensor:u,dataType:t,shape:r,fallbackDataType:s})}releaseTensor(e){this.externalTensors.has(e)&&this.externalTensors.delete(e),this.freeTensors.push(e)}},o8=(...e)=>new o6(...e)}}),f$=dQ({"web/lib/wasm/jsep/backend-webnn.ts"(){"use strict";fb(),fh(),fx(),fw(),f_(),o5=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[22,"int4"],[21,"uint4"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),o7=class{constructor(e){this.tensorManager=o8(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,this.mlContextCache=[],this.sessionGraphInputs=new Map,this.sessionGraphOutputs=new Map,this.temporaryGraphInputs=[],this.temporaryGraphOutputs=[],this.temporarySessionTensorIds=new Map,this.mlOpSupportLimitsBySessionId=new Map,oL(e.logLevel,!!e.debug)}get currentSessionId(){if(void 0===this.activeSessionId)throw Error("No active session");return this.activeSessionId}onRunStart(e){oV("verbose",()=>`[WebNN] onRunStart {sessionId: ${e}}`),this.activeSessionId=e}onRunEnd(e){oV("verbose",()=>`[WebNN] onRunEnd {sessionId: ${e}}`);let t=this.temporarySessionTensorIds.get(e);if(t){for(let e of t)oV("verbose",()=>`[WebNN] releasing temporary tensor {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e);this.temporarySessionTensorIds.delete(e),this.activeSessionId=void 0}}async createMLContext(e){if(e instanceof GPUDevice){let t=this.mlContextCache.findIndex(t=>t.gpuDevice===e);if(-1!==t)return this.mlContextCache[t].mlContext;{let t=await navigator.ml.createContext(e);return this.mlContextCache.push({gpuDevice:e,mlContext:t}),t}}if(void 0===e){let e=this.mlContextCache.findIndex(e=>void 0===e.options&&void 0===e.gpuDevice);if(-1!==e)return this.mlContextCache[e].mlContext;{let e=await navigator.ml.createContext();return this.mlContextCache.push({mlContext:e}),e}}let t=this.mlContextCache.findIndex(t=>((e,t)=>{if(e===t)return!0;if(void 0===e||void 0===t)return!1;let r=Object.keys(e).sort(),n=Object.keys(t).sort();return r.length===n.length&&r.every((r,i)=>r===n[i]&&e[r]===t[r])})(t.options,e));if(-1!==t)return this.mlContextCache[t].mlContext;{let t=await navigator.ml.createContext(e);return this.mlContextCache.push({options:e,mlContext:t}),t}}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e),this.mlOpSupportLimitsBySessionId.has(e)||this.mlOpSupportLimitsBySessionId.set(e,t.opSupportLimits()),this.temporaryGraphInputs.length>0&&(this.sessionGraphInputs.set(e,this.temporaryGraphInputs),this.temporaryGraphInputs=[]),this.temporaryGraphOutputs.length>0&&(this.sessionGraphOutputs.set(e,this.temporaryGraphOutputs),this.temporaryGraphOutputs=[])}onReleaseSession(e){this.sessionGraphInputs.delete(e),this.sessionGraphOutputs.delete(e);let t=this.mlContextBySessionId.get(e);if(!t)return;this.tensorManager.releaseTensorsForSession(e),this.mlContextBySessionId.delete(e),this.mlOpSupportLimitsBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);if(r.delete(e),0===r.size){this.sessionIdsByMLContext.delete(t);let e=this.mlContextCache.findIndex(e=>e.mlContext===t);-1!==e&&this.mlContextCache.splice(e,1)}}getMLContext(e){return this.mlContextBySessionId.get(e)}getMLOpSupportLimits(e){return this.mlOpSupportLimitsBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){oV("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,n,i){let o=o5.get(r);if(!o)throw Error(`Unsupported ONNX data type: ${r}`);return this.tensorManager.ensureTensor(e??this.currentSessionId,t,o,n,i)}async createTemporaryTensor(e,t,r){oV("verbose",()=>`[WebNN] createTemporaryTensor {onnxDataType: ${t}, shape: ${r}}`);let n=o5.get(t);if(!n)throw Error(`Unsupported ONNX data type: ${t}`);let i=this.tensorManager.reserveTensorId();await this.tensorManager.ensureTensor(e,i,n,r,!1);let o=this.temporarySessionTensorIds.get(e);return o?o.push(i):this.temporarySessionTensorIds.set(e,[i]),i}uploadTensor(e,t){if(!ox().shouldTransferToMLTensor)throw Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");oV("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return oZ(r,t)}}registerMLTensor(e,t,r,n){let i=o5.get(r);if(!i)throw Error(`Unsupported ONNX data type: ${r}`);let o=this.tensorManager.registerTensor(e,t,i,n);return oV("verbose",()=>`[WebNN] registerMLTensor {tensor: ${t}, dataType: ${i}, dimensions: ${n}} -> {tensorId: ${o}}`),o}registerGraphInput(e){this.temporaryGraphInputs.push(e)}registerGraphOutput(e){this.temporaryGraphOutputs.push(e)}isGraphInput(e,t){let r=this.sessionGraphInputs.get(e);return!!r&&r.includes(t)}isGraphOutput(e,t){let r=this.sessionGraphOutputs.get(e);return!!r&&r.includes(t)}isGraphInputOutputTypeSupported(e,t,r=!0){let n=o5.get(oP(t)),i=this.mlOpSupportLimitsBySessionId.get(e);return void 0!==n&&(r?!!i?.input.dataTypes.includes(n):!!i?.output.dataTypes.includes(n))}flush(){}}}}),fT=dQ({"web/lib/wasm/jsep/webgpu/types.ts"(){}}),fI=dQ({"web/lib/wasm/jsep/webgpu/gpu-data-manager.ts"(){"use strict";f_(),fT(),o9=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[0xc00000,10],[0x1000000,10],[0x1900000,15],[0x2000000,22],[0x2a30000,2],[0x3840000,6],[0x4000000,6],[0x8000000,6],[0xa000000,6]]),se=[],st=e=>16*Math.ceil(Number(e)/16),sr=1,sn=()=>sr++,si=async(e,t,r,n)=>{let i=st(r),o=e.device.createBuffer({size:i,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let s=e.getCommandEncoder();e.endComputePass(),s.copyBufferToBuffer(t,0,o,0,i),e.flush(),await o.mapAsync(GPUMapMode.READ);let a=o.getMappedRange();if(!n)return new Uint8Array(a.slice(0,r));{let e=n();return e.set(new Uint8Array(a,0,r)),e}}finally{o.destroy()}},so=class{constructor(e){for(let[t]of(this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersPending=[],this.capturedPendingBuffers=new Map,o9))se.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[]);this.sessionCount=0}upload(e,t){let r=t.buffer,n=t.byteOffset,i=t.byteLength,o=st(i),s=this.storageCache.get(e);if(!s)throw Error("gpu data for uploading does not exist");if(Number(s.originalSize)!==i)throw Error(`inconsistent data size. gpu data size=${s.originalSize}, data size=${i}`);if(o===i&&n%4==0)this.backend.device.queue.writeBuffer(s.gpuData.buffer,0,r,n,i);else{let e=new Uint8Array(o);e.set(t),this.backend.device.queue.writeBuffer(s.gpuData.buffer,0,e,0,o)}oV("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw Error("source gpu data for memcpy does not exist");let n=this.storageCache.get(t);if(!n)throw Error("destination gpu data for memcpy does not exist");if(r.originalSize!==n.originalSize)throw Error("inconsistent source and destination gpu data size");let i=st(r.originalSize),o=this.backend.getCommandEncoder();this.backend.endComputePass(),o.copyBufferToBuffer(r.gpuData.buffer,0,n.gpuData.buffer,0,i)}registerExternalBuffer(e,t,r){let n;if(r){if(n=r[0],e===r[1])return oV("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${n}, buffer is the same, skip.`),n;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else n=sn();return this.storageCache.set(n,{gpuData:{id:n,type:0,buffer:e},originalSize:t}),oV("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${n}, registered.`),n}unregisterExternalBuffer(e){void 0!==e&&(this.storageCache.delete(e),oV("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r,n=(e=>{for(let t=0;t<se.length;t++){let r=se[t];if(e<=r)return r}return 16*Math.ceil(e/16)})(e),i=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,o=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(i||o){let e=(i?this.freeBuffers:this.freeUniformBuffers).get(n);r=e&&e.length>0?e.pop():this.backend.device.createBuffer({size:n,usage:t})}else r=this.backend.device.createBuffer({size:n,usage:t});let s={id:sn(),type:0,buffer:r};return this.storageCache.set(s.id,{gpuData:s,originalSize:Number(e)}),oV("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${s.id}`),s}get(e){return this.storageCache.get(e)?.gpuData}release(e){let t="bigint"==typeof e?Number(e):e,r=this.storageCache.get(t);if(!r)if(0===this.storageCache.size)return 0;else throw Error("releasing data does not exist");return oV("verbose",()=>`[WebGPU] GpuDataManager.release(id=${t}), gpuDataId=${r.gpuData.id}`),this.storageCache.delete(t),this.buffersPending.push(r.gpuData.buffer),r.originalSize}async download(e,t){let r=this.storageCache.get(Number(e));if(!r)throw Error("data does not exist");await si(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){if(0!==this.buffersPending.length)if("default"===this.backend.sessionStatus){for(let e of this.buffersPending){let t=o9.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];void 0===t||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];void 0===t||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);for(let t of(e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e)),this.buffersPending))e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onCreateSession(){this.sessionCount+=1}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(e=>{e.destroy()}),this.capturedPendingBuffers.delete(e)),this.sessionCount-=1,0===this.sessionCount&&(oV("warning",()=>"[WebGPU] Clearing webgpu buffer cache"),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.storageCache=new Map)}},ss=(...e)=>new so(...e)}}),fS=dQ({"web/lib/wasm/jsep/webgpu/attribute-with-cache-key.ts"(){"use strict";sa=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},su=e=>new sa(e)}}),fO=dQ({"web/lib/wasm/jsep/webgpu/ops/common.ts"(){"use strict";fb(),fv(),sl=64,sd=(e,t)=>{if(3===t)throw Error("vec3 has same alignment as vec4, use vec4 instead");switch(Number(e)){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(4!==t)throw Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw Error(`Unknown data type: ${e}`)}},sp=(e,t=1)=>{let r=sd(e,t);return"string"==typeof r?r:r[0]},sc=(e,t=1)=>{let r=sd(e,t);return"string"==typeof r?r:r[1]},sh=(...e)=>{let t=[];return e.forEach(e=>{0!==e.length&&t.push({type:12,data:e},{type:12,data:oG.computeStrides(e)})}),t},sf=e=>e%4==0?4:e%2==0?2:1,sg=(e="f32",t,r="0")=>t&&1!==t?`vec${t}<${e}>(${r})`:`${e}(${r})`,sm=(e,t,r)=>"f32"===e?r:1===t?`f32(${r})`:`vec${t}<f32>(${r})`,sb=(e,t)=>4===t?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:2===t?`(${e}.x + ${e}.y)`:3===t?`(${e}.x + ${e}.y + ${e}.z)`:e,sy=(e,t,r,n)=>{if(!e.startsWith("uniforms.")||!(r>4))return r>1?`${e}[${t}]`:e;if("string"==typeof t)if("f16"===n)return`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`;else return`${e}[(${t}) / 4][(${t}) % 4]`;return"f16"===n?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`},s_=(e,t,r,n,i)=>{let o,s,a,u,l="number"==typeof r,d=l?r:r.length,p=[...Array(d).keys()],c=d<2?"u32":d<=4?`vec${d}<u32>`:`array<u32, ${d}>`,h=sd(t,i),f="string"==typeof h?h:h[1],g={indices:c,value:f,storage:"string"==typeof h?h:h[0],tensor:t},m=e=>"string"==typeof e?e:`${e}u`,b={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},y=l?"uniforms.":"",_=`${y}${e}_shape`,v=`${y}${e}_strides`,x="";for(let e=0;e<d-1;e++)x+=`
    let dim${e} = current / ${sy(v,e,d)};
    let rest${e} = current % ${sy(v,e,d)};
    indices[${e}] = dim${e};
    current = rest${e};
    `;x+=`indices[${d-1}] = current;`;let w=d<2?"":`
  fn o2i_${e}(offset: u32) -> ${g.indices} {
    var indices: ${g.indices};
    var current = offset;
    ${x}
    return indices;
  }`,$=[];if(d>=2)for(let e=d-1;e>=0;e--)$.push(`${sy(v,e,d)} * (indices[${e}])`);let T=d<2?"":`
  fn i2o_${e}(indices: ${g.indices}) -> u32 {
    return ${$.join("+")};
  }`,I=(...e)=>0===d?"0u":`${g.indices}(${e.map(m).join(",")})`,S=(e,t)=>d<2?`${e}`:`${sy(e,t,d)}`,O={},E=(t,r)=>(()=>{if(g.storage===g.value)return`${e}[${t}]=${r};`;if("vec2<u32>"===g.storage&&"i32"===g.value)return`${e}[${t}]=vec2<u32>(u32(${r}), select(0u, 0xFFFFFFFFu, ${r} < 0));`;if("vec2<u32>"===g.storage&&"u32"===g.value)return`${e}[${t}]=vec2<u32>(u32(${r}), 0u);`;if("u32"===g.storage&&"vec4<bool>"===g.value)return`${e}[${t}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${r}));`;throw Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),P=t=>(()=>{if(g.storage===g.value)return`${e}[${t}]`;if("vec2<u32>"===g.storage&&"i32"===g.value)return`i32(${e}[${t}].x)`;if("vec2<u32>"===g.storage&&"u32"===g.value)return`u32(${e}[${t}].x)`;if("u32"===g.storage&&"vec4<bool>"===g.value)return`vec4<bool>(bool(${e}[${t}] & 0xFFu), bool(${e}[${t}] & 0xFF00u), bool(${e}[${t}] & 0xFF0000u), bool(${e}[${t}] & 0xFF000000u))`;throw Error(`not supported combination of storage type ${g.storage} and value type ${g.value} yet`)})(),k=d<2?"":`
  fn get_${e}ByIndices(indices: ${g.indices}) -> ${f} {
    return ${P(`i2o_${e}(indices)`)};
  }`,A=d<2?"":(o=p.map(e=>`d${e}: u32`).join(", "),s=p.map(e=>`d${e}`).join(", "),`
  fn get_${e}(${o}) -> ${f} {
    return get_${e}ByIndices(${I(s)});
  }`),D=d<2?"":`
  fn set_${e}ByIndices(indices: ${g.indices}, value: ${f}) {
    ${E(`i2o_${e}(indices)`,"value")}
  }`,z=d<2?"":(a=p.map(e=>`d${e}: u32`).join(", "),u=p.map(e=>`d${e}`).join(", "),`
  fn set_${e}(${a}, value: ${f}) {
    set_${e}ByIndices(${I(u)}, value);
  }`);return{impl:()=>{let e=[],t=!1;return b.offsetToIndices&&(e.push(w),t=!0),b.indicesToOffset&&(e.push(T),t=!0),b.broadcastedIndicesToOffset&&(Object.values(O).forEach(t=>e.push(t)),t=!0),b.set&&(e.push(z),t=!0),b.setByIndices&&(e.push(D),t=!0),b.get&&(e.push(A),t=!0),b.getByIndices&&(e.push(k),t=!0),!l&&t&&e.unshift(`const ${_} = ${g.indices}(${r.join(",")});`,`const ${v} = ${g.indices}(${oG.computeStrides(r).join(",")});`),e.join("\n")},type:g,offsetToIndices:t=>(b.offsetToIndices=!0,d<2?t:`o2i_${e}(${t})`),indicesToOffset:t=>(b.indicesToOffset=!0,d<2?t:`i2o_${e}(${t})`),broadcastedIndicesToOffset:(t,r)=>{b.broadcastedIndicesToOffset=!0;let n=`${r.name}broadcastedIndicesTo${e}Offset`;if(n in O)return`${n}(${t})`;let i=[];for(let e=d-1;e>=0;e--){let t=r.indicesGet("outputIndices",e+r.rank-d);i.push(`${S(v,e)} * (${t} % ${S(_,e)})`)}return O[n]=`fn ${n}(outputIndices: ${r.type.indices}) -> u32 {
             return ${i.length>0?i.join("+"):"0u"};
           }`,`${n}(${t})`},indices:I,indicesGet:S,indicesSet:(e,t,r)=>d<2?`${e}=${r};`:`${sy(e,t,d)}=${r};`,set:(...t)=>{if(t.length!==d+1)throw Error(`indices length must be ${d}`);let r=t[d];if("string"!=typeof r)throw Error("value must be string");let n=t.slice(0,d).map(m).join(",");return 0===d?E("0u",r):1===d?E(n[0],r):(b.set=!0,b.setByIndices=!0,b.indicesToOffset=!0,`set_${e}(${n}, ${r})`)},setByOffset:E,setByIndices:(t,r)=>d<2?E(t,r):(b.setByIndices=!0,b.indicesToOffset=!0,`set_${e}ByIndices(${t}, ${r});`),get:(...t)=>{if(t.length!==d)throw Error(`indices length must be ${d}`);let r=t.map(m).join(",");return 0===d?P("0u"):1===d?P(r[0]):(b.get=!0,b.getByIndices=!0,b.indicesToOffset=!0,`get_${e}(${r})`)},getByOffset:P,getByIndices:t=>d<2?P(t):(b.getByIndices=!0,b.indicesToOffset=!0,`get_${e}ByIndices(${t})`),usage:n,name:e,strides:v,shape:_,rank:d}},sv=(e,t,r,n=1)=>s_(e,t,r,"input",n),sx=(e,t,r,n=1)=>s_(e,t,r,"output",n),sw=(e,t,r)=>s_(e,t,r,"atomicOutput",1),s$=(e,t,r,n=1)=>s_(e,t,r,"internal",n),sT=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){let t="number"==typeof e?`${e}u`:e;return`if (global_idx >= ${t}) { return; }`}mainStart(e=sl){let t="number"==typeof e?e:e[0],r="number"==typeof e?1:e[1],n="number"==typeof e?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||n>this.limits.maxComputeWorkgroupSizeZ)throw Error(`workgroup size [${t}, ${r}, ${n}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*n>this.limits.maxComputeInvocationsPerWorkgroup)throw Error(`workgroup size [${t}, ${r}, ${n}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let i=1===this.normalizedDispatchGroup[1]&&1===this.normalizedDispatchGroup[2],o=i?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,s=i?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*n}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${n})
  fn main(${o}) {
    ${s}
  `}appendVariableUniforms(e){0!==e.rank&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if("internal"===e.usage)throw Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r="input"===e.usage?"read":"read_write",n="atomicOutput"===e.usage?"atomic<i32>":e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${n}>;`}declareVariables(...e){return e.map(e=>this.declareVariable(e,this.variableIndex++)).join("\n")}registerInternalVariable(e){if("internal"!==e.usage)throw Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(e=>this.registerInternalVariable(e)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(0===this.uniforms.length)return"";let e=[];for(let{name:t,type:r,length:n}of this.uniforms)if(n&&n>4)"f16"===r?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(n/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(n/4)}>`);else{let i=null==n||1===n?r:`vec${n}<${r}>`;e.push(`${t}:${i}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join("\n")+this.internalVariables.map(e=>e.impl()).join("\n")}get variablesInfo(){if(0!==this.uniforms.length)return this.uniforms.map(e=>[[12,10,1,6][["u32","f16","f32","i32"].indexOf(e.type)],e.length??1])}},sI=(e,t)=>new sT(e,t)}}),fE=dQ({"web/lib/wasm/jsep/webgpu/ops/transpose.ts"(){"use strict";fb(),fv(),fS(),fO(),sS=(e,t)=>0!==t.length?t:[...Array(e).keys()].reverse(),sO=(e,t)=>{let r,n=e.dataType,i=e.dims.length,o=sS(i,t),s=(r=e.dims,oG.sortBasedOnPerm(r,sS(r.length,o))),a=e.dims,u=s;if(i<2||((e,t)=>{let r=0;for(let n=0;n<e.length;++n)if(1!==t[e[n]]){if(e[n]<r)return!1;r=e[n]}return!0})(o,e.dims))return{name:"TransposeCopy",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let t=oG.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(t/64/4)},programUniforms:[{type:12,data:Math.ceil(t/4)}]}},getShaderSource:e=>{let t=sv("input",n,a,4),r=sx("output",n,u,4);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    output[global_idx] = input[global_idx];
  }`}};let{newShape:l,newPerm:d}=((e,t)=>{let r=[],n=[];for(let i=0;i<e.length;++i)1!==e[i]&&r.push(e[i]),1!==e[t[i]]&&n.push(t[i]);return{newShape:r,newPerm:n}})(e.dims,o),p=oG.areEqual(d,[2,3,1]),c=oG.areEqual(d,[3,1,2]);return 2===l.length||p||c?(u=[(a=p?[l[0],l[1]*l[2]]:c?[l[0]*l[1],l[2]]:l)[1],a[0]],{name:"TransposeShared",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let t=oG.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(u[1]/16),y:Math.ceil(u[0]/16)},programUniforms:[{type:12,data:t},...sh(a,u)]}},getShaderSource:e=>{let t=sv("a",n,a.length),r=sx("output",n,u.length);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}
  var<workgroup> tile : array<array<${r.type.value}, 17>, 16>;
  ${e.mainStart([16,16,1])}
    let stride = (uniforms.output_shape[1] - 1) / 16 + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * 16u + local_id.x;
    let input_row = workgroup_id_x * 16u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${t.getByIndices(`${t.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * 16u + local_id.x;
    let output_row = workgroup_id_y * 16u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${r.setByIndices(`${r.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`}}):{name:"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let t=oG.size(s);return{outputs:[{dims:s,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(t/64)},programUniforms:[{type:12,data:t},...sh(a,u)]}},getShaderSource:e=>{let t=sv("a",n,a.length),r=sx("output",n,u.length);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}

  ${((e,t,r,n)=>{let i=`fn perm(i: ${n.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let r=0;r<t;++r)i+=`a[${e[r]}]=i[${r}];`;return i+"return a;}"})(o,i,t,r)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${r.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${r.setByOffset("global_idx",t.getByIndices("aIndices"))}
  }`}}},sE=(e,t)=>{var r=e.inputs,n=t.perm;if(!r||1!==r.length)throw Error("Transpose requires 1 input.");if(0!==n.length&&n.length!==r[0].dims.length)throw Error(`perm size ${n.length} does not match input rank ${r[0].dims.length}`);e.compute(sO(e.inputs[0],t.perm))},sP=e=>su({perm:e.perm})}}),fP=dQ({"web/lib/wasm/jsep/webgpu/ops/reduce-shared.ts"(){"use strict";fb(),fv(),fO(),fk(),fE(),sk={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},sA={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},sD={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},sz={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},sC=(e,t,r,n)=>{var i,o,s,a;let u,l,d,p,c,h,f,g=1===e.inputs.length?r:sK(e.inputs,r),m=g.axes;0!==m.length||g.noopWithEmptyAxes||(m=e.inputs[0].dims.map((e,t)=>t));let b=oG.normalizeAxes(m,e.inputs[0].dims.length),y=b,_=e.inputs[0],v=((e,t)=>{let r=[];if(!((e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0})(e,t)){for(let n=0;n<t;++n)-1===e.indexOf(n)&&r.push(n);e.forEach(e=>r.push(e))}return r})(y,e.inputs[0].dims.length);v.length>0&&(_=e.compute(sO(e.inputs[0],v),{inputs:[0],outputs:[-1]})[0],y=((e,t)=>{let r=[];for(let n=t-e;n<t;++n)r.push(n);return r})(y.length,_.dims.length));let[x,w]=((e,t)=>{let r=[],n=e.length;for(let i=0;i<n;i++)-1===t.indexOf(i)&&r.push(e[i]);return[r,t.map(t=>e[t])]})(_.dims,y),$=x;g.keepDims&&($=((e,t)=>{let r=e.length+t.length,n=[],i=0;for(let o=0;o<r;o++)-1===t.indexOf(o)?n.push(e[i++]):n.push(1);return n})(x,b)),e.compute((i=g.cacheKey,o=[_],s=e.inputs[0].dataType,a=$,u=o[0].dims,l=oG.size(a),d=oG.size(w),p=sv("_A",o[0].dataType,u),c=sx("output",s,a),h=64,1===l&&(h=256),f=`
          var<workgroup> aBestValues : array<f32, ${h}>;
       `,{name:t,shaderCache:{hint:`${i};${h}`,inputDependencies:["type"]},getShaderSource:e=>`
        ${e.registerUniform("reduceSize","u32").declareVariables(p,c)}
        ${f}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${e.mainStart(h)}

          let outputIndex = global_idx / ${h};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${sD[n]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${h}) {
           let candidate = f32(${p.getByOffset("offset + k")});
           bestValue = ${sk[n]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${h}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${sA[n]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${c.setByOffset("outputIndex",`${"mean"===n?`${c.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${c.type.storage}(${sz[n]})`}`)};
         }
        }`,getRunData:()=>({outputs:[{dims:a,dataType:s}],dispatchGroup:{x:l},programUniforms:[{type:12,data:d}]})}),{inputs:[_]})},sN=(e,t)=>{sC(e,"ReduceMeanShared",t,"mean")},sj=(e,t)=>{sC(e,"ReduceL1Shared",t,"l1")},sR=(e,t)=>{sC(e,"ReduceL2Shared",t,"l2")},sB=(e,t)=>{sC(e,"ReduceLogSumExpShared",t,"logSumExp")},sM=(e,t)=>{sC(e,"ReduceMaxShared",t,"max")},sF=(e,t)=>{sC(e,"ReduceMinShared",t,"min")},sL=(e,t)=>{sC(e,"ReduceProdShared",t,"prod")},sV=(e,t)=>{sC(e,"ReduceSumShared",t,"sum")},sU=(e,t)=>{sC(e,"ReduceSumSquareShared",t,"sumSquare")},sq=(e,t)=>{sC(e,"ReduceLogSumShared",t,"logSum")}}}),fk=dQ({"web/lib/wasm/jsep/webgpu/ops/reduce.ts"(){"use strict";fb(),fv(),fS(),fO(),fP(),sG=e=>{if(!e||0===e.length||e.length>2)throw Error("Reduce op requires 1 or 2 inputs.");if(2===e.length&&1!==e[1].dims.length)throw Error("Invalid axes input dims.")},sH=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],sW=(e,t,r,n,i,o,s=!1,a=!1)=>{let u=[],l=r[0].dims,d=l.length,p=oG.normalizeAxes(i,d),c=!a&&0===p.length;l.forEach((e,t)=>{c||p.indexOf(t)>=0?s&&u.push(1):u.push(e)});let h=u.length,f=oG.size(u);return{name:e,shaderCache:t,getShaderSource:e=>{let t=[],i=sv("_A",r[0].dataType,d),a=sx("output",o,h),u=n(i,a,p),f=u[2];for(let e=0,r=0;e<d;e++)c||p.indexOf(e)>=0?(s&&r++,f=`for(var j${e}: u32 = 0; j${e} < ${l[e]}; j${e}++) {
                  ${u[2].includes("last_index")?`let last_index = j${e};`:""}
                  ${i.indicesSet("input_indices",e,`j${e}`)}
                  ${f}
                }`):(t.push(`${i.indicesSet("input_indices",e,a.indicesGet("output_indices",r))};`),r++);return`

        ${e.registerUniform("output_size","u32").declareVariables(i,a)}

        ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${i.type.indices};
          let output_indices = ${a.offsetToIndices("global_idx")};

          ${t.join("\n")}
          ${u[0]}       // init ops for reduce max/min
          ${u[1]}
          ${f}
          ${u[3]}
          ${4===u.length?a.setByOffset("global_idx","value"):u.slice(4).join("\n")}
        }`},getRunData:()=>({outputs:[{dims:u,dataType:o}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:[{type:12,data:f},...sh(l,u)]})}},sK=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(e=>r.push(Number(e))),su({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},sX=(e,t,r,n)=>{let i=e.inputs,o=1===i.length?r:sK(i,r);e.compute(sW(t,{hint:o.cacheKey,inputDependencies:["rank"]},[i[0]],o.noopWithEmptyAxes&&0===o.axes.length?sH:n,o.axes,i[0].dataType,o.keepDims,o.noopWithEmptyAxes),{inputs:[0]})},sZ=(e,t,r)=>{if(0===t.length)return r;let n=1,i=1;for(let r=0;r<t.length;r++)-1===t.indexOf(r)?n*=e[r]:i*=e[r];return i<32&&n>1024},sJ=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceMean",t,(t,r,n)=>{let i=1;for(let r=0;r<t.rank;r++)(n.indexOf(r)>=0||0===n.length)&&(i*=e.inputs[0].dims[r]);return["var sum = f32(0);","",`sum += f32(${t.getByIndices("input_indices")});`,`let value = ${r.type.value}(sum / ${i});`]});else sN(e,t)},sQ=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceL1",t,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += abs(${e.getByIndices("input_indices")});`,""]);else sj(e,t)},sY=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceL2",t,(e,t)=>[`var t = ${t.type.value}(0); var value = ${t.type.value}(0);`,"",`t = ${e.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"]);else sR(e,t)},s0=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceLogSumExp",t,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += exp(${e.getByIndices("input_indices")});`,"value = log(value);"]);else sB(e,t)},s1=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceMax",t,(e,t,r)=>{let n=[];for(let t=0;t<e.rank;t++)(r.indexOf(t)>=0||0===r.length)&&n.push(e.indicesSet("input_indices",t,0));return[`${n.join("\n")}`,`var value = ${e.getByIndices("input_indices")};`,`value = max(value, ${e.getByIndices("input_indices")});`,""]});else sM(e,t)},s2=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceMin",t,(e,t,r)=>{let n=[];for(let t=0;t<e.rank;t++)(r.indexOf(t)>=0||0===r.length)&&n.push(`input_indices[${t}] = 0;`);return[`${n.join("\n")}`,`var value = ${e.getByIndices("input_indices")};`,`value = min(value, ${e.getByIndices("input_indices")});`,""]});else sF(e,t)},s3=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceProd",t,(e,t)=>[`var value = ${t.type.storage}(1);`,"",`value *= ${e.getByIndices("input_indices")};`,""]);else sL(e,t)},s4=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceSum",t,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += ${e.getByIndices("input_indices")};`,""]);else sV(e,t)},s6=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceSumSquare",t,(e,t)=>[`var t = ${t.type.value}(0); var value = ${t.type.value}(0);`,"",`t = ${e.getByIndices("input_indices")}; value += t * t;`,""]);else sU(e,t)},s8=(e,t)=>{if(sZ(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes))sG(e.inputs),sX(e,"ReduceLogSum",t,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += ${e.getByIndices("input_indices")};`,"value = log(value);"]);else sq(e,t)}}}),fA=dQ({"web/lib/wasm/jsep/webgpu/ops/argminmax.ts"(){"use strict";fb(),fS(),fk(),s5=e=>{if(!e||0===e.length||e.length>2)throw Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(1!==e[0].dataType)throw Error("Invalid input type.")},s7=(e,t)=>{s5(e.inputs),e.compute(sW("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],(e,r,n)=>{let i=[];for(let t=0;t<e.rank;t++)(n.indexOf(t)>=0||0===n.length)&&i.push(`input_indices[${t}] = 0;`);return[`${i.join("\n")}`,`var value = ${e.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${e.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${e.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",r.setByOffset("global_idx","best_index")]},[t.axis],7,t.keepDims),{inputs:[0]})},s9=(e,t)=>{s5(e.inputs),e.compute(sW("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],(e,r,n)=>{let i=[];for(let t=0;t<e.rank;t++)(n.indexOf(t)>=0||0===n.length)&&i.push(`input_indices[${t}] = 0;`);return[`${i.join("\n")}`,`var value = ${e.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${e.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${e.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",r.setByOffset("global_idx","best_index")]},[t.axis],7,t.keepDims),{inputs:[0]})},ae=e=>su(e)}}),fD=dQ({"web/lib/wasm/jsep/webgpu/ops/attention.ts"(){"use strict";fb(),fv(),fT(),fO(),at=(e,t,r)=>t&&e?`
      let total_sequence_length_input = u32(${t.getByOffset("0")});
      let present_sequence_length = max(total_sequence_length_input, uniforms.past_sequence_length);
      let is_subsequent_prompt: bool = sequence_length > 1 && sequence_length != total_sequence_length_input;
      let is_first_prompt: bool = is_subsequent_prompt == false && sequence_length == total_sequence_length_input;
      total_sequence_length = u32(${e?.getByOffset("batchIdx")}) + 1;
      var past_sequence_length: u32 = 0;
      if (is_first_prompt == false) {
        past_sequence_length = total_sequence_length - sequence_length;
      }
       `:`
    ${r?"let past_sequence_length = uniforms.past_sequence_length":""};
    let present_sequence_length = total_sequence_length;
    `,ar=(e,t,r,n,i,o,s,a,u,l,d,p)=>{var c,h,f;let g,m,b,y,_,v,x,w,$,T,I,S,O,E,P,k,A,D,z,C,N,j,R,B,M,F,L,V,U,q,G,H,W,K=Math.min(e.outputCount,1+ +!!s+ +!!a),X=K>1?s:void 0,Z=K>1?a:void 0,J=K>1?l.pastSequenceLength:0,Q=J+l.kvSequenceLength,Y=u&&oG.size(u.dims)>0?u:void 0,ee=[t,r];X&&oG.size(X.dims)>0&&ee.push(X),Y&&ee.push(Y),d&&ee.push(d),p&&ee.push(p);let et=e.compute((g=J+l.kvSequenceLength,m=[l.batchSize,l.numHeads,l.sequenceLength,g],b=K>1&&X,y=l.kvNumHeads?l.kvNumHeads:l.numHeads,_=b?[l.batchSize,y,g,l.headSize]:void 0,v=l.nReps?l.nReps:1,x=0===l.scale?1/Math.sqrt(l.headSize):l.scale,w=sf(l.headSize),$=l.headSize/w,T={x:Math.ceil(g/12),y:Math.ceil(l.sequenceLength/12),z:l.batchSize*l.numHeads},I=[{type:12,data:l.sequenceLength},{type:12,data:$},{type:12,data:g},{type:12,data:l.numHeads},{type:12,data:l.headSize},{type:1,data:x},{type:12,data:J},{type:12,data:l.kvSequenceLength},{type:12,data:v}],S=b&&X&&oG.size(X.dims)>0,O=["type","type"],S&&O.push("type"),Y&&O.push("type"),d&&O.push("type"),p&&O.push("type"),E=[{dims:m,dataType:t.dataType,gpuDataType:0}],b&&E.push({dims:_,dataType:t.dataType,gpuDataType:0}),{name:"AttentionProbs",shaderCache:{hint:`${w};${void 0!==Y};${void 0!==X};${K}`,inputDependencies:O},getRunData:()=>({outputs:E,dispatchGroup:T,programUniforms:I}),getShaderSource:e=>{let n=sv("q",t.dataType,t.dims,w),i=[n,sv("key",r.dataType,r.dims,w)];if(S){let e=sv("past_key",X.dataType,X.dims,w);i.push(e)}Y&&i.push(sv("attention_bias",Y.dataType,Y.dims));let o=d?sv("seq_lens",d.dataType,d.dims):void 0;o&&i.push(o);let s=p?sv("total_sequence_length_input",p.dataType,p.dims):void 0;s&&i.push(s);let a=sx("output",t.dataType,m),u=[a];b&&u.push(sx("present_key",t.dataType,_,w));let l=sc(1,w);return`
  const TILE_SIZE = 12u;

  var<workgroup> tileQ: array<${n.type.storage}, 144>;
  var<workgroup> tileK: array<${n.type.storage}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}]).declareVariables(...i,...u)}
  ${e.mainStart([12,12,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let kvHeadIdx = ${1===v?"headIdx":"headIdx / uniforms.n_reps"};
    let kv_num_heads = ${1===v?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let sequence_length = uniforms.M;
    var total_sequence_length = uniforms.N;
    ${at(o,s,!0)}
    let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx;
    let qOffset = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
    ${S&&b?"let pastKeyOffset = absKvHeadIdx * uniforms.past_sequence_length * uniforms.K;":""};
    let kOffset = absKvHeadIdx * uniforms.kv_sequence_length * uniforms.K;
    ${b?"let presentKeyOffset = absKvHeadIdx * uniforms.N * uniforms.K;":""}
    var value = ${l}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${S&&b?`
              if (n + local_id.y < past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else if (n + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
                tileK[idx] = key[kOffset + (n + local_id.y - past_sequence_length) * uniforms.K + w + local_id.x];
              }`:`
          if (n + local_id.y < uniforms.kv_sequence_length) {
            tileK[idx] = key[kOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
          }`}
      ${b?`if (n + local_id.y < present_sequence_length) {
        present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];
      }`:""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
          value += ${l}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    if (global_id.y < uniforms.M && global_id.x < total_sequence_length) {
      let headOffset = workgroup_id.z * uniforms.M * uniforms.N;
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch(w){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw Error(`Unsupported components: ${w}`)}})()};
        output[outputIdx] = ${a.type.value} (sum * uniforms.alpha) + ${Y?"attention_bias[outputIdx]":"0.0"};
    }
  }`}}),{inputs:ee,outputs:K>1?[-1,1]:[-1]})[0];e.compute((c=l.batchSize,h=l.numHeads,f=l.sequenceLength,P=sf(d?1:Q),k=64,(A=Q/P)<64&&(k=32),D=[{type:12,data:c},{type:12,data:h},{type:12,data:J},{type:12,data:f},{type:12,data:A},{type:12,data:Math.ceil(Q/P/k)}],z=sp(et.dataType,P),C=sc(1,P),N=["type"],d&&N.push("type"),p&&N.push("type"),{name:"AttentionProbsSoftmax",shaderCache:{hint:`${k};${z};${P}`,inputDependencies:N},getShaderSource:e=>{let t=sx("x",et.dataType,et.dims,P),r=[t],n=d?sv("seq_lens",d.dataType,d.dims):void 0;n&&r.push(n);let i=p?sv("total_sequence_length_input",p.dataType,p.dims):void 0;i&&r.push(i);let o=sc(et.dataType);return`
  var<workgroup> thread_max: array<f32, ${k}>;
  var<workgroup> thread_sum: array<f32, ${k}>;
  ${e.registerUniforms([{name:"batch_size",type:"u32"},{name:"num_heads",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"sequence_length",type:"u32"},{name:"total_sequence_length",type:"u32"},{name:"elements_per_thread",type:"u32"}]).declareVariables(...r)}
  ${e.mainStart([k,1,1])}
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let sequence_length = uniforms.sequence_length;
    var total_sequence_length = uniforms.total_sequence_length;
    ${at(n,i,!1)}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${k}) * uniforms.total_sequence_length + local_offset;
    let seq_causal_length = ${d?"u32(past_sequence_length + workgroup_id.y + 1)":"total_sequence_length"};
    var thread_max_vector = ${C}(-3.4028234663852886e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      thread_max_vector = max(${C}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(P){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw Error(`Unsupported components: ${P}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.4028234663852886e+38f);
    for (var i = 0u; i < ${k}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${C}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      sum_vector += exp(${C}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(P){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw Error(`Unsupported components: ${P}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${k}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        x[offset + i] = ${t.type.value}(${o}(1.0) / ${o}(seq_causal_length));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        var f32input = ${C}(x[offset + i]);
        x[offset + i] = ${t.type.value}(exp(f32input - max_value) / sum);
      }
    }
      ${d?`
        for (var total_seq_id: u32 = seq_causal_length; total_seq_id + local_offset < uniforms.total_sequence_length; total_seq_id++) {
          x[offset + total_seq_id] = ${t.type.value}(${o}(0));
        }`:""};
  }`},getRunData:()=>({outputs:[],dispatchGroup:{x:1,y:f,z:c*h},programUniforms:D})}),{inputs:d&&p?[et,d,p]:[et],outputs:[]});let er=[et,n];Z&&oG.size(Z.dims)>0&&er.push(Z),d&&er.push(d),p&&er.push(p),e.compute((j=J+l.kvSequenceLength,R=l.nReps?l.nReps:1,B=l.vHiddenSize*R,M=K>1&&Z,F=l.kvNumHeads?l.kvNumHeads:l.numHeads,L=M?[l.batchSize,F,j,l.headSize]:void 0,V=[l.batchSize,l.sequenceLength,B],U={x:Math.ceil(l.vHeadSize/12),y:Math.ceil(l.sequenceLength/12),z:l.batchSize*l.numHeads},q=[{type:12,data:l.sequenceLength},{type:12,data:j},{type:12,data:l.vHeadSize},{type:12,data:l.numHeads},{type:12,data:l.headSize},{type:12,data:B},{type:12,data:J},{type:12,data:l.kvSequenceLength},{type:12,data:R}],G=M&&Z&&oG.size(Z.dims)>0,H=["type","type"],G&&H.push("type"),d&&H.push("type"),p&&H.push("type"),W=[{dims:V,dataType:et.dataType,gpuDataType:0}],M&&W.push({dims:L,dataType:et.dataType,gpuDataType:0}),{name:"AttentionScore",shaderCache:{hint:`${void 0!==Z};${K}`,inputDependencies:H},getRunData:()=>({outputs:W,dispatchGroup:U,programUniforms:q}),getShaderSource:e=>{let t=sv("probs",et.dataType,et.dims),r=[t,sv("v",n.dataType,n.dims)];G&&r.push(sv("past_value",Z.dataType,Z.dims));let i=d?sv("seq_lens",d.dataType,d.dims):void 0;d&&r.push(i);let o=p?sv("total_sequence_length_input",p.dataType,p.dims):void 0;p&&r.push(o);let s=[sx("output",et.dataType,V)];return M&&s.push(sx("present_value",et.dataType,L)),`
  const TILE_SIZE = 12u;
  var<workgroup> tileQ: array<${t.type.value}, 144>;
  var<workgroup> tileV: array<${t.type.value}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}]).declareVariables(...r,...s)}
  ${e.mainStart([12,12,1])}
   let headIdx = workgroup_id.z % uniforms.num_heads;
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let kvHeadIdx = ${1===R?"headIdx":"headIdx / uniforms.n_reps"};
   let kv_num_heads = ${1===R?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
   let m = global_id.y;
   let n = global_id.x;
   let sequence_length = uniforms.M;
   var total_sequence_length = uniforms.K;
   ${at(i,o,!0)}
   let offsetA = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
   let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx; // kvHeadIdx is relative to the batch
   ${G&&M?"let pastValueOffset = absKvHeadIdx * uniforms.N * uniforms.past_sequence_length + n;":""};
   let vOffset = absKvHeadIdx * uniforms.N * uniforms.kv_sequence_length + n;
   ${M?"let presentValueOffset = absKvHeadIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${t.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${G&&M?`
        if (w + local_id.y < past_sequence_length) {
          tileV[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else if (w + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
          tileV[idx] = v[vOffset + (w + local_id.y - past_sequence_length) * uniforms.N];
        }
      `:`
            if (w + local_id.y < uniforms.kv_sequence_length) {
              tileV[idx] = v[vOffset + (w + local_id.y) * uniforms.N];
            }`}
        ${M?`
            if (w + local_id.y < present_sequence_length) {
          present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileV[idx];
        }`:""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < total_sequence_length; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileV[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + headIdx * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`}}),{inputs:er,outputs:K>1?[0,2]:[0]})},an=(e,t)=>{let r,n,i,o,s,a,u,l=((e,t)=>{let r=e[0],n=e[1],i=e[2],o=e[3],s=e[4],a=e[5];if(s&&a)throw Error("Attention cannot have both past and attention_bias");if(3!==r.dims.length)throw Error('Input "input" must have 3 dimensions');let u=r.dims[0],l=r.dims[1],d=r.dims[2];if(1!==i.dims.length)throw Error('Input "bias" is expected to have 1 dimensions');if(2!==n.dims.length)throw Error('Input "weights" is expected to have 2 dimensions');if(n.dims[0]!==d)throw Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(i.dims[0]!==n.dims[1])throw Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let p=i.dims[0]/3,c=p,h=c;if(t.qkvHiddenSizes.length>0){if(3!==t.qkvHiddenSizes.length)throw Error("qkv_hidden_sizes attribute should have 3 elements");for(let e of t.qkvHiddenSizes)if(e%t.numHeads!=0)throw Error("qkv_hidden_sizes should be divisible by num_heads");p=t.qkvHiddenSizes[0],c=t.qkvHiddenSizes[1],h=t.qkvHiddenSizes[2]}if(p!==c)throw Error("qkv_hidden_sizes first element should be same as the second");if(i.dims[0]!==p+c+h)throw Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let f=0;if(s){if(c!==h)throw Error('Input "past" expect k_hidden_size == v_hidden_size');if(5!==s.dims.length)throw Error('Input "past" must have 5 dimensions');if(2!==s.dims[0])throw Error('Input "past" first dimension must be 2');if(s.dims[1]!==u)throw Error('Input "past" second dimension must be batch_size');if(s.dims[2]!==t.numHeads)throw Error('Input "past" third dimension must be num_heads');if(s.dims[4]!==c/t.numHeads)throw Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(f=s.dims[3])}let g=l+f;if(o)throw Error("Mask not supported");if(s)throw Error("past is not supported");if(a){if(4!==a.dims.length)throw Error('Input "attention_bias" must have 4 dimensions');if(a.dims[0]!==u||a.dims[1]!==t.numHeads||a.dims[2]!==l||a.dims[3]!==g)throw Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:u,sequenceLength:l,pastSequenceLength:f,kvSequenceLength:l,totalSequenceLength:g,maxSequenceLength:-1,inputHiddenSize:d,hiddenSize:p,vHiddenSize:h,headSize:Math.floor(p/t.numHeads),vHeadSize:Math.floor(h/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:0,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}})(e.inputs,t),[d,p,c]=(r=[l.batchSize,l.numHeads,l.sequenceLength,l.headSize],n=l.sequenceLength,i=l.inputHiddenSize,o=l.headSize,s={x:Math.ceil(l.headSize/12),y:Math.ceil(l.sequenceLength/12),z:l.batchSize*l.numHeads},a=[e.inputs[0],e.inputs[1],e.inputs[2]],u=[{type:12,data:n},{type:12,data:i},{type:12,data:o},{type:12,data:l.numHeads},{type:12,data:l.headSize},{type:12,data:l.hiddenSize},{type:12,data:l.hiddenSize+l.hiddenSize+l.vHiddenSize}],e.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0},{dims:r,dataType:e.inputs[0].dataType,gpuDataType:0}],dispatchGroup:s,programUniforms:u}),getShaderSource:e=>{let t=sx("output_q",a[0].dataType,r),n=sx("output_k",a[0].dataType,r),i=sx("output_v",a[0].dataType,r),o=sv("input",a[0].dataType,a[0].dims),s=sv("weight",a[1].dataType,a[1].dims),u=sv("bias",a[2].dataType,a[2].dims),l=o.type.storage;return`
  const TILE_SIZE = 12u;
  var<workgroup> tileInput: array<${l}, 144>;
  var<workgroup> tileWeightQ: array<${l}, 144>;
  var<workgroup> tileWeightK: array<${l}, 144>;
  var<workgroup> tileWeightV: array<${l}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}]).declareVariables(o,s,u,t,n,i)}
  ${e.mainStart([12,12,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${l}(0);
    var valueK = ${l}(0);
    var valueV = ${l}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`}},{inputs:a,outputs:[-1,-1,-1]}));return ar(e,d,p,c,e.inputs[4],void 0,void 0,void 0,e.inputs[5],l)}}}),fz=dQ({"web/lib/wasm/jsep/webgpu/ops/batch-norm.ts"(){"use strict";ph(),fb(),fv(),fS(),fO(),ai=(e,t)=>{let r,{inputs:n,outputCount:i}=e,o=(r={...t,outputCount:i},su(r));if(l.webgpu.validateInputContent&&((e,t)=>{if(!e||5!==e.length)throw Error("BatchNormalization requires 5 inputs");let r=(e,t,r)=>{let n=t.length;if(n!==e.length)throw Error(`${r}: num dimensions != ${n}`);t.forEach((t,n)=>{if(t!==e[n])throw Error(`${r}: dim[${n}] do not match`)})};if(e[0].dims.length>1){let n="NHWC"===t.format?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,n,"Invalid input scale"),r(e[2].dims,n,"Invalid input B"),r(e[3].dims,n,"Invalid input mean"),r(e[4].dims,n,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")})(n,o),t.trainingMode)throw Error("BatchNormalization trainingMode is not supported yet.");e.compute(((e,t)=>{let{epsilon:r,spatial:n,format:i}=t,o=e[0].dims,s=n?sf(o[o.length-1]):1,a="NHWC"===i&&o.length>1?s:1,u=oG.size(o)/s,l=n?o.length:o,d=sv("x",e[0].dataType,e[0].dims,s),p=sv("scale",e[1].dataType,e[1].dims,a),c=sv("bias",e[2].dataType,e[2].dims,a),h=sv("inputMean",e[3].dataType,e[3].dims,a),f=sv("inputVar",e[4].dataType,e[4].dims,a),g=sx("y",e[0].dataType,l,s);return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${n}_${s}`,inputDependencies:n?["rank","type","type","type","type"]:void 0},getShaderSource:e=>`
  const epsilon = ${r};
  ${e.registerUniform("outputSize","u32").declareVariables(d,p,c,h,f,g)}
  ${e.mainStart()}
  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${g.offsetToIndices(`global_idx * ${s}`)};
    ${(()=>{let e="";if(n)e=`let cOffset = ${1===o.length?"0u":"NHWC"===i?`outputIndices[${o.length-1}] / ${s}`:"outputIndices[1]"};`;else if("NCHW"===i)e=`
            ${g.indicesSet("outputIndices","0","0")}
            let cOffset = ${g.indicesToOffset("outputIndices")};`;else{e=`var cIndices = ${p.type.indices}(0);
                       cIndices[0] = outputIndices[${o.length-1}];`;for(let t=1;t<p.rank;t++)e+=`cIndices[${t}] = outputIndices[${t}];`;e+=`let cOffset = ${p.indicesToOffset("cIndices")};`}return e})()}
    let scale = ${p.getByOffset("cOffset")};
    let bias = ${c.getByOffset("cOffset")};
    let inputMean = ${h.getByOffset("cOffset")};
    let inputVar = ${f.getByOffset("cOffset")};
    let x = ${d.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${g.setByOffset("global_idx","value")}
  }`,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:n?[{type:12,data:u},...sh(o)]:[{type:12,data:u}]})}})(n,o))}}}),fC=dQ({"web/lib/wasm/jsep/webgpu/ops/bias-add.ts"(){"use strict";fv(),fO(),ao=e=>{let t,r,n,i,o,s,a,u;var l,d=e.inputs;if(3!==d[0].dims.length)throw Error("input should have 3 dimensions");if(![320,640,1280].includes(d[0].dims[2]))throw Error("number of channels should be 320, 640 or 1280");if(1!==d[1].dims.length)throw Error("bias is expected to have 1 dimensions");if(d[0].dims[2]!==d[1].dims[0])throw Error("last dimension of input and bias are not the same");e.compute((t=(l=e.inputs)[0].dims,r=l[0].dims[2],n=oG.size(t)/4,i=l[0].dataType,o=sv("input",i,t,4),s=sv("bias",i,[r],4),a=sv("residual",i,t,4),u=sx("output",i,t,4),{name:"BiasAdd",getRunData:()=>({outputs:[{dims:t,dataType:l[0].dataType}],dispatchGroup:{x:Math.ceil(n/64)}}),getShaderSource:e=>`
  const channels = ${r}u / 4;
  ${e.declareVariables(o,s,a,u)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes(n)}
    let value = ${o.getByOffset("global_idx")}
      + ${s.getByOffset("global_idx % channels")} + ${a.getByOffset("global_idx")};
    ${u.setByOffset("global_idx","value")}
  }`}))}}}),fN=dQ({"web/lib/wasm/jsep/webgpu/ops/unary-op.ts"(){"use strict";fb(),fv(),fS(),fO(),as=(e,t,r,n,i,o=e.dataType,s,a)=>{let u=[{type:12,data:Math.ceil(oG.size(e.dims)/4)}];return s&&u.push(...s),{name:t,shaderCache:{hint:i,inputDependencies:["type"]},getShaderSource:t=>{var i,s;let u,l,d,p,c;return i=oG.size(e.dims),s=e.dataType,u=Math.ceil(i/4),l="",l="string"==typeof r?`${r}(a)`:r("a"),d=sv("inputData",s,[u],4),p=sx("outputData",o,[u],4),c=[{name:"vec_size",type:"u32"}],a&&c.push(...a),`
      ${t.registerUniforms(c).declareVariables(d,p)}

  ${n??""}

  ${t.mainStart()}
    ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${d.getByOffset("global_idx")};
    ${p.setByOffset("global_idx",l)}
  }`},getRunData:t=>({outputs:[{dims:e.dims,dataType:o}],dispatchGroup:{x:Math.ceil(oG.size(t[0].dims)/64/4)},programUniforms:u})}},aa=e=>{e.compute(as(e.inputs[0],"Abs","abs"))},au=e=>{e.compute(as(e.inputs[0],"Acos","acos"))},al=e=>{e.compute(as(e.inputs[0],"Acosh","acosh"))},ad=e=>{e.compute(as(e.inputs[0],"Asin","asin"))},ap=e=>{e.compute(as(e.inputs[0],"Asinh","asinh"))},ac=e=>{e.compute(as(e.inputs[0],"Atan","atan"))},ah=e=>{e.compute(as(e.inputs[0],"Atanh","atanh"))},af=e=>su(e),ag=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(as(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},am=(e,t)=>{let r=t||(e=>{let t,r,n=e.length>=2&&0!==e[1].data,i=e.length>=3&&0!==e[2].data;switch(e[0].dataType){case 1:t=n?e[1].getFloat32Array()[0]:-34028234663852886e22,r=i?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=n?e[1].getUint16Array()[0]:64511,r=i?e[2].getUint16Array()[0]:31743;break;default:throw Error("Unsupport data type")}return su({min:t,max:r})})(e.inputs),n=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"Clip",e=>`clamp(${e}, vec4<${n}>(uniforms.min), vec4<${n}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:n},{name:"max",type:n}]),{inputs:[0]})},ab=e=>{e.compute(as(e.inputs[0],"Ceil","ceil"))},ay=e=>{e.compute(as(e.inputs[0],"Cos","cos"))},a_=e=>{e.compute(as(e.inputs[0],"Cosh","cosh"))},av=e=>su(e),ax=(e,t)=>{let r=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"Elu",e=>`elu_vf32(${e})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},aw=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,a$=e=>{let t=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"Erf",e=>`erf_vf32(${e})`,aw(t)))},aT=e=>{e.compute(as(e.inputs[0],"Exp","exp"))},aI=e=>{e.compute(as(e.inputs[0],"Floor","floor"))},aS=e=>{let t=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"Gelu",e=>`0.5 * ${e} * (1.0 + erf_vf32(${e} * 0.7071067811865475))`,aw(t)))},aO=(e,t)=>{let r=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"LeakyRelu",e=>`select(leaky_relu_alpha_ * ${e}, ${e}, ${e} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},aE=e=>{e.compute(as(e.inputs[0],"Not",e=>`!${e}`))},aP=e=>{e.compute(as(e.inputs[0],"Neg",e=>`-${e}`))},ak=e=>{e.compute(as(e.inputs[0],"Reciprocal",e=>`1.0/${e}`))},aA=e=>{let t=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"Relu",e=>`select(vec4<${t}>(0.0), ${e}, ${e} > vec4<${t}>(0.0))`))},aD=e=>{e.compute(as(e.inputs[0],"Sigmoid",e=>`(1.0 / (1.0 + exp(-${e})))`))},az=e=>su(e),aC=(e,t)=>{let r=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"HardSigmoid",e=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${e} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},aN=e=>{let t=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"HardSwish",e=>`${e} * max(vec4<${t}>(0.0), min(vec4<${t}>(1.0), vec4<${t}>(${t}(1.0 / 6.0)) * ${e} + vec4<${t}>(0.5)))`))},aj=e=>{e.compute(as(e.inputs[0],"Sin","sin"))},aR=e=>{e.compute(as(e.inputs[0],"Sinh","sinh"))},aB=e=>{e.compute(as(e.inputs[0],"Sqrt","sqrt"))},aM=e=>{e.compute(as(e.inputs[0],"Tan","tan"))},aF=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,aL=e=>{e.compute(as(e.inputs[0],"Tanh",aF))},aV=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${aF("v")};
}
`,aU=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,aq=e=>{let t=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"FastGelu",aU,aV(t),void 0,e.inputs[0].dataType))},aG=(e,t)=>{let r=sc(e.inputs[0].dataType);return e.compute(as(e.inputs[0],"ThresholdedRelu",e=>`select(vec4<${r}>(0.0), ${e}, ${e} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},aH=e=>{e.compute(as(e.inputs[0],"Log","log"))},aW=e=>`quick_gelu_impl(${e})`,aK=(e,t)=>{let r,n=sc(e.inputs[0].dataType);e.compute(as(e.inputs[0],"QuickGelu",aW,(r=t.alpha,`
const alpha = vec4<${n}>(${r});
const one = ${n}(1.0);
const zero = ${n}(0.0);

fn quick_gelu_impl(x: vec4<${n}>) -> vec4<${n}> {
  let v = x *alpha;
  var x1 : vec4<${n}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`),t.cacheKey,e.inputs[0].dataType))}}}),fj=dQ({"web/lib/wasm/jsep/webgpu/ops/bias-split-gelu.ts"(){"use strict";fv(),fO(),fN(),aX=e=>{let t,r,n,i,o,s;var a,u=e.inputs;if(3!==u[0].dims.length)throw Error("input should have 3 dimensions");if(![2560,5120,10240].includes(u[0].dims[2]))throw Error("hidden state should be 2560, 5120 or 10240");if(1!==u[1].dims.length)throw Error("bias is expected to have 1 dimensions");if(u[0].dims[2]!==u[1].dims[0])throw Error("last dimension of input and bias are not the same");e.compute(((t=(a=e.inputs)[0].dims.slice())[2]=t[2]/2,r=sv("input",a[0].dataType,a[0].dims,4),n=sv("bias",a[0].dataType,[a[0].dims[2]],4),i=sx("output",a[0].dataType,t,4),o=oG.size(t)/4,s=sp(a[0].dataType),{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:t,dataType:a[0].dataType}],dispatchGroup:{x:Math.ceil(o/64)}}),getShaderSource:e=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${a[0].dims[2]/4/2}u;

  ${e.declareVariables(r,n,i)}

  ${aw(s)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes(o)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${i.setByOffset("global_idx","valueLeft * geluRight")}
  }`}))}}}),fR=dQ({"web/lib/wasm/jsep/webgpu/ops/binary-op.ts"(){"use strict";fb(),fv(),fO(),aZ=(e,t,r,n,i,o)=>{e.compute(((e,t,r,n,i,o,s=r.dataType)=>{let a=r.dims.map(Number),u=n.dims.map(Number),l=!oG.areEqual(a,u),d=a,p=oG.size(a),c=!1,h=!1,f=[l];if(l){let e=oq.calcShape(a,u,!1);if(!e)throw Error("Can't perform binary op on the given tensors");d=e.slice(),p=oG.size(d);let t=1===oG.size(a),r=1===oG.size(u),n=a.length>0&&a[a.length-1]%4==0,i=u.length>0&&u[u.length-1]%4==0;f.push(t),f.push(r),f.push(n),f.push(i);let o=1;for(let e=1;e<d.length;e++){let t=a[a.length-e];if(t===u[u.length-e])o*=t;else break}o%4==0?(h=!0,c=!0):(t||r||n||i)&&(c=!0)}else c=!0;return f.push(c),{name:e,shaderCache:{hint:t+f.map(e=>e.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:e=>((e,t,r,n,i,o,s,a,u,l,d,p)=>{let c,h,f;"string"==typeof a?c=h=(e,t)=>`${a}((${e}),(${t}))`:"function"==typeof a?c=h=a:(c=a.scalar,h=a.vector);let g=sx("outputData",d,n.length,4),m=sv("aData",u,t.length,4),b=sv("bData",l,r.length,4);if(i)if(o){let e=1===oG.size(t),n=1===oG.size(r),i=t.length>0&&t[t.length-1]%4==0,o=r.length>0&&r[r.length-1]%4==0;f=e||n?g.setByOffset("global_idx",h(e?`${m.type.value}(${m.getByOffset("0")}.x)`:m.getByOffset("global_idx"),n?`${b.type.value}(${b.getByOffset("0")}.x)`:b.getByOffset("global_idx"))):`
            let outputIndices = ${g.offsetToIndices("global_idx * 4u")};
            let offsetA = ${m.broadcastedIndicesToOffset("outputIndices",g)};
            let offsetB = ${b.broadcastedIndicesToOffset("outputIndices",g)};
            ${g.setByOffset("global_idx",h(s||i?m.getByOffset("offsetA / 4u"):`${m.type.value}(${m.getByOffset("offsetA / 4u")}[offsetA % 4u])`,s||o?b.getByOffset("offsetB / 4u"):`${b.type.value}(${b.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else f=g.setByOffset("global_idx",h(m.getByOffset("global_idx"),b.getByOffset("global_idx")));else{if(!o)throw Error("no necessary to use scalar implementation for element-wise binary op implementation.");let e=(e,t,r="")=>{let n=`aData[indexA${t}][componentA${t}]`,i=`bData[indexB${t}][componentB${t}]`;return`
            let outputIndices${t} = ${g.offsetToIndices(`global_idx * 4u + ${t}u`)};
            let offsetA${t} = ${m.broadcastedIndicesToOffset(`outputIndices${t}`,g)};
            let offsetB${t} = ${b.broadcastedIndicesToOffset(`outputIndices${t}`,g)};
            let indexA${t} = offsetA${t} / 4u;
            let indexB${t} = offsetB${t} / 4u;
            let componentA${t} = offsetA${t} % 4u;
            let componentB${t} = offsetB${t} % 4u;
            ${e}[${t}] = ${r}(${c(n,i)});
          `};f=9===d?`
            var data = vec4<u32>(0);
            ${e("data",0,"u32")}
            ${e("data",1,"u32")}
            ${e("data",2,"u32")}
            ${e("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:`
            ${e("outputData[global_idx]",0)}
            ${e("outputData[global_idx]",1)}
            ${e("outputData[global_idx]",2)}
            ${e("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(m,b,g)}

        ${p??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${f}
      }`})(e,a,u,d,c,l,h,i,r.dataType,n.dataType,s,o),getRunData:()=>({outputs:[{dims:d,dataType:s}],dispatchGroup:{x:Math.ceil(p/64/4)},programUniforms:[{type:12,data:Math.ceil(oG.size(d)/4)},...sh(a,u,d)]})}})(t,i??"",e.inputs[0],e.inputs[1],r,n,o))},aJ=e=>{aZ(e,"Add",(e,t)=>`${e}+${t}`)},aQ=e=>{aZ(e,"Div",(e,t)=>`${e}/${t}`)},aY=e=>{aZ(e,"Equal",{scalar:(e,t)=>`u32(${e}==${t})`,vector:(e,t)=>`vec4<u32>(${e}==${t})`},void 0,void 0,9)},a0=e=>{aZ(e,"Mul",(e,t)=>`${e}*${t}`)},a1=e=>{let t=sv("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;aZ(e,"Pow",{scalar:(e,t)=>`pow_custom(${e},${t})`,vector:(e,t)=>`pow_vector_custom(${e},${t})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${"i32"===t?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},a2=e=>{aZ(e,"Sub",(e,t)=>`${e}-${t}`)},a3=e=>{aZ(e,"Greater",{scalar:(e,t)=>`u32(${e}>${t})`,vector:(e,t)=>`vec4<u32>(${e}>${t})`},void 0,void 0,9)},a4=e=>{aZ(e,"Less",{scalar:(e,t)=>`u32(${e}<${t})`,vector:(e,t)=>`vec4<u32>(${e}<${t})`},void 0,void 0,9)},a6=e=>{aZ(e,"GreaterOrEqual",{scalar:(e,t)=>`u32(${e}>=${t})`,vector:(e,t)=>`vec4<u32>(${e}>=${t})`},void 0,void 0,9)},a8=e=>{aZ(e,"LessOrEqual",{scalar:(e,t)=>`u32(${e}<=${t})`,vector:(e,t)=>`vec4<u32>(${e}<=${t})`},void 0,void 0,9)}}}),fB=dQ({"web/lib/wasm/jsep/webgpu/ops/concat.ts"(){"use strict";fb(),fv(),fS(),fO(),a5=(e,t)=>{let r=e.inputs,n=r[0].dims,i=oG.normalizeAxis(t.axis,n.length);if(!r||r.length<1)throw Error("too few inputs");let o=r[0],s=o.dataType,a=o.dims.length;r.forEach((e,t)=>{if(0!==t){if(e.dataType!==s)throw Error("input tensors should be one type");if(e.dims.length!==a)throw Error("input tensors should have the same shape");e.dims.forEach((e,t)=>{if(t!==i&&e!==o.dims[t])throw Error("non concat dimensions must match")})}});let u=n.slice();u[i]=r.reduce((e,t)=>e+(t.dims.length>i?t.dims[i]:0),0);let l=r.filter(e=>oG.size(e.dims)>0);e.compute(((e,t,r,n)=>{let i=oG.size(r),o=Array(e.length),s=Array(e.length),a=0,u=[],l=[],d=[{type:12,data:i}];for(let r=0;r<e.length;++r)a+=e[r].dims[t],o[r]=a,l.push(e[r].dims.length),s[r]=sv(`input${r}`,n,l[r]),u.push("rank"),d.push({type:12,data:o[r]});for(let t=0;t<e.length;++t)d.push(...sh(e[t].dims));d.push(...sh(r));let p=sx("output",n,r.length),c=p.indicesGet("indices",t),h=Array.from(Array(o.length).keys()).map(e=>`uniforms.sizeInConcatAxis${e}`).join(",");return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:r,dataType:n}],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:d}),getShaderSource:t=>{let r;return`

  ${(()=>{t.registerUniform("outputSize","u32");for(let r=0;r<e.length;r++)t.registerUniform(`sizeInConcatAxis${r}`,"u32");return t.declareVariables(...s,p)})()}

  ${r=o.length,`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${r}u>(${h});
    for (var i: u32 = 0u; i < ${r}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${r}u;
  }`}

  ${t.mainStart()}
    ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${p.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${c});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${o.length}u>(${h});
      ${c} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${((e,t)=>{let r=e.length,n=[];for(let i=0;i<r;++i){let o=t.setByOffset("global_idx",e[i].getByIndices("indices"));1===r?n.push(o):0===i?n.push(`if (inputIndex == ${i}u) { ${o} }`):i===r-1?n.push(`else { ${o} }`):n.push(`else if (inputIndex == ${i}) { ${o} }`)}return n.join("\n")})(s,p)}
  }`}}})(l,i,u,r[0].dataType),{inputs:l})},a7=e=>su({axis:e.axis})}}),fM=dQ({"web/lib/wasm/jsep/webgpu/ops/fuse-utils.ts"(){"use strict";fb(),fv(),a9=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw Error(`Unsupported activation ${e.activation}`)}},ue=(e,t)=>{"Clip"===e.activation?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):"HardSigmoid"===e.activation?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):"LeakyRelu"===e.activation&&t.push({type:1,data:e.alpha})},ut=(e,t)=>{"Clip"===e.activation?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):"HardSigmoid"===e.activation?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):"LeakyRelu"===e.activation&&t.push({name:"alpha",type:"f32"})},ur=e=>{let t=e?.activation||"";if("HardSigmoid"===t){let[r,n]=e?.activation_params||[.2,.5];return{activation:t,alpha:r,beta:n}}if("Clip"===t){let[r,n]=e?.activation_params||[oK,oX];return{activation:t,clipMax:n,clipMin:r}}if("LeakyRelu"===t){let[r]=e?.activation_params||[.01];return{activation:t,alpha:r}}return{activation:t}}}}),fF=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/activation_util.ts"(){"use strict";un=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw Error(`${e}-component is not supported.`)}},ui=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}}),fL=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/conv_util.ts"(){"use strict";uo=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}}),fV=dQ({"web/lib/wasm/jsep/webgpu/ops/matmul-shaders.ts"(){"use strict";fb(),fv(),fO(),fM(),us=(e,t,r,n,i)=>{let o=n-r;return`
      ${Array.from({length:r}).map((r,s)=>`
      if (${sy(t.shape,s,t.rank)} != 1) {
        ${t.indicesSet(e,s,sy(i,s+o,n))}
      } else {
        ${t.indicesSet(e,s,0)}
      }`).join("")}
`},ua=(e,t,r,n,i=!1,o)=>{let s=e[0].dims,a=e[1].dims,u=s[s.length-2],l=a[a.length-1],d=s[s.length-1],p=sf(l),c=sf(d),h=sf(u),f=oG.size(r)/p/h,g=e.length>2,m=n?n.slice(0,-2):r.slice(0,-2),b=[oG.size(m),u,l],y=[{type:12,data:f},{type:12,data:u},{type:12,data:l},{type:12,data:d}];return ue(t,y),y.push(...sh(m,s,a)),g&&y.push(...sh(e[2].dims)),y.push(...sh(b)),{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${p};${c};${h};${i}`,inputDependencies:g?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:o?o(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:y}),getShaderSource:n=>{let o=s$("batch_dims",e[0].dataType,m.length),u=sv("a",e[0].dataType,s.length,c),l=sv("b",e[1].dataType,a.length,p),d=sx("output",e[0].dataType,b.length,p),f=sp(d.type.tensor),y=a9(t,d.type.value,f),_=[u,l],v="";if(g){let t=i?p:1;_.push(sv("bias",e[2].dataType,e[2].dims.length,t)),v=`${i?`value += bias[col / ${t}];`:`value += ${d.type.value}(bias[row + i]);`}`}let x=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];return ut(t,x),`
  ${n.registerUniforms(x).registerInternalVariables(o).declareVariables(..._,d)}
  ${n.mainStart()}
    ${n.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${p})) * ${p};
    var index1 = global_idx / (uniforms.N / ${p});
    let stride1 = uniforms.M / ${h};
    let row = (index1 % stride1) * ${h};
    let batch = index1 / stride1;

    ${2===r.length?"":`let batch_indices = ${o.offsetToIndices("batch")};`}

    var a_indices: ${u.type.indices};
    ${us("a_indices",u,u.rank-2,o.rank,"batch_indices")}
    ${u.indicesSet("a_indices",u.rank-2,0)}
    ${u.indicesSet("a_indices",u.rank-1,0)}
    let a_offset = ${u.indicesToOffset("a_indices")};

    var b_indices: ${l.type.indices};
    ${us("b_indices",l,l.rank-2,o.rank,"batch_indices")}
    ${l.indicesSet("b_indices",l.rank-2,0)}
    ${l.indicesSet("b_indices",l.rank-1,0)}
    let b_offset = ${l.indicesToOffset("b_indices")};
    var values: array<${d.type.value}, ${h}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${c}) {
      ${(()=>{let e=`var a_data: ${u.type.value};`;for(let t=0;t<c;t++)e+=`
              let b_data${t} = b[(b_offset + (k + ${t}) * uniforms.N + col) / ${p}];`;for(let t=0;t<h;t++){e+=`a_data = a[(a_offset + (row + ${t}) * uniforms.K + k) / ${c}];`;for(let r=0;r<c;r++)e+=`
            values[${t}] = fma(${l.type.value}(a_data${1===c?"":`[${r}]`}), b_data${r}, values[${t}]);
`}return e})()}
    }
    for (var i = 0u; i < ${h}u; i++) {
      var value = values[i];
      ${v}
      ${y}
      let cur_indices = ${d.type.indices}(batch, row + i, col);
      let offset = ${d.indicesToOffset("cur_indices")};
      ${d.setByOffset(`offset / ${p}`,"value")};
    }
  }
  `}}}}}),fU=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/matmul_packed_webgpu.ts"(){"use strict";fb(),fv(),fO(),fM(),fV(),fF(),uu=(e,t,r="f32",n,i=!1,o=32,s=!1,a=32)=>{let u=t[1]*e[1],l=t[0]*e[0],d=i?u:o,p=d/t[0],c=o/t[1];if(!((i&&4===p&&4===e[1]||!i&&(3===p||4===p))&&d%t[0]==0&&o%t[1]==0&&4===e[0]))throw Error(`If transposeA ${i} is true, innerElementSize ${p} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${p} must be 3 or 4.
  tileAWidth ${d} must be divisible by workgroupSize[0]${t[0]}. tileInner ${o} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${p}<${r}>, ${d/p}>, ${i?o:u}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${l/e[0]}>, ${o}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${p};
const tileInner = ${o};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${s?"0":"i32(globalId.z)"};
  ${n?`let batchIndices = ${n.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${u};

  let num_tiles = ${s?`${Math.ceil(a/o)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${s?`i32(globalId.z) * ${a}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${c};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${i?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${n?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${n?", batchIndices":""});
        `}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${c}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${n?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${3===p?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${i?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${3===p?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${3===p?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${3===p?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},ul=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,ud=(e,t,r="f32",n,i=!1,o=32,s=!1,a=32,u=!1)=>{let l=e[1]*t[1],d=e[0]*t[0],p=i?l:o,c=i?o:l;if(c%t[1]!=0||p%t[0]!=0||o%t[1]!=0)throw Error(`tileAHight ${c} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${p} must be divisible by workgroupSize[0]${t[0]}, tileInner ${o} must be divisible by workgroupSize[1]${t[1]}`);let h=c/t[1],f=p/t[0],g=o/t[1],m=u?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${l};
    let globalColStart = i32(workgroupId.x) * ${d};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${c}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${p}; inputCol = inputCol + ${t[0]}) {
          ${ul(i,n)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${o}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${d}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${n?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${i?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${l};

let tileRowA = i32(localId.y) * ${h};
let tileColA = i32(localId.x) * ${f};
let tileRowB = i32(localId.y) * ${g};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${h}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${f}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${ul(i,n)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${g}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${n?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${i?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];"}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${p}>, ${c}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${d}>, ${o}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${o};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${s?"0":"i32(globalId.z)"};
    ${n?`let batchIndices = ${n.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${s?`${Math.ceil(a/o)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${s?`i32(globalId.z) * ${a}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${m}
  }
`},up=(e,t,r,n,i=!1,o)=>{let s=e[0].dims,a=e[1].dims,u=s.slice(0,-2),l=a.slice(0,-2),d=n?n.slice(0,-2):r.slice(0,-2),p=oG.size(d),c=s[s.length-2],h=s[s.length-1],f=a[a.length-1],g=h%4==0&&f%4==0,m=c<=8?[4,1,1]:[4,4,1],b=[8,8,1],y=[Math.ceil(f/b[0]/m[0]),Math.ceil(c/b[1]/m[1]),Math.ceil(p/b[2]/m[2])],_=g?4:1,v=[...u,c,h/_],x=v.length,w=[...l,h,f/_],$=w.length,T=[p,c,f/_],I=[{type:6,data:c},{type:6,data:f},{type:6,data:h}];ue(t,I),I.push(...sh(d,v,w));let S=["rank","rank"],O=e.length>2;return O&&(I.push(...sh(e[2].dims)),S.push("rank")),I.push(...sh(T)),{name:"MatMul",shaderCache:{hint:`${m};${t.activation};${g};${i}`,inputDependencies:S},getRunData:()=>({outputs:[{dims:o?o(r):r,dataType:e[0].dataType}],dispatchGroup:{x:y[0],y:y[1],z:y[2]},programUniforms:I}),getShaderSource:r=>{let n=d.length,o=s$("batchDims",e[0].dataType,n,1),s=sp(e[0].dataType),a=sv("a",e[0].dataType,x,_),u=sv("b",e[1].dataType,$,_),l=sx("result",e[0].dataType,T.length,_),p=[a,u];if(O){let t=i?_:1;p.push(sv("bias",e[2].dataType,e[2].dims.length,t))}let c=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];ut(t,c);let h=sp(l.type.tensor),f=((e,t,r,n,i=!1)=>{let[o,s,a,u]=n,l=sp(n[0].type.tensor);return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${o.type.indices}) -> ${un(e,l)} {
      var value = ${un(e,l)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        var aIndices: ${s.type.indices};
        ${us("aIndices",s,s.rank-2,o.rank,"batchIndices")}
        ${s.indicesSet("aIndices",s.rank-2,"u32(row)")}
        ${s.indicesSet("aIndices",s.rank-1,"u32(colIn)")}
        value = ${s.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${o.type.indices}) -> ${un(e,l)} {
      var value = ${un(e,l)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        var bIndices: ${a.type.indices};
        ${us("bIndices",a,a.rank-2,o.rank,"batchIndices")}
        ${a.indicesSet("bIndices",a.rank-2,"u32(row)")}
        ${a.indicesSet("bIndices",a.rank-1,"u32(colIn)")}
        value = ${a.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${un(e,l)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${i?"bias[colIn]":`${un(e,l)}(bias[row])`};`:""}
        ${r}
        ${u.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `})(_,O,a9(t,l.type.value,h),[o,a,u,l],i);return`
  ${r.registerUniforms(c).registerInternalVariables(o).declareVariables(...p,l)}
  ${f}
  ${g?uu(m,b,s,o):ud(m,b,s,o)}
                   `}}}}}),fq=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/conv2d_mm_webgpu.ts"(){"use strict";fb(),f_(),fO(),fM(),fF(),fL(),fU(),uc=(e,t,r,n,i,o,s,a,u)=>{let l="NHWC"===t.format,d=l?e[0].dims[3]:e[0].dims[1],p=r[0],c=l?r[2]:r[3],h=l?r[1]:r[2],f=l?r[3]:r[1],g=l&&(d%4==0||d%3==0)&&f%4==0,m=l?f:c*h,b=l?c*h:f,y=[8,8,1],_=n<=8?[4,1,1]:[4,4,1],v=[Math.ceil(m/y[0]/_[0]),Math.ceil(b/y[1]/_[1]),Math.ceil(p/y[2]/_[2])];oV("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${v}`);let x=g?l&&d%4!=0?3:4:1,w=y[1]*_[1],$=y[0]*_[0],T=Math.max(y[0]*x,y[1]),I=n%w==0,S=i%$==0,O=o%T==0,E=g?[x,4,4]:[1,1,1],P=[{type:6,data:n},{type:6,data:i},{type:6,data:o},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];ue(t,P),P.push(...sh(e[0].dims,e[1].dims));let k=["rank","rank"];return s&&(P.push(...sh(e[2].dims)),k.push("rank")),P.push(...sh(r)),{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${x};${g};${I};${S};${O};${w};${$};${T}`,inputDependencies:k},getRunData:()=>({outputs:[{dims:u?u(r):r,dataType:e[0].dataType}],dispatchGroup:{x:v[0],y:v[1],z:v[2]},programUniforms:P}),getShaderSource:n=>{let i=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];ut(t,i);let o=g?4:1,u=sp(e[0].dataType),d=`
      fn setOutputAtIndex(flatIndex : i32, value : ${g?`vec4<${u}>`:u}) {
        result[flatIndex] = ${g?`vec4<${u}>`:u}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${g?`vec4<${u}>`:u}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${g?"/ 4":""}, value);
      }`,p=[sv("x",e[0].dataType,e[0].dims.length,3===x?1:x),sv("w",e[1].dataType,e[1].dims.length,o)],c=sx("result",e[0].dataType,r.length,o);if(s){let t=sv("bias",e[2].dataType,e[2].dims.length,o);p.push(t),d+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${g?`vec4<${u}>`:u} {
          return bias[coords.${l?"w":"y"}${g?"/ 4":""}];
        }`}return`
        ${uo("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${n.registerUniforms(i).declareVariables(...p,c)}
        ${d}
        ${((e,t,r,n,i=!1,o,s=4,a=4,u=4,l="f32")=>{let d=e=>{switch(e){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw Error(`innerElementSize ${e} is not supported.`)}},p=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,c=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,h=e?"row":"col",f=e?"col":"row",g=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${h} / outWidth;
    let outCol = ${h} % outWidth;

    let WRow = ${f} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${f} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${f} % inChannels;
    var resData = ${un(s,l)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])"} && xCol >= 0 && xCol < ${e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])"}) {
      ${p}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${(e=>{switch(e){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${l}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw Error(`innerElementSize ${e} is not supported.`)}})(s)}
    }
    return resData;`,m=e?t&&n?`
    let col = colIn * ${s};
    ${g}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${g}
    }
    return ${un(s,l)}(0.0);`:n&&r?`
    let col = colIn * ${s};
    ${g}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${g}
    }
    return ${un(s,l)}(0.0);`,b=e?n&&r?d(a):`
    let col = colIn * ${a};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${d(a)}
    }
    return ${un(a,l)}(0.0);`:`
    let col = colIn * ${a};
    if (row < uniforms.dim_inner && col < uniforms.dim_a_outer) {
      ${d(a)}
    }
    return ${un(a,l)}(0.0);`,y=un(u,l),_=e?un(s,l):un(a,l),v=e?un(a,l):un(s,l),x=a9(o,y,l);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${_} {
      ${e?m:b}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${v} {
      ${e?b:m}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${y}) {
      let col = colIn * ${u};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${c}
      ${ui(i)}
      ${x}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`})(l,I,S,O,s,t,E[0],E[1],E[2],u)}
        ${g?uu(_,y,u,void 0,!l,T):ud(_,y,u,void 0,!l,T,!1,void 0,a)}`}}}}}),fG=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/conv3d_naive_webgpu.ts"(){"use strict";fb(),f_(),fv(),fO(),fM(),fF(),uh=e=>"number"==typeof e?[e,e,e]:e,uf=(e,t)=>t<=1?e:e+(e-1)*(t-1),ug=(e,t,r,n,i)=>{null==i&&(i=((e,t,r,n=1)=>{let i=uf(t,n);return Math.floor((e[0]*(r-1)-r+i)/2)})(e,t[0],n[0]));let o=[0,0,0,r];for(let r=0;r<3;r++)e[r]+2*i>=t[r]&&(o[r]=Math.trunc((e[r]-t[r]+2*i)/n[r]+1));return o},um=(e,t,r,n,i,o=!1,s="channelsLast")=>{let a,u,l,d,p;if("channelsLast"===s)[a,u,l,d,p]=e;else if("channelsFirst"===s)[a,p,u,l,d]=e;else throw Error(`Unknown dataFormat ${s}`);let[c,,h,f,g]=t,[m,b,y]=uh(r),[_,v,x]=uh(n),w=uf(h,_),$=uf(f,v),T=uf(g,x),{padInfo:I,outDepth:S,outHeight:O,outWidth:E}=((e,t,r,n,i,o,s,a,u,l)=>{let d,p,c,h;if("VALID"===e&&(e=0),"number"==typeof e){d={top:e,bottom:e,left:e,right:e,front:e,back:e};let f=ug([t,r,n,1],[a,u,l],1,[i,o,s],e);p=f[0],c=f[1],h=f[2]}else if(Array.isArray(e)){if(!e.every((e,t,r)=>e===r[0]))throw Error(`Unsupported padding parameter: ${e}`);d={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let f=ug([t,r,n,1],[a,u,l],1,[i,o,s],e[0]);p=f[0],c=f[1],h=f[2]}else if("SAME_UPPER"===e){let e=((p=Math.ceil(t/i))-1)*i+a-t,f=((c=Math.ceil(r/o))-1)*o+u-r,g=((h=Math.ceil(n/s))-1)*s+l-n,m=Math.floor(e/2),b=Math.floor(f/2),y=Math.floor(g/2);d={top:b,bottom:f-b,left:y,right:g-y,front:m,back:e-m}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:d,outDepth:p,outHeight:c,outWidth:h}})(i,u,l,d,m,b,y,w,$,T),P=o?c*p:c,k=[0,0,0,0,0];return"channelsFirst"===s?k=[a,P,S,O,E]:"channelsLast"===s&&(k=[a,S,O,E,P]),{batchSize:a,dataFormat:s,inDepth:u,inHeight:l,inWidth:d,inChannels:p,outDepth:S,outHeight:O,outWidth:E,outChannels:P,padInfo:I,strideDepth:m,strideHeight:b,strideWidth:y,filterDepth:h,filterHeight:f,filterWidth:g,effectiveFilterDepth:w,effectiveFilterHeight:$,effectiveFilterWidth:T,dilationDepth:_,dilationHeight:v,dilationWidth:x,inShape:e,outShape:k,filterShape:t}},ub=(e,t,r,n,i,o)=>{let s="channelsLast"===o,a=(s?e[0].dims[3]:e[0].dims[1],[Math.ceil((e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t})(({x:r.map((e,t)=>t)}).x.map(e=>r[e]))/64),1,1]);oV("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${a}`);let u=[{type:12,data:oG.size(r)},{type:12,data:n},{type:12,data:i},{type:12,data:t.strides},{type:12,data:t.dilations}];ue(t,u),u.push(...sh(e[0].dims,e[1].dims));let l=["rank","rank"],d=3===e.length;return d&&(u.push(...sh(e[2].dims)),l.push("rank")),u.push(...sh(r)),{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${s};1;${d}`,inputDependencies:l},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:a[0],y:a[1],z:a[2]},programUniforms:u}),getShaderSource:o=>{let a=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:n.length},{name:"pads",type:"u32",length:i.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];ut(t,a);let u=sp(e[0].dataType),l=sv("x",e[0].dataType,e[0].dims.length,1),p=sv("W",e[1].dataType,e[1].dims.length,1),c=[l,p],h=sx("result",e[0].dataType,r.length,1),f="";if(d){let t=sv("bias",e[2].dataType,e[2].dims.length,1);c.push(t),f+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${u} {
          return bias[${s?sy("coords",4,5):sy("coords",1,5)}];
        }`}let g=un(1,u),m=a9(t,g,u);return`
            ${f}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> ${u} {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${l.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> ${u} {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${p.getByIndices("aIndices")};
            }
          ${o.registerUniforms(a).declareVariables(...c,h)}
          ${o.mainStart()}
          ${o.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${h.offsetToIndices("global_idx")};
              let batch = ${sy("coords",0,l.rank)};
              let d2 = ${s?sy("coords",l.rank-1,l.rank):sy("coords",1,l.rank)};
              let xFRCCorner = vec3<u32>(${s?sy("coords",1,l.rank):sy("coords",2,l.rank)},
              ${s?sy("coords",2,l.rank):sy("coords",3,l.rank)},
              ${s?sy("coords",3,l.rank):sy("coords",4,l.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${s?sy("uniforms.x_shape",1,l.rank):sy("uniforms.x_shape",2,l.rank)};
              let xShapeZ = ${s?sy("uniforms.x_shape",2,l.rank):sy("uniforms.x_shape",3,l.rank)};
              let xShapeW = ${s?sy("uniforms.x_shape",3,l.rank):sy("uniforms.x_shape",4,l.rank)};
              let xShapeU = ${s?sy("uniforms.x_shape",4,l.rank):sy("uniforms.x_shape",1,l.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = ${u}(0);
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${s?`let xValues = vec4<${u}>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<${u}>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<${u}>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${s?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${s?`let xValues = vec2<${u}>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<${u}>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<${u}>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${s?`let xValues = vec3<${u}>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<${u}>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<${u}>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${d?"value = value + getBiasByOutputCoords(coords)":""};
              ${m}
              result[global_idx] = ${u}(value);
          }`}}}}}),fH=dQ({"web/lib/wasm/jsep/webgpu/ops/conv-grouped.ts"(){"use strict";fb(),fv(),fO(),fM(),uy=(e,t,r,n)=>{let i=e.length>2,o=i?"value += b[output_channel];":"",s=e[0].dims,a=e[1].dims,u="NHWC"===t.format,l=u?r[3]:r[1],d=l/t.group,p=u&&d>=4?sf(l):1,c=oG.size(r)/p,h=[{type:12,data:c},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:d}];return ue(t,h),h.push(...sh(s,[a[0],a[1],a[2],a[3]/p])),h.push(...sh([r[0],r[1],r[2],r[3]/p])),{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${p}`,inputDependencies:i?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(c/64)},programUniforms:h}),getShaderSource:n=>{let l=sx("output",e[0].dataType,r.length,p),d=sp(l.type.tensor),c=a9(t,l.type.value,d),h=sv("x",e[0].dataType,s.length),f=sv("w",e[1].dataType,a.length,p),g=[h,f];i&&g.push(sv("b",e[2].dataType,e[2].dims,p));let m=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];ut(t,m);let b=u?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${h.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${f.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${h.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${f.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${n.registerUniforms(m).declareVariables(...g,l)}

  ${n.mainStart()}
    ${n.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${l.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${u?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${u?1:2}], outputIndices[${u?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${p} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${u?2:1}];

    var value: ${l.type.value} = ${l.type.value}(0);
    ${b}
    ${o}
    ${c}
    ${l.setByOffset("global_idx","value")}
  }`}}},u_=(e,t,r,n)=>{let i=e.length>2,o=sf(r[3]),s=sf(r[2]),a=oG.size(r)/o/s,u=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/o],l=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/o],d=[r[0],r[1],r[2],r[3]/o],p=[{type:12,data:a},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];ue(t,p),p.push(...sh(u,l,d));let c=(s-1)*t.strides[1]+l[1];return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${o};${s};${c};${l[0]};${l[1]}`,inputDependencies:i?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:p}),getShaderSource:r=>{let n=sx("output",e[0].dataType,d.length,o),a=sp(n.type.tensor),p=a9(t,n.type.value,a),h=sv("x",e[0].dataType,u.length,o),f=sv("w",e[1].dataType,l.length,o),g=[h,f];i&&g.push(sv("b",e[2].dataType,e[2].dims,o));let m=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return ut(t,m),`
  ${r.registerUniforms(m).declareVariables(...g,n)}
  ${r.mainStart()}
    ${r.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${s}u;
    let col = (index1 % width1) * ${s}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${h.type.value}, ${c}>;
    var values: array<${n.type.value}, ${s}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${l[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${c}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${h.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${h.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${l[1]}; w_width++) {
          let w_val = ${f.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${s}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${s}u; i++) {
      var value = values[i];
      ${i?"value += b[output_channel];":""}
      ${p}
      ${n.set("batch","row","col + i","output_channel","value")};
    }
  }`}}}}}),fW=dQ({"web/lib/wasm/jsep/webgpu/ops/conv.ts"(){"use strict";fv(),fq(),fG(),fU(),fH(),fM(),fV(),fE(),uv=[2,3,1,0],ux=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let e=2;e<t[1].dims.length;++e)0===r[e-2]&&(r[e-2]=t[1].dims[e]);let n=e.pads.slice();oH.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,n,"NHWC"===e.format,e.autoPad);let i=Object.assign({},e);return Object.assign(i,{kernelShape:r,pads:n}),i},uw=e=>{let t=ur(e),r=e.format,n=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],i=e.dilations,o=e.group,s=e.kernel_shape,a=e.pads;return{autoPad:n,format:r,dilations:i,group:o,kernelShape:s,pads:a,strides:e.strides,wIsConst:e.w_is_const(),...t,cacheKey:`${e.format};${t.activation};`}},u$=(e,t,r,n)=>{var i,o,s,a,u;let l,d,p,c,h,f,g="NHWC"===r.format,m=(i=t[0].dims,o=t[1].dims,s=r.dilations,a=r.pads,u=r.strides,l=i[0],p=(d=i.slice(g?1:2,g?3:4)).length,c=o[0],h=o.slice(2).map((e,t)=>e+(e-1)*(s[t]-1)),(f=d.map((e,t)=>e+a[t]+a[t+p]).map((e,t)=>Math.floor((e-h[t]+u[t])/u[t]))).splice(0,0,l),f.splice(g?3:1,0,c),f);if(1!==r.group){let i=[t[0]];if(g){let n=e.kernelCustomData.wT??e.compute(sO(t[1],uv),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=n),i.push(n)}else i.push(t[1]);3===t.length&&i.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&g&&t[1].dims[0]===r.group&&1===t[1].dims[1]&&1===r.dilations[0]&&1===r.dilations[1]?e.compute(u_(i,r,m,n),{inputs:i}):e.compute(uy(i,r,m,n),{inputs:i});return}let b=3===t.length,y=t[0].dims[g?1:2],_=t[0].dims[g?2:3],v=t[0].dims[g?3:1],x=t[1].dims[2],w=t[1].dims[3],$=m[g?1:2],T=m[g?2:3],I=m[g?3:1],S=g&&x===y&&w===_&&0===r.pads[0]&&0===r.pads[1];if(S||1===x&&1===w&&1===r.dilations[0]&&1===r.dilations[1]&&1===r.strides[0]&&1===r.strides[1]&&0===r.pads[0]&&0===r.pads[1]){let i,o,s,a=m[0],u=[];if(g){let n=e.kernelCustomData.wT??e.compute(sO(t[1],uv),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=n),S){let e=y*_*v;i=t[0].reshape([1,a,e]),o=n.reshape([1,e,I]),s=[1,a,I]}else i=t[0].reshape([a,y*_,v]),o=n.reshape([1,v,I]),s=[a,$*T,I];u.push(i),u.push(o)}else i=t[0].reshape([a,v,y*_]),o=t[1].reshape([1,I,v]),s=[a,I,$*T],u.push(o),u.push(i);b&&u.push(t[2]);let l=s[2],d=u[0].dims[u[0].dims.length-1];l<8&&d<8?e.compute(ua(u,r,m,s,g,n),{inputs:u}):e.compute(up(u,r,m,s,g,n),{inputs:u});return}let O=e.kernelCustomData.wT??e.compute(sO(t[1],uv),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=O);let E=[t[0],O];b&&E.push(t[2]);let P=g?$*T:I,k=g?I:$*T,A=x*w*v;e.compute(uc(E,r,m,P,k,A,b,!0,n),{inputs:E})},uT=(e,t)=>{var r,n=e.inputs;if(!n||2!==n.length&&3!==n.length)throw Error("Conv requires 2 or 3 inputs");if(n[0].dims.length>5)throw Error("greater than 5D is not supported");if(n[0].dims.length!==n[1].dims.length)throw Error("filter does not have same dimension as input");if(n[0].dims["NHWC"===t.format?n[0].dims.length-1:1]!==n[1].dims[1]*t.group)throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(3===n.length&&(1!==n[2].dims.length||n[1].dims[0]!==n[2].dims[0]))throw Error("invalid bias");let i=n[0].dims.length-2;if(t.dilations.length!==i)throw Error(`dilations should be ${i}D`);if(t.strides.length!==i)throw Error(`strides should be ${i}D`);if(t.pads.length!==2*i)throw Error(`pads should be ${2*i}D`);if(0!==t.kernelShape.length&&t.kernelShape.length!==n[1].dims.length-2)throw Error("invalid kernel shape");if(3===e.inputs[0].dims.length){let r,n,i,o,s,a,u;r="NHWC"===t.format,n=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])],3===e.inputs.length&&n.push(e.inputs[2]),i=[0,t.pads[0],0,t.pads[1]],o=[1].concat(t.strides),s=[1].concat(t.dilations),a=[1].concat(t.kernelShape),u=ux({...t,pads:i,strides:o,dilations:s,kernelShape:a},n),u$(e,n,u,e=>r?[e[0],e[2],e[3]]:[e[0],e[1],e[3]])}else if(5===e.inputs[0].dims.length){let n,i,o,s;r=e.inputs,n="NHWC"===t.format?"channelsLast":"channelsFirst",i=ux(t,r),o="NOTSET"===t.autoPad?t.pads:t.autoPad,s=um(r[0].dims,r[1].dims,t.strides,t.dilations,o,!1,n),e.compute(ub(r,i,s.outShape,[s.filterDepth,s.filterHeight,s.filterWidth],[s.padInfo.front,s.padInfo.top,s.padInfo.left],n))}else{let r=ux(t,e.inputs);u$(e,e.inputs,r)}}}}),fK=dQ({"web/lib/wasm/jsep/webgpu/ops/3rd-party/conv_backprop_webgpu.ts"(){"use strict";fb(),f_(),fv(),fO(),uI=(e,t,r)=>{let n=e.length>2,i=t.outputShape,o="NHWC"===t.format,s=t.group,a=e[1].dims,u=a[2]/s,l=a[3],d=o?sf(u):1,p=o&&1===l&&u>=4,c=p?4*Math.floor(u/4):Math.floor(u/d)*d,h=u-c,f=o?sf(l):1,g=o?1===l?d:f:1,m=oG.size(i)/f,b=[Math.ceil(m/64),1,1];oV("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${b}`);let y=["rank","rank"],_=[t.strides[0],t.strides[1]],v=[t.kernelShape[o?1:2],t.kernelShape[o?2:3]],x=[t.dilations[0],t.dilations[1]],w=[v[0]+(t.dilations[0]<=1?0:(t.kernelShape[o?1:2]-1)*(t.dilations[0]-1)),v[1]+(t.dilations[1]<=1?0:(t.kernelShape[o?2:3]-1)*(t.dilations[1]-1))],$=[w[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),w[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],T=[{type:12,data:m},{type:12,data:_},{type:12,data:v},{type:12,data:x},{type:12,data:w},{type:6,data:$},{type:12,data:c},{type:12,data:u},{type:12,data:l},...sh(e[0].dims,e[1].dims)];return n&&(T.push(...sh(e[2].dims)),y.push("rank")),T.push(...sh(i)),{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};${d}${g}${f}${p}${h}`,inputDependencies:y},getRunData:()=>({dispatchGroup:{x:b[0],y:b[1],z:b[2]},outputs:[{dims:r?r(i):i,dataType:e[0].dataType}],programUniforms:T}),getShaderSource:t=>{let r=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:_.length},{name:"filter_dims",type:"u32",length:v.length},{name:"dilations",type:"u32",length:v.length},{name:"effective_filter_dims",type:"u32",length:w.length},{name:"pads",type:"i32",length:$.length},{name:"input_channels_per_group_int",type:"u32"},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],s=sp(e[0].dataType),a=o?1:2,u=o?2:3,l=o?3:1,c=sv("W",e[1].dataType,e[1].dims.length,g),m=sv("Dy",e[0].dataType,e[0].dims.length,d),b=[m,c];n&&b.push(sv("bias",e[2].dataType,[i[l]].length,f));let y=sx("result",e[0].dataType,i.length,f),x=`
            let outputIndices = ${y.offsetToIndices(`global_idx * ${f}`)};
            let batch = ${y.indicesGet("outputIndices",0)};
            let d1 = ${y.indicesGet("outputIndices",l)};
            let r = ${y.indicesGet("outputIndices",a)};
            let c = ${y.indicesGet("outputIndices",u)};
            let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
            let dyRCorner = dyCorner.x;
            let dyCCorner = dyCorner.y;
            let groupId = d1 / uniforms.output_channels_per_group;
            let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
            // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
            // ? = to be determined. : = across all values in that axis.
            var dotProd = ${y.type.value}(0.0);
            var wR: u32 = 0;
            if (uniforms.dilations.x == 1) {
              // Minimum wR >= 0 that satisfies (dyRCorner + wR) % (uniforms.strides.x) == 0
              wR = u32(((dyRCorner + i32(uniforms.strides.x) - 1) / i32(uniforms.strides.x)) * i32(uniforms.strides.x) - dyRCorner);
            }
            for (; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
              if (wR % uniforms.dilations.x != 0) {
                continue;
              }
              let dyR = (${s}(dyRCorner) + ${s}(wR)) / ${s}(uniforms.strides[0]);
              let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
              if (dyR < 0.0 || dyR >= ${s}(uniforms.Dy_shape[${a}]) || fract(dyR) > 0.0 ||
                  wRPerm < 0) {
                continue;
              }
              let idyR: u32 = u32(dyR);
              var wC: u32 = 0;
              if (uniforms.dilations.y == 1) {
                // Minimum wC >= 0 that satisfies (dyCCorner + wC) % (uniforms.strides.y) == 0
                wC = u32(((dyCCorner + i32(uniforms.strides.y) - 1) / i32(uniforms.strides.y)) * i32(uniforms.strides.y) - dyCCorner);
              }
              for (; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
                if (wC % uniforms.dilations.y != 0) {
                  continue;
                }
                let dyC = (${s}(dyCCorner) + ${s}(wC)) / ${s}(uniforms.strides.y);
                let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
                if (dyC < 0.0 || dyC >= ${s}(uniforms.Dy_shape[${u}]) ||
                    fract(dyC) > 0.0 || wCPerm < 0) {
                  continue;
                }
                let idyC: u32 = u32(dyC);
                var inputChannel = groupId * uniforms.input_channels_per_group;
                ${p?`
                var x_offset = ${m.indicesToOffset(`${m.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${d};
                var w_offset = ${c.indicesToOffset(`${c.type.indices}(wRPerm, wCPerm, inputChannel, wOutChannel)`)} / ${g};
                  `:""}
                for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group_int; d2 = d2 + ${p?4:d}) {
                  ${(()=>{let e="";if(p)4===d?e+=`
        let xValue = ${m.getByOffset("x_offset")};
        let wValue = ${c.getByOffset("w_offset")};
        dotProd = dotProd + dot(xValue, wValue);
        x_offset += 1u;
        w_offset += 1u;`:2===d?e+=`
          dotProd = dotProd + dot(vec4<${s}>(${m.getByOffset("x_offset")}, ${m.getByOffset("x_offset + 1u")}), vec4<${s}>(${c.getByOffset("w_offset")}, ${c.getByOffset("w_offset + 1u")}));
          x_offset += 2u;
          w_offset += 2u;`:1===d&&(e+=`
          dotProd = dotProd + dot(vec4<${s}>(${m.getByOffset("x_offset")}, ${m.getByOffset("x_offset + 1u")}, ${m.getByOffset("x_offset + 2u")}, ${m.getByOffset("x_offset + 3u")}), vec4<${s}>(${c.getByOffset("w_offset")}, ${c.getByOffset("w_offset + 1u")}, ${c.getByOffset("w_offset + 2u")}, ${c.getByOffset("w_offset + 3u")}));
          x_offset += 4u;
          w_offset += 4u;`);else if(e+=`
                  let xValue = ${o?m.getByOffset(`${m.indicesToOffset(`${m.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${d}`):m.get("batch","inputChannel","idyR","idyC")};
        `,1===d)e+=`
          let w_offset = ${c.indicesToOffset(`${c.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)};
          let wValue = ${c.getByOffset(`w_offset / ${g}`)};
          dotProd = dotProd + xValue * wValue;`;else for(let t=0;t<d;t++)e+=`
            let wValue${t} = ${c.getByOffset(`${c.indicesToOffset(`${c.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel + ${t}, wOutChannel)`)} / ${g}`)};
            dotProd = dotProd + xValue[${t}] * wValue${t};`;return e})()}
                  inputChannel = inputChannel + ${p?4:d};
                }
                ${(()=>{if(0===h)return"";if(!p)throw Error(`packInputAs4 ${p} is not true.`);let e="";if(1===d){e+="dotProd = dotProd";for(let t=0;t<h;t++)e+=`
            + ${m.getByOffset(`x_offset + ${t}`)} * ${c.getByOffset(`w_offset + ${t}`)}`;e+=";"}else if(2===d){if(2!==h)throw Error(`Invalid inputChannelsRemainder ${h}.`);e+=`
          let xValue = ${m.getByOffset("x_offset")};
          let wValue = ${c.getByOffset("w_offset")};
          dotProd = dotProd + dot(xValue, wValue);`}return e})()}
                wC = wC + uniforms.strides.y - 1;
              }
              wR = wR + uniforms.strides[0] - 1;
            }
            let value = dotProd${n?` + bias[d1 / ${f}]`:""};
            ${y.setByOffset("global_idx","value")};
          `;return`
    ${t.registerUniforms(r).declareVariables(...b,y)}
      ${t.mainStart()}
      ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
    ${x}}`}}}}}),fX=dQ({"web/lib/wasm/jsep/webgpu/ops/conv-transpose.ts"(){"use strict";fK(),fM(),fE(),uS=(e,t,r,n,i,o)=>(e-1)*t+r+(n-1)*i+1-o,uO=(e,t,r,n,i)=>{let o=Math.floor(e/2);"SAME_UPPER"===t?(r[n]=o,r[i]=e-o):"SAME_LOWER"===t&&(r[n]=e-o,r[i]=o)},uE=(e,t)=>{let r=e.kernelShape.slice();if(0===e.kernelShape.length||0===e.kernelShape.reduce((e,t)=>e*t,1)){r.length=0;for(let e=2;e<t[1].dims.length;++e)r.push(t[1].dims[e])}let n="NHWC"===e.format;r.splice(0,0,t[1].dims[0]),r.splice(n?3:1,0,t[1].dims[1]);let i=e.pads.slice(),o=e.outputShape.slice(),s=e.outputPadding.slice(),a=t[0].dims,u=e.dilations.slice();0===u.reduce((e,t)=>e+t,0)&&(u=Array(t[0].dims.length-2).fill(1));let l=e.strides.slice();0===l.reduce((e,t)=>e+t,0)&&(l=Array(t[0].dims.length-2).fill(1)),((e,t,r,n,i,o,s,a,u,l)=>{let d=e.length-2,p=0===l.length;u.length<d&&u.push(...Array(d-u.length).fill(0));let c=e[0],h=t[a?3:1]*i;for(let i=0,c=e.length-d-!!a;i<d;++i,++c){let a=e[c],h=p?a*s[i]:l[i];uO(uS(a,s[i],o[i],t[c],r[i],h),n,o,i,i+d),p&&l.push(s[i]*(a-1)+u[i]+(t[c]-1)*r[i]+1-o[i]-o[i+d])}l.splice(0,0,c),l.splice(a?3:1,0,h)})(a,r,u,e.autoPad,e.group,i,l,n,s,o);let d=Object.assign({},e);return Object.assign(d,{kernelShape:r,pads:i,outputPadding:s,outputShape:o,dilations:u,strides:l}),d},uP=e=>{let t=ur(e),r=e.format,n=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][void 0===e.autoPad?0:e.autoPad],i=e.dilations,o=e.group??1,s=e.kernelShape,a=e.pads,u=e.strides,l=e.wIsConst();return{autoPad:n,format:r,dilations:i,group:o,kernelShape:s,outputPadding:e.outputPadding,outputShape:e.outputShape,pads:a,strides:u,wIsConst:l,...t,cacheKey:`${e.format};${t.activation};`}},uk=(e,t,r,n)=>{let i=e.kernelCustomData.wT??e.compute(sO(t[1],[2,3,0,1]),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=i);let o=[t[0],i];3===t.length&&o.push(t[2]),e.compute(uI(o,r,n),{inputs:o})},uA=(e,t)=>{if(((e,t)=>{if(!e||2!==e.length&&3!==e.length)throw Error("Conv requires 2 or 3 inputs");if(4!==e[0].dims.length&&3!==e[0].dims.length)throw Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw Error("filter does not have same dimension as input");if(e[0].dims["NHWC"===t.format?e[0].dims.length-1:1]!==e[1].dims[0])throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let r=e[1].dims[1]*t.group;if(3===e.length&&(1!==e[2].dims.length||e[2].dims[0]!==r))throw Error("invalid bias");let n=e[0].dims.length-2;if(t.dilations.reduce((e,t)=>e+t,0)>0&&t.dilations.length!==n)throw Error(`dilations should be ${n}D`);if(t.strides.reduce((e,t)=>e+t,0)>0&&t.strides.length!==n)throw Error(`strides should be ${n}D`);if(t.pads.reduce((e,t)=>e+t,0)>0&&t.pads.length!==2*n)throw Error(`pads should be ${2*n}D`);if(t.outputPadding.length!==n&&0!==t.outputPadding.length)throw Error(`output_padding should be ${n}D`);if(t.kernelShape.reduce((e,t)=>e+t,0)>0&&0!==t.kernelShape.length&&t.kernelShape.length!==e[1].dims.length-2)throw Error("invalid kernel shape");if(0!==t.outputShape.length&&t.outputShape.length!==e[0].dims.length-2)throw Error("invalid output shape")})(e.inputs,t),3===e.inputs[0].dims.length){let r,n,i,o,s,a,u,l;r="NHWC"===t.format,n=[e.inputs[0].reshape(r?[e.inputs[0].dims[0],1,e.inputs[0].dims[1],e.inputs[0].dims[2]]:[e.inputs[0].dims[0],e.inputs[0].dims[1],1,e.inputs[0].dims[2]]),e.inputs[1].reshape([e.inputs[1].dims[0],e.inputs[1].dims[1],1,e.inputs[1].dims[2]])],3===e.inputs.length&&n.push(e.inputs[2]),(0===(i=t.kernelShape).length||0===i[0])&&(i=[e.inputs[1].dims[2]]),(0===(o=t.dilations).length||0===o[0])&&(o=[1]),(0===(s=t.strides).length||0===s[0])&&(s=[1]),0===(a=t.pads).length&&(a=[0,0]),a=[0,a[0],0,a[1]],s=[1].concat(s),o=[1].concat(o),i=[1].concat(i),u=[0].concat(u=t.outputPadding),l=uE({...t,pads:a,strides:s,dilations:o,kernelShape:i,outputPadding:u},n),uk(e,n,l,e=>r?[e[0],e[2],e[3]]:[e[0],e[1],e[3]])}else{let r=uE(t,e.inputs);uk(e,e.inputs,r)}}}}),fZ=dQ({"web/lib/wasm/jsep/webgpu/ops/cumsum.ts"(){"use strict";fb(),fv(),fS(),fO(),uD=(e,t)=>{let r,n,i,o,s,a,u=e.inputs[0].dims,l=e.inputs[0].dataType,d=e.inputs[1];e.compute((r=oG.size(u),n=u.length,i=sv("input",l,n),o=sx("output",l,n),s=6===d.dataType?d.getInt32Array()[0]:Number(d.getBigInt64Array()[0]),a=oG.normalizeAxis(s,n),{name:"CumSum",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:u,dataType:l}],dispatchGroup:{x:Math.ceil(r/64)},programUniforms:[{type:12,data:r},{type:12,data:a},...sh(u,u)]}),getShaderSource:e=>{let r=` i32(${i.indicesGet("inputIndices","uniforms.axis")}) `,s=sy("uniforms.input_shape","uniforms.axis",n),a=t.reverse?r+(t.exclusive?" + 1":""):"0",u=t.reverse?s:r+(t.exclusive?"":" + 1");return`
                ${e.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(i,o)}
                ${e.mainStart()}
                  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${o.offsetToIndices("global_idx")};
                  var sum = ${o.type.value}(0);
                  let first : i32 = ${a};
                  let last : i32 = ${u};
                  for (var i : i32 = first; i < last; i++) {
                    ${i.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${i.getByIndices("inputIndices")};
                  }
                  ${o.setByOffset("global_idx","sum")};
                }`}}),{inputs:[0]})},uz=e=>{let t=1===e.exclusive,r=1===e.reverse;return su({exclusive:t,reverse:r})}}}),fJ=dQ({"web/lib/wasm/jsep/webgpu/ops/depth-to-space.ts"(){"use strict";fb(),fv(),fS(),fO(),uC=(e,t)=>{let r,n,i,o,s,a,u,l,d,p,c,h,f,g;var m,b=e.inputs;if(!b||1!==b.length)throw Error("DepthToSpace requires 1 input.");if(4!==b[0].dims.length)throw Error("DepthToSpace requires 4D input.");e.compute((m=e.inputs[0],u="NHWC"===t.format,l=t.blocksize,d="DCR"===t.mode,u?([r,n,i,o]=m.dims,s=d?[r,n,i,l,l,o/l**2]:[r,n,i,o/l**2,l,l],a=d?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([r,n,i,o]=[m.dims[0],m.dims[2],m.dims[3],m.dims[1]],s=d?[r,l,l,o/l**2,n,i]:[r,o/l**2,l,l,n,i],a=d?[0,3,4,1,5,2]:[0,1,4,2,5,3]),c=(p=m.reshape(s)).dims.length,h=m.dataType,f=sv("a",h,c),g=sx("output",h,c),{name:"DepthToSpace",shaderCache:{hint:`${m.dims};${t.blocksize};${t.mode}`,inputDependencies:["rank"]},getRunData:e=>{let t=u?[r,n*l,i*l,o/l**2]:[r,o/l**2,n*l,i*l],s=oG.size(t),d=p.dims,c=oG.sortBasedOnPerm(d,a);return{outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:[{type:12,data:s},...sh(d,c)]}},getShaderSource:e=>`
  ${e.registerUniform("output_size","u32").declareVariables(f,g)}

  ${((e,t,r,n)=>{let i=[];i.push(`fn perm(i: ${n.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let n=0;n<t;++n)i.push(r.indicesSet("a",e[n],`i[${n}]`));return i.push("return a;}"),i.join("\n")})(a,c,f,g)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${g.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${g.setByOffset("global_idx",f.getByIndices("aIndices"))}
  }`}))},uN=e=>su({blocksize:e.blocksize,mode:e.mode,format:e.format})}}),fQ=dQ({"web/lib/wasm/jsep/webgpu/ops/dft.ts"(){"use strict";fb(),fv(),fS(),fO(),uj=2*Math.PI,uR=e=>{let t=[],r=e;for(let e of[4,2,3,5])for(;r%e==0;)t.push(e),r/=e;return 1===r?t:void 0},uB=e=>{let t=e.toPrecision(9);return/[.eE]/.test(t)?t:`${t}.0`},uM=(e,t,r,n,i)=>{let o=r/e,s=512-n,a=e=>`smem[${s}u + base + ${e*t}u]`,u=`  for (var t = local_idx; t < ${o}u; t += 256u) {
`;u+=`    let twiddleIndex = t % ${t}u;
    let angleUnit = f32(twiddleIndex);
    var leg: array<vec2<f32>, 5>;
`;for(let r=0;r<e;r++){let s=`${n}u + t + ${r*o}u`;if(0===r)u+=`    leg[0] = smem[${s}];
`;else{let n=i*uj*r/(e*t);u+=`    { let a = ${uB(n)} * angleUnit; leg[${r}] = cmul(smem[${s}], vec2<f32>(cos(a), sin(a))); }
`}}if(u+=`    let base = (t / ${t}u) * ${t*e}u + twiddleIndex;
`,2===e)u+=`    ${a(0)} = leg[0] + leg[1];
    ${a(1)} = leg[0] - leg[1];
`;else if(4===e)u+=`    let evenSum = leg[0] + leg[2]; let evenDiff = leg[0] - leg[2];
    let oddSum = leg[1] + leg[3]; let oddDiff = leg[1] - leg[3];
    let oddRot = ${i<0?"vec2<f32>(oddDiff.y, -oddDiff.x)":"vec2<f32>(-oddDiff.y, oddDiff.x)"};
    ${a(0)} = evenSum + oddSum;
    ${a(1)} = evenDiff + oddRot;
    ${a(2)} = evenSum - oddSum;
    ${a(3)} = evenDiff - oddRot;
`;else for(let t=0;t<e;t++){let r=["leg[0]"];for(let n=1;n<e;n++){let o=i*uj*(n*t)/e,s=uB(Math.cos(o)),a=uB(Math.sin(o));r.push(`vec2<f32>(leg[${n}].x*${s} - leg[${n}].y*${a}, leg[${n}].x*${a} + leg[${n}].y*${s})`)}u+=`    ${a(t)} = ${r.join(" + ")};
`}return`${u}  }
  workgroupBarrier();
`},uF=(e,t)=>[t,e.length,e.inputComponents,e.outputComponents,e.inverse,e.onesided].join(";"),uL=e=>[{type:12,data:e.batch},{type:12,data:e.signalLength},{type:12,data:e.inner},{type:12,data:e.outputLength}],uV=(e,t,r)=>e.registerUniform("batch","u32").registerUniform("signalLength","u32").registerUniform("inner","u32").registerUniform("outputLength","u32").declareVariables(t,r),uU=e=>{if(!e||0===e.dataType)return;if(1!==oG.size(e.dims))throw Error("DFT optional scalar inputs must have exactly 1 element.");if(6===e.dataType)return e.getInt32Array()[0];let t=Number(e.getBigInt64Array()[0]);if(!Number.isSafeInteger(t))throw Error("DFT optional scalar inputs are out of JavaScript safe integer range.");return t},uq=(e,t)=>{var r=e.inputs;if(!r||r.length<1)throw Error("DFT requires at least 1 input.");let n=r[0].dims;if(n.length<2)throw Error("DFT input must have at least 2 dimensions.");let i=n[n.length-1];if(1!==i&&2!==i)throw Error("DFT input's innermost dimension must be 1 (real) or 2 (complex).");let o=e.inputs[0],s=o.dims.length,a=0!==t.inverse,u=0!==t.onesided,l=uU(e.inputs[1]);if(void 0!==l&&l<=0)throw Error("dft_length must be greater than zero.");let d=oG.normalizeAxis(uU(e.inputs[2])??t.axis,s);if(d===s-1)throw Error("DFT axis must refer to a signal dimension, not the innermost (real/imaginary) dimension.");if(a&&u&&2!==o.dims[s-1])throw Error("Inverse one-sided DFT (IRFFT) requires complex-valued input (innermost dimension 2).");let p=((e,t,r,n,i)=>{let o=e.dims,s=o.length,a=o[s-1],u=o[t],l=r&&n?(u-1)*2:u;void 0!==i&&(l=i);let d=r&&n?1:2,p=n&&!r?Math.floor(l/2)+1:l,c=o.slice();c[t]=p,c[s-1]=d;let h=1;for(let e=t+1;e<s-1;e++)h*=o[e];let f=oG.size(o)/a/u;return{dataType:e.dataType,outputDims:c,length:l,signalLength:u,inner:h,batch:f,inputComponents:a,outputComponents:d,outputLength:p,inverse:r,onesided:n}})(o,d,a,u,l);if(p.length<=0)throw Error(`Invalid DFT length: ${p.length}`);let c=p.length<=512&&void 0!==uR(p.length)?(e=>{let{dataType:t,length:r,inputComponents:n,outputComponents:i,inverse:o,onesided:s}=e,a=sc(t),u=o?1:-1,l=o?1/r:1,d=uR(r);return{name:"DFT",shaderCache:{hint:uF(e,"fft"),inputDependencies:["type"]},getShaderSource:e=>{let p,c=sv("x",t,[1]),h=sx("y",t,[1]),f=e=>{let t=`inBase + (${e}) * uniforms.inner * ${n}u`,r=`f32(${c.getByOffset(t)})`,i=2===n?`f32(${c.getByOffset(`${t} + 1u`)})`:"0.0";return`vec2<f32>(${r}, ${i})`};if(o&&s){let e=Math.floor(r/2)+1,t=r%2==0?`select(provided, provided - 1u, provided == ${e}u)`:"provided";p=`
    let provided = min(uniforms.signalLength, ${e}u);
    for (var i = local_idx; i < ${r}u; i += 256u) {
      if (i < provided) { smem[i] = ${f("i")}; } else { smem[i] = vec2<f32>(0.0); }
    }
    workgroupBarrier();
    for (var k = local_idx + 1u; k < ${t}; k += 256u) {
      let h = smem[k];
      smem[${r}u - k] = vec2<f32>(h.x, -h.y);
    }
    workgroupBarrier();`}else p=`
    let loadCount = min(uniforms.signalLength, ${r}u);
    for (var i = local_idx; i < ${r}u; i += 256u) {
      if (i < loadCount) { smem[i] = ${f("i")}; } else { smem[i] = vec2<f32>(0.0); }
    }
    workgroupBarrier();`;let{code:g,resultOffset:m}=((e,t,r)=>{let n="",i=1,o=0;for(let s of e)n+=uM(s,i,t,o,r),i*=s,o=512-o;return{code:n,resultOffset:o}})(d,r,u),b=1===l?`smem[${m}u + i]`:`smem[${m}u + i] * ${uB(l)}`,y=2===i?h.setByOffset("off + 1u",`${a}(v.y)`):"";return`
  ${uV(e,c,h)}
  var<workgroup> smem: array<vec2<f32>, 1024>;
  fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
  }
  ${e.mainStart(256)}
    let row = workgroup_index;
    if (row >= uniforms.batch) { return; }
    let outer = row / uniforms.inner;
    let within = row % uniforms.inner;
    let inBase = (outer * uniforms.signalLength * uniforms.inner + within) * ${n}u;
    let outBase = (outer * uniforms.outputLength * uniforms.inner + within) * ${i}u;
    ${p}
${g}    for (var i = local_idx; i < uniforms.outputLength; i += 256u) {
      let v = ${b};
      let off = outBase + i * uniforms.inner * ${i}u;
      ${h.setByOffset("off",`${a}(v.x)`)}
      ${y}
    }
  }`},getRunData:()=>({outputs:[{dims:e.outputDims,dataType:t}],programUniforms:uL(e),dispatchGroup:{x:e.batch}})}})(p):(e=>{let{dataType:t,length:r,inputComponents:n,outputComponents:i,inverse:o,onesided:s}=e,a=sc(t),u=o?1:-1,l=o?1/r:1;return{name:"DFT",shaderCache:{hint:uF(e,"direct"),inputDependencies:["type"]},getShaderSource:e=>{let d=sv("x",t,[1]),p=sx("y",t,[1]),c=e=>{let t=`inBase + (${e}) * uniforms.inner * ${n}u`,r=`f32(${d.getByOffset(t)})`,i=2===n?`f32(${d.getByOffset(`${t} + 1u`)})`:"0.0";return`vec2<f32>(${r}, ${i})`},h=o&&s?`fn spectrum(inBase: u32, k: u32) -> vec2<f32> {
    let provided = min(uniforms.signalLength, ${Math.floor(r/2)+1}u);
    if (k < provided) { return ${c("k")}; }
    let m = ${r}u - k;
    if (m < provided) {
      let h = ${c("m")};
      return vec2<f32>(h.x, -h.y);
    }
    return vec2<f32>(0.0, 0.0);
  }`:`fn spectrum(inBase: u32, n: u32) -> vec2<f32> {
    if (n < uniforms.signalLength) { return ${c("n")}; }
    return vec2<f32>(0.0, 0.0);
  }`,f=`
      let angle = ${uB(u*uj)} * f32(knMod) / ${uB(r)};
      acc += cmul(spectrum(inBase, n), vec2<f32>(cos(angle), sin(angle)));
      knMod += k;
      if (knMod >= ${r}u) { knMod -= ${r}u; }`,g=2===i?p.setByOffset("off + 1u",`${a}(v.y)`):"",m=1===l?"acc":`acc * ${uB(l)}`;return`
  ${uV(e,d,p)}
  fn cmul(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
    return vec2<f32>(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
  }
  ${h}
  ${e.mainStart(256)}
    let row = workgroup_index;
    if (row >= uniforms.batch) { return; }
    let outer = row / uniforms.inner;
    let within = row % uniforms.inner;
    let inBase = (outer * uniforms.signalLength * uniforms.inner + within) * ${n}u;
    let outBase = (outer * uniforms.outputLength * uniforms.inner + within) * ${i}u;
    for (var k = local_idx; k < uniforms.outputLength; k += 256u) {
      var acc = vec2<f32>(0.0, 0.0);
      var knMod = 0u;
      for (var n = 0u; n < ${r}u; n++) {${f}
      }
      let v = ${m};
      let off = outBase + k * uniforms.inner * ${i}u;
      ${p.setByOffset("off",`${a}(v.x)`)}
      ${g}
    }
  }`},getRunData:()=>({outputs:[{dims:e.outputDims,dataType:t}],programUniforms:uL(e),dispatchGroup:{x:e.batch}})}})(p);e.compute(c,{inputs:[0]})},uG=e=>su({axis:e.axis??1,inverse:e.inverse??0,onesided:e.onesided??0})}}),fY=dQ({"web/lib/wasm/jsep/webgpu/ops/einsum.ts"(){"use strict";fb(),fv(),fS(),fO(),uK="^"+(uW="("+(uH="[a-zA-Z]|\\.\\.\\.")+")+")+"$",uX="^"+("("+uW+",)*")+uW+"$",uZ=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);void 0===r?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},uJ=class{constructor(e,t){this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=[],this.outputDims=[];let[r,n]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(uX)))throw Error("Invalid LHS term");if(r.split(",").forEach((t,r)=>{let n=e[r].dims.slice();if(!t.match(RegExp(uK)))throw Error("Invalid LHS term");let i=this.processTerm(t,!0,n,r);this.lhs.push(i)}),""===n)n+=[...this.symbolToInfo.entries()].filter(([e,t])=>1===t.count||"..."===e).map(([e])=>e).join("");else if(!n.match(RegExp(uW)))throw Error("Invalid RHS");let i=n.match(RegExp(uH,"g"));i?.forEach(e=>{if("..."===e)this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let t=this.symbolToInfo.get(e);if(void 0===t)throw Error("Invalid RHS symbol");this.outputDims.push(t.dimValue)}}),this.rhs=this.processTerm(n,!1,this.outputDims)}addSymbol(e,t,r){let n=this.symbolToInfo.get(e);if(void 0!==n)if(n.dimValue!==t&&1!==n.count)throw Error("Dimension mismatch");else n.count++,n.inputIndices.push(r);else n={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,n)}processTerm(e,t,r,n=-1){let i=r.length,o=!1,s=[],a=0;if(!e.match(RegExp(uK))&&!t&&""!==e)throw Error("Invalid LHS term");let u=e.match(RegExp(uH,"g")),l=new uZ(n);return u?.forEach((e,d)=>{if("..."===e){if(o)throw Error("Only one ellipsis is allowed per input term");o=!0;let e=i-u.length+1;if(e<0)throw Error("Ellipsis out of bounds");if(s=r.slice(a,a+e),this.hasEllipsis){if(this.ellipsisDims.length!==s.length||this.ellipsisDims.toString()!==s.toString())throw Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=s;else throw Error("Ellipsis must be specified in the LHS");for(let e=0;e<s.length;e++){let t=String.fromCharCode(48+e);l.addSymbol(t,d+e),this.addSymbol(t,r[a++],n)}}else l.addSymbol(e,d+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(e,r[a++],n)}),l}},uQ=(e,t)=>{var r;let n,i,o,s,a=new uJ(e.inputs,t.equation),u=a.outputDims,l=e.inputs.map((e,t)=>e.dims);e.compute((r=e.inputs[0].dataType,n=l.map(e=>e.length).map((e,t)=>sv(`input${t}`,r,e)),i=oG.size(u),o=sx("output",r,u.length),s=[...a.symbolToInfo.keys()].filter(e=>!a.rhs.symbolToIndices.has(e)),{name:"Einsum",shaderCache:{hint:a.equation,inputDependencies:l.map(()=>"rank")},getRunData:()=>{let e=s.filter(e=>a.symbolToInfo.has(e)).map(e=>({type:12,data:a.symbolToInfo.get(e)?.dimValue||0}));e.push({type:12,data:i});let t=l.map((e,t)=>[...sh(e)]).reduce((e,t)=>e.concat(t),e);return t.push(...sh(u)),{outputs:[{dims:u,dataType:r}],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:t}},getShaderSource:e=>{let t=[],r=[],i=[],u=[],l=[],d=a.symbolToInfo.size===a.rhs.symbolToIndices.size;a.symbolToInfo.forEach((e,s)=>{if(a.rhs.symbolToIndices.has(s)){let r=a.rhs.symbolToIndices.get(s)?.[0];void 0!==r&&a.lhs.forEach((i,a)=>{if(e.inputIndices.includes(a)){let e=i.symbolToIndices.get(s);if(void 0===e)throw Error("Invalid symbol error");e.forEach(e=>{t.push(`${n[a].indicesSet(`input${a}Indices`,e,o.indicesGet("outputIndices",r))}`)})}})}else a.lhs.forEach((t,i)=>{if(e.inputIndices.includes(i)){let e=t.symbolToIndices.get(s);if(void 0===e)throw Error("Invalid symbol error");e.forEach(e=>{r.push(`${n[i].indicesSet(`input${i}Indices`,e,`${s}`)}`)}),l.push(`prod *= ${n[i].getByIndices(`input${i}Indices`)};`)}}),i.push(`for(var ${s}: u32 = 0; ${s} < uniforms.${s+"_max"}; ${s}++) {`),u.push("}")});let p=d?[...t,`let sum = ${n.map((e,t)=>e.getByIndices(`input${t}Indices`)).join(" * ")};`]:[...t,"var sum = 0.0;",...i,...r,"var prod = 1.0;",...l,"sum += prod;",...u];return`
            ${e.registerUniforms(s.map(e=>({name:`${e+"_max"}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...n,o)}

            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${o.offsetToIndices("global_idx")};
            ${n.map((e,t)=>`var input${t}Indices: ${n[t].type.indices};`).join("\n")}
            ${p.join("\n")};
            ${o.setByOffset("global_idx","sum")};
          }`}}))},uY=e=>{let t=e.equation.replace(/\s+/g,"");return su({equation:t})}}}),f0=dQ({"web/lib/wasm/jsep/webgpu/ops/expand.ts"(){"use strict";fb(),fv(),fO(),u0=(e,t)=>{let r=e.length-t.length,n=[];for(let t=0;t<r;++t)n.push(e[t]);for(let i=0;i<t.length;++i)n.push(1===t[i]?e[i+r]:t[i]);return n},u1=e=>{var t;let r,n,i,o,s,a,u,l,d;(e=>{if(!e||2!==e.length)throw Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),n=r.length<t.length?0:r.length-t.length,i=t.length<r.length?0:t.length-r.length;for(;n<r.length&&i<t.length;++n,++i)if(r[n]!==t[i]&&1!==r[n]&&1!==t[i])throw Error("Expand requires shape to be broadcastable to input")})(e.inputs),e.compute((r=(t=e.inputs)[0].dims,n=Array.from(t[1].getBigInt64Array(),Number),i=r.length>n.length?u0(r,n):u0(n,r),s=9===(o=t[0].dataType)||1===oG.size(r),a=9===o||r.length>0&&r[r.length-1]%4==0?4:1,u=s||i.length>0&&i[i.length-1]%4==0?4:1,d=[{type:12,data:l=Math.ceil(oG.size(i)/u)},...sh(r,i)],{name:"Expand",shaderCache:{hint:`${i.length};${a}${u}`,inputDependencies:["rank"]},getShaderSource:e=>{let t,n=sv("input",o,r.length,a),s=sx("output",o,i.length,u);if(9===o){let e=(e,t,r="")=>`
          let outputIndices${t} = ${s.offsetToIndices(`outputOffset + ${t}u`)};
          let offset${t} = ${n.broadcastedIndicesToOffset(`outputIndices${t}`,s)};
          let index${t} = offset${t} / 4u;
          let component${t} = offset${t} % 4u;
          ${e}[${t}] = ${r}(${n.getByOffset(`index${t}`)}[component${t}]);
        `;t=`
        let outputOffset = global_idx * ${u};
        var data = vec4<u32>(0);
        ${e("data",0,"u32")}
        ${e("data",1,"u32")}
        ${e("data",2,"u32")}
        ${e("data",3,"u32")}
        ${s.setByOffset("global_idx","data")}
      }`}else t=`
        let outputIndices = ${s.offsetToIndices(`global_idx * ${u}`)};
        let inputOffset = ${n.broadcastedIndicesToOffset("outputIndices",s)};
        let data = ${s.type.value}(${n.getByOffset(`inputOffset / ${a}`)});
        ${s.setByOffset("global_idx","data")}
      }`;return`
    ${e.registerUniform("vec_size","u32").declareVariables(n,s)}
    ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${t}`},getRunData:()=>({outputs:[{dims:i,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:d})}),{inputs:[0]})}}}),f1=dQ({"web/lib/wasm/jsep/webgpu/ops/fast-gelu.ts"(){"use strict";fb(),fv(),fO(),fN(),u2=e=>{if(e.inputs.length<2||0===oG.size(e.inputs[1].dims))aq(e);else{var t;let r,n,i,o;e.compute((r=(t=e.inputs)[0].dataType,n=oG.size(t[0].dims),o=(i=oG.size(t[1].dims))%4==0,{name:"FastGeluWithBias",shaderCache:{hint:`${o}`,inputDependencies:["type","type"]},getShaderSource:e=>{let t=sv("x",r,[1],4),n=sv("bias",r,[1],4),i=sx("y",r,[1],4),s=e=>`
      let bias${e}_offset: u32 = (global_idx * 4 + ${e}) % uniforms.bias_size;
      let bias${e} = ${n.getByOffset(`bias${e}_offset / 4`)}[bias${e}_offset % 4];`,a=o?`
      let bias = ${n.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${s(0)}${s(1)}${s(2)}${s(3)}
      let bias = ${t.type.value}(bias0, bias1, bias2, bias3);`;return`${e.registerUniforms([{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}]).declareVariables(t,n,i)}

    ${aV(sc(r))}

    ${e.mainStart(sl)}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${t.getByOffset("global_idx")};
      ${a}
      let x_in = x + bias;
      ${i.setByOffset("global_idx",aU("x_in"))}
    }`},getRunData:e=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],programUniforms:[{type:12,data:Math.ceil(n/4)},{type:12,data:i}],dispatchGroup:{x:Math.ceil(n/sl/4)}})}))}}}}),f2=dQ({"web/lib/wasm/jsep/webgpu/ops/gather.ts"(){"use strict";fb(),fv(),fS(),fO(),u3=e=>su({axis:e.axis}),u4=(e,t)=>{let r,n,i,o,s,a,u,l,d;var p,c=e.inputs;if(!c||2!==c.length)throw Error("Gather requires 2 inputs.");e.compute((p=e.inputs,r=p[0].dims,n=p[1].dims,i=r.length,o=oG.normalizeAxis(t.axis,i),(s=r.slice(0)).splice(o,1,...n),a=r[o],u=9===p[0].dataType?4:1,d=[{type:12,data:l=Math.ceil(oG.size(s)/u)},{type:6,data:a},{type:12,data:o},...sh(p[0].dims,p[1].dims,s)],{name:"Gather",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:s,dataType:p[0].dataType}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:d}),getShaderSource:e=>{let t,r=sv("data",p[0].dataType,p[0].dims.length,u),a=sv("inputIndices",p[1].dataType,p[1].dims.length),l=sx("output",p[0].dataType,s.length,u),d=e=>{let t=n.length,u=`var indicesIndices${e}  = ${a.type.indices}(0);`;for(let r=0;r<t;r++)u+=`${t>1?`indicesIndices${e}[${r}]`:`indicesIndices${e}`} = ${s.length>1?`outputIndices${e}[uniforms.axis + ${r}]`:`outputIndices${e}`};`;u+=`
          var idx${e} = ${a.getByIndices(`indicesIndices${e}`)};
          if (idx${e} < 0) {
            idx${e} = idx${e} + uniforms.axisDimLimit;
          }
          var dataIndices${e} : ${r.type.indices};
        `;for(let r=0,n=0;r<i;r++)r===o?(u+=`${i>1?`dataIndices${e}[${r}]`:`dataIndices${e}`} = u32(idx${e});`,n+=t):(u+=`${i>1?`dataIndices${e}[${r}]`:`dataIndices${e}`} = ${s.length>1?`outputIndices${e}[${n}]`:`outputIndices${e}`};`,n++);return u};if(9===p[0].dataType){let e=(e,t,n="")=>`
          let outputIndices${t} = ${l.offsetToIndices(`outputOffset + ${t}u`)};
          ${d(t)};
          let offset${t} = ${r.indicesToOffset(`dataIndices${t}`)};
          let index${t} = offset${t} / 4u;
          let component${t} = offset${t} % 4u;
          ${e}[${t}] = ${n}(${r.getByOffset(`index${t}`)}[component${t}]);
        `;t=`
        let outputOffset = global_idx * ${u};
        var value = vec4<u32>(0);
        ${e("value",0,"u32")}
        ${e("value",1,"u32")}
        ${e("value",2,"u32")}
        ${e("value",3,"u32")}
        ${l.setByOffset("global_idx","value")}
      `}else t=`
      let outputIndices = ${l.offsetToIndices("global_idx")};
      ${d("")};
      let value = ${r.getByIndices("dataIndices")};
      ${l.setByOffset("global_idx","value")};
      `;return`
      ${e.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(r,a,l)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${t}
      }`}}))}}}),f3=dQ({"web/lib/wasm/jsep/webgpu/ops/gather-nd.ts"(){"use strict";fb(),fv(),fO(),u6=(e,t)=>{var r,n;let i,o,s=e.inputs,a=s[0].dims,u=s[0].dataType,l=s[1].dims,d=l[l.length-1],p=oG.sizeToDimension(l,l.length-1),c=oG.sizeFromDimension(a,t.batchDims+d),h=oG.sizeToDimension(a,t.batchDims),f=oG.sizeFromDimension(a,t.batchDims),g=Array(d),m=c;for(let e=0;e<d;++e)g[d-1-e]=m,m*=a[t.batchDims+d-1-e];let b=(r=s[1],n=t.batchDims,i=[{type:12,data:p},{type:12,data:n},{type:12,data:a},{type:12,data:g},{type:12,data:p/h},{type:12,data:f},{type:12,data:d}],o=[p],i.push(...sh(r.dims,o)),e.compute({name:"computeSliceOffsets",shaderCache:{hint:`${a.length}_${g.length}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:o,dataType:e.inputs[1].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:i}),getShaderSource:e=>{let t=sv("indices_data",r.dataType,r.dims.length),n=sx("input_slice_offsets_data",12,1,1),i=[{name:"output_size",type:"u32"},{name:"batch_dims",type:"u32"},{name:"input_dims",type:"u32",length:a.length},{name:"sizes_from_slice_dims_data",type:"u32",length:g.length},{name:"num_slices_per_batch",type:"u32"},{name:"input_batch_stride",type:"u32"},{name:"num_slice_dims",type:"u32"}];return`
  ${e.registerUniforms(i).declareVariables(t,n)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let batch_idx = global_idx / uniforms.num_slices_per_batch;
    let base_offset = batch_idx * uniforms.input_batch_stride;

    let slice_indices_base_offset = global_idx * uniforms.num_slice_dims;
    var relative_slice_offset = 0;
    for (var dim_idx = 0u; dim_idx < uniforms.num_slice_dims; dim_idx ++) {
      var index = i32(indices_data[dim_idx + slice_indices_base_offset].x);
      let input_dim_idx = uniforms.batch_dims + dim_idx;
      if (index < 0) {
        ${1===a.length?"index += i32(uniforms.input_dims);":"index += i32(uniforms.input_dims[input_dim_idx]);"}
      }
      ${1===g.length?"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data);":"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data[dim_idx]);"}
    }

    input_slice_offsets_data[global_idx] =  base_offset + u32(relative_slice_offset);
  }`}},{inputs:[r],outputs:[-1]})[0]),y=t.batchDims+d;if(y>a.length)throw Error("last dimension of indices must not be larger than rank of input tensor");let _=l.slice(0,-1).concat(a.slice(y)),v=oG.size(_),x=[{type:12,data:v},{type:12,data:c},...sh(s[0].dims,b.dims,_)];e.compute({name:"GatherND",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:_,dataType:u}],dispatchGroup:{x:Math.ceil(v/64)},programUniforms:x}),getShaderSource:e=>{let t=sv("data",s[0].dataType,s[0].dims.length),r=sv("slice_offsets",12,b.dims.length),n=sx("output",s[0].dataType,_.length);return`
          ${e.registerUniform("output_size","u32").registerUniform("slice_size","u32").declareVariables(t,r,n)}
            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let slice_offset = slice_offsets[global_idx / uniforms.slice_size];
          output[global_idx] = data[u32(slice_offset) + global_idx % uniforms.slice_size];
        }`}},{inputs:[s[0],b]})},u8=e=>({batchDims:e.batch_dims,cacheKey:""})}}),f4=dQ({"web/lib/wasm/jsep/webgpu/ops/gather-block-quantized.ts"(){"use strict";fb(),fv(),fS(),fO(),u5=(e,t)=>{var r;let n,i,o,s,a,u,l,d,p,c;((e,t)=>{if(e.length<3||e.length>4)throw Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=oG.normalizeAxis(t.quantizeAxis,e[0].dims.length),n=t.blockSize,i=e[0],o=e[2],s=4===e.length?e[3]:void 0;if(o.dims.length!==i.dims.length||!i.dims.map((e,t)=>t===r?Math.ceil(e/n)===o.dims[t]:e===o.dims[t]).reduce((e,t)=>e&&t,!0))throw Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(s){if(s.dataType!==i.dataType)throw Error("Zero point must have the same data type as the input tensor.");if(s.dims.length!==o.dims.length||!s.dims.map((e,t)=>e===o.dims[t]).reduce((e,t)=>e&&t,!0))throw Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}})(e.inputs,t),e.compute((r=e.inputs,n=r[0].dims,i=r[1].dims,o=n.length,s=oG.normalizeAxis(t.gatherAxis,o),a=oG.normalizeAxis(t.quantizeAxis,o),(u=n.slice(0)).splice(s,1,...i),l=oG.size(u),d=r[2].dataType,p=22===r[0].dataType,c=[{type:12,data:l},{type:12,data:a},{type:12,data:s},{type:12,data:t.blockSize},...sh(...r.map((e,t)=>e.dims),u)],{name:"GatherBlockQuantized",shaderCache:{hint:`${t.cacheKey};${r.filter((e,t)=>1!==t).map(e=>e.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:r.length},(e,t)=>"rank")},getRunData:()=>({outputs:[{dims:u,dataType:d}],dispatchGroup:{x:Math.ceil(l/64)},programUniforms:c}),getShaderSource:e=>{let t=sv("data",r[0].dataType,r[0].dims.length),o=sv("inputIndices",r[1].dataType,r[1].dims.length),a=sv("scales",r[2].dataType,r[2].dims.length),l=r.length>3?sv("zeroPoint",r[3].dataType,r[3].dims.length):void 0,c=sx("output",d,u.length),h=[t,o,a];return l&&h.push(l),`
        ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}]).declareVariables(...h,c)}
        ${e.mainStart()}
        let output_indices = ${c.offsetToIndices("global_idx")};
        var indices_indices = ${o.type.indices}(0);
        ${i.length>1?`
          for (var i: u32 = 0; i < ${i.length}; i++) {
            let index = ${c.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${o.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${c.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${t.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${c.indicesGet("output_indices","i")};
          ${t.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${o.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${n[s]};
        }
        ${t.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${u.length}; i++) {
          let index = ${c.indicesGet("output_indices",`i + ${i.length} - 1`)};
          ${t.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${t.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${t.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${p?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${a.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${a.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${a.getByIndices("scale_indices")};
        ${!l?"var zero_point = 0":`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${l.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${l.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${p?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`};
        let dequantized_data = ${sc(d)}(quantized_data - zero_point) * scale;
        ${c.setByOffset("global_idx","dequantized_data")};
    }`}}))},u7=e=>su({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}}),f6=dQ({"web/lib/wasm/jsep/webgpu/ops/gather-elements.ts"(){"use strict";fb(),fv(),fS(),fO(),u9=e=>su({axis:e.axis}),le=(e,t)=>{let r,n,i,o,s,a,u,l,d,p,c,h,f;var g,m=e.inputs;if(!m||2!==m.length)throw Error("GatherElements requires 2 inputs.");if(m[0].dims.length<1)throw Error("GatherElements requires that the data input be rank >= 1.");if(m[0].dims.length!==m[1].dims.length)throw Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`);e.compute((g=e.inputs,r=g[0].dims,n=g[0].dataType,i=r.length,o=g[1].dims,s=g[1].dataType,u=r[a=oG.normalizeAxis(t.axis,i)],l=o.slice(0),d=oG.size(l),p=sv("input",n,i),c=sv("indicesInput",s,o.length),h=sx("output",n,l.length),(f=[{type:12,data:d},{type:6,data:u},{type:12,data:a}]).push(...sh(r,o,l)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:l,dataType:g[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:f}),getShaderSource:e=>`
      ${e.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(p,c,h)}
      ${e.mainStart()}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${h.offsetToIndices("global_idx")};

      var idx = ${c.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${p.type.indices}(outputIndices);
      ${p.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${p.getByIndices("inputIndices")};

      ${h.setByOffset("global_idx","value")};
  }`}))}}}),f8=dQ({"web/lib/wasm/jsep/webgpu/ops/gemm.ts"(){"use strict";fb(),fv(),fO(),lt=e=>{let t=e.transA,r=e.transB;return{transA:t,transB:r,alpha:e.alpha,beta:e.beta,cacheKey:`${e.transA};${e.transB};${1===e.alpha}`}},lr=(e,t)=>{var r=e.inputs;if(!r)throw Error("Input is missing");if(r.length<2||r.length>3)throw Error("Invaid input number.");if(3===r.length&&r[2].dims.length>2)throw Error("Invalid input shape of C");if(r[0].dataType!==r[1].dataType||3===r.length&&r[0].dataType!==r[2].dataType)throw Error("Input types are mismatched");e.compute(((e,t)=>{let r=e[0].dims.slice(),n=e[1].dims.slice(),[i,o,s]=oW.getShapeOfGemmResult(r,t.transA,n,t.transB,3===e.length?e[2].dims:void 0),a=[i,o];if(!a)throw Error("Can't use gemm on the given tensors");let u=Math.ceil(o/16),l=Math.ceil(i/16),d=(oG.size(a),[{type:12,data:u},{type:12,data:i},{type:12,data:o},{type:12,data:s},{type:1,data:t.alpha},{type:1,data:t.beta}]),p=["type","type"];return 3===e.length&&(d.push(...sh(e[2].dims)),p.push("rank")),d.push(...sh(a)),{name:"GemmShared",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:a,dataType:e[0].dataType}],dispatchGroup:{x:u*l},programUniforms:d}),getShaderSource:r=>{let n=sv("a",e[0].dataType,e[0].dims),i=sv("b",e[1].dataType,e[1].dims),o=null,s=[n,i];3===e.length&&(o=sv("c",e[2].dataType,e[2].dims.length),s.push(o));let u=sx("output",e[0].dataType,a.length);s.push(u);let l="",d="";t.transA&&t.transB?(d=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${n.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${i.type.value}(0);
      }
      `,l="value += tile_a[k][local_id.y] * tile_b[local_id.x][k];"):t.transA&&!t.transB?(d=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${n.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${i.type.value}(0);
      }
      `,l="value += tile_a[k][local_id.y] * tile_b[k][local_id.x];"):!t.transA&&t.transB?(d=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${n.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${i.type.value}(0);
      }
      `,l="value += tile_a[local_id.y][k] * tile_b[local_id.x][k];"):t.transA||t.transB||(d=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${n.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${i.type.value}(0);
      }
      `,l="value += tile_a[local_id.y][k] * tile_b[k][local_id.x];");let p=1===t.alpha?"":"value *= uniforms.alpha;";return`
  ${r.registerUniforms([{name:"num_tile_n",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}]).declareVariables(...s)}
  var<workgroup> tile_a: array<array<${n.type.storage}, 16>, 16>;
  var<workgroup> tile_b: array<array<${i.type.storage}, 16>, 16>;
  ${r.mainStart([16,16,1])}
    let tile_col_start = (workgroup_index % uniforms.num_tile_n) * 16;
    let tile_row_start = (workgroup_index / uniforms.num_tile_n) * 16;
    let num_tiles = (uniforms.K - 1) / 16 + 1;
    var k_start = 0u;
    var value = ${u.type.value}(0);
    for (var t: u32 = 0u; t < num_tiles; t++) {
      ${d}
      k_start = k_start + 16;
      workgroupBarrier();

      for (var k: u32 = 0u; k < 16; k++) {
        ${l}
      }
      workgroupBarrier();
    }

    ${p}
    let m = tile_row_start + local_id.y;
    let n = tile_col_start + local_id.x;
    ${null!=o?`let cOffset = ${o.broadcastedIndicesToOffset("vec2(m, n)",u)}; value += ${u.type.value}(uniforms.beta) * ${o.getByOffset("cOffset")};`:""}
    if (m < uniforms.M && n < uniforms.N) {
      output[m * uniforms.N + n] = value;
    }
  }`}}})(e.inputs,t))}}}),f5=dQ({"web/lib/wasm/jsep/webgpu/ops/grid-sample.ts"(){"use strict";fb(),fv(),fS(),fO(),[ln,li,lo,ls]=[0,1,2,3],la=`
  fn gs_get_cubic_coeffs(x: f32) -> vec4<f32> {
    let cubic_alpha = -0.75f;
    let x_abs = abs(x);
    var coeffs: vec4<f32>;
    coeffs[0] = (((cubic_alpha * (x_abs + 1) - 5 * cubic_alpha) * (x_abs + 1) + 8 * cubic_alpha) * (x_abs + 1) - 4 * cubic_alpha);
    coeffs[1] = (((cubic_alpha + 2) * x_abs - (cubic_alpha + 3)) * x_abs * x_abs + 1);
    coeffs[2] = (((cubic_alpha + 2) * (1 - x_abs) - (cubic_alpha + 3)) * (1 - x_abs) * (1 - x_abs) + 1);
    coeffs[3] = (((cubic_alpha * (2 - x_abs) - 5 * cubic_alpha) * (2 - x_abs) + 8 * cubic_alpha) * (2 - x_abs) - 4 * cubic_alpha);
    return coeffs;
  }
`,lu=(e,t)=>{let r,n,i,o,s,a,u;var l,d=e.inputs;if(4!==d[0].dims.length)throw Error("only 4-D tensor is supported.");if(d[0].dims.length!==d[1].dims.length)throw Error("input dimensions must be equal to grid dimensions");if(d[0].dims.length-2!==d[1].dims[d[1].dims.length-1])throw Error(`last dimension of grid must be equal to ${d[0].dims.length-2}`);if(d[0].dims[0]!==d[1].dims[0])throw Error("grid batch size must match input batch size");e.compute((l=e.inputs,r=sv("x",l[0].dataType,l[0].dims.length),n=[l[1].dims[0],l[1].dims[1],l[1].dims[2]],i=sv("grid",l[1].dataType,n.length,2),o=[l[0].dims[0],l[0].dims[1],l[1].dims[1],l[1].dims[2]],"NHWC"===t.format&&(o=[l[0].dims[0],l[1].dims[1],l[1].dims[2],l[0].dims[3]],[ln,li,lo,ls]=[0,3,1,2]),s=sx("output",l[0].dataType,o.length),a=r.type.value,u=[{type:12,data:oG.size(o)},...sh(l[0].dims,n,o)],{name:"GridSample",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:["type","type"]},getRunData:e=>{let t=oG.size(o);return{outputs:[{dims:o,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(t/64)},programUniforms:u}},getShaderSource:e=>`
  ${e.registerUniform("output_size","u32").declareVariables(r,i,s)}
  ${la}
  
  fn gs_bicubic_interpolate(p: mat4x4<${a}>, x: f32, y: f32) -> ${a} {
    var v: vec4<f32>;
    var coeffs = gs_get_cubic_coeffs(x);
    for (var i = 0; i < 4; i++) {
      v[i] = coeffs[0] * p[i][0] + coeffs[1] * p[i][1] + coeffs[2] * p[i][2] + coeffs[3] * p[i][3];
    }
    coeffs = gs_get_cubic_coeffs(y);
    let pixel = ${a}(coeffs[0] * v[0] + coeffs[1] * v[1] + coeffs[2] * v[2] + coeffs[3] * v[3]);
    return pixel;
  }

  
  fn gs_denormalize(n: f32, length: i32) -> f32 {
    ${0===t.alignCorners?`
    // alignCorners: false => [-1, 1] to [-0.5, length - 0.5]
    return ((n + 1.0) * f32(length) - 1.0) / 2.0;
    `:`
    // alignCorners: true => [-1, 1] to [0, length - 1]
    return (n + 1.0) / 2.0 * (f32(length - 1));
    `}
  }

  
  ${"reflection"===t.paddingMode?`
      fn gs_reflect(x: i32, x_min: f32, x_max: f32) -> u32 {
        var dx = 0.0;
        var fx = f32(x);
        let range = x_max - x_min;
        if (fx < x_min) {
          dx = x_min - fx;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_min + r;
          } else {
            fx = x_max - r;
          }
        } else if (fx > x_max) {
          dx = fx - x_max;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_max - r;
          } else {
            fx = x_min + r;
          }
        }
        return u32(fx);
      }`:""}

  ${`
  fn pixel_at_grid(r: i32, c: i32, H: i32, W: i32, batch: u32, channel: u32, border: vec4<f32>) -> ${a} {
     var pixel = ${a}(0);
     var indices = vec4<u32>(0);
     indices[${ln}] = batch;
     indices[${li}] = channel;`+(()=>{switch(t.paddingMode){case"zeros":return`
          if (r >= 0 && r < H && c >=0 && c < W) {
            indices[${lo}] = u32(r);
            indices[${ls}] = u32(c);
          } else {
            return ${a}(0);
          }
        `;case"border":return`
          indices[${lo}] = u32(clamp(r, 0, H - 1));
          indices[${ls}] = u32(clamp(c, 0, W - 1));
        `;case"reflection":return`
          indices[${lo}] = gs_reflect(r, border[1], border[3]);
          indices[${ls}] = gs_reflect(c, border[0], border[2]);
        `;default:throw Error(`padding mode ${t.paddingMode} is not supported`)}})()+`
    return ${r.getByIndices("indices")};
  }
`}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let H_in = i32(uniforms.x_shape[${lo}]);
      let W_in = i32(uniforms.x_shape[${ls}]);

      ${0===t.alignCorners?`
      let x_min = -0.5;
      let x_max = f32(W_in) - 0.5;
      let y_min = -0.5;
      let y_max = f32(H_in) - 0.5;
      `:`
      let x_min = 0.0;
      let x_max = f32(W_in) - 1.0;
      let y_min = 0.0;
      let y_max = f32(H_in) - 1.0;
      `};
      let border = vec4<f32>(x_min, y_min, x_max, y_max);

      let indices = ${s.offsetToIndices("global_idx")};
      var grid_indices = vec3<u32>(indices[${ln}], indices[${lo}], indices[${ls}]);
      let nxy = ${i.getByIndices("grid_indices")};
      var x = gs_denormalize(f32(nxy[0]), W_in);
      var y = gs_denormalize(f32(nxy[1]), H_in);

      ${(()=>{switch(t.mode){case"nearest":return`
          let result = pixel_at_grid(i32(round(y)), i32(round(x)), H_in, W_in, indices[${ln}], indices[${li}], border);
        `;case"bilinear":return`
          let x1 = i32(floor(x));
          let y1 = i32(floor(y));
          let x2 = x1 + 1;
          let y2 = y1 + 1;

          let p11 = pixel_at_grid(y1, x1, H_in, W_in, indices[${ln}], indices[${li}], border);
          let p12 = pixel_at_grid(y1, x2, H_in, W_in, indices[${ln}], indices[${li}], border);
          let p21 = pixel_at_grid(y2, x1, H_in, W_in, indices[${ln}], indices[${li}], border);
          let p22 = pixel_at_grid(y2, x2, H_in, W_in, indices[${ln}], indices[${li}], border);

          let dx2 = ${a}(f32(x2) - x);
          let dx1 = ${a}(x - f32(x1));
          let dy2 = ${a}(f32(y2) - y);
          let dy1 = ${a}(y - f32(y1));
          let result = dy2 * (dx2 * p11 + dx1 * p12) + dy1 * (dx2 * p21 + dx1 * p22);
        `;case"bicubic":return`
          let x0 = i32(floor(x)) - 1;
          let y0 = i32(floor(y)) - 1;
          var p: mat4x4<${a}>;
          for (var h = 0; h < 4; h++) {
            for (var w = 0; w < 4; w++) {
              p[h][w] = pixel_at_grid(h + y0, w + x0, H_in, W_in, indices[${ln}], indices[${li}], border);
            }
          }

          let dx = x - f32(x0 + 1);
          let dy = y - f32(y0 + 1);
          let result = gs_bicubic_interpolate(p, dx, dy);
        `;default:throw Error(`mode ${t.mode} is not supported`)}})()+`${s.setByOffset("global_idx","result")}`}
  }`}))},ll=e=>su({alignCorners:e.align_corners,mode:e.mode,paddingMode:e.padding_mode,format:e.format})}}),f7=dQ({"web/lib/wasm/jsep/webgpu/ops/multihead-attention.ts"(){"use strict";fb(),fv(),fS(),fT(),fD(),fO(),fE(),ld=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,lp=e=>su({...e}),lc=su({perm:[0,2,1,3]}),lh=(e,t,r,n,i,o,s,a)=>{let u=o;if(s&&oG.size(s.dims)>0)if(1===n)throw Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");else{var l;let d,p,c;return(d=[t,n,l=r*i],c=[{type:12,data:p=oG.size(d)},{type:12,data:a},{type:12,data:l}],u=(u=e.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:d,dataType:o.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:c}),getShaderSource:e=>{let t=sx("qkv_with_bias",o.dataType,d),r=sv("qkv",o.dataType,d),n=sv("bias",s.dataType,d);return`
  ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}]).declareVariables(r,n,t)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`}},{inputs:[o,s],outputs:[-1]})[0]).reshape([t,n,r,i]),1===r||1===n)?u:e.compute(sO(u,lc.perm),{inputs:[u],outputs:[-1]})[0]}return(3===o.dims.length&&(u=o.reshape([t,n,r,i])),1===r||1===n)?u:e.compute(sO(u,lc.perm),{inputs:[u],outputs:[-1]})[0]},lf=(e,t)=>{let r=((e,t)=>{let r,n=e[0],i=ld(e,1),o=ld(e,2),s=ld(e,3),a=ld(e,4),u=ld(e,5),l=ld(e,6),d=ld(e,7);if(3!==n.dims.length&&5!==n.dims.length)throw Error("Input query is expected to have 3 or 5 dimensions");let p=n.dims[0],c=n.dims[1],h=3===n.dims.length?n.dims[2]:t.numHeads*n.dims[4],f=c,g=0,m=0,b=Math.floor(h/t.numHeads);if(l&&d&&oG.size(l.dims)&&oG.size(d.dims)){if(4!==l.dims.length)throw Error('Input "past_key" is expected to have 4 dimensions');if(l.dims[0]!==p||l.dims[1]!==t.numHeads||l.dims[3]!==b)throw Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(d.dims[0]!==p||d.dims[1]!==t.numHeads||d.dims[3]!==b)throw Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(l.dims[2]!==d.dims[2])throw Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(4!==d.dims.length)throw Error('Input "past_value" is expected to have 4 dimensions');g=l.dims[2],m=l.dims[2]}else if(l&&oG.size(l.dims)||d&&oG.size(d.dims))throw Error('Input "past_key" and "past_value" shall be both present or both absent');if(i&&oG.size(i.dims)>0){if(3!==n.dims.length)throw Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(n.dims[0]!==i.dims[0])throw Error('Input "query" and "key" shall have same dim 0 (batch size)');if(3===i.dims.length){if(i.dims[2]!==n.dims[2])throw Error('Input "query" and "key" shall have same dim 2 (hidden_size)');r=2,f=i.dims[1]}else if(5===i.dims.length){if(i.dims[2]!==t.numHeads||2!==i.dims[3]||i.dims[4]!==b)throw Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(o)throw Error('Expect "value" be none when "key" has packed kv format.');r=5,f=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==b)throw Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');r=0,f=i.dims[2]}}else{if(5!==n.dims.length)throw Error('Input "query" is expected to have 5 dimensions when key is empty');if(n.dims[2]!==t.numHeads||3!==n.dims[3])throw Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');r=3}if(s&&oG.size(s.dims)>0){if(1!==s.dims.length)throw Error('Input "bias" is expected to have 1 dimension');if(i&&5===i.dims.length&&2===i.dims[3])throw Error("bias is not allowed for packed kv.")}let y=g+f,_=0;if(a&&oG.size(a.dims)>0){_=8;let e=a.dims;if(1===e.length?e[0]===p?_=1:e[0]===3*p+2&&(_=3):2===e.length&&e[0]===p&&e[1]===y&&(_=5),8===_)throw Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)');throw Error("Mask not supported")}let v=!1,x=h;if(o&&oG.size(o.dims)>0){if(3!==o.dims.length&&4!==o.dims.length)throw Error('Input "value" is expected to have 3 or 4 dimensions');if(n.dims[0]!==o.dims[0])throw Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(3===o.dims.length){if(f!==o.dims[1])throw Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');x=o.dims[2]}else{if(f!==o.dims[2])throw Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');x=o.dims[1]*o.dims[3],v=!0}}if(a&&oG.size(a.dims)>0)throw Error("Key padding mask is not supported");if(u&&oG.size(u.dims)>0){if(4!==u.dims.length)throw Error('Input "attention_bias" is expected to have 4 dimensions');if(u.dims[0]!==p||u.dims[1]!==t.numHeads||u.dims[2]!==c||u.dims[3]!==y)throw Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:p,sequenceLength:c,pastSequenceLength:g,kvSequenceLength:f,totalSequenceLength:y,maxSequenceLength:m,inputHiddenSize:0,hiddenSize:h,vHiddenSize:x,headSize:b,vHeadSize:Math.floor(x/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:_,scale:t.scale,broadcastResPosBias:!1,passPastInKv:v,qkvFormat:r}})(e.inputs,t),n=e.inputs[0],i=ld(e.inputs,1),o=ld(e.inputs,2),s=ld(e.inputs,3),a=ld(e.inputs,4),u=ld(e.inputs,5),l=ld(e.inputs,6),d=ld(e.inputs,7);if(5===n.dims.length)throw Error("Packed QKV is not implemented");if(i?.dims.length===5)throw Error("Packed KV is not implemented");let p=i&&o&&4===i.dims.length&&4===o.dims.length,c=lh(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,n,s,0);if(p)return ar(e,c,i,o,a,void 0,l,d,u,r);if(!i||!o)throw Error("key and value must be provided");let h=lh(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,i,s,r.hiddenSize),f=lh(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,o,s,2*r.hiddenSize);ar(e,c,h,f,a,void 0,l,d,u,r)}}}),f9=dQ({"web/lib/wasm/jsep/webgpu/ops/split.ts"(){"use strict";fb(),fv(),fS(),fO(),lg=(e,t)=>{let r=e[0].dims,n=oG.size(r),i=e[0].dataType,o=oG.normalizeAxis(t.axis,r.length),s=Array(t.numOutputs),a=sv("input",i,r.length),u=Array(t.numOutputs),l=[],d=[],p=0,c=[{type:12,data:n}];for(let n=0;n<t.numOutputs;n++){p+=t.splitSizes[n],u[n]=p;let a=r.slice();a[o]=t.splitSizes[n],d.push(a),s[n]=sx(`output${n}`,i,a.length),l.push({dims:d[n],dataType:e[0].dataType})}return c.push({type:12,data:u},...sh(r,...d)),{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:e=>{let t;return`
  ${e.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",u.length).declareVariables(a,...s)}
  ${t=u.length,`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${t}u; i += 1u ) {
    if (index < ${sy("uniforms.size_in_split_axis","i",t)}) {
        return i;
    }
    }
    return ${t}u;
}`}
  ${(e=>{let t=e.length,r=[];for(let n=0;n<t;++n){let i=e[n].setByIndices("indices","input[global_idx]");1===t?r.push(i):0===n?r.push(`if (output_number == ${n}u) { ${i} }`):n===t-1?r.push(`else { ${i} }`):r.push(`else if (output_number == ${n}) { ${i} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join("\n")}
      }`})(s)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${a.offsetToIndices("global_idx")};
    var index = ${a.indicesGet("indices",o)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${sy("uniforms.size_in_split_axis","output_number - 1u",u.length)};
      ${a.indicesSet("indices",o,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`},getRunData:()=>({outputs:l,dispatchGroup:{x:Math.ceil(n/64)},programUniforms:c})}},lm=(e,t)=>{let r,n;var i,o=e.inputs;if(!o||o.length<1)throw Error("too few inputs");let s=1===e.inputs.length?t:(i=e.inputs,r=[],n=t.numOutputs,i[1].dims[0]>0&&(i[1].getBigInt64Array().forEach(e=>r.push(Number(e))),n=r.length),su({numOutputs:n,axis:t.axis,splitSizes:r}));e.compute(lg(e.inputs,s),{inputs:[0]})},lb=e=>{let t=e.axis,r=e.splitSizes,n=e.numOutputs<0?r.length:e.numOutputs;if(n!==r.length)throw Error("numOutputs and splitSizes length must be equal");return su({axis:t,numOutputs:n,splitSizes:r})}}}),ge=dQ({"web/lib/wasm/jsep/webgpu/ops/rotary-embedding.ts"(){"use strict";fb(),fv(),fS(),fO(),ly=(e,t)=>{let{interleaved:r,numHeads:n,rotaryEmbeddingDim:i,scale:o}=t,s=e[0].dims[0],a=oG.sizeFromDimension(e[0].dims,1),u=e[0].dims[e[0].dims.length-2],l=a/u,d=e[2].dims[1],p=0===i?2*d:l/n,c=[s,u,l/p,p-d],h=oG.computeStrides(c),f=[{type:1,data:o},{type:12,data:c},{type:12,data:h},...3===e[0].dims.length?Array({type:12,data:[a,l,p,1]}):[],...4===e[0].dims.length?Array({type:12,data:[a,p,u*p,1]}):[],...sh(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)];return{name:"RotaryEmbedding",shaderCache:{hint:su({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:t=>{let n=sv("input",e[0].dataType,e[0].dims.length),i=sv("position_ids",e[1].dataType,e[1].dims.length),o=sv("cos_cache",e[2].dataType,e[2].dims.length),s=sv("sin_cache",e[3].dataType,e[3].dims.length),a=sx("output",e[0].dataType,e[0].dims.length);return t.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:c.length},{name:"global_strides",type:"u32",length:h.length},{name:"input_output_strides",type:"u32",length:h.length}]),`
        ${t.declareVariables(n,i,o,s,a)}

        ${t.mainStart(sl)}
          let half_rotary_emb_dim = uniforms.${o.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${t.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${i.broadcastedIndicesToOffset("bsnh.xy",sx("",i.type.tensor,2))};
            let position_id =
                u32(${i.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${n.getByOffset("i")} * ${o.get("position_id","bsnh[3]")} -
                ${n.getByOffset("j")} * ${s.get("position_id","bsnh[3]")};
            ${a.setByOffset("i","re")}
            let im = ${n.getByOffset("i")} * ${s.get("position_id","bsnh[3]")} +
                ${n.getByOffset("j")} * ${o.get("position_id","bsnh[3]")};
            ${a.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${a.setByOffset("k",n.getByOffset("k"))}
          }
        }`},getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(oG.size(c)/sl)},programUniforms:f})}},l_=(e,t)=>{((e,t)=>{let[r,n,i,o]=e,{numHeads:s,rotaryEmbeddingDim:a}=t;if(3!==r.dims.length&&4!==r.dims.length)throw Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!oG.areEqual(n.dims,[])&&!oG.areEqual(n.dims,[1])&&2!==n.dims.length)throw Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${n.dims.length}`);if(2!==i.dims.length)throw Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${i.dims.length}`);if(2!==o.dims.length)throw Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${o.dims.length}`);if(!oG.areEqual(i.dims,o.dims))throw Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(a>0&&0===s)throw Error("num_heads must be provided if rotary_embedding_dim is specified");let u=r.dims[0],l=r.dims[r.dims.length-2],d=i.dims[0],p=oG.sizeFromDimension(r.dims,1)/l,c=0===a?2*i.dims[1]:p/s;if(a>c)throw Error("rotary_embedding_dim must be less than or equal to head_size");if(2===n.dims.length){if(u!==n.dims[0])throw Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${n.dims[0]}`);if(l!==n.dims[1])throw Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${n.dims[1]}`)}if(l>d)throw Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported");if(c/2!==i.dims[1]&&a/2!==i.dims[1])throw Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${i.dims[1]}`)})(e.inputs,t),e.compute(ly(e.inputs,t))}}}),gt=dQ({"web/lib/wasm/jsep/webgpu/ops/group-query-attention.ts"(){"use strict";fS(),fb(),fD(),f7(),f9(),fE(),ge(),fO(),lv=su({perm:[0,2,1,3]}),lx=(e,t,r)=>{let n=t,i=r.kvNumHeads;return 3===t.dims.length&&0!==r.kvSequenceLength&&(n=t.reshape([r.batchSize,r.kvSequenceLength,i,r.headSize]),n=e.compute(sO(n,lv.perm),{inputs:[n],outputs:[-1]})[0]),n},lw=(e,t)=>{let r,n;if(e.inputs.length>14&&e.inputs[14]||e.inputs.length>15&&e.inputs[15])throw Error("GroupQueryAttention (JSEP): q_norm_weight / k_norm_weight inputs are not supported. The per-head Q/K RMS normalization prologue is implemented only on the CUDA and native WebGPU EPs.");let i=((e,t)=>{if(t.doRotary&&e.length<=7)throw Error("cos_cache and sin_cache inputs are required if do_rotary is specified");let r=e[0],n=e[1],i=e[2],o=e[3],s=e[4];if(0!==t.doRotary&&e.length<=7)throw Error("cos_cast and sin_cache are expected if do_rotary attribute is non-zero");if(-1!==t.localWindowSize)throw Error("Local attention is not supported");if(0!==t.softcap)throw Error("Softcap is not supported");if(0!==t.rotaryInterleaved)throw Error("Rotary interleaved is not supported");if(t.smoothSoftmax)throw Error("Smooth softmax is not supported");if(3!==r.dims.length&&5!==r.dims.length)throw Error("Input query is expected to have 3 or 5 dimensions");let a=r.dims[0],u=r.dims[1],l=3===r.dims.length?r.dims[2]:t.numHeads*r.dims[4],d=u,p=0,c=!n||0===n.dims.length,h=c?Math.floor(l/(t.numHeads+2*t.kvNumHeads)):Math.floor(l/t.numHeads);c&&(l=h*t.numHeads);let f=o&&0!==o.dims.length,g=s&&0!==s.dims.length;if(f&&4===o.dims.length&&o.dims[0]===a&&o.dims[1]!==t.kvNumHeads&&o.dims[2]===t.kvNumHeads&&o.dims[3]===h)throw Error("BSNH pastKey/pastValue is not supported");if(f&&g){if(4!==o.dims.length)throw Error('Input "past_key" is expected to have 4 dimensions');if(4!==s.dims.length)throw Error('Input "past_value" is expected to have 4 dimensions');p=o.dims[2]}else if(f||g)throw Error('Input "past_key" and "past_value" shall be both present or both absent');let m=1;if(n&&n.dims.length>0){if(3!==r.dims.length)throw Error('Input "query" is expected to have 3 dimensions when key is given');if(n.dims.length<3||n.dims.length>5)throw Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==n.dims[0])throw Error('Input "query" and "key" shall have same dim 0 (batch size)');if(3===n.dims.length){if(r.dims[2]%n.dims[2]!=0)throw Error('Dimension 2 of "query" should be a multiple of "key"');d=n.dims[1]}else if(5===n.dims.length){if(n.dims[2]!==t.numHeads||2!==n.dims[3]||n.dims[4]!==h)throw Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(i)throw Error('Expect "value" be none when "key" has packed kv format.');d=n.dims[1]}else{if(n.dims[1]!==t.numHeads||n.dims[3]!==h)throw Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');d=n.dims[2]}}else{if(3!==r.dims.length&&5!==r.dims.length)throw Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(5===r.dims.length&&(r.dims[2]!==t.numHeads||3!==r.dims[3]))throw Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');m=3}let b=!1,y=t.kvNumHeads?h*t.kvNumHeads:l;if(i&&i.dims.length>0){if(3!==i.dims.length&&4!==i.dims.length)throw Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==i.dims[0])throw Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(3===i.dims.length){if(d!==i.dims[1])throw Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');y=i.dims[2]}else{if(d!==i.dims[2])throw Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');y=i.dims[1]*i.dims[3],b=!0}}let _=e.length>4?e[5]:void 0;if(_){if(0===_.dims.length)throw Error("seqlens_k must be at least 1D, got scalar.");let e=_.dims.reduce((e,t)=>e*t,1);if(e!==a)throw Error(`seqlens_k must have batch_size (${a}) elements, got ${e}.`);for(let e=0;e<_.dims.length;e++)if(1!==_.dims[e]&&_.dims[e]!==a)throw Error(`seqlens_k has unexpected shape. Each dimension must be 1 or batch_size (${a}), got dims[${e}] = ${_.dims[e]}.`)}return{batchSize:a,sequenceLength:u,pastSequenceLength:p,kvSequenceLength:d,totalSequenceLength:-1,maxSequenceLength:-1,inputHiddenSize:0,hiddenSize:l,vHiddenSize:y,headSize:h,vHeadSize:Math.floor(y/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:0,scale:t.scale,broadcastResPosBias:!1,passPastInKv:b,qkvFormat:m}})(e.inputs,t);if(5===e.inputs[0].dims.length)throw Error("Packed QKV is not implemented");if(e.inputs[1]?.dims.length===5)throw Error("Packed KV is not implemented");let o=e.inputs[0],s=e.inputs[1]&&e.inputs[1].dims.length>0?e.inputs[1]:void 0,a=e.inputs[2]&&e.inputs[2].dims.length>0?e.inputs[2]:void 0,u=e.inputs[3]&&0!==e.inputs[3].dims.length?e.inputs[3]:void 0,l=e.inputs[4]&&0!==e.inputs[4].dims.length?e.inputs[4]:void 0,d=e.inputs.length>4?e.inputs[5]:void 0,p=e.inputs.length>5?e.inputs[6]:void 0,c=i.kvNumHeads?i.kvNumHeads:i.numHeads,h=su({axis:2,numOutputs:3,splitSizes:[i.numHeads*i.headSize,c*i.headSize,c*i.headSize]}),[f,g,m]=s||a?[o,s,a]:e.compute(lg([o],h),{inputs:[o],outputs:[-1,-1,-1]});if(t.doRotary){var b,y;let o,s,a,u=e.compute((b=i.batchSize,y=i.sequenceLength,o=[b*y],a=[{type:12,data:s=b*y},{type:12,data:y},{type:12,data:b}],{name:"GeneratePositionIds",shaderCache:{hint:`${b};${y}`,inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:o,dataType:7}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:a}),getShaderSource:e=>{let t=sv("seq_lens",d.dataType,d.dims),r=sv("total_seq_lens",p.dataType,p.dims),n=sx("pos_ids",7,o);return`
  ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"sequence_length",type:"u32"},{name:"batch_size",type:"u32"}]).declareVariables(t,r,n)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let total_sequence_length = u32(${r.getByOffset("0")});
    let is_subsequent_prompt = uniforms.sequence_length > 1 && uniforms.sequence_length != total_sequence_length;
    let is_first_prompt = !is_subsequent_prompt && uniforms.sequence_length == total_sequence_length;
    let batch_idx = global_idx / uniforms.sequence_length;
    let sequence_idx = i32(global_idx % uniforms.sequence_length);
    var pos_id: i32 = 0;
    let seqlen = ${t.getByOffset("batch_idx")};
    let total_seqlen = seqlen + 1;
    if (is_first_prompt) {
      if (sequence_idx < total_seqlen) {
        pos_id = sequence_idx;
      } else {
        pos_id = 1;
      }
      ${n.setByOffset("global_idx","pos_id")}
    } else if (is_subsequent_prompt) {
      let past_seqlen = total_seqlen - i32(uniforms.sequence_length);
      if (past_seqlen + sequence_idx < total_seqlen) {
        pos_id = past_seqlen + sequence_idx;
      } else {
        pos_id = 1;
      }
      ${n.setByOffset("global_idx","pos_id")}
    } else if (global_idx < uniforms.batch_size) {
      ${n.setByOffset("global_idx","seqlen")}
    };
  }
  `}}),{inputs:[d,p],outputs:[-1]})[0],l=e.inputs[7],c=e.inputs[8],h=su({interleaved:0!==t.rotaryInterleaved,numHeads:i.numHeads,rotaryEmbeddingDim:0,scale:t.scale}),m=[f,u,l,c],_=[-1];r=e.compute(ly(m,h),{inputs:m,outputs:_})[0],m.splice(0,1,g);let v=su({interleaved:0!==t.rotaryInterleaved,numHeads:i.kvNumHeads,rotaryEmbeddingDim:0,scale:t.scale});n=e.compute(ly(m,v),{inputs:m,outputs:_})[0]}let _=lh(e,i.batchSize,i.numHeads,i.sequenceLength,i.headSize,t.doRotary?r:f,void 0,0),v=lx(e,t.doRotary?n:g,i),x=lx(e,m,i);ar(e,_,v,x,void 0,void 0,u,l,void 0,i,d,p)}}}),gr=dQ({"web/lib/wasm/jsep/webgpu/ops/instance-norm.ts"(){"use strict";fb(),fv(),fE(),fO(),l$=(e,t,r,n,i,o,s,a)=>{let u=sf(o),l=1===u?"f32":`vec${u}f`,d=1===u?"vec2f":`mat2x${u}f`,p=i*s,c=64;1===p&&(c=256);let h=[i,s,o/u],f=[i,s,2],g=[];return g.push(...sh(h,f)),e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${u};${a};${c}`,inputDependencies:["rank","type","type"]},getRunData:()=>({outputs:[{dims:f,dataType:1}],dispatchGroup:{x:p},programUniforms:g}),getShaderSource:e=>{let i=sv("x",t.dataType,3,u),o=[i,sv("scale",r.dataType,r.dims),sv("bias",n.dataType,n.dims),sx("output",1,3,2)];return`
  var<workgroup> workgroup_shared : array<${d}, ${c}>;
  const workgroup_size = ${c}u;
  ${e.declareVariables(...o)}
  ${e.mainStart(c)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${l}(0);
    var squared_sum = ${l}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${l}(${i.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${d}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${sb("workgroup_shared[0][0]",u)} / f32(hight * ${u});
      let squared_sum_final = ${sb("workgroup_shared[0][1]",u)} / f32(hight * ${u});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${a}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`}},{inputs:[t,r,n],outputs:[-1]})[0]},lT=(e,t)=>{if("NHWC"===t.format)((e,t,r)=>{let n=t[0].dims,i=n[0],o=n[n.length-1],s=oG.sizeFromDimension(n,1)/o,a=sf(o),u=oG.size(n)/a,l=[{type:12,data:s},{type:12,data:Math.floor(o/a)}],d=!1,p=[0,n.length-1];for(let e=0;e<n.length-2;e++)d=d||1!==n[e+1],p.push(e+1);let c=(d=d&&1!==n[n.length-1])?e.compute(sO(e.inputs[0],p),{inputs:[e.inputs[0]],outputs:[-1]})[0]:e.inputs[0].reshape(Array.from({length:n.length},(e,t)=>n[p[t]])),h=l$(e,c,t[1],t[2],i,s,o,r.epsilon);e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${a}`,inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:n,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:l}),getShaderSource:e=>{let r=sp(t[0].dataType),i=1===a?"vec2f":`mat${a}x2f`,o=e=>{let t=0===e?"x":"y",n=1===a?"f32":`vec${a}f`;switch(a){case 1:return`${r}(${n}(scale.${t}))`;case 2:return`vec2<${r}>(${n}(scale[0].${t}, scale[1].${t}))`;case 4:return`vec4<${r}>(${n}(scale[0].${t}, scale[1].${t}, scale[2].${t}, scale[3].${t}))`;default:throw Error(`Not supported compoents ${a}`)}},s=sv("input",t[0].dataType,t[0].dims,a),u=sx("output",t[0].dataType,n,a);return`
  @group(0) @binding(0) var<storage, read> input : array<${s.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${i}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${u.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${e.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${o(0)}, ${o(1)});
  }`}},{inputs:[t[0],h]})})(e,e.inputs,t);else{var r;let n,i,o,s,a,u,l,d,p;r=e.inputs,i=(n=r[0].dims)[0],o=n[1],s=oG.sizeFromDimension(n,2),a=sf(s),u=oG.size(n)/a,l=l$(e,r[0],r[1],r[2],i,s,o,t.epsilon),d=[i,o,s/a],p=[i,o],e.compute({name:"InstanceNormalization",shaderCache:{hint:`${a}`,inputDependencies:["type","none"]},getRunData:()=>({outputs:[{dims:n,dataType:r[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:[{type:12,data:u},...sh(d,p,d)]}),getShaderSource:e=>{let t=sv("x",r[0].dataType,d.length,a),n=sv("scale_shift",1,p.length,2),i=sx("output",r[0].dataType,d.length,a),o=[t,n,i];return`
  ${e.registerUniform("output_size","u32").declareVariables(...o)}
  ${e.mainStart()}
  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${i.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${n.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${t.getByOffset("global_idx")} * ${i.type.value}(scale_shift.x) + ${i.type.value}(scale_shift.y);
      ${i.setByOffset("global_idx","value")};
  }`}},{inputs:[r[0],l]})}}}}),gn=dQ({"web/lib/wasm/jsep/webgpu/ops/layer-norm.ts"(){"use strict";fb(),fv(),fO(),lI=(e,t)=>{var r=e.inputs;if(!r||r.length<2)throw Error("layerNorm requires at least 2 inputs.");e.compute(((e,t,r)=>{let n=t.simplified,i=e[0].dims,o=e[1],s=!n&&e[2],a=oG.normalizeAxis(t.axis,i.length),u=oG.sizeToDimension(i,a),l=oG.sizeFromDimension(i,a),d=oG.size(o.dims),p=s?oG.size(s.dims):0;if(d!==l||s&&p!==l)throw Error(`Size of X.shape()[axis:] == ${l}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${d} and bias size of ${p}`);let c=[];for(let e=0;e<i.length;++e)e<a?c.push(i[e]):c.push(1);let h=sf(l),f=["type","type"],g=[{type:12,data:u},{type:1,data:l},{type:12,data:Math.floor(l/h)},{type:1,data:t.epsilon}];s&&f.push("type");let m=r>1,b=r>2,y=[{dims:i,dataType:e[0].dataType}];return m&&y.push({dims:c,dataType:1}),b&&y.push({dims:c,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${h};${r};${n}`,inputDependencies:f},getRunData:()=>({outputs:y,dispatchGroup:{x:Math.ceil(u/64)},programUniforms:g}),getShaderSource:t=>{let r=sp(e[0].dataType),a=[sv("x",e[0].dataType,e[0].dims,h),sv("scale",o.dataType,o.dims,h)];return s&&a.push(sv("bias",s.dataType,s.dims,h)),a.push(sx("output",e[0].dataType,i,h)),m&&a.push(sx("mean_data_output",1,c)),b&&a.push(sx("inv_std_output",1,c)),`
  ${t.registerUniforms([{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}]).declareVariables(...a)}
  ${t.mainStart()}
    ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${sg("f32",h)};
    var mean_square_vector = ${sg("f32",h)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${sm(r,h,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${sb("mean_vector",h)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${sb("mean_square_vector",h)} / uniforms.norm_size ${n?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${sm(r,h,"x[j + offset]")};
      let f32scale = ${sm(r,h,"scale[j]")};
      output[j + offset] = ${a[0].type.value}((f32input ${n?"":"- mean"}) * inv_std_dev * f32scale
        ${s?`+ ${sm(r,h,"bias[j]")}`:""}
      );
    }

    ${m?"mean_data_output[global_idx] = mean":""};
    ${b?"inv_std_output[global_idx] = inv_std_dev":""};
  }`}}})(e.inputs,t,e.outputCount))}}}),gi=dQ({"web/lib/wasm/jsep/webgpu/ops/matmul.ts"(){"use strict";fv(),fV(),fU(),lS=e=>{var t=e.inputs;if(!t||2!==t.length)throw Error("MatMul requires 2 inputs.");if(t[0].dims[t[0].dims.length-1]!==t[1].dims[t[1].dims.length-2])throw Error("shared dimension does not match.");let r=oq.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!r)throw Error("Can't use matmul on the given tensors");let n=r[r.length-1],i=e.inputs[0].dims[e.inputs[0].dims.length-1];if(n<8&&i<8)e.compute(ua(e.inputs,{activation:""},r));else{let t=r[r.length-2],o=oG.size(e.inputs[0].dims.slice(0,-2)),s=oG.size(e.inputs[1].dims.slice(0,-2));if(1!==o&&1===t&&1===s){let t=e.inputs[0].reshape([1,o,i]),s=e.inputs[1].reshape([1,i,n]),a=[1,o,n],u=[t,s];e.compute(up(u,{activation:""},r,a),{inputs:u})}else e.compute(up(e.inputs,{activation:""},r))}}}}),go=dQ({"web/lib/wasm/jsep/webgpu/ops/matmulnbits.ts"(){"use strict";fb(),fv(),fS(),fO(),lO=(e,t)=>{var r,n;if(((e,t)=>{if(e.length<3||e.length>4)throw Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],n=r.dims.length;if(r.dims[n-1]!==t.k)throw Error("The last dim of input shape does not match the k value");let i=Math.floor((t.k+t.blockSize-1)/t.blockSize),o=t.blockSize/8*t.bits,s=e[1];if(!oG.areEqual(s.dims,[t.n,i,o]))throw Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let a=e[2].dims;if(oG.size(a)!==t.n*i)throw Error("scales input size error.");if(4===e.length){let r=e[3].dims,n=t.n*(8===t.bits?i:Math.floor((i*t.bits+7)/8));if(oG.size(r)!==n)throw Error("zeroPoints input size error.")}})(e.inputs,t),32===t.blockSize&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")){let n,i,o,s,a,u,l,d,p,c,h,f,g,m,b,y,_,v,x,w,$,T,I;e.compute((r=e.inputs,i=(n=r[0].dims).length,o=n[i-2],s=t.k,a=t.n,u=n.slice(0,i-2),l=oG.size(u),d=r[1].dims[2]/4,p=r[0].dataType,c=sf(t.k),h=sf(d),f=u.concat([o,a]),m=128/(g=a%8==0?8:a%4==0?4:1),_=(y=m*h*(b=Math.floor(32/t.bits)))/c,v=y/t.blockSize,x=oG.size(f)/g,w=[],$=[l,o,s/c],(T=oG.convertShape(r[1].dims).slice()).splice(-1,1,d/h),w.push(...sh($)),w.push(...sh(T)),w.push(...sh(r[2].dims)),4===r.length&&w.push(...sh(oG.convertShape(r[3].dims))),I=[l,o,a],w.push(...sh(I)),{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${t.blockSize};${c};${h};${m};${g}`,inputDependencies:Array(r.length).fill("rank")},getRunData:()=>({outputs:[{dims:f,dataType:p}],dispatchGroup:{x:x},programUniforms:w}),getShaderSource:e=>{let n=$.length,i=sv("a",r[0].dataType,n,c),o=sv("b",12,T.length,h),s=sv("scales",r[2].dataType,r[2].dims.length),a=[i,o,s],u=4===r.length?sv("zero_points",12,r[3].dims.length):void 0;u&&a.push(u);let l=I.length,d=sx("output",r[0].dataType,l),p=sp(r[0].dataType),f=()=>{switch(c){case 1:return`
          let a_data0 = vec4<${p}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${p}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${p}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${p}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw Error(`${c}-component is not supported.`)}};return`
        var<workgroup> sub_a: array<${i.type.value}, ${_}>;
        var<workgroup> inter_results: array<array<${d.type.value}, ${m}>, ${g}>;
        ${e.declareVariables(...a,d)}
        ${e.mainStart([m,g,1])}
          let output_indices = ${d.offsetToIndices(`workgroup_index * ${g}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${v} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${_};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${_}; a_offset += 128)
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${i.getByIndices(`${i.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${i.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${v} + local_id.x;
            ${u?`
            let zero_point_values_per_byte: u32 = ${Math.floor(8/t.bits)}u;
            let zero_point_bytes_per_col = (n_blocks_per_col + zero_point_values_per_byte - 1u) / zero_point_values_per_byte;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block / zero_point_values_per_byte);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_sub_offset: u32 = block % zero_point_values_per_byte;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_sub_offset * ${t.bits}u);
            let zero_point_word = ${u.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${p}((zero_point_word) & ${2===t.bits?"0x3u":"0xFu"});`:`
            // The default zero point is ${Math.pow(2,t.bits-1)} for unsigned ${t.bits}-bit quantization.
            let zero_point = ${p}(${Math.pow(2,t.bits-1).toFixed(1)});`}
            let scale = ${s.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${o.getByIndices(`${o.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${t.blockSize/c};
            for (var i: u32 = 0; i < ${h}; i++) {
              let b_value = ${1===h?"b_data":"b_data[i]"};
              ${(()=>{let e=Math.floor(b/8),r="";for(let n=0;n<e;n++){let e=n*t.bits*4,i=e+t.bits;r+=`
              ${f()}
              {${2===t.bits?`
                let half_word = b_value >> ${16*n}u;
                let byte_lo = half_word & 0xFFu;
                let byte_hi = (half_word >> 8u) & 0xFFu;
                let spread_word = (byte_lo & 0xFu) | ((byte_lo >> 4u) << 8u) | ((byte_hi & 0xFu) << 16u) | ((byte_hi >> 4u) << 24u);
                let b_value_lower = unpack4xU8(spread_word & 0x03030303u);
                let b_value_upper = unpack4xU8((spread_word >> 2u) & 0x03030303u);`:`
                let b_value_lower = unpack4xU8((b_value >> ${e}u) & 0x0F0F0F0Fu);
                let b_value_upper = unpack4xU8((b_value >> ${i}u) & 0x0F0F0F0Fu);`}
                let b_quantized_values = mat2x4<${p}>(${Array.from({length:4},(e,t)=>`${p}(b_value_lower[${t}]), ${p}(b_value_upper[${t}])`).join(", ")});
                let b_dequantized_values = (b_quantized_values - mat2x4<${p}>(${Array(8).fill("zero_point").join(",")})) * scale;
                inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(e,t)=>`dot(a_data${t}, b_dequantized_values[${t}])`).join(" + ")};
              }
              word_offset += ${8/c};`}return r})()}
            }
            workgroupBarrier();
          }

          if (local_idx < ${g}) {
            var output_value: ${d.type.value} = ${d.type.value}(0);
            for (var b = 0u; b < ${m}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${d.setByIndices(`${d.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`}}))}else{let r,i,o,s,a,u,l,d,p,c,h,f,g,m,b,y,_,v,x;e.compute((n=e.inputs,i=(r=n[0].dims).length,o=r[i-2],s=t.k,a=t.n,u=r.slice(0,i-2),l=oG.size(u),d=n[1].dims[2]/4,p=n[0].dataType,c=sf(t.k),h=sf(d),f=sf(a),g=u.concat([o,a]),m=o>1&&a/f%2==0?2:1,b=oG.size(g)/f/m,y=[],_=[l,o,s/c],(v=oG.convertShape(n[1].dims).slice()).splice(-1,1,d/h),y.push(...sh(_)),y.push(...sh(v)),y.push(...sh(n[2].dims)),4===n.length&&y.push(...sh(oG.convertShape(n[3].dims))),x=[l,o,a/f],y.push(...sh(x)),{name:"MatMulNBits",shaderCache:{hint:`${t.blockSize};${t.bits};${c};${h};${f};${m};64`,inputDependencies:Array(n.length).fill("rank")},getRunData:()=>({outputs:[{dims:g,dataType:p}],dispatchGroup:{x:b},programUniforms:y}),getShaderSource:e=>{let r=_.length,i=sv("a",n[0].dataType,r,c),o=sv("b",12,v.length,h),s=sv("scales",n[2].dataType,n[2].dims.length),a=[i,o,s],u=4===n.length?sv("zero_points",12,n[3].dims.length):void 0;u&&a.push(u);let l=x.length,p=sx("output",n[0].dataType,l,f),g=sp(n[0].dataType),b=(()=>{switch(c){case 1:return`array<${g}, 8>`;case 2:return`mat4x2<${g}>`;case 4:return`mat2x4<${g}>`;default:throw Error(`${c}-component is not supported.`)}})(),y=Math.floor(32/t.bits),w=Math.floor(y/8);return`
        var<workgroup> workgroup_shared: array<${p.type.value}, ${64*m}>;
        ${e.declareVariables(...a,p)}
        ${e.mainStart([64,1,1])}
          let output_indices = ${p.offsetToIndices(`(global_idx / 64) * ${m}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += 64) {
            //process one block
            var word_offset: u32 = block * ${t.blockSize/c};
            ${(()=>{let e=`
            var col_index = col * ${f};
            ${u?`
            let zero_point_values_per_byte: u32 = ${Math.floor(8/t.bits)}u;
            let zero_point_bytes_per_col = (nBlocksPerCol + zero_point_values_per_byte - 1u) / zero_point_values_per_byte;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_sub_offset: u32 = block % zero_point_values_per_byte;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is ${Math.pow(2,t.bits-1)} for unsigned ${t.bits}-bit quantization.
            let zero_point = ${g}(${Math.pow(2,t.bits-1).toFixed(1)});`}
            `;for(let r=0;r<f*m;r++)e+=`
            let scale${r} = ${s.getByOffset("col_index * nBlocksPerCol + block")};
            ${u?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block / zero_point_values_per_byte);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_sub_offset * ${t.bits}u);
            zero_point_word = ${u.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${r} = ${g}((zero_point_word) & ${2===t.bits?"0x3u":"0xFu"});`:""}
            col_index += 1;`;return e})()}
            for (var word: u32 = 0; word < ${d}; word += ${h}) {
              ${(()=>{let e=`col_index = col * ${f};`;for(let t=0;t<f*m;t++)e+=`
            let b${t}_data = ${o.getByIndices(`${o.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return e+`
            var b_value: u32;
            let b_mask: u32 = ${2===t.bits?"0x03030303u":"0x0F0F0F0Fu"};
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${b};
            var b_dequantized_values: ${b};`})()}
              for (var i: u32 = 0; i < ${h}; i++) {
                ${(()=>{let e="";for(let r=0;r<w;r++){let n=r*t.bits*4,o=n+t.bits;e+=`
          // reuse a data (pass ${r})
            var input_offset${r>0?r:""} = ${0===r?i.indicesToOffset(`${i.type.indices}(batch, row, word_offset)`):"input_offset"};
            var a_data${r>0?r:""}: ${b};
            for (var j${r>0?r:""}: u32 = 0; j${r>0?r:""} < ${8/c}; j${r>0?r:""}++) {
              a_data${r>0?r:""}[j${r>0?r:""}] = ${i.getByOffset(`input_offset${r>0?r:""}`)};
              input_offset${r>0?r:""}++;
            }
          `;for(let i=0;i<f*m;i++)e+=`
            b_value = ${1===h?`b${i}_data`:`b${i}_data[i]`};
            ${2===t.bits?`{
              let half_word = b_value >> ${16*r}u;
              let byte_lo = half_word & 0xFFu;
              let byte_hi = (half_word >> 8u) & 0xFFu;
              let spread_word = (byte_lo & 0xFu) | ((byte_lo >> 4u) << 8u) | ((byte_hi & 0xFu) << 16u) | ((byte_hi >> 4u) << 24u);
              b_value_lower = unpack4xU8(spread_word & b_mask);
              b_value_upper = unpack4xU8((spread_word >> 2u) & b_mask);
            }`:`b_value_lower = unpack4xU8((b_value >> ${n}u) & b_mask);
            b_value_upper = unpack4xU8((b_value >> ${o}u) & b_mask);`}
            b_quantized_values = ${b}(${Array.from({length:4},(e,t)=>`${g}(b_value_lower[${t}]), ${g}(b_value_upper[${t}])`).join(", ")});
            b_dequantized_values = ${1===c?`${b}(${Array.from({length:8},(e,t)=>`(b_quantized_values[${t}] - ${u?`zero_point${i}`:"zero_point"}) * scale${i}`).join(", ")});`:`(b_quantized_values - ${b}(${Array(8).fill(`${u?`zero_point${i}`:"zero_point"}`).join(",")})) * scale${i};`};
            workgroup_shared[local_id.x * ${m} + ${Math.floor(i/f)}]${f>1?`[${i%f}]`:""} += ${Array.from({length:8/c},(e,t)=>`${1===c?`a_data${r>0?r:""}[${t}] * b_dequantized_values[${t}]`:`dot(a_data${r>0?r:""}[${t}], b_dequantized_values[${t}])`}`).join(" + ")};
          `}return e})()}
                word_offset += ${y/c};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${m}) {
            var output_value: ${p.type.value} = ${p.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < 64u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${m};
            }
            ${p.setByIndices(`${p.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`}}))}},lE=e=>su(e)}}),gs=dQ({"web/lib/wasm/jsep/webgpu/ops/pad.ts"(){"use strict";fb(),fv(),fO(),lP=(e,t)=>{let r,n,i,o;var s,a=e.inputs;if(!a||a.length<1)throw Error("Too few inputs");if(1!==a[0].dataType&&10!==a[0].dataType)throw Error("Input type must be float or float16.");if(a.length>=2){let e=2*a[0].dims.length===a[1].dims[0];if(4===a.length&&(e=2*a[3].dims[0]===a[1].dims[0]),!e)throw Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}let u=((e,t)=>{if(!(e.length>1))return t;{let r=e[1].getBigInt64Array(),n=e.length>=3&&e[2].data?10===e[2].dataType?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,i=e[0].dims.length,o=new Int32Array(2*i).fill(0);if(e.length>=4){let t=e[3].getBigInt64Array();for(let e=0;e<t.length;e++)o[Number(t[e])]=Number(r[e]),o[Number(t[e])+i]=Number(r[e+t.length])}else r.forEach((e,t)=>o[Number(t)]=Number(e));let s=[];return o.forEach(e=>s.push(e)),{mode:t.mode,value:n,pads:s}}})(e.inputs,t);e.compute((s=e.inputs,r=oG.padShape(s[0].dims.slice(),u.pads),n=s[0].dims,i=[{type:12,data:oG.size(r)},{type:6,data:u.pads}],o=s.length>=3&&s[2].data,0===u.mode&&i.push({type:o?s[2].dataType:1,data:u.value}),i.push(...sh(s[0].dims,r)),{name:"Pad",shaderCache:{hint:`${u.mode}${o}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:r,dataType:s[0].dataType}],dispatchGroup:{x:Math.ceil(oG.size(r)/64)},programUniforms:i}),getShaderSource:e=>{let t=sx("output",s[0].dataType,r.length),i=sv("x",s[0].dataType,n.length),a=i.type.value,l=((e,t,r)=>{switch(r.mode){case 0:var n=r.pads.length;let i="";for(let r=t-1;r>=0;--r)i+=`
            k = i32(${e.indicesGet("indices",r)}) - ${sy("uniforms.pads",r,n)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${sy("uniforms.x_shape",r,t)})) {
              break;
            }
            offset += k * i32(${sy("uniforms.x_strides",r,t)});
        `;return`
          value = ${e.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${i}
            value = x[offset];
          }
      `;case 1:var o=r.pads.length;let s="";for(let r=t-1;r>=0;--r)s+=`
                k = i32(${e.indicesGet("indices",r)}) - ${sy("uniforms.pads",r,o)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${sy("uniforms.x_shape",r,t)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${sy("uniforms.x_shape",r,t)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${sy("uniforms.x_strides",r,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${s}
              value = x[offset];
          `;case 2:var a=r.pads.length;let u="";for(let r=t-1;r>=0;--r)u+=`
                k = i32(${e.indicesGet("indices",r)}) - ${sy("uniforms.pads",r,a)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${sy("uniforms.x_shape",r,t)})) {
                  k = i32(${sy("uniforms.x_shape",r,t)}) - 1;
                }
                offset += k * i32(${sy("uniforms.x_strides",r,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${u}
              value = x[offset];
          `;case 3:var l=r.pads.length;let d="";for(let r=t-1;r>=0;--r)d+=`
                k = i32(${e.indicesGet("indices",r)}) - ${sy("uniforms.pads",r,l)};
                if (k < 0)  {
                  k += i32(${sy("uniforms.x_shape",r,t)}]);
                }
                if (k >= i32(${sy("uniforms.x_shape",r,t)})) {
                  k -= i32(${sy("uniforms.x_shape",r,t)});
                }
                offset += k * i32(${sy("uniforms.x_strides",r,t)});
            `;return`
              var offset = 0;
              var k = 0;
              ${d}
              value = x[offset];
          `;default:throw Error("Invalid mode")}})(t,n.length,u),d=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:u.pads.length}];return 0===u.mode&&d.push({name:"constant_value",type:o?a:"f32"}),`
            ${e.registerUniforms(d).declareVariables(i,t)}
            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${t.offsetToIndices("global_idx")};

            var value = ${a}(0);
            ${l}
            output[global_idx] = value;
        }`}}),{inputs:[0]})}}}),ga=dQ({"web/lib/wasm/jsep/webgpu/ops/pool.ts"(){"use strict";ph(),fb(),fv(),fO(),lk=e=>{if(l.webgpu.validateInputContent&&(!e||1!==e.length))throw Error("Pool ops requires 1 input.")},lA=(e,t,r)=>{let n="NHWC"===t.format,i=e.dims.slice();n&&i.splice(1,0,i.pop());let o=Object.hasOwnProperty.call(t,"dilations"),s=t.kernelShape.slice(),a=t.strides.slice(),u=o?t.dilations.slice():[],l=t.pads.slice();oH.adjustPoolAttributes(r,i,s,a,u,l);let d=oH.computePoolOutputShape(r,i,a,u,s,l,t.autoPad,t.ceilMode),p=Object.assign({},t);o?Object.assign(p,{kernelShape:s,strides:a,pads:l,dilations:u,cacheKey:t.cacheKey}):Object.assign(p,{kernelShape:s,strides:a,pads:l,cacheKey:t.cacheKey});let c=d.slice();return c.push(c.splice(1,1)[0]),[p,n?c:d]},lD=(e,t)=>{let r="NHWC"===t.format,n=[{type:12,data:oG.size(e)},{type:12,data:oG.size(t.kernelShape)}],i=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let e=t.kernelShape[t.kernelShape.length-1],r=t.strides[t.strides.length-1],o=t.pads[t.pads.length/2-1],s=t.pads[t.pads.length-1],a=!!(o+s);n.push({type:12,data:e},{type:12,data:r},{type:12,data:o},{type:12,data:s}),i.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let u=!1;if(2===t.kernelShape.length){let e=t.kernelShape[t.kernelShape.length-2],r=t.strides[t.strides.length-2],o=t.pads[t.pads.length/2-2],s=t.pads[t.pads.length-2];u=!!(o+s),n.push({type:12,data:e},{type:12,data:r},{type:12,data:o},{type:12,data:s}),i.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[n,i,!0,a,u]}{if(r)throw Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let e=oG.computeStrides(t.kernelShape);return n.push({type:12,data:e},{type:12,data:t.pads},{type:12,data:t.strides}),i.push({name:"kernelStrides",type:"u32",length:e.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length}),[n,i,!!t.pads.reduce((e,t)=>e+t),!1,!1]}},lz=(e,t,r,n,i,o,s,a,u,l,d,p)=>{let c="NHWC"===i.format,h=t.type.value,f=sx("output",t.type.tensor,n);if(i.kernelShape.length<=2){let n="",l="",g="",m=r-(c?2:1);if(n=d?`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${m}] = indices[${m}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${m}] < 0 || xIndices[${m}]
                      >= uniforms.x_shape[${m}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${o}
                }`:`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${m}] = indices[${m}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${o}
                }`,2===i.kernelShape.length){let e=r-(c?3:2);l=p?`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${e}] = indices[${e}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${e}] < 0 || xIndices[${e}] >= uniforms.x_shape[${e}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${e}] = indices[${e}] * uniforms.sh - uniforms.phStart + j;
                `,g=`
              }
            `}return`
            ${e.registerUniforms(u).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var value = ${h}(${a});
              var pad = 0;
              ${l}
              ${n}
              ${g}
              ${s}

              output[global_idx] = value;
            }`}{if(c)throw Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let n=i.kernelShape.length,d=i.pads.length,p="";return p=l?`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${o}
              }`:`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${o}
            `,`
            ${e.registerUniforms(u).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var offsets: array<u32, ${n}>;

              var value = ${h}(${a});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${n-1}u; j++) {
                  offsets[j] = offset / ${sy("uniforms.kernelStrides","j",n)};
                  offset -= offsets[j] * ${sy("uniforms.kernelStrides","j",n)};
                }
                offsets[${n-1}] = offset;

                isPad = false;
                for (var j = ${r-n}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${sy("uniforms.strides",`j - ${r-n}u`,n)}
                    + offsets[j - ${r-n}u] - ${sy("uniforms.pads","j - 2u",d)};
                  ${p}
              }
              ${s}

              output[global_idx] = value;
            }`}},lC=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,lN=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),lj=(e,t,r,n)=>{let[i,o]=lA(t,n,r),s=sv("x",t.dataType,t.dims.length),a=s.type.value,u="";i.countIncludePad?u+=`value /= ${a}(uniforms.kernelSize);`:u+=`value /= ${a}(i32(uniforms.kernelSize) - pad);`;let[l,d,p,c,h]=lD(o,i);return l.push(...sh(t.dims,o)),{name:e,shaderCache:{hint:`${n.cacheKey};${p};${c};${h}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:o,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(oG.size(o)/64)},programUniforms:l}),getShaderSource:e=>lz(e,s,t.dims.length,o.length,i,"value += x_val;",u,0,d,p,c,h)}},lR=e=>{let t=0!==e.count_include_pad,r=lN(e);if(0!==r.ceilMode)throw Error("ceil_mode output-shape is computed, but ceil_mode kernel execution (padding/divisor) is not yet implemented in the WebGPU AveragePool kernel");let n={countIncludePad:t,...r,cacheKey:""};return{...n,cacheKey:`${lC(n)};${n.countIncludePad}`}},lB=(e,t)=>{lk(e.inputs),e.compute(lj("AveragePool",e.inputs[0],!1,t))},lM={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},lF=e=>{let t=e.format;return{format:t,...lM,cacheKey:t}},lL=(e,t)=>{lk(e.inputs),e.compute(lj("GlobalAveragePool",e.inputs[0],!0,t))},lV=(e,t,r,n)=>{let[i,o]=lA(t,n,r),s=`
      value = max(x_val, value);
    `,a=sv("x",t.dataType,t.dims.length),[u,l,d,p,c]=lD(o,i);return u.push(...sh(t.dims,o)),{name:e,shaderCache:{hint:`${n.cacheKey};${d};${p};${c}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:o,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(oG.size(o)/64)},programUniforms:u}),getShaderSource:e=>lz(e,a,t.dims.length,o.length,i,s,"",10===t.dataType?-65504:-1e5,l,d,p,c)}},lU=(e,t)=>{lk(e.inputs),e.compute(lV("MaxPool",e.inputs[0],!1,t))},lq=e=>{let t=e.storage_order,r=e.dilations,n=lN(e);if(0!==t)throw Error("column major storage order is not yet supported for MaxPool");if(0!==n.ceilMode)throw Error("ceil_mode output-shape is computed, but ceil_mode kernel execution (padding) is not yet implemented in the WebGPU MaxPool kernel");let i={storageOrder:t,dilations:r,...n,cacheKey:""};return{...i,cacheKey:`${lC(i)};${i.storageOrder};${i.dilations}`}},lG=e=>{let t=e.format;return{format:t,...lM,cacheKey:t}},lH=(e,t)=>{lk(e.inputs),e.compute(lV("GlobalMaxPool",e.inputs[0],!0,t))}}}),gu=dQ({"web/lib/wasm/jsep/webgpu/ops/quantize-linear.ts"(){"use strict";fb(),fv(),fS(),fO(),lW=(e,t)=>{let r,n,i,o,s,a,u,l,d,p,c,h,f,g,m,b,y,_,v,x,w,$,T,I;var S,O=e.inputs;if(O.length<2||O.length>3)throw Error("DequantizeLinear requires 2 or 3 inputs.");if(3===O.length&&O[1].dims===O[2].dims)throw Error("x-scale and x-zero-point must have the same shape.");if(3===O.length&&O[0].dataType!==O[2].dataType)throw Error("x and x-zero-point must have the same data type.");if(0!==O[1].dims.length&&1!==O[1].dims.length&&O[1].dims.length!==O[0].dims.length)throw Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(O.length>2){if(O[0].dataType!==O[2].dataType)throw Error("x and x-zero-point must have the same data type.");if(O[1].dims.length!==O[2].dims.length)throw Error("scale and zero-point inputs must have the same rank.");if(!O[1].dims.map((e,t)=>e===O[2].dims[t]).reduce((e,t)=>e&&t,!0))throw Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(0===O[1].dims.length||1===O[1].dims.length&&1===O[1].dims[0])throw Error("blockSize must be set only for block quantization.");if(!O[1].dims.map((e,r)=>r===t.axis||e===O[0].dims[r]).reduce((e,t)=>e&&t,!0))throw Error("For block qunatization, scale input shape to match the input shape except for the axis");if(O[1].dims.length!==O[0].dims.length)throw Error("For block qunatization the scale input rank must be the same as the x rank.");let e=O[0].dims[t.axis],r=O[1].dims[t.axis];if(t.blockSize<Math.ceil(e/r)||t.blockSize>Math.ceil(e/(r-1)-1))throw Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}e.compute((S=e.inputs,r=oG.normalizeAxis(t.axis,S[0].dims.length),i=3===(n=S[0].dataType),o=S[0].dims,s=S[1].dataType,a=oG.size(o),l=(u=3===n||2===n)?[Math.ceil(oG.size(S[0].dims)/4)]:S[0].dims,d=S[1].dims,c=(p=S.length>2?S[2]:void 0)?u?[Math.ceil(oG.size(p.dims)/4)]:p.dims:void 0,f=!1==(h=0===d.length||1===d.length&&1===d[0])&&1===d.length,g=sf(a),b=(m=h&&(!u||4===g))?g:1,y=m&&!u?g:1,_=sv("input",u?12:n,l.length,y),v=sv("scale",s,d.length),x=p?sv("zero_point",u?12:n,c.length):void 0,w=sx("output",s,o.length,b),$=[_,v],x&&$.push(x),T=[l,d],p&&T.push(c),I=[{type:12,data:a/b},{type:12,data:r},{type:12,data:t.blockSize},...sh(...T,o)],{name:"DequantizeLinear",shaderCache:{hint:t.cacheKey,inputDependencies:x?["rank","rank","rank"]:["rank","rank"]},getShaderSource:e=>`
      ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}]).declareVariables(...$,w)}
      ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${w.offsetToIndices("global_idx")};

          // Set input x
          ${u?`
            let input = ${_.getByOffset("global_idx / 4")};
            let x_vec = ${i?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${1===b?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${_.getByOffset("global_idx")};`};

          // Set scale input
          ${h?`let scale_value= ${v.getByOffset("0")}`:f?`
            let scale_index = ${w.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${v.getByOffset("scale_index")};`:`
            var scale_indices: ${v.type.indices} = output_indices;
            let index = ${v.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${v.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${v.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${(()=>{if(!x)return`let zero_point_value = ${u?i?"i32":"u32":_.type.value}(0);`;if(h)if(u)return`
                let zero_point_input = ${x.getByOffset("0")};
                let zero_point_vec =  ${i?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`;else return`let zero_point_value = ${x.getByOffset("0")}`;if(f)if(u)return`
                let zero_point_index = ${w.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${x.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${i?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`;else return`
                let zero_point_index = ${w.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${x.getByOffset("zero_point_index")};`;if(u)return`
                let zero_point_offset = ${v.indicesToOffset("scale_indices")};
                let zero_point_input = ${x.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${i?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`;return`let zero_point_value = ${x.getByIndices("scale_indices")};`})()};
      // Compute and write output
      ${w.setByOffset("global_idx",`${w.type.value}(x_value - zero_point_value) * scale_value`)};
      }`,getRunData:()=>({outputs:[{dims:o,dataType:s}],dispatchGroup:{x:Math.ceil(a/b/64),y:1,z:1},programUniforms:I})}))},lK=e=>su({axis:e.axis,blockSize:e.blockSize})}}),gl=dQ({"web/lib/wasm/jsep/webgpu/ops/range.ts"(){"use strict";ph(),fb(),fO(),lX=e=>{var t,r,n,i;let o,s,a,u=0,d=0,p=0;6===e.inputs[0].dataType?(u=e.inputs[0].getInt32Array()[0],d=e.inputs[1].getInt32Array()[0],p=e.inputs[2].getInt32Array()[0]):1===e.inputs[0].dataType&&(u=e.inputs[0].getFloat32Array()[0],d=e.inputs[1].getFloat32Array()[0],p=e.inputs[2].getFloat32Array()[0]),l.webgpu.validateInputContent&&((e,t,r)=>{if(e===t||e<t&&r<0||e>t&&r>0)throw Error("Range these inputs' contents are invalid.")})(u,d,p),e.compute((t=u,r=d,n=p,i=e.inputs[0].dataType,s=[o=Math.abs(Math.ceil((r-t)/n))],a=[{type:12,data:o},{type:i,data:t},{type:i,data:n},...sh(s)],{name:"Range",shaderCache:{hint:`${i}`},getShaderSource:e=>{let t=sx("output",i,s.length),r=t.type.value;return`
        ${e.registerUniforms([{name:"outputSize",type:"u32"},{name:"start",type:r},{name:"delta",type:r}]).declareVariables(t)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${r}(global_idx) * uniforms.delta;
      }`},getRunData:()=>({outputs:[{dims:s,dataType:i}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:a})}),{inputs:[]})}}}),gd=dQ({"web/lib/wasm/jsep/webgpu/ops/scatter-nd.ts"(){"use strict";fb(),fv(),fS(),fO(),lZ=e=>su({reduction:e.reduction}),lJ=(e,t)=>{var r;let n,i,o,s,a,u;e.compute((r=e.inputs,n=r[0].dims,i=r[1].dims,o=Math.ceil(oG.sizeToDimension(i,i.length-1)/1),s=i[i.length-1],a=oG.sizeFromDimension(n,s),u=[{type:12,data:o},{type:12,data:s},{type:12,data:a},...sh(r[1].dims,r[2].dims,n)],{name:"ScatterND",shaderCache:{hint:`${t.cacheKey}_${t.reduction}`,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:n,dataType:r[0].dataType}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:u}),getShaderSource:e=>{let i=sv("indices",r[1].dataType,r[1].dims.length),o=sv("updates",r[2].dataType,r[2].dims.length,1),s="none"!==t.reduction&&""!==t.reduction?sw("output",r[0].dataType,n.length):sx("output",r[0].dataType,n.length,1);return`
      ${e.registerUniform("output_size","u32").registerUniform("last_index_dimension","u32").registerUniform("num_updates_elements","u32").declareVariables(i,o,s)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
  var data_offset = 0u;
  let indices_start = uniforms.last_index_dimension * global_idx;
  let indices_end = indices_start + uniforms.last_index_dimension;
  for (var i = indices_start; i < indices_end; i++) {
    var index = i32(indices[i].x);
    ${1===r[0].dims.length?`
    let element_count_dim = uniforms.output_strides;
    let dim_value = uniforms.output_shape;`:`
    let element_count_dim = uniforms.output_strides[i - indices_start];
    let dim_value = uniforms.output_shape[i - indices_start];`}
    if (index >= 0) {
      if (index >= i32(dim_value)) {
        index = i32(dim_value - 1);
      }
    } else {
      if (index < -i32(dim_value)) {
        index = 0;
      } else {
        index += i32(dim_value);
      }
    }
    data_offset += u32((u32(index) * element_count_dim));
  }

  for (var i = 0u; i < uniforms.num_updates_elements; i++) {
    let value = updates[uniforms.num_updates_elements * global_idx + i];
    ${((e,t,r,n)=>{if("none"!==e&&"i32"!==n&&"u32"!==n&&"f32"!==n)throw Error(`Input ${n} is not supported with reduction ${e}.`);let i=`{
                var oldValue = 0;
                loop {
                  let newValueF32 =`,o=`;
                  let newValue = bitcast<i32>(newValueF32);
                  let res = atomicCompareExchangeWeak(&${t}, oldValue, newValue);
                  if res.exchanged {
                    break;
                  }
                  oldValue = res.old_value;
                }
              }`;switch(e){case"none":return`${t}=${r};`;case"add":if("i32"===n||"u32"===n)return`atomicAdd(&${t}, bitcast<${n}>(${r}));`;return`
              ${i}bitcast<${n}>(oldValue) + (${r})${o}`;case"max":if("i32"===n||"u32"===n)return`atomicMax(&${t}, bitcast<${n}>(${r}));`;return`
                ${i}max(bitcast<f32>(oldValue), (${r}))${o}`;case"min":if("i32"===n||"u32"===n)return`atomicMin(&${t}, bitcast<${n}>(${r}));`;return`${i}min(bitcast<${n}>(oldValue), (${r}))${o}`;case"mul":return`${i}(bitcast<${n}>(oldValue) * (${r}))${o}`;default:throw Error(`Reduction ${e} is not supported.`)}})(t.reduction,"output[data_offset + i]","value",s.type.value)}
  }

      }`}}),{inputs:[e.inputs[1],e.inputs[2]],outputs:[]})}}}),gp=dQ({"web/lib/wasm/jsep/webgpu/ops/resize.ts"(){"use strict";fb(),fv(),fS(),fO(),lQ=(e,t,r,n)=>`
  // The whole part and the fractional part are calculated separately due to inaccuracy of floating
  // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
  // offset-by-one error later in floor().
  let big = (${e}) * (${t});
  let whole = ${n}(big / (${r}));
  let fract = ${n}(big % (${r})) / ${n}(${r});
  return whole + fract;
`,lY=(e,t,r,n)=>e.rank>n?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",l0=(e,t)=>{let r,n=[],i=[],o=[],s=new Uint32Array((r=e.customDataBuffer).buffer,r.byteOffset,1)[0];if(0!==t.antialias)throw Error("Only default value (0) for Antialias attribute is supported");((e,t,r,n,i,o)=>{let[s,a,u]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],l=e[0].dims.length;if(s>0&&e.length>s&&e[s].dims.length>0)e[s].getFloat32Array().forEach(e=>o.push(e));else if("tf_crop_and_resize"===t.coordinateTransformMode)throw Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(a>0&&e.length>a&&1===e[a].dims.length&&e[a].dims[0]>0){var d;let i;if(e[a].getFloat32Array().forEach(e=>n.push(e)),0!==n.length&&n.length!==l&&r>=18&&n.length!==t.axes.length)throw Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");if(n.every(e=>e>0||(()=>{throw Error("Resize requires scales input values to be positive")})),n.length>0){if("linear"===t.mode){if(2!==n.length&&3!==n.length&&(4!==n.length||1!==n[0]||1!==n[1])&&(4!==n.length||1!==n[0]||1!==n[3])&&(5!==n.length||1!==n[0]||1!==n[1]))throw Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if("cubic"===t.mode&&2!==n.length&&(4!==n.length||1!==n[0]||1!==n[1])&&(4!==n.length||1!==n[0]||1!==n[3]))throw Error("Resize requires scales input size to be 2 or 4 for cubic mode")}t.axes.length>0&&(d=t.axes,d.every(e=>e>=0&&e<l||(()=>{throw Error("Resize requires axes input values to be positive and less than rank")})),i=Array(l).fill(1),d.forEach((e,t)=>i[e]=n[t]),i).forEach((e,t)=>n[t]=e)}if(u>0&&e.length>u&&1===e[u].dims.length&&e[u].dims[0]>0&&(e[u].getBigInt64Array().forEach(e=>i.push(Number(e))),0!==i.length&&i.length!==l&&r>=18&&i.length!==t.axes.length))throw Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(0!==n.length&&n.length!==t.axes.length)throw Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(0!==i.length&&i.length!==t.axes.length)throw Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if(void 0!==n&&void 0!==i&&n.length>0&&i.length>l)throw Error("Resize requires only of scales or sizes to be specified")})(e.inputs,t,s,n,i,o),e.compute(((e,t,r,n,i,o)=>{var s,a,u;let l,d,p=e.dims,c=(s=t.axes,l=Array(a=p.length).fill(0).concat(Array(a).fill(1)),d=0===o.length?l:o.slice(),s.length>0?(s.forEach((e,t)=>{l[e]=d[t],l[t+a]=d[s.length+t]}),l):d),h=((e,t,r,n)=>{let i=[];if(r.length>0)if(n.length>0){if(e.forEach(e=>i.push(e)),Math.max(...n)>e.length)throw Error("axes is out of bound");n.forEach((e,t)=>i[e]=r[t])}else r.forEach(e=>i.push(e));else if(0===t.length)throw Error("Resize requires either scales or sizes.");else i=e.map((e,r)=>Math.round(e*t[r]));return i})(p,n,i,t.axes),f=n.slice();if(0===n.length){let e,r;f=p.map((e,t)=>0===e?1:h[t]/e),"stretch"!==t.keepAspectRatioPolicy&&(u=f,e=(()=>{switch(t.keepAspectRatioPolicy){case"not_larger":return t.axes.length>0?Math.min(...t.axes.map(e=>u[e]),Number.MAX_VALUE):Math.min(...u,Number.MAX_VALUE);case"not_smaller":return t.axes.length>0?Math.max(...t.axes.map(e=>u[e]),5e-324):Math.max(...u,5e-324);default:throw Error(`Keep aspect ratio policy ${t.keepAspectRatioPolicy} is not supported`)}})(),u.fill(1,0,u.length),r=p.slice(),t.axes.length>0?(t.axes.forEach(t=>u[t]=e),t.axes.forEach(e=>r[e]=Math.round(p[e]*u[e]))):(u.fill(e,0,u.length),r.forEach((e,t)=>r[t]=Math.round(e*u[t]))),h=r)}let g=sx("output",e.dataType,h.length),m=sv("input",e.dataType,p.length),b=oG.size(h),y=p.length===h.length&&p.every((e,t)=>e===h[t]),_="tf_crop_and_resize"===t.coordinateTransformMode,v=t.extrapolationValue,x=m.type.value;return{name:"Resize",shaderCache:{hint:`${t.cacheKey}|${r}|${f.length>0?"cubic"===t.mode?f:f.length:""}|${i.length>0?i:""}|${c.length>0?c:""}|${y}|${"nearest"===t.mode?p.length:p}`,inputDependencies:["rank"]},getShaderSource:e=>{let n;return`
      ${y?"":`
      ${n=t.coordinateTransformMode,`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${x} { `+(()=>{switch(n){case"asymmetric":return`
          if (xScale < 1.0 || floor(xScale) != xScale) {
            return ${x}(xResized) / ${x}(xScale);
          } else {
            ${lQ("xResized","lengthOriginal","lengthResized",x)}
          }
        `;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${x}(xResized) + 0.5) / ${x}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${x}(xResized) + 0.5) / ${x}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    ${lQ("xResized","lengthOriginal - 1","lengthResized - 1",x)}
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${x}(roiStart) * ${x}(lengthOriginal - 1) +
                        (${x}(xResized) * ${x}(roiEnd - roiStart) * ${x}(lengthOriginal - 1)) /
                        ${x}(lengthResized - 1);
                  } else {
                    return 0.5 * ${x}(roiStart + roiEnd) * ${x}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${x}xScale * ${x}(lengthResized);
                  const adjustment = ${x}(lengthResized) / outputWidth;
                  const center = ${x}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${x}(xResized) + 0.5) / ${x}(xScale)) - 0.5;`;case"half_pixel":return`return ((${x}(xResized) + 0.5) / ${x}(xScale)) - 0.5;`;default:throw Error(`Coordinate transform mode ${n} is not supported`)}})()+"}"};
      ${(()=>{switch(t.mode){case"nearest":let e,n,i,o;return`
              
    fn checkInputIndices(input_indices: ${m.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${p.length}; i++) {
        var input_index = ${m.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${sy("uniforms.input_shape","i",p.length)}) {
          return false;
        }
      }
      return true;
    };
              ${e=t.nearestMode,`fn getNearestPixelFromOriginal(xOriginal: ${x}, isDownSample: bool) -> ${x} {`+(()=>{switch(e){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";default:if(r<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw Error(`Nearest mode ${e} is not supported`)}})()+"}"};
              ${n=h,i=f.length,o=c.length,`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${g.type.indices}) -> ${m.type.indices} {
      var input_indices: ${m.type.indices};
      for (var i:u32 = 0; i < ${n.length}; i++) {
        var output_index = ${g.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${sy("uniforms.scales","i",i)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${sy("uniforms.roi","i",o)};
          var roi_hi = ${sy("uniforms.roi",`i + ${p.length}`,o)};
          var input_shape_i = ${sy("uniforms.input_shape","i",p.length)};
          var output_shape_i = ${sy("uniforms.output_shape","i",n.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${_} || (original_idx >= 0 && original_idx < ${g.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${g.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${m.indicesSet("input_indices","i","input_index")}
      }
      return input_indices;
    }`};
              `;case"linear":let s,a,u;return`
              ${s=h,a=f.length,u=c.length,`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${g.type.indices}) -> array<${g.type.value}, ${s.length}> {
      var original_indices: array<${g.type.value}, ${s.length}>;
      for (var i:u32 = 0; i < ${s.length}; i++) {
        var output_index = ${g.indicesGet("output_indices","i")};
        var scale = ${sy("uniforms.scales","i",a)};
        var roi_low = ${sy("uniforms.roi","i",u)};
        var roi_hi = ${sy("uniforms.roi",`i + ${p.length}`,u)};
        if (scale == 1.0) {
          original_indices[i] = ${g.type.value}(output_index);
        } else {
          var input_shape_i = ${sy("uniforms.input_shape","i",p.length)};
          var output_shape_i = ${sy("uniforms.output_shape","i",s.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`};
              ${(()=>{if(2===p.length||4===p.length)return`${((e,t,r,n,i)=>{let[o,s,a,u]=2===r.length?[-1,0,1,-1]:[0,2,3,1],l=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${l} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(row, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",a,`max(0, min(col, ${r[a]} - 1))`)};
      ${lY(e,u,o,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${l} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${l} = originalIndices[${s}];
      var col:${l} = originalIndices[${a}];
      ${n?`if (row < 0 || row > (${r[s]} - 1) || col < 0 || col > (${r[a]} - 1)) {
        return ${i};
      }`:""};
      row = max(0, min(row, ${r[s]} - 1));
      col = max(0, min(col, ${r[a]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${u}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${o}])`:"0"};
      var x11: ${l} = getInputValue(batch, channel, row1, col1);
      var x12: ${l} = getInputValue(batch, channel, row1, col2);
      var x21: ${l} = getInputValue(batch, channel, row2, col1);
      var x22: ${l} = getInputValue(batch, channel, row2, col2);
      var dx1: ${l} = abs(row - ${l}(row1));
      var dx2: ${l} = abs(${l}(row2) - row);
      var dy1: ${l} = abs(col - ${l}(col1));
      var dy2: ${l} = abs(${l}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`})(m,g,p,_,v)}`;if(3===p.length||5===p.length)return`${((e,t,r,n,i)=>{let[o,s,a,u,l]=3===r.length?[-1,0,1,2,-1]:[0,2,3,4,1],d=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${d} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(depth, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",a,`max(0, min(height, ${r[a]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(width, ${r[u]} - 1))`)};
      ${lY(e,l,o,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${d} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${d} = originalIndices[${s}];
      var height:${d} = originalIndices[${a}];
      var width:${d} = originalIndices[${u}];
      ${n?`if (depth < 0 || depth > (${r[s]} - 1) || height < 0 || height > (${r[a]} - 1) || width < 0 || (width > ${r[u]} - 1)) {
      return ${i};
        }`:""};

    depth = max(0, min(depth, ${r[s]} - 1));
      height = max(0, min(height, ${r[a]} - 1));
      width = max(0, min(width, ${r[u]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${l}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${o}])`:"0"};

      var x111: ${d} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${d} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${d} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${d} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${d} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${d} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${d} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${d} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${d} = abs(depth - ${d}(depth1));
      var dx2: ${d} = abs(${d}(depth2) - depth);
      var dy1: ${d} = abs(height - ${d}(height1));
      var dy2: ${d} = abs(${d}(height2) - height);
      var dz1: ${d} = abs(width - ${d}(width1));
      var dz2: ${d} = abs(${d}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`})(m,g,p,_,v)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(2===p.length||4===p.length)return`${((e,t,r,n,i,o,s,a,u,l)=>{let[d,p]=2===r.length?[0,1]:[2,3],c=e.type.value,h=s=>{let p=s===d?"row":"col";return`
      fn ${p}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${c} {
        var output_index = ${t.indicesGet("output_indices",s)};
        var originalIdx: ${c} = getOriginalCoordinateFromResizedCoordinate(output_index, ${i[s]},
        ${n[s]}, ${r[s]}, ${o[s]}, ${o[s]} + ${r.length});
        var fractOriginalIdx: ${c} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${a} && (originalIdx < 0 || originalIdx > (${r[s]} - 1))) {
          return ${u};
        }
        var data: array<${c}, 4> = array<${c}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${p}: ${c} = originalIdx + ${c}(i);
          if (${p} < 0 || ${p} >= ${r[s]}) {
            ${l?`coefs[i + 1] = 0.0;
                        continue;`:a?`return ${u};`:`${p} = max(0, min(${p}, ${r[s]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",s,`u32(${p})`)};
          data[i + 1] = ${s===d?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${h(d)};
    ${h(p)};
  fn getCubicInterpolationCoefs(s: ${c}) -> array<${c}, 4> {
    var absS = abs(s);
    var coeffs: array<${c}, 4> = array<${c}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${c} = 1.0 - absS;
    var twoMinusAbsS: ${c} = 2.0 - absS;
    var onePlusAbsS: ${c} = 1.0 + absS;
    coeffs[0] = ((${s} * onePlusAbsS - 5 * ${s}) * onePlusAbsS + 8 * ${s}) * onePlusAbsS - 4 * ${s};
    coeffs[1] = ((${s} + 2) * absS - (${s} + 3)) * absS * absS + 1;
    coeffs[2] = ((${s} + 2) * oneMinusAbsS - (${s} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${s} * twoMinusAbsS - 5 * ${s}) * twoMinusAbsS + 8 * ${s}) * twoMinusAbsS - 4 * ${s};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${c}, 4>, coefs: array<${c}, 4>) -> ${c} {
    var coefsSum: ${c} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${c} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `})(m,g,p,h,f,c,t.cubicCoeffA,_,t.extrapolationValue,t.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${e.registerUniform("output_size","u32").registerUniform("scales","f32",f.length).registerUniform("roi","f32",c.length).declareVariables(m,g)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${y?"output[global_idx] = input[global_idx];":`
        let output_indices = ${g.offsetToIndices("global_idx")};
        var input_indices: ${m.type.indices};
        ${(()=>{switch(t.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${m.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${t.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${2===p.length||4===p.length?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${t.mode}`)}})()};
`}
      }`},getRunData:()=>({outputs:[{dims:h,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(b/64)},programUniforms:[{type:12,data:b},{type:1,data:f},{type:1,data:c},...sh(p,h)]})}})(e.inputs[0],t,s,n,i,o),{inputs:[0]})},l1=e=>{let t=e.antialias,r=e.axes,n=e.coordinateTransformMode,i=e.cubicCoeffA,o=0!==e.excludeOutside,s=e.extrapolationValue,a=e.keepAspectRatioPolicy,u=e.mode,l=""===e.nearestMode?"simple":e.nearestMode;return su({antialias:t,axes:r,coordinateTransformMode:n,cubicCoeffA:i,excludeOutside:o,extrapolationValue:s,keepAspectRatioPolicy:a,mode:u,nearestMode:l})}}}),gc=dQ({"web/lib/wasm/jsep/webgpu/ops/skip-layer-norm.ts"(){"use strict";fb(),fv(),fO(),l2=(e,t)=>{var r,n;let i,o,s,a,u,l,d,p,c,h,f,g,m;(e=>{if(!e||e.length<3)throw Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],n=e[2];if(t.dataType!==r.dataType||t.dataType!==n.dataType)throw Error("All inputs must have the same data type");if(3!==t.dims.length&&2!==t.dims.length)throw Error("Input must be 2D or 3D");if(3!==r.dims.length&&2!==r.dims.length)throw Error("Skip must be 2D or 3D");let i=t.dims[t.dims.length-1],o=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==i)throw Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==o)throw Error("Skip must have the same sequence length as input");if(1!==n.dims.length)throw Error("Gamma must be 1D");if(n.dims[n.dims.length-1]!==i)throw Error("Gamma must have the same hidden size as input");if(e.length>3){let t=e[3];if(1!==t.dims.length)throw Error("Beta must be 1D");if(t.dims[t.dims.length-1]!==i)throw Error("Beta must have the same hidden size as input")}if(e.length>4){let t=e[4];if(1!==t.dims.length)throw Error("Bias must be 1D");if(t.dims[t.dims.length-1]!==i)throw Error("Bias must have the same hidden size as input")}})(e.inputs);let b=[0];e.outputCount>1&&b.push(-3),e.outputCount>2&&b.push(-3),e.outputCount>3&&b.push(3),e.compute((r=e.inputs,n=e.outputCount,i=t.simplified,o=r[0].dims,s=oG.size(o),a=o.slice(-1)[0],u=[],l=!i&&r.length>3,d=r.length>4,p=!1,c=!1,h=n>3,g=[{type:12,data:s},{type:12,data:f=sf(a)},{type:12,data:a},{type:1,data:t.epsilon}],m=[{dims:o,dataType:r[0].dataType}],n>1&&m.push({dims:u,dataType:1}),n>2&&m.push({dims:u,dataType:1}),n>3&&m.push({dims:o,dataType:r[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${f};${p};${c};${h}`,inputDependencies:r.map((e,t)=>"type")},getShaderSource:e=>{let t=[sv("x",r[0].dataType,r[0].dims,f),sv("skip",r[1].dataType,r[1].dims,f),sv("gamma",r[2].dataType,r[2].dims,f)];l&&t.push(sv("beta",r[3].dataType,r[3].dims,f)),d&&t.push(sv("bias",r[4].dataType,r[4].dims,f)),t.push(sx("output",r[0].dataType,o,f)),p&&t.push(sx("mean_output",1,u)),c&&t.push(sx("inv_std_output",1,u)),h&&t.push(sx("input_skip_bias_sum",r[0].dataType,o,f));let n=sp(r[0].dataType),s=sp(1,f);return`

      ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}]).declareVariables(...t)}
      var<workgroup> sum_shared : array<${s}, 64>;
      var<workgroup> sum_squared_shared : array<${s}, 64>;

      ${e.mainStart([64,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / 64;

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / 64;
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == 63) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${d?"bias[offset1d + i]":n+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${h?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${sm(n,f,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = 64;
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${sb("sum",f)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${sb("square_sum",f)} / f32(uniforms.hidden_size) ${i?"":"- mean * mean"} + uniforms.epsilon);
        ${p?"mean_output[global_idx] = mean;":""}
        ${c?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${i?"":`- ${n}(mean)`}) *
            ${n}(inv_std_dev) * gamma[offset1d + i]
            ${l?"+ beta[offset1d + i]":""};
        }
      }`},getRunData:()=>({outputs:m,dispatchGroup:{x:Math.ceil(s/a)},programUniforms:g})}),{outputs:b})}}}),gh=dQ({"web/lib/wasm/jsep/webgpu/ops/slice.ts"(){"use strict";fb(),fv(),fS(),fO(),l3=(e,t)=>{let r=[];if(e.length>t)if(7===e[t].dataType)e[t].getBigInt64Array().forEach(e=>r.push(Number(e)));else if(6===e[t].dataType)e[t].getInt32Array().forEach(e=>r.push(Number(e)));else throw Error(`Input ${t} must be an array of int32 or int64`);return r},l4=(e,t,r,n,i)=>{let o=e;return(e<0&&(o+=r[n[t]]),i[t]<0)?Math.max(0,Math.min(o,r[n[t]]-1)):Math.max(0,Math.min(o,r[n[t]]))},l6=(e,t)=>{var r=e.inputs;if(!r||r.length<1)throw Error("too few inputs");if(0!==t.axes.length){if(t.axes.length!==t.starts.length||t.axes.length!==t.ends.length)throw Error("axes, starts and ends must have the same length")}else if(t.starts.length!==t.ends.length)throw Error("starts and ends must have the same length");r.slice(1).forEach((e,t)=>{if(6!==r[t+1].dataType&&7!==r[t+1].dataType)throw Error(`Input ${t} must be an array of int32 or int64`)});let n=((e,t)=>{if(!(e.length>1))return t;{let t=l3(e,1),r=l3(e,2),n=l3(e,3);return 0===n.length&&(n=[...Array(e[0].dims.length).keys()]),su({starts:t,ends:r,axes:n})}})(e.inputs,t);e.compute(((e,t)=>{let r=e[0].dims,n=oG.size(r),i=t.axes.length>0?oG.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],o=l3(e,4);o.forEach(e=>0!==e||(()=>{throw Error("step cannot be 0")})),0===o.length&&(o=Array(i.length).fill(1));let s=t.starts.map((e,t)=>l4(e,t,r,i,o)),a=t.ends.map((e,t)=>l4(e,t,r,i,o));if(i.length!==s.length||i.length!==a.length)throw Error("start, ends and axes should have the same number of elements");if(i.length!==r.length)for(let e=0;e<r.length;++e)i.includes(e)||(s.splice(e,0,0),a.splice(e,0,r[e]),o.splice(e,0,1));let u=o.map(e=>Math.sign(e));o.forEach((e,t,r)=>{if(e<0){let n=(a[t]-s[t])/e,i=s[t],u=i+n*o[t];s[t]=u,a[t]=i,r[t]=-e}});let l=r.slice(0);i.forEach((e,t)=>{l[e]=Math.ceil((a[e]-s[e])/o[e])});let d={dims:l,dataType:e[0].dataType},p=sx("output",e[0].dataType,l.length),c=sv("input",e[0].dataType,e[0].dims.length),h=oG.size(l),f=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:s.length},{name:"signs",type:"i32",length:u.length},{name:"steps",type:"u32",length:o.length}],g=[{type:12,data:h},{type:12,data:s},{type:6,data:u},{type:12,data:o},...sh(e[0].dims,l)];return{name:"Slice",shaderCache:{hint:`${u.length}_${s.length}_${o.length}`,inputDependencies:["rank"]},getShaderSource:e=>`
      ${e.registerUniforms(f).declareVariables(c,p)}
        fn calculateInputIndices(output_indices: ${p.type.indices}) -> ${c.type.indices} {
          var input_indices: ${c.type.indices};
          var carry = 0u;
          for (var i = ${r.length-1}; i >= 0; i--) {
            let input_shape_i = ${sy("uniforms.input_shape","i",r.length)};
            let steps_i = ${sy("uniforms.steps","i",r.length)};
            let signs_i = ${sy("uniforms.signs","i",r.length)};
            let starts_i = ${sy("uniforms.starts","i",r.length)};
            var output_index = ${p.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${c.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }
        ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${p.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${p.setByOffset("global_idx",c.getByIndices("input_indices"))}
      }`,getRunData:()=>({outputs:[d],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:g})}})(e.inputs,n),{inputs:[0]})},l8=e=>{let t=e.starts,r=e.ends,n=e.axes;return su({starts:t,ends:r,axes:n})}}}),gf=dQ({"web/lib/wasm/jsep/webgpu/ops/softmax.ts"(){"use strict";fb(),fv(),fS(),fE(),fO(),l5=(e,t)=>{let r,n,i,o,s,a,u,l,d,p,c,h,f,g,m,b,y,_,v;var x=e.inputs;if(!x||1!==x.length)throw Error("Softmax op requires 1 input.");i=(n=e.inputs[0]).dims,o=oG.size(i),s=i.length,u=(a=oG.normalizeAxis(t.axis,s))<i.length-1,l=[],u?((l=Array.from({length:s},(e,t)=>t))[a]=s-1,l[s-1]=a,r=e.compute(sO(n,l),{inputs:[n],outputs:[-1]})[0]):r=n,c=o/(p=(d=r.dims)[s-1]),h=sf(p),f=p/h,g=64,1===c&&(g=256),m=sv("x",r.dataType,r.dims,h),b=sx("result",r.dataType,r.dims,h),y=m.type.value,_="f32"===sp(r.dataType)?`var threadMax = ${y}(-3.4028234663852886e+38f);`:`var threadMax = ${y}(-65504.0h);`,v=e.compute({name:"Softmax",shaderCache:{hint:`${h};${g}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:d,dataType:r.dataType}],dispatchGroup:{x:c},programUniforms:[{type:6,data:f}]}),getShaderSource:e=>{var t,r;return`
      var<workgroup> rowMaxShared : ${y};
      var<workgroup> rowSumShared : ${y};
      var<workgroup> threadShared : array<${y}, ${g}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${y} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${y}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${e.registerUniform("packedCols","i32").declareVariables(m,b)}
      ${e.mainStart(g)}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${g};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${_}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${y}(${t="threadShared[0]",4===(r=h)?`max(max(${t}.x, ${t}.y), max(${t}.z, ${t}.w))`:2===r?`max(${t}.x, ${t}.y)`:3===r?`max(max(${t}.x, ${t}.y), ${t}.z)`:t});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${y}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${y}(${sb("threadShared[0]",h)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          var value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          // max operation protects against NaN since all values should be >=0
          value = max(value, ${y}(0.0));
          setValue(row, col, row_stride, value);
        }
      }`}},{inputs:[r],outputs:[u?-1:0]})[0],u&&e.compute(sO(v,l),{inputs:[v]})},l7=e=>su({axis:e.axis})}}),gg=dQ({"web/lib/wasm/jsep/webgpu/ops/tile.ts"(){"use strict";fb(),fv(),fO(),l9=e=>Array.from(e.getBigInt64Array(),Number),de=e=>{let t,r,n,i,o,s,a;var u,l=e.inputs;if(!l||2!==l.length)throw Error("Tile requires 2 inputs.");if(1!==l[0].dataType&&10!==l[0].dataType&&6!==l[0].dataType&&12!==l[0].dataType)throw Error("Tile only support float, float16, int32, and uint32 data types");if(7!==l[1].dataType)throw Error("Tile `repeats` input should be of int64 data type");if(1!==l[1].dims.length)throw Error("Tile `repeats` input should be 1-D");if(l9(l[1]).length!==l[0].dims.length)throw Error("Tile `repeats` input should have same number of elements as rank of input data tensor");e.compute((t=(u=e.inputs)[0].dims,n=((e,t)=>{let r=[];for(let n=0;n<e.length;++n)r.push(e[n]*t[n]);return r})(t,r=l9(u[1])),i=oG.size(n),o=u[0].dataType,s=sv("input",o,t.length),a=sx("output",o,n.length),{name:"Tile",shaderCache:{hint:`${r}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:n,dataType:u[0].dataType}],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:[{type:12,data:i},...sh(u[0].dims,n)]}),getShaderSource:e=>`
      const inputShape = ${s.indices(...t)};
      ${e.registerUniform("output_size","u32").declareVariables(s,a)}
      ${e.mainStart()}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${a.offsetToIndices("global_idx")};
      var input_indices: ${s.type.indices};
      for (var i = 0; i < ${t.length}; i++) {
        let input_dim_i = ${s.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${a.indicesGet("output_indices","i")}  % input_dim_i;

        ${s.indicesSet("input_indices","i","input_dim_value")}
      }
      ${a.setByOffset("global_idx",s.getByIndices("input_indices"))}
    }`}),{inputs:[0]})}}}),gm=dQ({"web/lib/wasm/jsep/webgpu/ops/where.ts"(){"use strict";fb(),fv(),fO(),dt=e=>{e.compute((e=>{let t=e[1].dims,r=e[2].dims,n=e[0].dims,i=e[1].dataType,o=!(oG.areEqual(t,r)&&oG.areEqual(r,n)),s=t,a=oG.size(t);if(o){let e=oq.calcShape(oq.calcShape(t,r,!1),n,!1);if(!e)throw Error("Can't perform where op on the given tensors");s=e,a=oG.size(s)}let u=Math.ceil(a/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:t=>((e,t,r,n,i)=>{let o,s=sx("output_data",i,r.length,4),a=sv("a_data",t[1].dataType,t[1].dims.length,4),u=sv("b_data",t[2].dataType,t[2].dims.length,4),l=sv("c_data",t[0].dataType,t[0].dims.length,4),d=(e,t,r)=>`select(${t}, ${e}, ${r})`;if(n){let e=(e,t,r="")=>{let n=`a_data[index_a${t}][component_a${t}]`,i=`b_data[index_b${t}][component_b${t}]`,o=`bool(c_data[index_c${t}] & (0xffu << (component_c${t} * 8)))`;return`
            let output_indices${t} = ${s.offsetToIndices(`global_idx * 4u + ${t}u`)};
            let offset_a${t} = ${a.broadcastedIndicesToOffset(`output_indices${t}`,s)};
            let offset_b${t} = ${u.broadcastedIndicesToOffset(`output_indices${t}`,s)};
            let offset_c${t} = ${l.broadcastedIndicesToOffset(`output_indices${t}`,s)};
            let index_a${t} = offset_a${t} / 4u;
            let index_b${t} = offset_b${t} / 4u;
            let index_c${t} = offset_c${t} / 4u;
            let component_a${t} = offset_a${t} % 4u;
            let component_b${t} = offset_b${t} % 4u;
            let component_c${t} = offset_c${t} % 4u;
            ${e}[${t}] = ${r}(${d(n,i,o)});
          `};o=9===i?`
            var data = vec4<u32>(0);
            ${e("data",0,"u32")}
            ${e("data",1,"u32")}
            ${e("data",2,"u32")}
            ${e("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:`
            ${e("output_data[global_idx]",0)}
            ${e("output_data[global_idx]",1)}
            ${e("output_data[global_idx]",2)}
            ${e("output_data[global_idx]",3)}
          `}else o=s.setByOffset("global_idx",d(a.getByOffset("global_idx"),u.getByOffset("global_idx"),l.getByOffset("global_idx")));return`
        ${e.registerUniform("vec_size","u32").declareVariables(l,a,u,s)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${o}
      }`})(t,e,s,o,i),getRunData:()=>({outputs:[{dims:s,dataType:i}],dispatchGroup:{x:Math.ceil(a/64/4)},programUniforms:[{type:12,data:u},...sh(n,t,r,s)]})}})(e.inputs))}}}),gb=dQ({"web/lib/wasm/jsep/webgpu/op-resolve-rules.ts"(){"use strict";fA(),fD(),fz(),fC(),fj(),fR(),fB(),fW(),fX(),fZ(),fJ(),fQ(),fY(),f0(),f1(),f2(),f3(),f4(),f6(),f8(),f5(),gt(),gr(),gn(),gi(),go(),f7(),gs(),ga(),gu(),gl(),gd(),fk(),gp(),ge(),gc(),gh(),gf(),f9(),gg(),fE(),fN(),gm(),dr=new Map([["Abs",[aa]],["Acos",[au]],["Acosh",[al]],["Add",[aJ]],["ArgMax",[s9,ae]],["ArgMin",[s7,ae]],["Asin",[ad]],["Asinh",[ap]],["Atan",[ac]],["Atanh",[ah]],["Attention",[an]],["AveragePool",[lB,lR]],["BatchNormalization",[ai]],["BiasAdd",[ao]],["BiasSplitGelu",[aX]],["Cast",[ag,af]],["Ceil",[ab]],["Clip",[am]],["Concat",[a5,a7]],["Conv",[uT,uw]],["ConvTranspose",[uA,uP]],["Cos",[ay]],["Cosh",[a_]],["CumSum",[uD,uz]],["DepthToSpace",[uC,uN]],["DequantizeLinear",[lW,lK]],["DFT",[uq,uG]],["Div",[aQ]],["Einsum",[uQ,uY]],["Elu",[ax,av]],["Equal",[aY]],["Erf",[a$]],["Exp",[aT]],["Expand",[u1]],["FastGelu",[u2]],["Floor",[aI]],["FusedConv",[uT,uw]],["Gather",[u4,u3]],["GatherElements",[le,u9]],["GatherBlockQuantized",[u5,u7]],["GatherND",[u6,u8]],["Gelu",[aS]],["Gemm",[lr,lt]],["GlobalAveragePool",[lL,lF]],["GlobalMaxPool",[lH,lG]],["Greater",[a3]],["GreaterOrEqual",[a6]],["GridSample",[lu,ll]],["GroupQueryAttention",[lw]],["HardSigmoid",[aC,az]],["HardSwish",[aN]],["InstanceNormalization",[lT]],["LayerNormalization",[lI]],["LeakyRelu",[aO,av]],["Less",[a4]],["LessOrEqual",[a8]],["Log",[aH]],["MatMul",[lS]],["MatMulNBits",[lO,lE]],["MaxPool",[lU,lq]],["Mul",[a0]],["MultiHeadAttention",[lf,lp]],["Neg",[aP]],["Not",[aE]],["Pad",[lP]],["Pow",[a1]],["QuickGelu",[aK,av]],["Range",[lX]],["Reciprocal",[ak]],["ReduceMin",[s2]],["ReduceMean",[sJ]],["ReduceMax",[s1]],["ReduceSum",[s4]],["ReduceProd",[s3]],["ReduceL1",[sQ]],["ReduceL2",[sY]],["ReduceLogSum",[s8]],["ReduceLogSumExp",[s0]],["ReduceSumSquare",[s6]],["Relu",[aA]],["Resize",[l0,l1]],["RotaryEmbedding",[l_]],["ScatterND",[lJ,lZ]],["Sigmoid",[aD]],["Sin",[aj]],["Sinh",[aR]],["Slice",[l6,l8]],["SkipLayerNormalization",[l2]],["Split",[lm,lb]],["Sqrt",[aB]],["Softmax",[l5,l7]],["Sub",[a2]],["Tan",[aM]],["Tanh",[aL]],["ThresholdedRelu",[aG,av]],["Tile",[de]],["Transpose",[sE,sP]],["Where",[dt]]])}}),gy=dQ({"web/lib/wasm/jsep/webgpu/program-manager.ts"(){"use strict";ph(),f_(),fO(),dn=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,n,i){E(e.programInfo.name);let o=this.backend.device,s=this.backend.getComputePassEncoder();this.backend.writeTimestamp(2*this.backend.pendingDispatchNumber);let a=[];for(let e of t)a.push({binding:a.length,resource:{buffer:e.buffer}});for(let e of r)a.push({binding:a.length,resource:{buffer:e.buffer}});i&&a.push({binding:a.length,resource:i});let u=o.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:a,label:e.programInfo.name});if("capturing"===this.backend.sessionStatus){let t={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:u,dispatchGroup:n};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(t)}s.setPipeline(e.computePipeline),s.setBindGroup(0,u),s.dispatchWorkgroups(...n),this.backend.writeTimestamp(2*this.backend.pendingDispatchNumber+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||"at-passes"===this.backend.queryType)&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),P(e.programInfo.name)}dispose(){}build(e,t){E(e.name);let r=this.backend.device,n=[];[{feature:"shader-f16",extension:"f16"},{feature:"subgroups",extension:"subgroups"}].forEach(e=>{r.features.has(e.feature)&&n.push(`enable ${e.extension};`)});let i=sI(t,this.backend.device.limits),o=e.getShaderSource(i),s=`${n.join("\n")}
${i.additionalImplementations}
${o}`,a=r.createShaderModule({code:s,label:e.name});oV("verbose",()=>`[WebGPU] ${e.name} shader code: ${s}`);let u=r.createComputePipeline({compute:{module:a,entryPoint:"main"},layout:"auto",label:e.name});return P(e.name),{programInfo:e,computePipeline:u,uniformVariablesInfo:i.variablesInfo}}normalizeDispatchGroupSize(e){let t="number"==typeof e?e:e.x,r="number"==typeof e?1:e.y||1,n="number"==typeof e?1:e.z||1,i=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=i&&r<=i&&n<=i)return[t,r,n];let o=t*r*n,s=Math.ceil(Math.sqrt(o));if(!(s>i))return[s,s,1];if((s=Math.ceil(Math.cbrt(o)))>i)throw Error("Total dispatch size exceeds WebGPU maximum.");return[s,s,s]}}}}),g_={};d0(g_,{WebGpuBackend:()=>ds});var gv=dQ({"web/lib/wasm/jsep/backend-webgpu.ts"(){"use strict";ph(),fb(),f_(),fx(),fI(),gb(),gy(),di=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},ds=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(null===this.currentKernelId)throw Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],n={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r},i=e=>t.features.has(e)&&r.push(e)&&!0;i("chromium-experimental-timestamp-query-inside-passes")||i("timestamp-query"),i("shader-f16"),i("subgroups"),this.device=await t.requestDevice(n);let o=t.info??("function"==typeof t.requestAdapterInfo?await t.requestAdapterInfo():void 0);this.adapterInfo=new di(o),this.gpuDataManager=ss(this),this.programManager=new dn(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,oL(e.logLevel,!!e.debug),this.device.onuncapturederror=e=>{e.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${e.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!0}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){void 0!==this.querySet&&this.querySet.destroy(),this.gpuDataManager.dispose(),this.device&&this.env?.webgpu&&this.device.lost.then(()=>{delete this.env.webgpu.device})}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};"at-passes"===this.queryType&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:2*this.pendingDispatchNumber,endOfPassWriteIndex:2*this.pendingDispatchNumber+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){let e;this.commandEncoder&&(E(),this.endComputePass(),"none"!==this.queryType&&(this.commandEncoder.resolveQuerySet(this.querySet,0,2*this.pendingDispatchNumber,this.queryResolveBuffer,0),e=this.device.createBuffer({size:2*this.pendingDispatchNumber*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,2*this.pendingDispatchNumber*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,"none"!==this.queryType&&e.mapAsync(GPUMapMode.READ).then(()=>{let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let e=0;e<t.length/2;e++){let n=r[e],i=n.kernelId,o=this.kernels.get(i),s=o.kernelType,a=o.kernelName,u=n.programName,l=n.inputTensorViews,d=n.outputTensorViews,p=t[2*e],c=t[2*e+1];void 0===this.queryTimeBase&&(this.queryTimeBase=p);let h=Number(p-this.queryTimeBase),f=Number(c-this.queryTimeBase);if(!Number.isSafeInteger(h)||!Number.isSafeInteger(f))throw RangeError("incorrect timestamp range");if(this.env.webgpu.profiling?.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:l.map(e=>({dims:e.dims,dataType:ok(e.dataType)})),outputsMetadata:d.map(e=>({dims:e.dims,dataType:ok(e.dataType)})),kernelId:i,kernelType:s,kernelName:a,programName:u,startTime:h,endTime:f});else{let e="";l.forEach((t,r)=>{e+=`input[${r}]: [${t.dims}] | ${ok(t.dataType)}, `});let t="";d.forEach((e,r)=>{t+=`output[${r}]: [${e.dims}] | ${ok(e.dataType)}, `}),console.log(`[profiling] kernel "${i}|${s}|${a}|${u}" ${e}${t}start time: ${h} ns, execution time: ${f-h} ns`)}S("GPU",`${u}::${p}::${c}`)}e.unmap(),this.pendingQueries.delete(e)}),P())}run(e,t,r,n,i,o){let s,a;E(e.name);let u=[];for(let e=0;e<t.length;++e){let r=t[e].data;if(0===r)continue;let n=this.gpuDataManager.get(r);if(!n)throw Error(`no GPU data for input: ${r}`);u.push(n)}let{outputs:l,dispatchGroup:d,programUniforms:p}=e.getRunData(t),c=0===r.length?l.map((e,t)=>t):r;if(c.length!==l.length)throw Error(`Output size ${c.length} must be equal to ${l.length}.`);let h=[],f=[];for(let e=0;e<l.length;++e){if(!Number.isInteger(c[e])||c[e]<-3||c[e]>=o)throw Error(`Invalid output index: ${c[e]}`);if(-3===c[e])continue;let t=-1===c[e],r=-2===c[e],s=t||r?i(l[e].dataType,l[e].dims):n(c[e],l[e].dataType,l[e].dims);if(h.push(s),0===s.data)continue;let a=this.gpuDataManager.get(s.data);if(!a)throw Error(`no GPU data for output: ${s.data}`);if(t&&this.temporaryData.push(a),r){let e=this.kernelPersistentData.get(this.currentKernelId);e||(e=[],this.kernelPersistentData.set(this.currentKernelId,e)),e.push(a)}f.push(a)}if(u.length!==t.length||f.length!==h.length){if(0===f.length)return P(e.name),h;throw Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}if(p){let e=0,t=[];p.forEach(r=>{let n,i,o="number"==typeof r.data?[r.data]:r.data;if(0===o.length)return;let s=10===r.type?2:4;10===r.type?(i=o.length>4?16:o.length>2?8:o.length*s,n=o.length>4?16:s*o.length):(i=o.length<=2?o.length*s:16,n=16),e=Math.ceil(e/i)*i,t.push(e);let a=10===r.type?8:4;e+=o.length>4?Math.ceil(o.length/a)*n:o.length*s});let r=new ArrayBuffer(e=16*Math.ceil(e/16));p.forEach((e,n)=>{let i=t[n],o="number"==typeof e.data?[e.data]:e.data;if(6===e.type)new Int32Array(r,i,o.length).set(o);else if(12===e.type)new Uint32Array(r,i,o.length).set(o);else if(10===e.type)new Uint16Array(r,i,o.length).set(o);else if(1===e.type)new Float32Array(r,i,o.length).set(o);else throw Error(`Unsupported uniform type: ${ok(e.type)}`)});let n=this.gpuDataManager.create(e,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(n.buffer,0,r,0,e),this.gpuDataManager.release(n.id),s={offset:0,size:e,buffer:n.buffer}}let g=this.programManager.normalizeDispatchGroupSize(d),m=1===g[1]&&1===g[2],b=(a=e.name,e.shaderCache?.hint&&(a+="["+e.shaderCache.hint+"]"),a+=":"+m+`:${((e,t)=>{if(t.length!==e.length)throw Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let n=0;n<e.length;++n){let i=e[n].dataType;switch(t[n]){case"none":r.push("");break;case"type":r.push(`${i}`);break;case"rank":{let t=e[n].dims.length;r.push(`${i};${t}`);break}case"dims":{let t=e[n].dims.join(",");r.push(`${i};${t}`);break}default:throw Error(`unsupported input dependency: ${t[n]}`)}}return r.join("|")})(t,e.shaderCache?.inputDependencies??Array(t.length).fill("dims"))}`),y=this.programManager.getArtifact(b);if(y||(y=this.programManager.build(e,g),this.programManager.setArtifact(b,y),oV("info",()=>`[artifact] key: ${b}, programName: ${e.name}`)),p&&y.uniformVariablesInfo){if(p.length!==y.uniformVariablesInfo.length)throw Error(`Uniform variables count mismatch: expect ${y.uniformVariablesInfo.length}, got ${p.length} in program "${y.programInfo.name}".`);for(let e=0;e<p.length;e++){let t=p[e],r=t.type,n="number"==typeof t.data?1:t.data.length,[i,o]=y.uniformVariablesInfo[e];if(r!==i||n!==o)throw Error(`Uniform variable ${e} mismatch: expect type ${i} with size ${o}, got type ${r} with size ${n} in program "${y.programInfo.name}".`)}}if(oV("info",()=>`[ProgramManager] run "${e.name}" (key=${b}) with ${g[0]}x${g[1]}x${g[2]}`),"none"!==this.queryType||"capturing"===this.sessionStatus){let e={kernelId:this.currentKernelId,programName:y.programInfo.name,inputTensorViews:t,outputTensorViews:h};this.pendingKernels.push(e),"capturing"===this.sessionStatus&&this.capturedPendingKernels.get(this.currentSessionId).push(e)}return this.programManager.run(y,u,f,g,s),P(e.name),h}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,n){let i=dr.get(e);if(!i)throw Error(`kernel not implemented: ${e}`);let o={kernelType:e,kernelName:n,kernelEntry:i[0],attributes:[i[1],r]};this.kernels.set(t,o)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let e of t)this.gpuDataManager.release(e.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let n=this.kernels.get(e);if(!n)throw Error(`kernel not created: ${e}`);let i=n.kernelType,o=n.kernelName,s=n.kernelEntry,a=n.attributes;if(null!==this.currentKernelId)throw Error(`kernel "[${i}] ${o}" is not allowed to be called recursively`);this.currentKernelId=e,a[0]&&(a[1]=a[0](a[1]),a[0]=void 0),oV("info",()=>`[WebGPU] Start to run kernel "[${i}] ${o}"...`);let u=this.env.debug;this.temporaryData=[];try{return u&&this.device.pushErrorScope("validation"),s(t,a[1]),0}catch(e){return r.push(Promise.resolve(`[WebGPU] Kernel "[${i}] ${o}" failed. ${e}`)),1}finally{for(let e of(u&&r.push(this.device.popErrorScope().then(e=>e?`GPU validation error for kernel "[${i}] ${o}": ${e.message}`:null)),this.temporaryData))this.gpuDataManager.release(e.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,n){let i=this.sessionExternalDataMapping.get(e);i||(i=new Map,this.sessionExternalDataMapping.set(e,i));let o=i.get(t),s=this.gpuDataManager.registerExternalBuffer(r,n,o);return i.set(t,[s,r]),s}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(e=>this.gpuDataManager.unregisterExternalBuffer(e[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let n=await si(this,e,t);return oZ(n.buffer,r)}}writeTimestamp(e){"inside-passes"===this.queryType&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){this.queryType="none",(this.env.webgpu.profiling?.mode==="default"||(void 0===this.env.trace?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),"none"!==this.queryType&&void 0===this.querySet&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:2*this.maxDispatchNumber}),this.queryResolveBuffer=this.device.createBuffer({size:2*this.maxDispatchNumber*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){oV("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){oV("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){oV("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let n=0;n<r;n++){let r=this.getComputePassEncoder(),i=e[n];this.writeTimestamp(2*this.pendingDispatchNumber),r.setPipeline(i.computePipeline),r.setBindGroup(0,i.bindGroup),r.dispatchWorkgroups(...i.dispatchGroup),this.writeTimestamp(2*this.pendingDispatchNumber+1),this.pendingDispatchNumber++,"none"!==this.queryType&&this.pendingKernels.push(t[n]),(this.pendingDispatchNumber>=this.maxDispatchNumber||"at-passes"===this.queryType)&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onCreateSession(){this.gpuDataManager.onCreateSession()}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}}),gx={};d0(gx,{init:()=>dl});var gw=dQ({"web/lib/wasm/jsep/init.ts"(){"use strict";fb(),f_(),fv(),f$(),da=class e{constructor(e,t,r,n){this.module=e,this.dataType=t,this.data=r,this.dims=n}getFloat32Array(){if(1!==this.dataType)throw Error("Invalid data type");let e=oG.size(this.dims);return 0===e?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,e)}getBigInt64Array(){if(7!==this.dataType)throw Error("Invalid data type");let e=oG.size(this.dims);return 0===e?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,e)}getInt32Array(){if(6!==this.dataType)throw Error("Invalid data type");let e=oG.size(this.dims);return 0===e?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,e)}getUint16Array(){if(10!==this.dataType&&4!==this.dataType)throw Error("Invalid data type");let e=oG.size(this.dims);return 0===e?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,e)}reshape(t){if(oG.size(t)!==oG.size(this.dims))throw Error("Invalid new shape");return new e(this.module,this.dataType,this.data,t)}},du=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo;let n=e.PTR_SIZE,i=r/e.PTR_SIZE,o=4===n?"i32":"i64";this.opKernelContext=Number(e.getValue(n*i++,o));let s=Number(e.getValue(n*i++,o));this.outputCount=Number(e.getValue(n*i++,o)),this.customDataOffset=Number(e.getValue(n*i++,"*")),this.customDataSize=Number(e.getValue(n*i++,o));let a=[];for(let t=0;t<s;t++){let t=Number(e.getValue(n*i++,o)),r=Number(e.getValue(n*i++,"*")),s=Number(e.getValue(n*i++,o)),u=[];for(let t=0;t<s;t++)u.push(Number(e.getValue(n*i++,o)));a.push(new da(e,t,r,u))}this.inputs=a}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}compute(e,t){let r=t?.inputs?.map(e=>"number"==typeof e?this.inputs[e]:e)??this.inputs,n=t?.outputs??[],i=(e,t,r)=>new da(this.module,t,this.output(e,r),r),o=(e,t)=>{let r=oA(e,t);if(!r)throw Error(`Unsupported data type: ${e}`);let n=r>0?this.backend.gpuDataManager.create(r).id:0;return new da(this.module,e,n,t)};return this.backend.run(e,r,n,i,o,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let r=this.module.PTR_SIZE,n=4===r?"i32":"i64",i=this.module.stackAlloc((1+t.length)*r);this.module.setValue(i,t.length,n);for(let e=0;e<t.length;e++)this.module.setValue(i+r*(e+1),t[e],n);return this.module._JsepOutput(this.opKernelContext,e,i)}catch(r){throw Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${r}`)}finally{this.module.stackRestore(r)}}},dl=async(e,t,r,n)=>{let i=t.jsepInit;if(!i)throw Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if("webgpu"===e){let e=new(gv(),d3(g_)).WebGpuBackend;await e.initialize(r,n),i("webgpu",[e,t=>e.alloc(Number(t)),t=>e.free(t),(r,n,i,o=!1)=>{if(o)oV("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${Number(r)}, dst=${Number(n)}, size=${Number(i)}`),e.memcpy(Number(r),Number(n));else{oV("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${Number(r)}, gpuDataId=${Number(n)}, size=${Number(i)}`);let o=t.HEAPU8.subarray(Number(r>>>0),Number(r>>>0)+Number(i));e.upload(Number(n),o)}},async(r,n,i)=>{oV("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${r}, dataOffset=${n}, size=${i}`),await e.download(Number(r),()=>t.HEAPU8.subarray(Number(n)>>>0,Number(n+i)>>>0))},(r,n,i)=>e.createKernel(r,Number(n),i,t.UTF8ToString(t._JsepGetNodeName(Number(n)))),t=>e.releaseKernel(t),(r,n,i,o)=>{oV("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${i}, kernel=${r}, contextDataOffset=${n}`);let s=new du(t,e,Number(n));return e.computeKernel(Number(r),s,o)},()=>e.captureBegin(),()=>e.captureEnd(),()=>e.replay()])}else{let e=new o7(r);i("webnn",[e,()=>e.reserveTensorId(),t=>e.releaseTensorId(t),async(t,r,n,i,o)=>e.ensureTensor(t,r,n,i,o),(t,r)=>{e.uploadTensor(t,r)},async(t,r)=>e.downloadTensor(t,r),(t,r)=>e.registerMLContext(t,r),!!r.trace])}}}}),g$=dQ({"web/lib/wasm/wasm-core-impl.ts"(){"use strict";ph(),fg(),fm(),fb(),fh(),ff(),fy(),dd=async e=>{var t,r;t=e.wasm.numThreads,r=oz(e.logLevel),0!==ox()._OrtInit(t,r)&&oT("Can't initialize onnxruntime.")},dp=async(e,t)=>{ox().asyncInit?.();let r=e.webgpu.adapter;if("webgpu"===t){if("u"<typeof navigator||!navigator.gpu)throw Error("WebGPU is not supported in current environment");if(r){if("object"!=typeof r.limits||"object"!=typeof r.features||"function"!=typeof r.requestDevice)throw Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let t=e.webgpu.powerPreference;if(void 0!==t&&"low-power"!==t&&"high-performance"!==t)throw Error(`Invalid powerPreference setting: "${t}"`);let n=e.webgpu.forceFallbackAdapter;if(void 0!==n&&"boolean"!=typeof n)throw Error(`Invalid forceFallbackAdapter setting: "${n}"`);if(!(r=await navigator.gpu.requestAdapter({powerPreference:t,forceFallbackAdapter:n})))throw Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}}if("webnn"===t&&("u"<typeof navigator||!navigator.ml))throw Error("WebNN is not supported in current environment");{let n=(gw(),d3(gx)).init;"webgpu"===t&&await n("webgpu",ox(),e,r),"webnn"===t&&await n("webnn",ox(),e)}},dc=new Map,dh=(e,t)=>{let r=ox(),n=r.stackSave(),i=0;try{let n=r.PTR_SIZE,o=r.stackAlloc(2*n),s=r._OrtGetInputOutputMetadata(e,t,o,o+n);0!==s&&oT("Can't get session input/output metadata.");let a=Number(r.getValue(o,"*"));i=Number(r.getValue(o+n,"*"));let u=r.HEAP32[i/4];if(0===u)return[a,0];let l=r.HEAPU32[i/4+1],d=[];for(let e=0;e<l;e++){let t=Number(r.getValue(i+8+e*n,"*"));d.push(0!==t?r.UTF8ToString(t):Number(r.getValue(i+8+(e+l)*n,"*")))}return[a,u,d]}finally{r.stackRestore(n),0!==i&&r._OrtFree(i)}},df=e=>{let t=ox(),r=t._malloc(e.byteLength);if(0===r)throw Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},dg=async(e,t)=>{let r,n,i=ox();Array.isArray(e)?[r,n]=e:e.buffer===i.HEAPU8.buffer?[r,n]=[e.byteOffset,e.byteLength]:[r,n]=df(e);let o=0,s=0,a=0,u=[],l=[],d=[];try{if([s,u]=await oE(t),t?.externalData&&i.mountExternalData){let e=[];for(let r of t.externalData){let t="string"==typeof r?r:r.path,n="string"==typeof r?r:r.data;e.push(oR(n).then(e=>{i.mountExternalData(t,e)}))}await Promise.all(e)}for(let e of t?.executionProviders??[]){let t="string"==typeof e?e:e.name;if("webnn"===t){if(i.shouldTransferToMLTensor=!1,"string"!=typeof e){let t=e?.context,r=e?.gpuDevice,n=e?.deviceType,o=e?.powerPreference;t?i.currentContext=t:r?i.currentContext=await i.webnnCreateMLContext(r):i.currentContext=await i.webnnCreateMLContext({deviceType:n,powerPreference:o})}else i.currentContext=await i.webnnCreateMLContext();break}}o=await i._OrtCreateSession(r,n,s),i.webgpuOnCreateSession?.(o),0===o&&oT("Can't create a session."),i.jsepOnCreateSession?.(),i.currentContext&&(i.webnnRegisterMLContext(o,i.currentContext),i.currentContext=void 0,i.shouldTransferToMLTensor=!0);let[e,p]=(e=>{let t=ox(),r=t.stackSave();try{let r=t.PTR_SIZE,n=t.stackAlloc(2*r),i=t._OrtGetInputOutputCount(e,n,n+r);0!==i&&oT("Can't get session input/output count.");let o=4===r?"i32":"i64";return[Number(t.getValue(n,o)),Number(t.getValue(n+r,o))]}finally{t.stackRestore(r)}})(o),c=!!t?.enableGraphCapture,h=[],f=[],g=[],m=[],b=[];for(let t=0;t<e;t++){let[e,r,n]=dh(o,t);0===e&&oT("Can't get an input name."),l.push(e);let s=i.UTF8ToString(e);h.push(s),g.push(0===r?{name:s,isTensor:!1}:{name:s,isTensor:!0,type:ok(r),shape:n})}for(let r=0;r<p;r++){let[n,s,a]=dh(o,r+e);0===n&&oT("Can't get an output name."),d.push(n);let u=i.UTF8ToString(n);f.push(u),m.push(0===s?{name:u,isTensor:!1}:{name:u,isTensor:!0,type:ok(s),shape:a});{if(c&&t?.preferredOutputLocation===void 0){b.push("gpu-buffer");continue}let e="string"==typeof t?.preferredOutputLocation?t.preferredOutputLocation:t?.preferredOutputLocation?.[u]??"cpu",r=i.webnnIsGraphOutput;if("cpu"===e&&r&&r(o,u)){b.push("ml-tensor-cpu-output");continue}if("cpu"!==e&&"cpu-pinned"!==e&&"gpu-buffer"!==e&&"ml-tensor"!==e)throw Error(`Not supported preferred output location: ${e}.`);if(c&&"gpu-buffer"!==e)throw Error(`Not supported preferred output location: ${e}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);b.push(e)}}let y=null;return b.some(e=>"gpu-buffer"===e||"ml-tensor"===e||"ml-tensor-cpu-output"===e)&&(a=i._OrtCreateBinding(o),0===a&&oT("Can't create IO binding."),y={handle:a,outputPreferredLocations:b,outputPreferredLocationsEncoded:b.map(e=>"ml-tensor-cpu-output"===e?"ml-tensor":e).map(e=>oj(e))}),dc.set(o,[o,l,d,y,c,!1]),[o,h,f,g,m]}catch(e){throw l.forEach(e=>i._OrtFree(e)),d.forEach(e=>i._OrtFree(e)),0!==a&&0!==i._OrtReleaseBinding(a)&&oT("Can't release IO binding."),0!==o&&0!==i._OrtReleaseSession(o)&&oT("Can't release session."),e}finally{i._free(r),0!==s&&0!==i._OrtReleaseSessionOptions(s)&&oT("Can't release session options."),u.forEach(e=>i._free(e)),i.unmountExternalData?.()}},dm=e=>{let t=ox(),r=dc.get(e);if(!r)throw Error(`cannot release session. invalid session id: ${e}`);let[n,i,o,s,a]=r;s&&(a&&0!==t._OrtClearBoundOutputs(s.handle)&&oT("Can't clear bound outputs."),0!==t._OrtReleaseBinding(s.handle)&&oT("Can't release IO binding.")),t.jsepOnReleaseSession?.(e),t.webnnOnReleaseSession?.(e),t.webgpuOnReleaseSession?.(e),i.forEach(e=>t._OrtFree(e)),o.forEach(e=>t._OrtFree(e)),0!==t._OrtReleaseSession(n)&&oT("Can't release session."),dc.delete(e)},db=async(e,t,r,n,i,o,s=!1)=>{let a,u;if(!e)return void t.push(0);let l=ox(),d=l.PTR_SIZE,p=e[0],c=e[1],h=e[3],f=h;if("string"===p&&("gpu-buffer"===h||"ml-tensor"===h))throw Error("String tensor is not supported on GPU.");if(s&&"gpu-buffer"!==h)throw Error(`External buffer must be provided for input/output index ${o} when enableGraphCapture is true.`);if("gpu-buffer"===h){let t=e[2].gpuBuffer;u=oA(oP(p),c);{let e=l.jsepRegisterBuffer;if(!e)throw Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');a=e(n,o,t,u)}}else if("ml-tensor"===h){let t=e[2].mlTensor;u=oA(oP(p),c);let r=l.webnnRegisterMLTensor;if(!r)throw Error('Tensor location "ml-tensor" is not supported without using WebNN.');a=r(n,t,oP(p),c)}else{let t=e[2];if(Array.isArray(t)){u=d*t.length,a=l._malloc(u),r.push(a);for(let e=0;e<t.length;e++){if("string"!=typeof t[e])throw TypeError(`tensor data at index ${e} is not a string`);l.setValue(a+e*d,ow(t[e],r),"*")}}else{let e=l.webnnIsGraphInput,o=l.webnnIsGraphOutput;if("string"!==p&&e&&o){let s=l.UTF8ToString(i);if(e(n,s)||o(n,s)){let e=oP(p);u=oA(e,c),f="ml-tensor";let r=l.webnnCreateTemporaryTensor,i=l.webnnUploadTensor;if(!r||!i)throw Error('Tensor location "ml-tensor" is not supported without using WebNN.');let o=await r(n,e,c);i(o,new Uint8Array(t.buffer,t.byteOffset,t.byteLength)),a=o}else u=t.byteLength,a=l._malloc(u),r.push(a),l.HEAPU8.set(new Uint8Array(t.buffer,t.byteOffset,u),a)}else u=t.byteLength,a=l._malloc(u),r.push(a),l.HEAPU8.set(new Uint8Array(t.buffer,t.byteOffset,u),a)}}let g=l.stackSave(),m=l.stackAlloc(4*c.length);try{c.forEach((e,t)=>l.setValue(m+t*d,e,4===d?"i32":"i64"));let e=l._OrtCreateTensor(oP(p),a,u,m,c.length,oj(f));0===e&&oT(`Can't create tensor for input/output. session=${n}, index=${o}.`),t.push(e)}finally{l.stackRestore(g)}},dy=async(e,t,r,n,i,o)=>{let s=ox(),a=s.PTR_SIZE,u=dc.get(e);if(!u)throw Error(`cannot run inference. invalid session id: ${e}`);let l=u[0],d=u[1],p=u[2],c=u[3],h=u[4],f=u[5],g=t.length,m=n.length,b=0,y=[],_=[],v=[],x=[],w=[],$=s.stackSave(),T=s.stackAlloc(g*a),I=s.stackAlloc(g*a),S=s.stackAlloc(m*a),O=s.stackAlloc(m*a);try{let u;[b,y]=oI(o),k("wasm prepareInputOutputTensor");for(let n=0;n<g;n++)await db(r[n],_,x,e,d[t[n]],t[n],h);for(let t=0;t<m;t++)await db(i[t],v,x,e,p[n[t]],g+n[t],h);A("wasm prepareInputOutputTensor");for(let e=0;e<g;e++)s.setValue(T+e*a,_[e],"*"),s.setValue(I+e*a,d[t[e]],"*");for(let e=0;e<m;e++)s.setValue(S+e*a,v[e],"*"),s.setValue(O+e*a,p[n[e]],"*");if(c&&!f){let{handle:r,outputPreferredLocations:o,outputPreferredLocationsEncoded:a}=c;if(d.length!==g)throw Error(`input count from feeds (${g}) is expected to be always equal to model's input count (${d.length}).`);k("wasm bindInputsOutputs");for(let n=0;n<g;n++){let i=t[n],o=await s._OrtBindInput(r,d[i],_[n]);0!==o&&oT(`Can't bind input[${n}] for session=${e}.`)}for(let t=0;t<m;t++){let u=n[t];if(i[t]?.[3]){w.push(v[t]);let n=s._OrtBindOutput(r,p[u],v[t],0);0!==n&&oT(`Can't bind pre-allocated output[${t}] for session=${e}.`)}else{let n=s._OrtBindOutput(r,p[u],0,a[u]);0!==n&&oT(`Can't bind output[${t}] to ${o[t]} for session=${e}.`)}}A("wasm bindInputsOutputs"),dc.set(e,[l,d,p,c,h,!0])}s.jsepOnRunStart?.(l),s.webnnOnRunStart?.(l),u=c?await s._OrtRunWithBinding(l,c.handle,m,S,b):await s._OrtRun(l,I,T,g,O,m,S,b),0!==u&&oT("failed to call OrtRun().");let $=[],E=[];k("wasm ProcessOutputTensor");for(let t=0;t<m;t++){let r=Number(s.getValue(S+t*a,"*"));if(r===v[t]||w.includes(v[t])){$.push(i[t]),r!==v[t]&&0!==s._OrtReleaseTensor(r)&&oT("Can't release tensor.");continue}let o=s.stackSave(),u=s.stackAlloc(4*a),l=!1,d,p=0;try{let i=s._OrtGetTensorData(r,u,u+a,u+2*a,u+3*a);0!==i&&oT(`Can't access output tensor data on index ${t}.`);let o=4===a?"i32":"i64",h=Number(s.getValue(u,o));p=s.getValue(u+a,"*");let f=s.getValue(u+2*a,"*"),g=Number(s.getValue(u+3*a,o)),m=[];for(let e=0;e<g;e++)m.push(Number(s.getValue(f+e*a,o)));0!==s._OrtFree(f)&&oT("Can't free memory for tensor dims.");let b=m.reduce((e,t)=>e*t,1);d=ok(h);let y=c?.outputPreferredLocations[n[t]];if("string"===d){if("gpu-buffer"===y||"ml-tensor"===y)throw Error("String tensor is not supported on GPU.");let e=[];for(let t=0;t<b;t++){let r=s.getValue(p+t*a,"*"),n=s.getValue(p+(t+1)*a,"*"),i=t===b-1?void 0:n-r;e.push(s.UTF8ToString(r,i))}$.push([d,m,e,"cpu"])}else if("gpu-buffer"===y&&b>0){let e=s.jsepGetBuffer;if(!e)throw Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let t=e(p),n=oA(h,b);if(void 0===n||!oC(d))throw Error(`Unsupported data type: ${d}`);l=!0,$.push([d,m,{gpuBuffer:t,download:s.jsepCreateDownloader(t,n,d),dispose:()=>{0!==s._OrtReleaseTensor(r)&&oT("Can't release tensor.")}},"gpu-buffer"])}else if("ml-tensor"===y&&b>0){let t=s.webnnEnsureTensor,n=s.webnnIsGraphInputOutputTypeSupported;if(!t||!n)throw Error('preferredLocation "ml-tensor" is not supported without using WebNN.');let i=oA(h,b);if(void 0===i||!oN(d))throw Error(`Unsupported data type: ${d}`);if(!n(e,d,!1))throw Error(`preferredLocation "ml-tensor" for ${d} output is not supported by current WebNN Context.`);let o=await t(e,p,h,m,!1);l=!0,$.push([d,m,{mlTensor:o,download:s.webnnCreateMLTensorDownloader(p,d),dispose:()=>{s.webnnReleaseTensorId(p),s._OrtReleaseTensor(r)}},"ml-tensor"])}else if("ml-tensor-cpu-output"===y&&b>0){let e=s.webnnCreateMLTensorDownloader(p,d)(),t=$.length;l=!0,E.push((async()=>{let n=[t,await e];return s.webnnReleaseTensorId(p),s._OrtReleaseTensor(r),n})()),$.push([d,m,[],"cpu"])}else{let e=new(oD(d))(b);new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(s.HEAPU8.subarray(p,p+e.byteLength)),$.push([d,m,e,"cpu"])}}finally{s.stackRestore(o),"string"===d&&p&&s._free(p),l||s._OrtReleaseTensor(r)}}for(let[t,r]of(c&&!h&&(0!==s._OrtClearBoundOutputs(c.handle)&&oT("Can't clear bound outputs."),dc.set(e,[l,d,p,c,h,!1])),await Promise.all(E)))$[t][2]=r;return A("wasm ProcessOutputTensor"),$}finally{s.webnnOnRunEnd?.(l),s.stackRestore($),_.forEach(e=>s._OrtReleaseTensor(e)),v.forEach(e=>s._OrtReleaseTensor(e)),x.forEach(e=>s._free(e)),0!==b&&s._OrtReleaseRunOptions(b),y.forEach(e=>s._free(e))}},d_=e=>{let t=ox(),r=dc.get(e);if(!r)throw Error("invalid session id");let n=r[0],i=t._OrtEndProfiling(n);0===i&&oT("Can't get an profile file name."),t._OrtFree(i)},dv=e=>{let t=[];for(let r of e){let e=r[2];!Array.isArray(e)&&"buffer"in e&&t.push(e.buffer)}return t}}}),gT=dQ({"web/lib/wasm/proxy-wrapper.ts"(){"use strict";ph(),g$(),fh(),fc(),dx=()=>!!l.wasm.proxy&&"u">typeof document,d$=!1,dT=!1,dI=!1,dE=new Map,dP=(e,t)=>{let r=dE.get(e);r?r.push(t):dE.set(e,[t])},dk=()=>{if(d$||!dT||dI||!dw)throw Error("worker not ready")},dA=e=>{switch(e.data.type){case"init-wasm":d$=!1,e.data.err?(dI=!0,dO[1](e.data.err)):(dT=!0,dO[0]()),dS&&(URL.revokeObjectURL(dS),dS=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=dE.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out)}}},dD=async()=>{if(!dT){if(d$)throw Error("multiple calls to 'initWasm()' detected.");if(dI)throw Error("previous call to 'initWasm()' failed.");if(d$=!0,dx())return new Promise((e,t)=>{dw?.terminate(),oh().then(([r,n])=>{try{(dw=n).onerror=e=>t(e),dw.onmessage=dA,dO=[e,t];let i={type:"init-wasm",in:l};if(!i.in.wasm.wasmPaths&&r){let e=ou();e&&(i.in.wasm.wasmPaths=e)}dw.postMessage(i),dS=r}catch(e){t(e)}},t)});try{await ov(l.wasm),await dd(l),dT=!0}catch(e){throw dI=!0,e}finally{d$=!1}}},dz=async e=>{if(dx())return dk(),new Promise((t,r)=>{dP("init-ep",[t,r]);let n={type:"init-ep",in:{epName:e,env:l}};dw.postMessage(n)});await dp(l,e)},dC=async e=>dx()?(dk(),new Promise((t,r)=>{dP("copy-from",[t,r]),dw.postMessage({type:"copy-from",in:{buffer:e}},[e.buffer])})):df(e),dN=async(e,t)=>{if(!dx())return dg(e,t);if(t?.preferredOutputLocation)throw Error('session option "preferredOutputLocation" is not supported for proxy.');return dk(),new Promise((r,n)=>{dP("create",[r,n]);let i={type:"create",in:{model:e,options:{...t}}},o=[];e instanceof Uint8Array&&o.push(e.buffer),dw.postMessage(i,o)})},dj=async e=>{if(dx())return dk(),new Promise((t,r)=>{dP("release",[t,r]),dw.postMessage({type:"release",in:e})});dm(e)},dR=async(e,t,r,n,i,o)=>{if(!dx())return dy(e,t,r,n,i,o);if(r.some(e=>"cpu"!==e[3]))throw Error("input tensor on GPU is not supported for proxy.");if(i.some(e=>e))throw Error("pre-allocated output tensor is not supported for proxy.");return dk(),new Promise((i,s)=>{dP("run",[i,s]),dw.postMessage({type:"run",in:{sessionId:e,inputIndices:t,inputs:r,outputIndices:n,options:o}},dv(r))})},dB=async e=>{if(dx())return dk(),new Promise((t,r)=>{dP("end-profiling",[t,r]),dw.postMessage({type:"end-profiling",in:e})});d_(e)}}}),gI=dQ({"web/lib/wasm/session-handler-inference.ts"(){"use strict";ph(),gT(),fb(),fl(),fy(),dM=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw Error(`invalid data location: ${e.location} for ${t()}`)}},dF=e=>{switch(e[3]){case"cpu":return new I(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!oC(t))throw Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:n,dispose:i}=e[2];return I.fromGpuBuffer(r,{dataType:t,dims:e[1],download:n,dispose:i})}case"ml-tensor":{let t=e[0];if(!oN(t))throw Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:n,dispose:i}=e[2];return I.fromMLTensor(r,{dataType:t,dims:e[1],download:n,dispose:i})}default:throw Error(`invalid data location: ${e[3]}`)}},dL=class{async fetchModelAndCopyToWasmMemory(e){return dC(await oR(e))}async loadModel(e,t){let r;E(),r="string"==typeof e?or?await oR(e):await this.fetchModelAndCopyToWasmMemory(e):e,[this.sessionId,this.inputNames,this.outputNames,this.inputMetadata,this.outputMetadata]=await dN(r,t),P()}async dispose(){return dj(this.sessionId)}async run(e,t,r){E();let n=[],i=[];Object.entries(e).forEach(e=>{let t=e[0],r=e[1],o=this.inputNames.indexOf(t);if(-1===o)throw Error(`invalid input '${t}'`);n.push(r),i.push(o)});let o=[],s=[];Object.entries(t).forEach(e=>{let t=e[0],r=e[1],n=this.outputNames.indexOf(t);if(-1===n)throw Error(`invalid output '${t}'`);o.push(r),s.push(n)});let a=n.map((e,t)=>dM(e,()=>`input "${this.inputNames[i[t]]}"`)),u=o.map((e,t)=>e?dM(e,()=>`output "${this.outputNames[s[t]]}"`):null),l=await dR(this.sessionId,i,a,s,u,r),d={};for(let e=0;e<l.length;e++)d[this.outputNames[s[e]]]=o[e]??dF(l[e]);return P(),d}startProfiling(){}endProfiling(){dB(this.sessionId)}}}}),gS={};d0(gS,{OnnxruntimeWebAssemblyBackend:()=>dU,initializeFlags:()=>dV,wasmBackend:()=>dq});var gO=dQ({"web/lib/backend-wasm.ts"(){"use strict";ph(),gT(),gI(),dV=()=>{("number"!=typeof l.wasm.initTimeout||l.wasm.initTimeout<0)&&(l.wasm.initTimeout=0);let e=l.wasm.simd;if("boolean"!=typeof e&&void 0!==e&&"fixed"!==e&&"relaxed"!==e&&(console.warn(`Property "env.wasm.simd" is set to unknown value "${e}". Reset it to \`false\` and ignore SIMD feature checking.`),l.wasm.simd=!1),"boolean"!=typeof l.wasm.proxy&&(l.wasm.proxy=!1),"boolean"!=typeof l.wasm.trace&&(l.wasm.trace=!1),"number"!=typeof l.wasm.numThreads||!Number.isInteger(l.wasm.numThreads)||l.wasm.numThreads<=0)if("u">typeof self&&!self.crossOriginIsolated)l.wasm.numThreads=1;else{let e="u"<typeof navigator?dJ("node:os").cpus().length:navigator.hardwareConcurrency;l.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},dq=new(dU=class{async init(e){dV(),await dD(),await dz(e)}async createInferenceSessionHandler(e,t){let r=new dL;return await r.loadModel(e,t),r}})}});ph(),ph(),ph();var gE=pc;{let e=(fu(),d3(fa)).onnxjsBackend;n("webgl",e,-10)}{let e=(gO(),d3(gS)).wasmBackend;n("webgpu",e,5),n("webnn",e,5),n("cpu",e,10),n("wasm",e,10)}Object.defineProperty(l.versions,"web",{value:"1.30.0",enumerable:!0});export{z as InferenceSession,S as TRACE,k as TRACE_EVENT_BEGIN,A as TRACE_EVENT_END,E as TRACE_FUNC_BEGIN,P as TRACE_FUNC_END,I as Tensor,gE as default,l as env,n as registerBackend};