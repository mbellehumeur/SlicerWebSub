// ../client/dist/hub-client.js
var ue = "UNKNOWN";
var Oe = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function Ke(e, t = ue) {
  return String(e || t).trim().replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "") || t;
}
function At(e) {
  return `${Ke(e)}-`;
}
function F(e) {
  return typeof crypto < "u" && crypto.randomUUID ? e + crypto.randomUUID().replace(/-/g, "").slice(0, 16) : e + Math.random().toString(36).substring(2, 18);
}
function Pe(e = ue) {
  const t = Ke(e);
  let n = "";
  for (let r = 0; r < 6; r++) {
    const i = Math.floor(Math.random() * Oe.length);
    n += Oe[i];
  }
  return `${t}-${n}`;
}
var De = [
  "dicom",
  "nifti",
  "jpg",
  "png",
  "nrrd",
  "imagingstudy",
  "scene"
  // scene-update (LiveSync HubBlobs multipart)
];
function X(e) {
  if (typeof e != "string") return false;
  const t = e.trim().toLowerCase();
  if (!t) return false;
  for (let n = 0; n < De.length; n++) {
    const r = De[n];
    if (t === r || t.startsWith(`${r}-`) || t.startsWith(`${r}_`))
      return true;
  }
  return false;
}
function Nt(e) {
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView(e);
}
async function Y(e) {
  if (e instanceof ArrayBuffer)
    return e;
  if (Nt(e)) {
    const { buffer: t, byteOffset: n, byteLength: r } = e;
    return t.slice(n, n + r);
  }
  if (typeof Blob < "u" && e instanceof Blob && typeof e.arrayBuffer == "function")
    return e.arrayBuffer();
  throw new Error(
    "HubClient: binary resource.data must be ArrayBuffer, TypedArray, DataView, Blob, or File"
  );
}
function M(e) {
  const t = e && e.context;
  if (!t || typeof t != "object" || Array.isArray(t))
    return [];
  const n = t.files;
  return Array.isArray(n) ? n.filter((r) => r && typeof r == "object") : [];
}
function le(e) {
  if (!e || typeof e != "object" || e.data != null)
    return { payloadIds: [], chunkByteLengths: [] };
  const t = e.payloadIds;
  if (Array.isArray(t) && t.length) {
    const r = t.map((s2) => typeof s2 == "string" ? s2.trim() : "").filter(Boolean), i = Array.isArray(e.chunkByteLengths) ? e.chunkByteLengths.filter((s2) => typeof s2 == "number" && s2 >= 0) : [];
    if (i.length === r.length)
      return { payloadIds: r, chunkByteLengths: i };
    if (r.length === 1) {
      const s2 = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
      return {
        payloadIds: r,
        chunkByteLengths: s2 != null ? [s2] : []
      };
    }
  }
  const n = typeof e.payloadId == "string" ? e.payloadId.trim() : "";
  if (n) {
    const r = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
    return {
      payloadIds: [n],
      chunkByteLengths: r != null ? [r] : []
    };
  }
  return { payloadIds: [], chunkByteLengths: [] };
}
function Tt(e) {
  const t = M(e);
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (r.data == null) {
      const i = le(r);
      if (i.payloadIds.length)
        return {
          kind: "files",
          index: n,
          chunkIndex: 0,
          payloadId: i.payloadIds[0],
          expectedChunkBytes: i.chunkByteLengths[0] ?? null
        };
    }
  }
  return null;
}
function Qe(e) {
  return Tt(e);
}
function se(e) {
  return !!Qe(e);
}
function oe(e, t) {
  return (typeof e == "string" ? e.trim().toLowerCase() : "").startsWith("nifti") ? t === 0 ? "nifti-send.nii.gz" : `nifti-send-${t + 1}.nii.gz` : t === 0 ? "dicom-send.dcm" : `dicom-send-${t + 1}.dcm`;
}
function ce(e) {
  return (typeof e == "string" ? e.trim().toLowerCase() : "").startsWith("nifti") ? "application/octet-stream" : "application/dicom";
}
function ne(e) {
  const t = e && e.event;
  if (!t || !X(t["hub.event"]) || M(t).length)
    return e;
  const n = t["hub.event"], r = t.context;
  let i = [];
  Array.isArray(r) ? i = r : r != null && (i = [r]);
  const s2 = [];
  for (let o = 0; o < i.length; o++) {
    const c = i[o];
    if (c && typeof c == "object") {
      const a = c.resource;
      if (a && typeof a == "object" && a.data != null) {
        const u = { ...a };
        (typeof u.fileName != "string" || !u.fileName.trim()) && (u.fileName = oe(n, o)), (typeof u.mimeType != "string" || !u.mimeType.trim()) && (u.mimeType = ce(n)), s2.push(u);
      }
    }
  }
  return s2.length ? {
    ...e,
    event: {
      ...t,
      context: {
        files: s2
      }
    }
  } : e;
}
function et(e, t) {
  const n = e && e.event, r = n && n.context;
  let i = [];
  Array.isArray(r) ? i = r : r != null && (i = [r]);
  for (let s2 = 0; s2 < i.length; s2++) {
    const o = i[s2];
    if (o && typeof o == "object") {
      const c = o.resource;
      if (c && typeof c == "object") {
        const a = typeof c.fileName == "string" ? c.fileName.trim() : "";
        if (a)
          return a;
      }
    }
  }
  return t;
}
function J(e) {
  if (!e || typeof e != "object")
    return false;
  const t = typeof e.url == "string" ? e.url.trim() : "";
  if (!t)
    return false;
  const n = t.toLowerCase();
  return n.startsWith("http://") || n.startsWith("https://");
}
function Ut(e) {
  const t = [];
  for (let n = 0; n < e.length; n += 1)
    J(e[n]) || t.push(n);
  return t;
}
function Lt(e) {
  const t = e && e.event;
  if (!t || !X(t["hub.event"]))
    return false;
  const n = M(t);
  return n.length ? n.some(
    (r) => r.data != null && !J(r)
  ) : false;
}
async function kt(e, t = "", n = 0) {
  if (!e || typeof e != "object")
    throw new Error(
      "HubClient: binary batch publish files[] entries must be objects"
    );
  const r = J(e);
  let i = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
  if ("data" in e && e.data != null) {
    if (typeof e.data == "string")
      throw new Error(
        "HubClient: binary batch publish string payloads are not supported; pass binary input instead"
      );
    i = (await Y(e.data)).byteLength;
  }
  if (i == null && r) {
    const o = { ...e };
    return delete o.data, delete o.binaryTransfer, delete o.payloadId, delete o.payloadIds, delete o.chunkByteLengths, delete o.expiresAt, (typeof o.fileName != "string" || !o.fileName.trim()) && (o.fileName = oe(t, n)), (typeof o.mimeType != "string" || !o.mimeType.trim()) && (o.mimeType = ce(t)), o;
  }
  if (i == null)
    throw new Error(
      "HubClient: binary batch publish requires files[].data or files[].byteLength"
    );
  const s2 = { ...e };
  return delete s2.data, delete s2.binaryTransfer, r || delete s2.url, delete s2.payloadId, delete s2.payloadIds, delete s2.chunkByteLengths, delete s2.expiresAt, s2.byteLength = i, (typeof s2.fileName != "string" || !s2.fileName.trim()) && (s2.fileName = oe(t, n)), (typeof s2.mimeType != "string" || !s2.mimeType.trim()) && (s2.mimeType = ce(t)), s2;
}
async function vt(e) {
  if (!e.event || typeof e.event != "object")
    throw new Error("HubClient: binary batch publish requires event object");
  const t = e.event;
  if (!X(t["hub.event"]))
    return e;
  const n = t.context;
  if (!n || typeof n != "object" || Array.isArray(n))
    throw new Error(
      "HubClient: binary batch publish requires event.context object"
    );
  const r = n.files;
  if (!Array.isArray(r) || !r.length)
    throw new Error(
      "HubClient: binary batch publish requires non-empty event.context.files[]"
    );
  const i = t["hub.event"], s2 = await Promise.all(
    r.map(
      (o, c) => kt(o, i, c)
    )
  );
  return {
    ...e,
    event: {
      ...t,
      context: {
        ...n,
        files: s2
      }
    }
  };
}
async function Me(e) {
  const t = e && e.event;
  if (!t)
    return [];
  const r = M(t).filter(
    (i) => i && typeof i == "object" && i.data != null && !J(i)
  );
  return Promise.all(r.map((i) => Y(i.data)));
}
function Rt(e, t, n) {
  const r = new TextEncoder(), i = r.encode(`\r
`), s2 = [], o = (c) => {
    s2.push(r.encode(c));
  };
  o(
    `--${e}\r
Content-Type: application/dicom+json\r
\r
${t}\r
`
  );
  for (let c = 0; c < n.length; c++) {
    const a = n[c], u = a && a.mimeType && String(a.mimeType).trim() || "application/octet-stream";
    o(`--${e}\r
Content-Type: ${u}\r
\r
`), s2.push(new Uint8Array(a.buffer)), s2.push(i);
  }
  return o(`--${e}--\r
`), new Blob(s2);
}
async function Ot({
  msg: e,
  fileBytesList: t,
  hub: n,
  messageIdPrefix: r
}) {
  const i = await vt(e), s2 = await Promise.all(
    (t || []).map((d) => Y(d))
  ), o = M(i.event), c = Ut(o);
  if (s2.length !== c.length)
    throw new Error(
      `HubClient: binary batch publish expected ${c.length} file part(s), got ${s2.length}`
    );
  const a = s2.map((d, b) => {
    const f = c[b];
    return {
      buffer: d,
      mimeType: o[f] && o[f].mimeType || "application/octet-stream"
    };
  }), u = `hub-batch-${F(r())}`, l = Rt(
    u,
    JSON.stringify(i),
    a
  );
  try {
    return await fetch(n.hub_endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${n.token}`,
        "Content-Type": `multipart/related; boundary="${u}"; type="application/dicom"`
      },
      body: l
    });
  } catch (d) {
    const b = d instanceof Error ? d.message : String(d);
    return console.debug("HubClient:", b), null;
  }
}
function Pt() {
  return {
    name: "",
    friendlyName: "",
    version: "",
    hub_endpoint: "",
    authorization_endpoint: "",
    token_endpoint: "",
    client_id: "",
    client_secret: ""
  };
}
function Dt() {
  return {
    subscriberName: "",
    productName: "",
    productVersion: "",
    actors: [],
    topic: "",
    events: [],
    lease: 999,
    userName: "",
    defaultTargetActor: ""
  };
}
function re(e) {
  if (e == null)
    return;
  const t = String(e).trim();
  if (!(!t || t === "*"))
    return t;
}
function Mt(e) {
  if (e == null)
    return;
  const t = String(e).trim();
  if (!(!t || t === "*"))
    return t;
}
function Ht() {
  return {
    token: "",
    lastIdToken: "",
    lastPublishedMessageID: "",
    subscribed: false,
    resubscribeRequested: false,
    websocket: null,
    /** ``mock`` | ``oidc`` from GET /api/hub/auth/config (when known). */
    authMode: "",
    /** True after tokens were applied from an OIDC redirect fragment. */
    oidcSession: false
  };
}
function $t() {
  if (typeof navigator > "u")
    return null;
  const e = {};
  typeof navigator.userAgent == "string" && navigator.userAgent.trim() && (e.userAgent = navigator.userAgent.trim()), typeof navigator.platform == "string" && navigator.platform.trim() && (e.platform = navigator.platform.trim()), typeof navigator.language == "string" && navigator.language.trim() && (e.language = navigator.language.trim());
  try {
    const t = Intl.DateTimeFormat().resolvedOptions().timeZone;
    typeof t == "string" && t.trim() && (e.timezone = t.trim());
  } catch {
  }
  return Object.keys(e).length ? e : null;
}
function He(e) {
  return e || (typeof window < "u" ? `${window.location.origin}/castCallback` : "");
}
function $e(e, t, n, r = "") {
  const i = new URLSearchParams();
  i.append("hub.mode", e), i.append("hub.channel.type", "websocket"), i.append("hub.callback", n), i.append("hub.events", (t.events || []).toString()), i.append("hub.topic", t.topic || ""), i.append("hub.lease", String(t.lease || 999)), i.append("subscriber.name", t.subscriberName || ""), i.append("subscriber.product.name", t.productName || ""), i.append(
    "subscriber.product.version",
    t.productVersion || r || ""
  );
  const s2 = (t.actors || []).map((c) => c.trim()).filter(Boolean);
  s2.length && i.append("subscriber.actors", JSON.stringify(s2));
  const o = $t();
  return o && i.append("subscriber.client_info", JSON.stringify(o)), i;
}
var U = 25;
function xt(e) {
  try {
    const t = new URL(e);
    return t.hostname.toLowerCase() === "localhost" && (t.hostname = "127.0.0.1"), t.toString();
  } catch {
    return e;
  }
}
function Ft(e) {
  if (!(e instanceof Error))
    return false;
  const t = e.name || "";
  return t === "TypeError" || t === "NetworkError";
}
function Bt(e, t) {
  if (!e)
    return "";
  try {
    const n = `/api/hub/payloads/${encodeURIComponent(e)}`;
    return xt(new URL(n, t).toString());
  } catch (n) {
    return console.warn("HubClient: invalid payloadId url", e, n), "";
  }
}
function jt(e) {
  delete e.binaryTransfer, delete e.url, delete e.payloadId, delete e.payloadIds, delete e.chunkByteLengths, delete e.expiresAt;
}
function tt(e, t) {
  const n = e.reduce((s2, o) => s2 + o.byteLength, 0);
  if (typeof t == "number" && t >= 0 && n !== t)
    throw new Error(
      `HubClient: payload size mismatch expected=${t} received=${n}`
    );
  const r = new Uint8Array(n);
  let i = 0;
  for (let s2 = 0; s2 < e.length; s2++)
    r.set(new Uint8Array(e[s2]), i), i += e[s2].byteLength;
  return r.buffer;
}
function xe(e, t, n) {
  const r = e && e.event, i = r && r.context, s2 = i && i.files, o = s2 && s2[t];
  return !o || typeof o != "object" ? false : (jt(o), o.data = n, o.byteLength = n.byteLength, true);
}
async function nt(e, t, { hubEndpoint: n, accessToken: r }) {
  const i = Bt(e, n);
  if (!i)
    throw new Error("HubClient.fetchPayload: missing or invalid payloadId");
  const s2 = {};
  r && (s2.Authorization = `Bearer ${r}`);
  async function o() {
    const c = await fetch(i, {
      method: "GET",
      credentials: "omit",
      headers: s2
    });
    if (!c.ok)
      throw new Error(
        `HubClient.fetchPayload: GET ${c.status} ${c.statusText}`
      );
    const a = await c.arrayBuffer();
    if (typeof t == "number" && t >= 0 && a.byteLength !== t)
      throw new Error(
        `HubClient.fetchPayload: chunk size mismatch payloadId=${e.slice(
          0,
          8
        )} expected=${t} received=${a.byteLength}`
      );
    return a;
  }
  try {
    return await o();
  } catch (c) {
    if (Ft(c))
      return o();
    throw c;
  }
}
async function Wt(e, t) {
  const n = le(e);
  if (!n.payloadIds.length)
    throw new Error("HubClient.fetchPayload: no payloadIds on file entry");
  const r = [];
  for (let i = 0; i < n.payloadIds.length; i += U) {
    const s2 = n.payloadIds.slice(
      i,
      i + U
    ), o = n.chunkByteLengths.slice(
      i,
      i + U
    ), c = await Promise.all(
      s2.map(
        (a, u) => nt(a, o[u] ?? null, t)
      )
    );
    r.push(...c);
  }
  return tt(
    r,
    typeof e.byteLength == "number" ? e.byteLength : null
  );
}
async function Vt(e, t, n = U) {
  if (!e.length)
    return [];
  const r = Math.max(1, n | 0), i = new Array(e.length);
  let s2 = 0;
  async function o() {
    for (; s2 < e.length; ) {
      const a = s2++, u = e[a];
      i[a] = await nt(
        u.payloadId,
        u.expectedLength ?? null,
        t
      );
    }
  }
  const c = Array.from(
    { length: Math.min(r, e.length) },
    () => o()
  );
  return await Promise.all(c), i;
}
function Fe(e) {
  return JSON.parse(JSON.stringify(e));
}
function Gt(e) {
  const t = () => e();
  return {
    hasPendingPayload(n) {
      const r = n && n.event;
      return !!(r && se(r));
    },
    async fetchPayload(n) {
      const r = n && n.event;
      if (!r || !se(r))
        return n;
      const i = Qe(r);
      if (!i)
        return n;
      const s2 = typeof performance < "u" && performance.now ? performance.now() : Date.now(), o = r.context.files[i.index], c = await Wt(o, t()), a = Fe(n);
      if (!xe(a, i.index, c))
        throw new Error("HubClient.fetchPayload: no payload slot on message");
      const l = (typeof performance < "u" && performance.now ? performance.now() : Date.now()) - s2;
      return console.debug(
        `HubClient: payload fetched fileIndex=${i.index} bytes=${c.byteLength} elapsed=${(l / 1e3).toFixed(2)}s`
      ), a;
    },
    async fetchAllPayloads(n) {
      const r = n && n.event, i = r && r.context, s2 = i && typeof i == "object" && !Array.isArray(i) && Array.isArray(i.files) ? i.files : [], o = [];
      for (let f = 0; f < s2.length; f++) {
        const h = s2[f];
        if (!h || typeof h != "object" || h.data != null)
          continue;
        const g = le(h);
        if (g.payloadIds.length)
          for (let m = 0; m < g.payloadIds.length; m++)
            o.push({
              fileIndex: f,
              chunkIndex: m,
              payloadId: g.payloadIds[m],
              expectedLength: typeof g.chunkByteLengths[m] == "number" ? g.chunkByteLengths[m] : null
            });
      }
      if (!o.length)
        return n;
      const c = typeof performance < "u" && performance.now ? performance.now() : Date.now(), a = t(), u = await Vt(
        o,
        a,
        U
      ), l = /* @__PURE__ */ new Map();
      for (let f = 0; f < o.length; f++) {
        const { fileIndex: h, chunkIndex: g } = o[f];
        let m = l.get(h);
        m || (m = [], l.set(h, m)), m[g] = u[f];
      }
      const d = Fe(n);
      for (const [f, h] of l) {
        const g = d.event.context.files[f], m = typeof g.byteLength == "number" ? g.byteLength : null, y = tt(h, m);
        if (!xe(d, f, y))
          throw new Error("HubClient.fetchAllPayloads: attach failed");
      }
      const b = (typeof performance < "u" && performance.now ? performance.now() : Date.now()) - c;
      return console.debug(
        `HubClient: fetchAllPayloads files=${l.size} chunks=${o.length} concurrent=${U} elapsed=${(b / 1e3).toFixed(2)}s`
      ), d;
    }
  };
}
var B = "-request";
var j = "-response";
var $i = "imagingstudy-open";
var xi = "imagingstudy-close";
var Be = "status-update";
var Fi = "scene-update";
var Wi = "dicom-send";
var Gi = "png-send";
var Ji = "dicomsr-update";
var Zi = "subscription-removed";
function rt(e) {
  return typeof e != "string" ? "" : e.trim().toLowerCase();
}
function k(e) {
  const t = rt(e);
  return t ? `${t}${B}` : "";
}
function zt(e) {
  const t = rt(e);
  return t ? `${t}${j}` : "";
}
function Qi(e) {
  return typeof e != "string" ? false : e.endsWith(B);
}
var Xt = 1e4;
var je = 5e3;
var Yt = {
  hub: {},
  session: {},
  productName: void 0,
  productVersion: void 0,
  callbackUrl: void 0,
  autoStart: false,
  autoReconnect: false,
  preserveSessionTopicFromToken: false
};
var fe = class _fe {
  constructor(t = {}, n = {}, r = {}) {
    this._config = { ...Yt, ...r }, this._session = {
      ...Dt(),
      ...n || {}
    }, (!this._session.subscriberName || !String(this._session.subscriberName).trim()) && (this._session.subscriberName = Pe(
      this._session.productName || this._config.productName || "UNKNOWN"
    )), this._hub = {
      ...Pt(),
      ...t || {},
      ...Ht()
    }, this._reconnectInterval = null, this._onMessageCallback = null, this._onConnectionStateChangeCallback = null, this._payloadFetchApi = Gt(() => ({
      hubEndpoint: this._hub.hub_endpoint,
      accessToken: this._hub.token
    })), this._websocketClose = this._websocketClose.bind(this), this._checkWebsocket = this._checkWebsocket.bind(this), this._config.autoReconnect && (this._reconnectInterval = setInterval(
      this._checkWebsocket,
      Xt
    ));
  }
  static newInstance(t = {}) {
    const { hub: n = {}, session: r = {}, ...i } = t || {};
    return new _fe(n, r, i);
  }
  onMessage(t) {
    this._onMessageCallback = t;
  }
  onConnectionStateChange(t) {
    this._onConnectionStateChangeCallback = t;
  }
  _emitConnectionState(t, n) {
    this._onConnectionStateChangeCallback && this._onConnectionStateChangeCallback(t, n);
  }
  _messageIdPrefix() {
    const t = this._session.productName || this._config.productName || ue;
    return At(t);
  }
  _resolveHubOrigin() {
    try {
      return new URL(this._hub.hub_endpoint).origin;
    } catch {
      try {
        return new URL(this._hub.token_endpoint).origin;
      } catch {
        return "";
      }
    }
  }
  async _fetchHubAuthConfig() {
    const t = this._resolveHubOrigin();
    if (!t)
      return { mode: "mock" };
    try {
      const n = await fetch(`${t}/api/hub/auth/config`, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (!n.ok)
        return { mode: "mock" };
      const r = await n.json();
      return r && typeof r == "object" ? r : { mode: "mock" };
    } catch {
      return console.debug("HubClient: auth/config unavailable; assuming mock mode"), { mode: "mock" };
    }
  }
  _parseOidcHashTokens() {
    if (typeof window > "u" || !window.location)
      return null;
    const t = String(window.location.hash || "").replace(/^#/, "");
    if (!t)
      return null;
    const n = new URLSearchParams(t);
    if (n.get("hub_auth") !== "oidc")
      return null;
    const r = n.get("access_token") || "";
    return r ? {
      access_token: r,
      id_token: n.get("id_token") || "",
      topic: n.get("topic") || "",
      user_name: n.get("user_name") || "",
      expires_in: n.get("expires_in") || ""
    } : null;
  }
  _clearOidcHashFromUrl() {
    if (typeof window > "u" || !window.history || !window.location)
      return;
    const t = `${window.location.pathname}${window.location.search}`;
    window.history.replaceState(null, "", t);
  }
  _applySessionTokens(t) {
    this._hub.token = t.access_token, t.id_token && (this._hub.lastIdToken = t.id_token), this._hub.oidcSession = true, t.user_name && (this._session.userName = t.user_name), t.topic && !this._config.preserveSessionTopicFromToken && this.setTopic(t.topic);
  }
  /** @deprecated Use _applySessionTokens */
  _applyOidcSessionTokens(t) {
    this._applySessionTokens(t);
  }
  _resolveLoginUrl(t) {
    const n = typeof (t == null ? void 0 : t.login_url) == "string" && t.login_url.trim();
    if (n)
      return n.trim();
    const r = this._resolveHubOrigin();
    return r ? `${r}/oauth/login` : "";
  }
  _websocketClose() {
    console.debug("HubClient: websocket is closed."), this._hub.resubscribeRequested = true, this._emitConnectionState("disconnected");
  }
  _processTextMessage(t) {
    try {
      const n = JSON.parse(t);
      if (n["hub.mode"])
        return;
      const r = n.event;
      if (!r || r["hub.event"] === "heartbeat" || n.id === this._hub.lastPublishedMessageID)
        return;
      this._onMessageCallback && this._onMessageCallback(n);
    } catch (n) {
      console.warn("HubClient: websocket processing error:", n);
    }
  }
  async _checkWebsocket() {
    this._hub.resubscribeRequested && this._hub.subscribed && this._config.autoReconnect ? (console.debug("HubClient: Try to resubscribe"), this._hub.resubscribeRequested = false, await this.subscribe() !== 202 && (this._hub.resubscribeRequested = true)) : !this._hub.subscribed && this._hub.resubscribeRequested && (this._hub.resubscribeRequested = false);
  }
  getConfig() {
    return this._config;
  }
  getHubConfig() {
    const t = this._hub;
    return {
      name: t.name,
      friendlyName: t.friendlyName,
      version: t.version,
      hub_endpoint: t.hub_endpoint,
      authorization_endpoint: t.authorization_endpoint,
      token_endpoint: t.token_endpoint,
      client_id: t.client_id,
      client_secret: t.client_secret
    };
  }
  getSessionConfig() {
    const t = this._session;
    return {
      subscriberName: t.subscriberName,
      productName: t.productName,
      productVersion: t.productVersion,
      actors: t.actors,
      topic: t.topic,
      events: t.events,
      lease: t.lease,
      userName: t.userName,
      defaultTargetActor: t.defaultTargetActor
    };
  }
  getConnectionState() {
    const t = this._hub;
    return {
      token: t.token,
      subscribed: t.subscribed,
      resubscribeRequested: t.resubscribeRequested,
      websocket: t.websocket,
      lastPublishedMessageID: t.lastPublishedMessageID
    };
  }
  setTopic(t) {
    console.debug("HubClient: setting topic to", t), this._session.topic = t;
  }
  setToken(t) {
    this._hub.token = t;
  }
  setSubscriberName(t) {
    this._session.subscriberName = t;
  }
  setUserName(t) {
    this._session.userName = t || "";
  }
  async authenticate() {
    const t = this._parseOidcHashTokens();
    if (t)
      return this._applySessionTokens(t), this._clearOidcHashFromUrl(), console.debug("HubClient: Applied OIDC session tokens from redirect"), {
        user_name: t.user_name || this._session.userName || "",
        code: "",
        expires_in: t.expires_in && Number(t.expires_in) || void 0,
        mode: "oidc",
        tokensReady: true
      };
    if (this._hub.oidcSession && this._hub.token)
      return {
        user_name: this._session.userName || "",
        code: "",
        mode: this._hub.authMode || "oidc",
        tokensReady: true
      };
    const n = await this._fetchHubAuthConfig();
    if (this._hub.authMode = n.mode || "mock", n.mode === "oidc") {
      if (typeof window > "u" || !window.location)
        throw new Error(
          "HubClient.authenticate: OIDC mode requires a browser environment"
        );
      const l = this._resolveLoginUrl(n), d = `${window.location.origin}${window.location.pathname}${window.location.search}`, b = `${l}?return_to=${encodeURIComponent(d)}`;
      return console.debug("HubClient: Redirecting to OIDC login", b), window.location.assign(b), {
        user_name: "",
        code: "",
        mode: "oidc",
        redirecting: true
      };
    }
    const r = this._resolveLoginUrl(n);
    if (!r)
      throw new Error(
        "HubClient.authenticate: no login_url or hub origin configured."
      );
    const i = this._session.productName || this._config.productName || "UNKNOWN", s2 = new URLSearchParams();
    this._hub.lastIdToken ? s2.set("id_token", this._hub.lastIdToken) : this._session.userName && s2.set("user_name", this._session.userName), s2.set("client_product_name", i), this._session.topic && s2.set("topic", this._session.topic);
    const o = `${r}?${s2.toString()}`;
    try {
      const l = new URL(r);
      console.debug("HubClient: Mock login at:", `${l.origin}${l.pathname}`);
    } catch {
      console.debug("HubClient: Mock login at hub");
    }
    let c;
    try {
      c = await fetch(o, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
    } catch (l) {
      const d = l instanceof Error ? l.message : String(l);
      throw console.error("HubClient: Exception during authenticate:", d), l;
    }
    if (c.status !== 200) {
      const l = await c.text().catch(() => "");
      throw console.error("HubClient: Authenticate failed. Status:", c.status, l), new Error(`HubClient.authenticate failed (HTTP ${c.status})`);
    }
    const a = await c.json(), u = typeof a.access_token == "string" ? a.access_token : "";
    if (!u)
      throw new Error("HubClient.authenticate: mock login missing access_token");
    return this._applySessionTokens({
      access_token: u,
      id_token: typeof a.id_token == "string" ? a.id_token : "",
      topic: typeof a.topic == "string" ? a.topic : "",
      user_name: typeof a.user_name == "string" ? a.user_name : ""
    }), {
      user_name: this._session.userName || a.user_name || "",
      code: "",
      expires_in: typeof a.expires_in == "number" ? a.expires_in : void 0,
      mode: "mock",
      tokensReady: true
    };
  }
  async getToken(t) {
    if (this._hub.oidcSession && this._hub.token)
      return this._config.autoStart && this.subscribe(), true;
    const n = this._parseOidcHashTokens();
    if (n)
      return this._applySessionTokens(n), this._clearOidcHashFromUrl(), this._config.autoStart && this.subscribe(), !!this._hub.token;
    if (typeof t != "string" || !t)
      return console.error(
        "HubClient.getToken: code is required (call authenticate() first)."
      ), false;
    try {
      const i = new URL(this._hub.token_endpoint);
      console.debug("HubClient: Exchanging code at:", `${i.origin}${i.pathname}`);
    } catch {
      console.debug("HubClient: Exchanging code at hub");
    }
    const r = new URLSearchParams();
    r.append("grant_type", "authorization_code"), r.append("code", t), r.append("client_id", this._hub.client_id || ""), r.append("client_secret", this._hub.client_secret || ""), r.append(
      "client_product_name",
      this._session.productName || this._config.productName || "UNKNOWN"
    );
    try {
      const i = await fetch(this._hub.token_endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: r
      });
      if (i.status === 200) {
        const s2 = await i.json();
        return typeof s2.access_token == "string" && s2.access_token && (this._hub.token = s2.access_token), typeof s2.id_token == "string" && s2.id_token && (this._hub.lastIdToken = s2.id_token), s2.topic && typeof s2.topic == "string" && (this._config.preserveSessionTopicFromToken || this.setTopic(s2.topic), this._config.autoStart && this.subscribe()), !!this._hub.token;
      }
      return await i.text(), console.error("HubClient: Error getting token. Status:", i.status), false;
    } catch (i) {
      const s2 = i instanceof Error ? i.message : String(i);
      return console.error("HubClient: Exception getting token:", s2), false;
    }
  }
  async connect() {
    const t = await this.authenticate();
    if (t != null && t.redirecting)
      return t;
    if (!(t != null && t.tokensReady)) {
      const n = this._config.autoStart;
      this._config.autoStart = false;
      let r = false;
      try {
        r = await this.getToken((t == null ? void 0 : t.code) || "");
      } finally {
        this._config.autoStart = n;
      }
      if (!r)
        return false;
    }
    return this.subscribe();
  }
  async subscribe(t = false) {
    const n = this._session.topic && this._session.topic.trim();
    if (!n)
      return console.warn("HubClient: Error. subscription not sent. No topic defined."), "error: topic not defined";
    if ((!this._session.subscriberName || !String(this._session.subscriberName).trim()) && (this._session.subscriberName = Pe(
      this._session.productName || this._config.productName || "UNKNOWN"
    )), !this._hub.token)
      return console.warn("HubClient: Error. subscription not sent. No token available."), "error: no token";
    const r = He(this._config.callbackUrl), i = $e(
      "subscribe",
      { ...this._session, topic: n, subscriberName: this._session.subscriberName },
      r,
      this._config.productVersion
    );
    try {
      this._emitConnectionState("connecting");
      const s2 = await fetch(this._hub.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Bearer ${this._hub.token}`
        },
        body: i,
        signal: typeof AbortSignal < "u" && AbortSignal.timeout ? AbortSignal.timeout(je) : void 0
      });
      if (s2.status === 202) {
        this._hub.resubscribeRequested = false;
        let o;
        try {
          o = await s2.json();
        } catch (l) {
          return this._hub.subscribed = false, console.error(
            "HubClient: Subscribe 202 body was not valid JSON:",
            l instanceof Error ? l.message : String(l)
          ), this._emitConnectionState("error"), 0;
        }
        const c = o["hub.channel.endpoint"];
        if (!c || typeof c != "string")
          return this._hub.subscribed = false, console.error("HubClient: Subscribe 202 missing hub.channel.endpoint"), this._emitConnectionState("error"), 0;
        let a = c;
        try {
          const l = new URL(this._hub.hub_endpoint), d = new URL(c);
          a = c.replace(
            d.origin,
            `${l.protocol === "https:" ? "wss:" : "ws:"}//${l.host}`
          );
        } catch {
        }
        if (this._hub.websocket) {
          try {
            this._hub.websocket.removeEventListener("close", this._websocketClose), this._hub.websocket.close();
          } catch {
          }
          this._hub.websocket = null;
        }
        let u;
        try {
          u = new WebSocket(a);
        } catch (l) {
          return this._hub.subscribed = false, console.error(
            "HubClient: Failed to open WebSocket after subscribe:",
            l instanceof Error ? l.message : String(l)
          ), this._emitConnectionState("error"), 0;
        }
        return this._hub.subscribed = true, this._hub.websocket = u, u.onopen = () => {
          u.send(JSON.stringify({ "hub.channel.endpoint": a })), this._emitConnectionState("connected");
        }, u.addEventListener("message", (l) => {
          typeof l.data == "string" && this._processTextMessage(l.data);
        }), u.addEventListener("close", this._websocketClose), u.onerror = () => {
          console.warn("HubClient: Error reported on websocket"), this._emitConnectionState("error");
        }, s2.status;
      }
      if (s2.status === 401) {
        if (console.warn("HubClient: Subscription response 401 - Token refresh needed."), t)
          return s2.status;
        try {
          const o = await this.authenticate();
          if (o != null && o.tokensReady ? true : !!(o != null && o.code && await this.getToken(o.code)))
            return await this.subscribe(true);
        } catch (o) {
          console.error(
            "HubClient: Token refresh after 401 failed:",
            o instanceof Error ? o.message : String(o)
          );
        }
      } else
        console.error(
          "HubClient: Subscription rejected by hub. Status:",
          s2.status
        );
      return s2.status;
    } catch (s2) {
      return this._hub.subscribed = false, console.error(
        "HubClient: Exception subscribing to the hub:",
        s2 instanceof Error ? s2.message : String(s2)
      ), 0;
    }
  }
  async unsubscribe() {
    this._hub.subscribed = false, this._hub.resubscribeRequested = false;
    const t = $e(
      "unsubscribe",
      this._session,
      He(this._config.callbackUrl),
      this._config.productVersion
    );
    try {
      (await fetch(this._hub.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Bearer ${this._hub.token}`
        },
        body: t,
        signal: typeof AbortSignal < "u" && AbortSignal.timeout ? AbortSignal.timeout(je) : void 0
      })).status === 202 && console.debug("HubClient: Unsubscribe successfully from hub", this._hub.name);
    } catch (n) {
      console.warn(
        "HubClient: Error unsubscribing from the hub.",
        n instanceof Error ? n.message : String(n)
      );
    }
    this._closeWebsocket(), this._emitConnectionState("disconnected");
  }
  _closeWebsocket() {
    this._hub.websocket && (this._hub.websocket.close(), this._hub.websocket = null);
  }
  async close({ hubUnsubscribe: t = true } = {}) {
    this._reconnectInterval && (clearInterval(this._reconnectInterval), this._reconnectInterval = null), t ? await this.unsubscribe() : (this._hub.subscribed = false, this._hub.resubscribeRequested = false, this._closeWebsocket(), this._emitConnectionState("disconnected"));
  }
  delete() {
    return this.close();
  }
  async rebindUserName(t) {
    const n = String(t || "").trim();
    if (!n)
      throw new Error("HubClient.rebindUserName: user name is required");
    const r = String(this._session.userName || "").trim(), i = String(this._session.topic || "").trim();
    if (n === r && (i === n || i === r) && this._hub.subscribed)
      return { user_name: r, topic: i, status: 202 };
    await this.unsubscribe(), this._hub.lastIdToken = "", this.setUserName(n), this.setTopic("");
    const s2 = await this.authenticate(), { code: o, user_name: c, tokensReady: a, redirecting: u } = s2 || {};
    if (u)
      throw new Error(
        "HubClient.rebindUserName: OIDC redirect in progress; complete login in the browser"
      );
    if (!a && !o)
      throw new Error("HubClient.rebindUserName: authenticate failed");
    const l = this._config.autoStart;
    this._config.autoStart = false;
    let d = false;
    try {
      d = await this.getToken(o || "");
    } finally {
      this._config.autoStart = l;
    }
    if (!d)
      throw new Error("HubClient.rebindUserName: token exchange failed");
    const b = await this.subscribe();
    return {
      user_name: String(c || this._session.userName || n).trim() || n,
      topic: String(this._session.topic || "").trim(),
      status: b
    };
  }
  _preparePublishMessage(t, n = this._hub) {
    const r = { ...t, timestamp: (/* @__PURE__ */ new Date()).toJSON() };
    r.id = F(this._messageIdPrefix()), n.lastPublishedMessageID = r.id;
    const i = this._session.subscriberName && this._session.subscriberName.trim(), s2 = this._session.productName && this._session.productName.trim();
    if (i && r["subscriber.name"] === void 0 && (r["subscriber.name"] = i), s2 && r["subscriber.product.name"] === void 0 && (r["subscriber.product.name"] = s2), r.event && !r.event["hub.topic"] && (r.event["hub.topic"] = this._session.topic), r["target.actor"] === void 0 && this._session.defaultTargetActor && !String(r["target.subscriber.name"] || "").trim()) {
      const c = re(
        this._session.defaultTargetActor
      );
      c && (r["target.actor"] = c);
    }
    return r;
  }
  fetchPayload(t) {
    return this._payloadFetchApi.fetchPayload(t);
  }
  fetchAllPayloads(t) {
    return this._payloadFetchApi.fetchAllPayloads(t);
  }
  hasPendingPayload(t) {
    return this._payloadFetchApi.hasPendingPayload(t);
  }
  async publishMultipart(t, n, r = this._hub) {
    let i = this._preparePublishMessage(t, r);
    const s2 = await Y(n);
    i = ne(i);
    let o = await Me(i);
    if (!o.length) {
      const a = (i.event && typeof i.event["hub.event"] == "string" ? i.event["hub.event"] : "") === "dicom-send" ? "dicom-send.dcm" : "nifti-send.nii.gz";
      i.event.context = {
        files: [
          {
            data: s2,
            fileName: et(i, a),
            mimeType: "application/octet-stream",
            byteLength: s2.byteLength
          }
        ]
      }, o = [s2];
    }
    return this.publishBinaryBatch(i, o, r);
  }
  async publishBinaryBatch(t, n, r = this._hub) {
    const i = ne(
      this._preparePublishMessage(t, r)
    );
    return Ot({
      msg: i,
      fileBytesList: n,
      hub: r,
      messageIdPrefix: () => this._messageIdPrefix()
    });
  }
  async publish(t, n = this._hub) {
    let r = this._preparePublishMessage(t, n);
    if (r = ne(r), Lt(r)) {
      const i = await Me(r);
      if (i.length)
        return this.publishBinaryBatch(r, i, n);
    }
    try {
      return await fetch(n.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${n.token}`
        },
        body: JSON.stringify(r)
      });
    } catch (i) {
      return console.debug("HubClient:", i instanceof Error ? i.message : String(i)), null;
    }
  }
  publishNiftiMultipart(t, n, r) {
    return this.publishBinaryBatch(t, [n], r);
  }
  async request(t = {}) {
    const n = String(t["subscriber.name"] || "").trim();
    if (!n)
      throw new Error('HubClient.request: "subscriber.name" is required.');
    const r = this._hub.token && this._hub.token.trim();
    if (!r)
      throw new Error(
        "HubClient.request: token is required (call authenticate() then getToken(code) first)."
      );
    const i = {
      "subscriber.name": n,
      id: t.id && String(t.id).trim() || F(this._messageIdPrefix()),
      timestamp: t.timestamp && String(t.timestamp).trim() || (/* @__PURE__ */ new Date()).toJSON()
    };
    if (t.event && typeof t.event == "object") {
      i.event = { ...t.event };
      const d = this._session.topic && String(this._session.topic).trim();
      d && !i.event["hub.topic"] && (i.event["hub.topic"] = d);
    } else
      throw new Error('HubClient.request: "event" with hub.event is required.');
    if (!i.event["hub.event"] || !String(i.event["hub.event"]).trim())
      throw new Error(
        'HubClient.request: event["hub.event"] must be a *-request event name.'
      );
    t["subscriber.actor"] && String(t["subscriber.actor"]).trim() && (i["subscriber.actor"] = String(t["subscriber.actor"]).trim());
    const s2 = Object.prototype.hasOwnProperty.call(t, "target.actor");
    let o = s2 ? re(t["target.actor"]) : void 0;
    o === void 0 && !s2 && this._session.defaultTargetActor && (o = re(this._session.defaultTargetActor)), o !== void 0 && (i["target.actor"] = o);
    const c = t["target.product.name"] !== void 0 ? t["target.product.name"] : t.targetProductName, a = Mt(c);
    a !== void 0 && (i["target.product.name"] = a);
    const u = await fetch(
      (this._hub.hub_endpoint || "").replace(/\/+$/, ""),
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${r}`
        },
        body: JSON.stringify(i)
      }
    );
    let l;
    if ((u.headers.get("content-type") || "").includes("application/json"))
      try {
        l = await u.json();
      } catch {
        l = "";
      }
    else
      l = await u.text();
    return { ok: u.ok, status: u.status, data: l };
  }
  sendHubRequestResponse(t, n, r, i) {
    if (!this._hub.websocket || typeof WebSocket > "u" || this._hub.websocket.readyState !== WebSocket.OPEN)
      return;
    const s2 = typeof n == "string" ? n.trim() : n == null ? "" : String(n).trim();
    if (!s2) {
      console.error(
        "HubClient.sendHubRequestResponse requires a non-empty dataType."
      );
      return;
    }
    const o = {
      timestamp: (/* @__PURE__ */ new Date()).toJSON(),
      id: F(this._messageIdPrefix()),
      "subscriber.name": this._session.subscriberName || void 0,
      "subscriber.product.name": this._session.productName || void 0,
      event: {
        "hub.topic": i || this._session.topic,
        "hub.event": zt(s2),
        context: { id: t, dataType: s2, data: r }
      }
    };
    Array.isArray(this._session.actors) && this._session.actors.length && (o.actor = this._session.actors[0]), this._hub.websocket.send(JSON.stringify(o));
  }
  sendCastRequestResponse(t, n, r, i) {
    return this.sendHubRequestResponse(t, n, r, i);
  }
};
function de(e) {
  const t = {
    responses: [],
    expected: [],
    missing: [],
    timedOut: false,
    ok: false,
    id: null,
    actor: null,
    productName: null
  };
  if (!e || typeof e != "object")
    return t;
  const n = (
    /** @type {Record<string, unknown>} */
    e
  ), r = Array.isArray(n.responses) ? n.responses.filter((o) => o && typeof o == "object") : [], i = Array.isArray(n.expected) ? n.expected.map((o) => String(o)) : [], s2 = Array.isArray(n.missing) ? n.missing.map((o) => String(o)) : [];
  return {
    responses: r,
    expected: i,
    missing: s2,
    timedOut: !!n.timedOut,
    ok: !!n.ok,
    id: n.id != null ? String(n.id) : null,
    actor: n.actor != null ? String(n.actor) : null,
    productName: n.productName != null ? String(n.productName) : null
  };
}
function he(e) {
  const t = String(e ?? "").trim();
  if (!t)
    return null;
  try {
    const n = new URL(t);
    return n.protocol === "ws:" ? n.protocol = "http:" : n.protocol === "wss:" && (n.protocol = "https:"), n;
  } catch {
    return null;
  }
}
var as = "hubViewer-worklist";
var ms = [
  "Anatomy class",
  "Tumor Board",
  "Case discussion",
  "Pedicle screw"
];
function H(e, t) {
  const n = he(e);
  return n ? new URL(t, n.origin).href : null;
}
function v(e, t = false) {
  const n = {};
  t && (n["Content-Type"] = "application/json");
  const r = String(e ?? "").trim();
  if (!r)
    throw new Error(
      "Hub conference APIs require a Bearer access token (authenticate first)"
    );
  return n.Authorization = `Bearer ${r}`, n;
}
function it(e) {
  if (!Array.isArray(e))
    return [];
  const t = /* @__PURE__ */ new Set();
  return e.map((n) => String(n ?? "").trim()).filter((n) => !n || t.has(n) ? false : (t.add(n), true));
}
function Z(e) {
  return String((e == null ? void 0 : e.hostTopic) ?? (e == null ? void 0 : e.user) ?? "").trim();
}
function st(e) {
  const t = Z(e);
  return String((e == null ? void 0 : e.sceneLeaderTopic) ?? "").trim() || t;
}
function Jt(e, t) {
  const n = Z(t), r = String(e ?? "").trim();
  return !r || !n ? false : r === n || r.toLowerCase() === n.toLowerCase();
}
function Zt(e, t) {
  const n = st(t), r = String(e ?? "").trim();
  return !r || !n ? false : r === n || r.toLowerCase() === n.toLowerCase();
}
function ot(e, t, n) {
  const r = String(e ?? "").trim(), i = String(t ?? "").trim(), s2 = Z(n), o = Array.isArray(n == null ? void 0 : n.topics) ? n.topics.map((c) => String(c).trim()).filter(Boolean) : [];
  return !!(r && (r === s2 || o.includes(r)) || i && i === s2);
}
function ct(e, t, n) {
  return n.find(
    (r) => ot(e, t, r)
  ) || null;
}
async function gs(e, t) {
  const n = H(e, "/api/hub/conference-topics");
  if (!n)
    return [];
  try {
    const r = await fetch(n, {
      headers: v(t)
    });
    if (!r.ok)
      return [];
    const i = await r.json();
    if (!Array.isArray(i))
      return [];
    const s2 = [];
    for (const o of i) {
      if (o && typeof o == "object") {
        const a = String(o.topic ?? "").trim();
        if (!a || a === "*") continue;
        s2.push({
          topic: a,
          timezone: String(o.timezone ?? "").trim()
        });
        continue;
      }
      const c = String(o ?? "").trim();
      !c || c === "*" || s2.push({ topic: c, timezone: "" });
    }
    return s2;
  } catch {
    return [];
  }
}
async function at(e, t) {
  const n = he(e);
  if (!n)
    return [];
  const r = new URL("/api/hub/conference", n.origin).href;
  try {
    const i = await fetch(r, {
      headers: v(t)
    });
    if (!i.ok)
      return [];
    const s2 = await i.json();
    return Array.isArray(s2) ? s2 : [];
  } catch {
    return [];
  }
}
async function ys(e, t, n, r, i, s2) {
  const o = H(e, "/api/hub/conference");
  if (!o)
    throw new Error("Invalid hub endpoint");
  const c = {
    hostTopic: String(t).trim(),
    title: String(n).trim(),
    topics: r
  }, a = String(i ?? "").trim();
  a && (c.hostUserName = a);
  const u = await fetch(o, {
    method: "POST",
    headers: v(s2, true),
    body: JSON.stringify(c)
  });
  if (!u.ok) {
    const l = await u.text();
    throw new Error(l || `HTTP ${u.status}`);
  }
}
async function ps(e, t, n, r, i) {
  const s2 = H(e, "/api/hub/conference/join");
  if (!s2)
    throw new Error("Invalid hub endpoint");
  const o = {
    hostTopic: String(t).trim(),
    joinTopic: String(n).trim()
  }, c = String(r ?? "").trim();
  c && (o.joinUserName = c);
  const a = await fetch(s2, {
    method: "PATCH",
    headers: v(i, true),
    body: JSON.stringify(o)
  });
  if (!a.ok) {
    const u = await a.text();
    throw new Error(u || `HTTP ${a.status}`);
  }
}
async function Ss(e, t, n, r) {
  const i = H(e, "/api/hub/conference");
  if (!i)
    throw new Error("Invalid hub endpoint");
  const s2 = { hostTopic: String(t).trim() }, o = n == null ? void 0 : n.trim();
  o && (s2.leaveTopic = o);
  const c = await fetch(i, {
    method: "DELETE",
    headers: v(r, true),
    body: JSON.stringify(s2)
  });
  if (!c.ok) {
    const a = await c.text();
    throw new Error(a || `HTTP ${c.status}`);
  }
}
function Kt(e, t) {
  if (!t)
    return null;
  const n = String((e == null ? void 0 : e.topic) ?? "").trim(), r = String((e == null ? void 0 : e.subscriberName) ?? "").trim(), i = String((e == null ? void 0 : e.userName) ?? "").trim(), s2 = Z(t);
  if (!s2 || !ot(n, r, t))
    return null;
  const o = Array.isArray(t.topics) ? t.topics.map((h) => String(h).trim()).filter(Boolean) : [], c = it(t.participants), a = [], u = /* @__PURE__ */ new Set();
  for (const h of [n, s2, ...o])
    !h || u.has(h) || (u.add(h), a.push(h));
  const l = st(t), d = Jt(n, t), b = Zt(n, t) ? "leading" : "following", f = a.map((h) => {
    const g = !!n && (h === n || h.toLowerCase() === n.toLowerCase()), m = h === l || h.toLowerCase() === l.toLowerCase(), y = m && b === "following";
    let T = "";
    return g ? T = b === "leading" ? "(You) \xB7 leading" : "(You)" : y ? T = "Following" : b === "leading" && (T = "Following you"), {
      placeId: h,
      label: g && i ? i : h,
      isSelf: g,
      isLeading: m,
      isFollowing: y,
      statusLabel: T
    };
  });
  return {
    title: String(t.title ?? "").trim(),
    places: f,
    selfPlaceId: n,
    leadingPlaceId: l,
    selfRole: b,
    isConferenceOwner: d,
    hostTopic: s2,
    sceneLeaderTopic: l,
    attendeeTopics: o,
    participants: c
  };
}
async function ws(e, t, n, r, i) {
  const s2 = await at(e, i), o = ct(t, n, s2);
  return Kt({ topic: t, subscriberName: n, userName: r }, o);
}
function ut(e, t) {
  if (t === "file:")
    return true;
  const n = String(e || "").toLowerCase();
  return !!(n === "localhost" || n === "127.0.0.1" || n === "[::1]" || /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(n) || /^192\.168\.\d{1,3}\.\d{1,3}$/.test(n) || /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(n));
}
function Qt(e = typeof window < "u" ? window.location : null) {
  return e ? !ut(e.hostname, e.protocol) : false;
}
function en(e) {
  try {
    const t = new URL(e);
    return !ut(t.hostname, t.protocol);
  } catch {
    return false;
  }
}
function Is(e, t, n = Qt()) {
  const r = t.find((s2) => {
    var c;
    const o = (c = e[s2]) == null ? void 0 : c.hubEndpoint;
    return o && en(o) === n;
  });
  if (r)
    return r;
  const i = n ? "cloud" : "local";
  return e[i] ? i : t[0];
}
function Es() {
  return typeof document > "u" ? Promise.resolve() : tn().then(nn);
}
function tn() {
  return document.prerendering ? new Promise((e) => {
    const t = () => {
      document.prerendering || (document.removeEventListener("prerenderingchange", t), e());
    };
    document.addEventListener("prerenderingchange", t);
  }) : Promise.resolve();
}
function nn() {
  return document.visibilityState === "visible" ? Promise.resolve() : new Promise((e) => {
    const t = () => {
      document.visibilityState === "visible" && (document.removeEventListener("visibilitychange", t), e());
    };
    document.addEventListener("visibilitychange", t);
  });
}
function rn(e) {
  return String(e || "").trim().toUpperCase();
}
var sn = Object.freeze({
  ira: (e) => e === "SLICERLIVE-IRA" || e.startsWith("SLICERLIVE-IRA"),
  ohif: (e) => e === "OHIF" || e.startsWith("OHIF"),
  volview: (e) => e === "VOLVIEW" || e.startsWith("VOLVIEW"),
  slicer: (e) => e === "3DSLICER-ID" || e === "SLICER-HUB" || e.startsWith("3DSLICER") || e.startsWith("SLICER-HUB"),
  /** slicer-mirror Four-Up LiveScene stream client (not desktop Image Display). */
  slicerMirror: (e) => e === "SLICER-MIRROR" || e.startsWith("SLICER-MIRROR"),
  mhub: (e) => e === "MHUB" || e.startsWith("MHUB") || e === "MHUB_AI" || e.startsWith("MHUB_AI") || e === "MHUBAI" || e.startsWith("MHUBAI"),
  eucaim: (e) => e === "EUCAIM" || e.startsWith("EUCAIM") || e === "NNUNET_EUCAIM" || e.startsWith("NNUNET_EUCAIM") || e === "NNUNET-EUCAIM" || e.startsWith("NNUNET-EUCAIM"),
  vox2seglam: (e) => e === "VOX2SEGLAM" || e.startsWith("VOX2SEGLAM") || e === "VOX2_SEG_LAM" || e.startsWith("VOX2_SEG_LAM") || e === "VOX2-SEG-LAM" || e.startsWith("VOX2-SEG-LAM"),
  lung: (e) => e === "LUNGSCREENING" || e.startsWith("LUNGSCREENING"),
  totalseg: (e) => e === "TOTALSEG" || e.startsWith("TOTALSEG") || e === "TOTAL_SEGMENTATOR" || e.startsWith("TOTAL_SEGMENTATOR") || e === "TOTAL-SEGMENTATOR" || e.startsWith("TOTAL-SEGMENTATOR"),
  neuro: (e) => e === "NEURO_SEG" || e.startsWith("NEURO_SEG") || e === "NEUROSEG" || e.startsWith("NEUROSEG"),
  dental: (e) => e === "DENTAL_SEG" || e.startsWith("DENTAL_SEG") || e === "DENTALSEG" || e.startsWith("DENTALSEG") || e === "DENTALSEGMENTATOR" || e.startsWith("DENTALSEGMENTATOR"),
  txrv: (e) => e === "TORCHXRAYVISION" || e.startsWith("TORCHXRAYVISION") || e === "TXRV" || e.startsWith("TXRV") || e === "TORCH_XRAY_VISION" || e.startsWith("TORCH_XRAY_VISION") || e === "TORCH-XRAY-VISION" || e.startsWith("TORCH-XRAY-VISION"),
  flexray: (e) => e === "FLEXRAY" || e.startsWith("FLEXRAY") || e === "FLEX_RAY" || e.startsWith("FLEX_RAY"),
  reporting: (e) => e === "RPT" || e.startsWith("RPT-") || e === "CAST-RPT" || e.startsWith("CAST-RPT"),
  classroom: (e) => e === "CLASSROOM" || e.startsWith("CLASSROOM-") || e === "CAST-CLASSROOM" || e.startsWith("CAST-CLASSROOM")
});
function As(e, t) {
  const n = sn[t];
  return n ? n(rn(e)) : false;
}
var Q = "urn:dicom:uid";
var lt = "urn:cast:nifti-url";
var ft = "urn:cast:nifti-filename";
var be = "urn:cast:volview-sample-id";
var $ = "urn:cast:worklist-sample-id";
var x = "urn:cast:open-mode";
var W = "dicomweb";
var ge = "dicom-url";
var O = "files";
var ye = "idc";
var pe = "local-dicom";
var dt = "urn:cast:dicomweb-root";
function _(e) {
  return typeof e != "string" ? "" : e.trim().replace(/^urn:oid:/i, "");
}
function We(e) {
  return typeof e == "string" ? e.trim().toLowerCase() : "";
}
function D(e, t) {
  if (!Array.isArray(e))
    return null;
  const n = String(t || "").trim().toLowerCase(), r = e.find(
    (i) => i && typeof i == "object" && typeof i.key == "string" && i.key.trim().toLowerCase() === n
  );
  return !(r != null && r.resource) || typeof r.resource != "object" ? null : r.resource;
}
function C(e, t) {
  const n = D(e, "study");
  if (!n)
    return "";
  const r = Array.isArray(n.identifier) ? n.identifier : [], i = We(t), s2 = r.find(
    (o) => We(o == null ? void 0 : o.system) === i
  );
  return typeof (s2 == null ? void 0 : s2.value) == "string" ? s2.value.trim() : "";
}
function E(e) {
  const t = D(e, "study");
  return t ? _(t.uid) || _(C(e, Q)) : "";
}
function I(e) {
  const t = D(e, "series");
  if (t)
    return _(t.uid);
  const n = D(e, "study"), i = (Array.isArray(n == null ? void 0 : n.series) ? n.series : [])[0];
  return !i || typeof i != "object" ? "" : _(i.uid);
}
function Ve(e) {
  const t = C(e, dt);
  if (!t)
    return "";
  try {
    const n = new URL(t);
    if (n.protocol === "http:" || n.protocol === "https:")
      return n.href.replace(/\/$/, "");
  } catch {
    return "";
  }
  return "";
}
function V(e) {
  const t = C(e, lt);
  if (!t)
    return "";
  try {
    const n = new URL(t);
    if (n.protocol === "http:" || n.protocol === "https:")
      return n.href;
  } catch {
    return "";
  }
  return "";
}
function ht(e) {
  return C(e, ft);
}
function G(e) {
  return C(e, be) || C(e, $);
}
function on(e) {
  return typeof e.url == "string" ? e.url.trim() : typeof e.uri == "string" ? e.uri.trim() : "";
}
function cn(e) {
  return typeof e.fileName == "string" ? e.fileName.trim() : typeof e.filename == "string" ? e.filename.trim() : "";
}
var an = /* @__PURE__ */ new Set(["http:", "https:", "s3:", "gs:"]);
function ee(e) {
  if (!e || typeof e != "object")
    return null;
  const t = on(e);
  if (!t)
    return null;
  try {
    const o = new URL(t);
    if (!an.has(o.protocol))
      return null;
  } catch {
    return null;
  }
  const n = cn(e), r = typeof e.mimeType == "string" ? e.mimeType.trim() : "", i = typeof e.role == "string" ? e.role.trim() : "", s2 = typeof e.label == "string" ? e.label.trim() : "";
  return {
    url: t,
    fileName: n,
    mimeType: r,
    role: i,
    label: s2
  };
}
function P(e) {
  const t = D(e, "files"), r = (Array.isArray(t == null ? void 0 : t.files) ? t.files : []).map((s2) => ee(s2)).filter((s2) => s2 !== null);
  if (r.length > 0)
    return r;
  const i = V(e);
  return i ? [
    {
      url: i,
      fileName: ht(e),
      mimeType: "",
      role: "",
      label: ""
    }
  ] : [];
}
function un(e) {
  const t = C(e, x);
  return t === W || t === ge || t === O || t === ye || t === pe ? t : P(e).length > 0 || V(e) ? O : E(e) && !V(e) ? W : "";
}
var vs = "Study already open - skipped reload";
function Rs(e, t) {
  if (!(e != null && e.length) || !(t != null && t.length)) return false;
  const n = G(e), r = G(t);
  if (n && r && n === r) return true;
  const i = E(e), s2 = E(t);
  if (!i || !s2 || i !== s2) return false;
  const o = I(e) || "", c = I(t) || "";
  return !o || !c ? true : o === c;
}
function Ce(e) {
  if (Array.isArray(e) || !e || typeof e != "object")
    return e;
  const t = Object.entries(e).reduce((n, [r, i]) => (i && typeof i == "object" && !Array.isArray(i) && n.push({ key: r, resource: i }), n), []);
  return t.length ? t : e;
}
var kn = "mhub";
var vn = "MHUB";
var Rn = "MHub models";
var On = "Boston, USA";
var Pn = "Medical Imaging Model Hub \u2014 peer-reviewed deep learning models via standardized Docker I/O.";
var Dn = "https://github.com/MHubAI/";
var Mn = "https://mhub.ai";
var Hn = "Apache-2.0";
var $n = "https://www.apache.org/licenses/LICENSE-2.0";
var xn = "Models may use different licenses; check each model";
var Fn = "dicom-send";
var Bn = true;
var jn = "https://github.com/MHubAI.png";
var Wn = {
  id: kn,
  product: vn,
  title: Rn,
  location: On,
  summary: Pn,
  githubUrl: Dn,
  websiteUrl: Mn,
  license: Hn,
  licenseUrl: $n,
  licenseRestriction: xn,
  hubEvent: Fn,
  enabled: Bn,
  iconUrl: jn
};
var Vn = "eucaim";
var Gn = "EUCAIM";
var zn = "EUCAIM nnU-Net";
var qn = "Heidelberg, Germany";
var Xn = "MIC-DKFZ EUCAIM nnU-Net Docker tasks \u2014 DICOM series in, DICOM SEG out.";
var Yn = "https://github.com/MIC-DKFZ/nnunet-eucaim-docker";
var Jn = "https://cancerimage.eu/";
var Zn = "Apache-2.0";
var Kn = "https://www.apache.org/licenses/LICENSE-2.0";
var Qn = "dicom-send";
var er = true;
var tr = "https://github.com/MIC-DKFZ.png";
var nr = {
  id: Vn,
  product: Gn,
  title: zn,
  location: qn,
  summary: Xn,
  githubUrl: Yn,
  websiteUrl: Jn,
  license: Zn,
  licenseUrl: Kn,
  hubEvent: Qn,
  enabled: er,
  iconUrl: tr
};
var rr = "vox2seglam";
var ir = "VOX2SEGLAM";
var sr = "Vox2SegLAM";
var or = "Montreal, Canada";
var cr = "Joint subcortical segmentation and anatomical landmark detection on T1-weighted brain MRI (Harvard\u2013Oxford Atlas 2.0 protocol). DICOM in \u2192 DICOM SEG/SR out; NIfTI in \u2192 NIfTI out.";
var ar = "https://github.com/Neuro-iX/Vox2SegLAM";
var ur = "https://github.com/Neuro-iX/Vox2SegLAM";
var lr = "MIT";
var fr = "https://opensource.org/licenses/MIT";
var dr = "dicom-send";
var hr = true;
var br = {
  id: rr,
  product: ir,
  title: sr,
  location: or,
  summary: cr,
  githubUrl: ar,
  websiteUrl: ur,
  license: lr,
  licenseUrl: fr,
  hubEvent: dr,
  enabled: hr
};
var mr = "totalseg";
var gr = "TOTALSEG";
var yr = "Total Segmentator";
var pr = "Basel, Switzerland";
var Sr = "Whole-body CT/MR multi-organ segmentation.";
var _r = "https://github.com/wasserth/TotalSegmentator";
var Cr = "https://totalsegmentator.com/";
var wr = "https://www.buymeacoffee.com/totalsegmentator";
var Ir = "Apache-2.0";
var Er = "https://www.apache.org/licenses/LICENSE-2.0";
var Ar = "dicom-send";
var Nr = true;
var Tr = "https://pubs.rsna.org/doi/10.1148/ryai.230024";
var Ur = {
  id: mr,
  product: gr,
  title: yr,
  location: pr,
  summary: Sr,
  githubUrl: _r,
  websiteUrl: Cr,
  buyMeACoffeeUrl: wr,
  license: Ir,
  licenseUrl: Er,
  hubEvent: Ar,
  enabled: Nr,
  citeUrl: Tr
};
var Lr = "dental";
var kr = "DENTAL_SEG";
var vr = "Dental Segmentator";
var Rr = "Paris, France";
var Or = "Fully automatic CT/CBCT dental segmentation (maxilla, mandible, upper/lower teeth, mandibular canal).";
var Pr = "https://github.com/gaudot/SlicerDentalSegmentator";
var Dr = "https://www.kitware.com/dental-segmentator/";
var Mr = "Apache-2.0";
var Hr = "https://www.apache.org/licenses/LICENSE-2.0";
var $r = "dicom-send";
var xr = true;
var Fr = {
  id: Lr,
  product: kr,
  title: vr,
  location: Rr,
  summary: Or,
  githubUrl: Pr,
  websiteUrl: Dr,
  license: Mr,
  licenseUrl: Hr,
  hubEvent: $r,
  enabled: xr
};
var Br = "txrv";
var jr = "TORCHXRAYVISION";
var Wr = "TorchXRayVision";
var Vr = "Montreal, Canada";
var Gr = "Chest X-ray pathology classification (18 findings) and lung/heart anatomy segmentation.";
var zr = "https://github.com/mlmed/torchxrayvision";
var qr = "https://mlmed.org/torchxrayvision/";
var Xr = "Cohen et al., TorchXRayVision: A library of chest X-ray datasets and models, MIDL 2022";
var Yr = "https://arxiv.org/abs/2111.00595";
var Jr = "Apache-2.0";
var Zr = "https://www.apache.org/licenses/LICENSE-2.0";
var Kr = "dicom-send";
var Qr = true;
var ei = {
  id: Br,
  product: jr,
  title: Wr,
  location: Vr,
  summary: Gr,
  githubUrl: zr,
  websiteUrl: qr,
  cite: Xr,
  citeUrl: Yr,
  license: Jr,
  licenseUrl: Zr,
  hubEvent: Kr,
  enabled: Qr
};
var ti = "flexray";
var ni = "FLEXRAY";
var ri = "FleXray";
var ii = "local - in browser";
var si = "Foundation model for universal clinical X-ray anatomy segmentation (60 structures) across body regions, views, and acquisition settings. Designed for on-device / local inference.";
var oi = "https://flexray.csail.mit.edu/";
var ci = "https://github.com/VictorButoi/FleXray";
var ai = "CC-BY-NC-4.0";
var ui = "https://creativecommons.org/licenses/by-nc/4.0/";
var li = "Not for commercial use";
var fi = "Victor Ion Butoi, Vivek Gopalakrishnan, John V. Guttag, Adrian V. Dalca, and Neel Dey (2026). FleXray: Universal Clinical X-ray Segmentation. arXiv:2609.26756";
var di = "https://arxiv.org/abs/2609.26756";
var hi = "dicom-send";
var bi = true;
var mi = true;
var gi = {
  id: ti,
  product: ni,
  title: ri,
  location: ii,
  summary: si,
  websiteUrl: oi,
  githubUrl: ci,
  license: ai,
  licenseUrl: ui,
  licenseRestriction: li,
  cite: fi,
  citeUrl: di,
  hubEvent: hi,
  enabled: bi,
  localCapable: mi
};
function pi(e) {
  const t = String(e.summary || e.capabilities || "").trim(), n = e.hubEvent === "nifti-send" ? "nifti-send" : "dicom-send", r = {
    id: String(e.id || "").trim(),
    product: String(e.product || "").trim(),
    title: String(e.title || "").trim(),
    location: String(e.location || "").trim(),
    summary: t,
    capabilities: t,
    hubEvent: n
  }, i = String(e.githubUrl || "").trim();
  i && (r.githubUrl = i);
  const s2 = String(e.websiteUrl || "").trim();
  s2 && (r.websiteUrl = s2);
  const o = String(e.buyMeACoffeeUrl || "").trim();
  o && (r.buyMeACoffeeUrl = o);
  const c = String(e.iconUrl || "").trim();
  c && (r.iconUrl = c);
  const a = String(e.cite || "").trim();
  a && (r.cite = a);
  const u = String(e.citeUrl || "").trim();
  u && (r.citeUrl = u);
  const l = String(e.license || "").trim();
  l && (r.license = l);
  const d = String(e.licenseUrl || "").trim();
  d && (r.licenseUrl = d);
  const b = String(e.licenseRestriction || "").trim();
  return b && (r.licenseRestriction = b), e.localCapable === true && (r.localCapable = true), r;
}
function Si(e) {
  return (e == null ? void 0 : e.enabled) !== false;
}
var A = Object.freeze(
  [
    br,
    Wn,
    Ur,
    Fr,
    ei,
    gi,
    nr
  ].filter(Si).map(pi)
);
var zs = Object.freeze(
  A.filter((e) => e.localCapable === true)
);
function te(e) {
  const t = e == null ? void 0 : e["hub.event"];
  return typeof t == "string" ? t.trim().toLowerCase() : "";
}
function eo(e) {
  if (!Array.isArray(e))
    return [];
  try {
    return structuredClone(e);
  } catch {
    try {
      return JSON.parse(JSON.stringify(e));
    } catch {
      return [...e];
    }
  }
}
function to(e) {
  const t = e == null ? void 0 : e.event;
  return t && typeof t == "object" && t.context != null ? t.context : [];
}
function no(e) {
  return String(
    (e == null ? void 0 : e["subscriber.name"]) || (e == null ? void 0 : e.subscriber) || ""
  ).trim() || null;
}
function ro(e) {
  return String((e == null ? void 0 : e["subscriber.product.name"]) || "").trim();
}
function io(e) {
  const t = String((e == null ? void 0 : e["subscriber.actor"]) || "").trim();
  if (t)
    return t;
  const n = e == null ? void 0 : e["subscriber.actors"];
  if (Array.isArray(n))
    for (const r of n) {
      const i = String(r || "").trim();
      if (i)
        return i;
    }
  return "";
}
function Ei(e) {
  const t = e == null ? void 0 : e.context;
  if (!t || typeof t != "object" || Array.isArray(t))
    return [];
  const n = t.files;
  return Array.isArray(n) ? n.filter((r) => !!(r && typeof r == "object")) : [];
}
function Ri(e) {
  const t = e == null ? void 0 : e.event;
  return !!(t && se(t));
}
async function mo(e, t) {
  var i, s2;
  if (!(((i = e == null ? void 0 : e.hasPendingPayload) == null ? void 0 : i.call(e, t)) || Ri(t)))
    return t;
  let r = t;
  if (e != null && e.fetchAllPayloads)
    r = await e.fetchAllPayloads(t);
  else if (e != null && e.fetchPayload)
    for (; (s2 = e.hasPendingPayload) != null && s2.call(e, r); )
      r = await e.fetchPayload(r);
  return r;
}
async function It(e, t) {
  const n = String((t == null ? void 0 : t.subscriberName) || "").trim();
  if (!(e != null && e.request))
    return { ok: false, status: 0, data: { error: "No Hub client" } };
  if (!n)
    return { ok: false, status: 0, data: { error: "No subscriber name" } };
  const r = String((t == null ? void 0 : t.topic) || "").trim(), i = String((t == null ? void 0 : t.subscriberProductName) || "").trim(), s2 = String((t == null ? void 0 : t.subscriberActor) || "").trim(), o = String((t == null ? void 0 : t.targetActor) || "*").trim() || "*", c = String((t == null ? void 0 : t.targetProductName) || "").trim();
  return e.request({
    "subscriber.name": n,
    ...i ? { "subscriber.product.name": i } : {},
    ...s2 ? { "subscriber.actor": s2 } : {},
    "target.actor": o,
    ...c ? { "target.product.name": c } : {},
    event: {
      "hub.event": k("STATUS"),
      ...r ? { "hub.topic": r } : {},
      context: { dataType: "STATUS" }
    }
  });
}

// ../conference-ui/dist/conference-ui.js
var Ee = Object.freeze({
  // Dialog shell
  dialogTitle: "Conferencing",
  close: "Close",
  closeAria: "Close",
  // Session (user / topic)
  sessionSection: "User / topic",
  sessionInfo: "Session info",
  participantsAria: "Participants",
  userLabel: "User:",
  changeUserName: "Change user name",
  changeUserNameTitle: "Change user name",
  userNamePlaceholder: "Enter user name",
  openAnotherUser: "Open another user",
  openAnotherUserTitle: "Open another user session to test conferencing",
  openAnotherUserPrompt: "User name for new session",
  userNameSavedNote: "Switched user.",
  userNameSwitchingNote: "Switching user\u2026",
  userNameAlreadyExists: "A user with this name already exists.",
  done: "OK",
  // Create
  createSection: "Create a conference",
  conferenceTitle: "Conference title",
  selectConferenceTitle: "Select a conference title",
  otherTitle: "Other\u2026",
  customTitle: "Custom title",
  customTitlePlaceholder: "Enter conference title",
  users: "Users",
  loadingUsers: "Loading users\u2026",
  noUsers: "No users available",
  createConference: "Create conference",
  creating: "Creating\u2026",
  // Join
  joinSection: "Join a conference",
  activeConferences: "Active conferences",
  noConferences: "No conferences available",
  selectConference: "Select a conference",
  untitled: "Untitled",
  joinConference: "Join conference",
  joining: "Joining\u2026",
  // Manage
  manageSection: "Manage conference",
  titleLabel: "Title:",
  na: "N/A",
  participants: "Participants",
  noPlaces: "No places",
  leaveConference: "Leave conference",
  endConference: "End conference",
  ending: "Ending\u2026",
  leaving: "Leaving\u2026",
  conferenceEnded: "Conference ended.",
  leftConference: "Left conference.",
  // Errors / status
  connectHubFirst: "Connect to the Slicer hub first.",
  topicRequiredHost: "Hub topic is required to host a conference.",
  topicRequiredJoin: "Hub topic is required to join a conference.",
  titleRequired: "Conference title is required.",
  selectAttendee: "Select at least one attendee topic.",
  selectConferenceToJoin: "Select a conference to join.",
  failedCreate: "Failed to create conference.",
  failedJoin: "Failed to join conference.",
  failedUpdate: "Failed to update conference.",
  // Invite
  inviteTitle: "Conference invitation",
  joinAndFollow: "Join and follow",
  joinNoFollow: "Join but do not follow",
  doNotJoin: "Do not join",
  hostFallback: "host",
  /** {{title}} — join and follow {{host}}? */
  inviteLeadWithTitle: "{{title}} \u2014 join and follow {{host}}?",
  /** Join conference and follow {{host}}? */
  inviteLeadNoTitle: "Join conference and follow {{host}}?",
  /** Join and follow {{host}} */
  joinAndFollowHost: "Join and follow {{host}}",
  // Takeover
  takeoverTitle: "Take over?",
  takeoverBody: "The host and all participants will be notified that you are taking over. You will lead scene updates for this conference.",
  cancel: "Cancel",
  takeOver: "Take over",
  // Header
  conferencing: "Conferencing",
  subscribeHubFirst: "Subscribe to the hub first",
  stopFollowing: "Stop following",
  resumeFollowing: "Resume following"
});
function ae(e, n = {}) {
  return String(e || "").replace(
    /\{\{(\w+)\}\}/g,
    (o, l) => n[l] != null ? String(n[l]) : ""
  );
}
function Q2(e) {
  return !e || typeof e != "object" ? { ...Ee } : { ...Ee, ...e };
}
function Te(e, n, o = "hub-dialog-anchored") {
  e instanceof HTMLElement && e.classList.remove(o), n instanceof HTMLElement && (n.style.top = "", n.style.left = "", n.style.right = "", n.style.bottom = "", n.style.maxWidth = "", n.style.position = "", n.style.margin = "");
}
function Ze(e) {
  const n = e == null ? void 0 : e.overlay, o = e == null ? void 0 : e.dialog, l = e == null ? void 0 : e.anchor, t = String((e == null ? void 0 : e.anchoredClass) || "hub-dialog-anchored").trim(), u = Number.isFinite(e == null ? void 0 : e.gap) ? Number(e.gap) : 6, c = Number.isFinite(e == null ? void 0 : e.pad) ? Number(e.pad) : 8, a = (e == null ? void 0 : e.align) === "end";
  if (!(n instanceof HTMLElement) || !(o instanceof HTMLElement))
    return;
  if (!(l instanceof HTMLElement)) {
    Te(n, o, t);
    return;
  }
  const g = l.getBoundingClientRect();
  n.classList.add(t), o.style.position = "absolute", o.style.margin = "0";
  const y = Math.max(
    280,
    Math.min(o.offsetWidth || 480, window.innerWidth - c * 2)
  );
  let d = a ? g.right - y : g.left, i = g.bottom + u;
  const b = window.innerWidth - y - c;
  d > b && (d = Math.max(c, b)), d < c && (d = c);
  const p = o.offsetHeight || 280;
  i + p > window.innerHeight - c && (i = Math.max(c, g.top - p - u)), o.style.left = `${Math.round(d)}px`, o.style.top = `${Math.round(i)}px`, o.style.maxWidth = `${Math.round(y)}px`;
}
function s(e, n) {
  return `${e}-${n}`;
}
function Z2(e) {
  return String(e ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Ke2(e, n) {
  const o = String(e || "").trim();
  if (!o) return false;
  const l = Z(n);
  return l && (l === o || l.toLowerCase() === o.toLowerCase()) ? true : (Array.isArray(n == null ? void 0 : n.topics) ? n.topics : []).some((u) => {
    const c = String(u || "").trim();
    return c === o || c.toLowerCase() === o.toLowerCase();
  });
}
function ut2(e) {
  const n = typeof (e == null ? void 0 : e.getSession) == "function" ? e.getSession : () => ({}), o = typeof (e == null ? void 0 : e.onConferenceChange) == "function" ? e.onConferenceChange : null, l = typeof (e == null ? void 0 : e.onFollowChange) == "function" ? e.onFollowChange : null, t = String((e == null ? void 0 : e.classPrefix) || "hub-conference").trim(), u = (e == null ? void 0 : e.anchorAlign) === "end" ? "end" : "start", c = (e == null ? void 0 : e.root) || (typeof document < "u" ? document.body : null);
  if (!c)
    throw new Error("createHubConferenceDialog requires a DOM root");
  let a = Q2(e == null ? void 0 : e.strings), g = null, y = false, d = null;
  const i = document.createElement("div");
  i.className = s(t, "overlay"), i.hidden = true, i.innerHTML = `
    <div class="${s(t, "dialog")}" role="dialog" aria-modal="true" aria-labelledby="${s(t, "title")}" tabindex="-1">
      <div class="${s(t, "header")}">
        <h2 id="${s(t, "title")}" class="${s(t, "title")}" data-hub-conference-dialog-title></h2>
        <button type="button" class="${s(t, "close")}" data-hub-conference-close aria-label="">\xD7</button>
      </div>
      <div class="${s(t, "body")}">
        <p class="${s(t, "status")}" data-hub-conference-status role="alert" hidden></p>
        <div data-hub-conference-create>
          <div class="${s(t, "section")}" data-hub-conference-create-form>
            <div class="${s(t, "section-title")}" data-hub-conference-create-section></div>
            <div class="${s(t, "field")}">
              <label class="${s(t, "label")}" for="${s(t, "title-select")}" data-hub-conference-title-label></label>
              <select id="${s(t, "title-select")}" class="${s(t, "select")}" data-hub-conference-title-select>
              </select>
            </div>
            <div class="${s(t, "field")}" data-hub-conference-custom-group hidden>
              <label class="${s(t, "label")}" for="${s(t, "custom-title")}" data-hub-conference-custom-label></label>
              <input id="${s(t, "custom-title")}" class="${s(t, "input")}" type="text" data-hub-conference-custom-title />
            </div>
            <div class="${s(t, "field")}">
              <span class="${s(t, "label")}" data-hub-conference-users-label></span>
              <div class="${s(t, "topics")}" data-hub-conference-topics>
                <p class="${s(t, "muted")}" data-hub-conference-loading-users></p>
              </div>
              <p class="${s(t, "muted")}" data-hub-conference-user-note hidden></p>
            </div>
            <button type="button" class="${s(t, "primary")}" data-hub-conference-create-btn></button>
          </div>
          <div class="${s(t, "section")}" data-hub-conference-join-section>
            <div class="${s(t, "section-title")}" data-hub-conference-join-section-title></div>
            <div class="${s(t, "field")}">
              <label class="${s(t, "label")}" for="${s(t, "join-select")}" data-hub-conference-active-label></label>
              <select id="${s(t, "join-select")}" class="${s(t, "select")}" data-hub-conference-join-select>
              </select>
            </div>
            <button type="button" class="${s(t, "primary")}" data-hub-conference-join-btn disabled></button>
          </div>
        </div>
        <div data-hub-conference-manage hidden>
          <div class="${s(t, "info")}" data-hub-conference-info></div>
        </div>
        <button
          type="button"
          id="openConferenceTestWorklistBtn"
          class="${s(t, "secondary")} ${s(t, "open-another-user")}"
          data-hub-conference-open-another-user
        ></button>
      </div>
    </div>
    <div
      class="${s(t, "change-user-overlay")}"
      data-hub-conference-change-user-overlay
      hidden
    >
      <div
        class="${s(t, "change-user-dialog")}"
        role="dialog"
        aria-modal="true"
        aria-labelledby="${s(t, "change-user-title")}"
        tabindex="-1"
      >
        <div class="${s(t, "change-user-header")}">
          <h3
            id="${s(t, "change-user-title")}"
            class="${s(t, "change-user-title")}"
            data-hub-conference-change-user-title
          ></h3>
          <button
            type="button"
            class="${s(t, "close")}"
            data-hub-conference-change-user-close
            aria-label=""
          >\xD7</button>
        </div>
        <div class="${s(t, "field")}">
          <label
            class="${s(t, "label")}"
            for="sessionUserNameInput"
            data-hub-conference-user-label
          ></label>
          <input
            type="text"
            id="sessionUserNameInput"
            class="${s(t, "input")} ${s(t, "user-input")}"
            autocomplete="username"
            data-hub-conference-user-input
          />
        </div>
        <div class="${s(t, "change-user-actions")}">
          <button
            type="button"
            class="${s(t, "primary")}"
            data-hub-conference-change-user-done
          ></button>
        </div>
      </div>
    </div>
  `, c.appendChild(i);
  const b = i.querySelector(`.${s(t, "dialog")}`), p = i.querySelector("[data-hub-conference-status]"), C2 = i.querySelector(
    "[data-hub-conference-open-another-user]"
  ), E2 = i.querySelector(
    "[data-hub-conference-change-user-overlay]"
  ), v2 = i.querySelector(
    "[data-hub-conference-change-user-done]"
  ), w = i.querySelector(
    "[data-hub-conference-change-user-close]"
  ), N = i.querySelector("#sessionUserNameInput"), $2 = i.querySelector("[data-hub-conference-user-note]"), D2 = typeof (e == null ? void 0 : e.onUserNameChange) == "function" ? e.onUserNameChange : null, I2 = i.querySelector("[data-hub-conference-create]"), S = i.querySelector(
    "[data-hub-conference-create-form]"
  ), U2 = i.querySelector("[data-hub-conference-manage]"), H2 = i.querySelector("[data-hub-conference-join-section]"), A2 = i.querySelector("[data-hub-conference-title-select]"), re2 = i.querySelector("[data-hub-conference-custom-group]"), W2 = i.querySelector("[data-hub-conference-custom-title]"), q = i.querySelector("[data-hub-conference-topics]"), T = i.querySelector("[data-hub-conference-join-select]"), le2 = i.querySelector("[data-hub-conference-info]"), F2 = i.querySelector("[data-hub-conference-create-btn]"), k2 = i.querySelector("[data-hub-conference-join-btn]"), ee2 = i.querySelector("[data-hub-conference-close]");
  function ue2(r) {
    !I2 || !S || !H2 || (r ? I2.insertBefore(H2, S) : I2.insertBefore(S, H2));
  }
  function Ae() {
    if (!(A2 instanceof HTMLSelectElement)) return;
    const r = String(A2.value || "");
    A2.replaceChildren();
    const f = document.createElement("option");
    f.value = "", f.textContent = a.selectConferenceTitle, A2.appendChild(f);
    for (const m of ms) {
      const L = document.createElement("option");
      L.value = m, L.textContent = m, m === "Anatomy class" && (L.selected = true), A2.appendChild(L);
    }
    const h = document.createElement("option");
    h.value = "other", h.textContent = a.otherTitle, A2.appendChild(h), r && [...A2.options].some((m) => m.value === r) && (A2.value = r);
  }
  function de5() {
    const r = (f, h) => {
      const m = i.querySelector(f);
      m && (m.textContent = h);
    };
    r("[data-hub-conference-dialog-title]", a.dialogTitle), r("[data-hub-conference-create-section]", a.createSection), r("[data-hub-conference-title-label]", a.conferenceTitle), r("[data-hub-conference-custom-label]", a.customTitle), r("[data-hub-conference-users-label]", a.users), r("[data-hub-conference-loading-users]", a.loadingUsers), r("[data-hub-conference-join-section-title]", a.joinSection), r("[data-hub-conference-active-label]", a.activeConferences), F2 && (F2.textContent = a.createConference), k2 && (k2.textContent = a.joinConference), i.querySelectorAll("[data-hub-conference-user-label]").forEach((f) => {
      f instanceof HTMLElement && (f.textContent = a.userLabel);
    }), r("[data-hub-conference-change-user-title]", a.changeUserNameTitle), C2 instanceof HTMLElement && (C2.textContent = a.openAnotherUser, C2.title = a.openAnotherUserTitle), v2 instanceof HTMLElement && (v2.textContent = a.done), $2 instanceof HTMLElement && ($2.textContent = a.userNameSavedNote), N instanceof HTMLInputElement && (N.placeholder = a.userNamePlaceholder), W2 instanceof HTMLInputElement && (W2.placeholder = a.customTitlePlaceholder), ee2 instanceof HTMLElement && ee2.setAttribute("aria-label", a.closeAria), w instanceof HTMLElement && w.setAttribute("aria-label", a.closeAria), Ae(), oe2();
  }
  function ke() {
  }
  function fe2() {
    return i.querySelector("[data-hub-conference-user-name-btn]");
  }
  function oe2() {
    const r = fe2();
    if (!(r instanceof HTMLElement)) return;
    const f = String(_2().userName || "").trim() || "\u2014";
    r.textContent = f, r.title = a.changeUserNameTitle, r.setAttribute("aria-label", a.changeUserName);
  }
  function Me2() {
    const r = document.createElement("button");
    r.type = "button", r.className = `${s(t, "secondary")} ${s(t, "user-name-btn")}`, r.dataset.hubConferenceUserNameBtn = "";
    const f = String(_2().userName || "").trim() || "\u2014";
    return r.textContent = f, r.title = a.changeUserNameTitle, r.setAttribute("aria-label", a.changeUserName), r;
  }
  function he2(r = "") {
    const f = document.createElement("div");
    f.className = `${s(t, "topic-row")} ${s(t, "topic-row-self")}`;
    const h = String(_2().topic || "").trim(), m = document.createElement("input");
    m.type = "checkbox", m.dataset.hubConferenceTopic = "1", m.value = h, m.checked = true, f.appendChild(m), f.appendChild(Me2());
    const L = ge2(r);
    if (L) {
      const x2 = document.createElement("span");
      x2.className = s(t, "topic-timezone"), x2.textContent = L, f.appendChild(x2);
    }
    return f;
  }
  function X2(r, { error: f = false } = {}) {
    if (!($2 instanceof HTMLElement)) return;
    const h = String(r || "").trim();
    if (!h) {
      $2.hidden = true, $2.textContent = "";
      return;
    }
    $2.hidden = false, $2.textContent = h, $2.classList.toggle(s(t, "status-error"), f);
  }
  async function me(r, f = {}) {
    const h = String(r || "").trim();
    if (!h) return false;
    const m = _2(), L = String(m.topic || "").trim(), x2 = String(m.userName || "").trim();
    return f.excludeSelf !== false && (h === L || h === x2) || !m.hubEndpoint ? false : (await gs(
      m.hubEndpoint,
      m.accessToken
    )).some((R) => String((R == null ? void 0 : R.topic) || "").trim() === h);
  }
  async function Ue() {
    const r = a.openAnotherUserPrompt || "User name for new session", f = window.prompt(r, "STUDENT-1");
    if (f === null) return;
    const h = String(f).trim();
    if (!h) return;
    if (await me(h, { excludeSelf: false })) {
      X2(a.userNameAlreadyExists, { error: true });
      return;
    }
    const m = new URL(window.location.href);
    m.searchParams.set("userName", h), m.searchParams.set("topic", h), m.searchParams.delete("freshUser"), window.open(m.href, "_blank", "noopener,noreferrer"), J2(), V2();
  }
  function qe() {
    E2 instanceof HTMLElement && (N instanceof HTMLInputElement && (N.value = String(_2().userName || "").trim()), X2("", {}), E2.hidden = false, N instanceof HTMLInputElement && (N.focus(), N.select()));
  }
  function J2() {
    E2 instanceof HTMLElement && (E2.hidden = true);
  }
  async function be2() {
    if (!(N instanceof HTMLInputElement)) return;
    const r = N.value.trim();
    if (!r) return;
    const f = _2(), h = String(f.userName || "").trim();
    if (r === h) {
      J2();
      return;
    }
    if (await me(r, { excludeSelf: true })) {
      X2(a.userNameAlreadyExists, { error: true });
      return;
    }
    v2 instanceof HTMLButtonElement && (v2.disabled = true), X2(a.userNameSwitchingNote || "Switching user\u2026");
    try {
      D2 && await D2(r);
      const m = fe2();
      m instanceof HTMLElement && (m.textContent = r || "\u2014"), X2(a.userNameSavedNote), J2(), te2();
    } catch (m) {
      const L = m instanceof Error && m.message ? m.message : a.userNameAlreadyExists;
      X2(L, { error: true });
    } finally {
      v2 instanceof HTMLButtonElement && (v2.disabled = false);
    }
  }
  de5();
  function j2(r, f) {
    if (!p)
      return;
    const h = String(f || "").trim();
    if (p.classList.remove(
      s(t, "status-success"),
      s(t, "status-error")
    ), !h) {
      p.hidden = true, p.textContent = "";
      return;
    }
    p.hidden = false, p.textContent = h, r === "success" ? p.classList.add(s(t, "status-success")) : r === "error" && p.classList.add(s(t, "status-error"));
  }
  function pe2(r) {
    g = r, o && o(r);
  }
  function _2() {
    const r = n() || {};
    return {
      hubEndpoint: String(r.hubEndpoint ?? "").trim(),
      topic: String(r.topic ?? "").trim(),
      subscriberName: String(r.subscriberName ?? "").trim(),
      userName: String(r.userName ?? "").trim(),
      connected: !!r.connected,
      accessToken: String(r.accessToken ?? "").trim()
    };
  }
  function je2() {
    const r = String((A2 == null ? void 0 : A2.value) || "").trim();
    return r === "other" ? String((W2 == null ? void 0 : W2.value) || "").trim() : r;
  }
  function Pe2() {
    return q ? Array.from(
      q.querySelectorAll(
        'input[type="checkbox"][data-hub-conference-topic]:checked'
      )
    ).map((r) => String(r.value || "").trim()).filter(Boolean) : [];
  }
  function ge2(r) {
    var h;
    const f = String(r || "").trim();
    if (!f) return "";
    try {
      const L = (h = new Intl.DateTimeFormat("en", {
        timeZone: f,
        timeZoneName: "shortOffset"
      }).formatToParts(/* @__PURE__ */ new Date()).find((x2) => x2.type === "timeZoneName")) == null ? void 0 : h.value;
      return L ? `${f} (${L})` : f;
    } catch {
      return f;
    }
  }
  function ye2(r) {
    if (!q)
      return;
    q.replaceChildren();
    const f = String(_2().topic || "").trim();
    let h = false, m = 0;
    const L = Array.isArray(r) ? r : [];
    for (const x2 of L) {
      const B2 = typeof x2 == "string" ? String(x2).trim() : String((x2 == null ? void 0 : x2.topic) ?? "").trim();
      if (!B2) continue;
      const R = typeof x2 == "string" ? "" : String((x2 == null ? void 0 : x2.timezone) ?? "").trim();
      if (f && B2 === f) {
        q.appendChild(he2(R)), h = true, m += 1;
        continue;
      }
      const O2 = document.createElement("label");
      O2.className = s(t, "topic-row");
      const G2 = document.createElement("input");
      G2.type = "checkbox", G2.dataset.hubConferenceTopic = "1", G2.value = B2, G2.checked = true;
      const Y2 = document.createElement("span");
      Y2.className = s(t, "topic-label"), Y2.textContent = B2, O2.appendChild(G2), O2.appendChild(Y2);
      const ve = ge2(R);
      if (ve) {
        const se2 = document.createElement("span");
        se2.className = s(t, "topic-timezone"), se2.textContent = ve, O2.appendChild(se2);
      }
      q.appendChild(O2), m += 1;
    }
    if (f && !h && (q.insertBefore(
      he2(""),
      q.firstChild
    ), m += 1), !m) {
      const x2 = document.createElement("p");
      x2.className = s(t, "muted"), x2.textContent = a.noUsers, q.appendChild(x2);
    }
    oe2();
  }
  function Se(r, f) {
    if (!T || !k2) return;
    const h = (Array.isArray(r) ? r : []).filter(
      (B2) => B2 && typeof B2 == "object" && !Ke2(
        f,
        /** @type {Record<string, unknown>} */
        B2
      )
    ), m = String(T.value || "");
    if (T.replaceChildren(), !h.length) {
      T.replaceChildren(), T.disabled = true, k2.disabled = true, H2 instanceof HTMLElement && (H2.hidden = true), ue2(false);
      return;
    }
    H2 instanceof HTMLElement && (H2.hidden = false);
    const L = document.createElement("option");
    L.value = "", L.textContent = a.selectConference, T.appendChild(L);
    const x2 = [];
    for (const B2 of h) {
      const R = (
        /** @type {Record<string, unknown>} */
        B2
      ), O2 = Z(R);
      if (!O2) continue;
      x2.push(O2);
      const G2 = String(R.title || "").trim() || a.untitled, Y2 = document.createElement("option");
      Y2.value = O2, Y2.textContent = `${G2} \u2014 ${O2}`, T.appendChild(Y2);
    }
    T.disabled = false, m && x2.includes(m) ? T.value = m : x2.length && (T.value = x2[0]), k2.disabled = !String(T.value || "").trim(), ue2(true);
  }
  function ce2(r) {
    if (I2 && (I2.hidden = !!r), U2 && (U2.hidden = !r), r && le2) {
      const f = r.places.length ? `<div class="${s(t, "places")}">${r.places.map((h) => {
        const m = [s(t, "place")];
        h.isSelf && m.push(s(t, "place-self")), h.isLeading && m.push(s(t, "place-leading")), h.isFollowing && m.push(s(t, "place-following"));
        const L = h.statusLabel ? `<span class="${s(t, "place-status")}">${Z2(
          h.statusLabel
        )}</span>` : "";
        return `<span class="${m.join(
          " "
        )}" title="${Z2(h.placeId)}"><span class="${s(
          t,
          "place-name"
        )}">${Z2(h.label)}</span>${L}</span>`;
      }).join("")}</div>` : `<div class="${s(t, "muted")}">${Z2(a.noPlaces)}</div>`;
      le2.innerHTML = `<div><strong>${Z2(a.titleLabel)}</strong> ${Z2(
        r.title || a.na
      )}</div><div class="${s(t, "places-label")}">${Z2(
        a.participants
      )}</div>${f}`;
    }
  }
  async function te2() {
    const r = _2();
    if (!r.hubEndpoint || !r.connected)
      return ye2([]), Se([], r.topic), ce2(null), pe2(null), null;
    const [f, h] = await Promise.all([
      gs(r.hubEndpoint, r.accessToken),
      at(r.hubEndpoint, r.accessToken)
    ]), m = ct(
      r.topic,
      r.subscriberName,
      h
    ), L = Kt(r, m);
    return m || (ye2(f), Se(h, r.topic)), ce2(L), pe2(L), L;
  }
  async function Ie() {
    if (y)
      return;
    const r = _2(), f = je2(), h = Pe2();
    if (!r.connected) {
      j2("error", a.connectHubFirst);
      return;
    }
    if (!r.topic) {
      j2("error", a.topicRequiredHost);
      return;
    }
    if (!f) {
      j2("error", a.titleRequired);
      return;
    }
    if (!h.length) {
      j2("error", a.selectAttendee);
      return;
    }
    y = true, F2 && (F2.disabled = true, F2.textContent = a.creating), j2("", "");
    try {
      await ys(
        r.hubEndpoint,
        r.topic,
        f,
        h,
        r.userName,
        r.accessToken
      ), await te2(), V2();
    } catch (m) {
      j2(
        "error",
        m instanceof Error ? m.message : a.failedCreate
      );
    } finally {
      y = false, F2 && (F2.disabled = false, F2.textContent = a.createConference);
    }
  }
  async function Fe2() {
    if (y) return;
    const r = _2(), f = String((T == null ? void 0 : T.value) || "").trim();
    if (!r.connected) {
      j2("error", a.connectHubFirst);
      return;
    }
    if (!r.topic) {
      j2("error", a.topicRequiredJoin);
      return;
    }
    if (!f) {
      j2("error", a.selectConferenceToJoin);
      return;
    }
    y = true, k2 && (k2.disabled = true, k2.textContent = a.joining), j2("", "");
    try {
      await ps(
        r.hubEndpoint,
        f,
        r.topic,
        r.userName,
        r.accessToken
      ), l == null || l(true), await te2(), V2();
    } catch (h) {
      j2(
        "error",
        h instanceof Error ? h.message : a.failedJoin
      );
    } finally {
      y = false, k2 && (k2.textContent = a.joinConference, k2.disabled = !String((T == null ? void 0 : T.value) || "").trim());
    }
  }
  function Be2() {
    Te(
      i,
      b instanceof HTMLElement ? b : null,
      s(t, "overlay-anchored")
    );
  }
  function ie(r) {
    Ze({
      overlay: i,
      dialog: b instanceof HTMLElement ? b : null,
      anchor: r,
      anchoredClass: s(t, "overlay-anchored"),
      align: u
    });
  }
  function _e(r) {
    j2("", ""), A2 && (A2.value = "Anatomy class"), W2 && (W2.value = ""), re2 && (re2.hidden = true), J2(), $2 instanceof HTMLElement && ($2.hidden = true), oe2(), d = r instanceof HTMLElement ? r : null, i.hidden = false, ie(d), b instanceof HTMLElement && b.focus({ preventScroll: true }), te2().then(() => ie(d)).catch(() => {
    });
  }
  function V2() {
    J2(), i.hidden = true, j2("", ""), Be2(), d = null;
  }
  function Oe2() {
    V2(), i.remove();
  }
  function De2(r) {
    a = Q2(r), de5(), g && ce2(g);
  }
  return A2 == null || A2.addEventListener("change", () => {
    re2 && (re2.hidden = String(A2.value || "") !== "other");
  }), T == null || T.addEventListener("change", () => {
    k2 && (k2.disabled = !String(T.value || "").trim() || y);
  }), F2 == null || F2.addEventListener("click", () => {
    Ie().catch(() => {
    });
  }), k2 == null || k2.addEventListener("click", () => {
    Fe2().catch(() => {
    });
  }), ee2 == null || ee2.addEventListener("click", (r) => {
    r.stopPropagation(), V2();
  }), q == null || q.addEventListener("click", (r) => {
    const f = r.target;
    if (!(f instanceof Element)) return;
    const h = f.closest("[data-hub-conference-user-name-btn]");
    !(h instanceof HTMLElement) || !q.contains(h) || (r.stopPropagation(), qe());
  }), v2 == null || v2.addEventListener("click", (r) => {
    r.stopPropagation(), be2();
  }), w == null || w.addEventListener("click", (r) => {
    r.stopPropagation(), J2();
  }), C2 == null || C2.addEventListener("click", (r) => {
    r.stopPropagation(), Ue();
  }), N == null || N.addEventListener("keydown", (r) => {
    r.key === "Enter" ? (r.preventDefault(), be2()) : r.key === "Escape" && (r.preventDefault(), J2());
  }), E2 == null || E2.addEventListener("click", (r) => {
    r.target === E2 && J2();
  }), i.addEventListener("click", (r) => {
    r.target === i && V2();
  }), window.addEventListener("resize", () => {
    i.hidden || ie(d);
  }), {
    open: _e,
    close: V2,
    destroy: Oe2,
    refresh: te2,
    setStrings: De2,
    syncSessionControl: ke,
    getSessionControl: () => ({
      button: null,
      label: null
    }),
    getView: () => g,
    get element() {
      return i;
    }
  };
}
var Le = "ID";
function dt2(e = {}) {
  const n = Array.isArray(e.selfActors) ? e.selfActors.map((u) => String(u || "").trim()).filter(Boolean) : [], o = Array.isArray(e.connectedActors) ? e.connectedActors.map((u) => String(u || "").trim()).filter(Boolean) : [];
  return n.some(
    (u) => u === Le || u.toUpperCase() === "ID"
  ) ? true : !o.some(
    (u) => u === Le || u.toUpperCase() === "ID"
  );
}
function Xe(e) {
  const n = e && typeof e == "object" ? (
    /** @type {{ event?: Record<string, unknown> }} */
    e.event
  ) : null;
  if (!n || typeof n != "object")
    return null;
  const o = String(n["hub.event"] || "").trim().toLowerCase();
  if (o !== "conference-start" && o !== "conference-end" && o !== "conference-lead")
    return null;
  const l = n.context && typeof n.context == "object" ? (
    /** @type {Record<string, unknown>} */
    n.context
  ) : {}, t = String(
    l.hostTopic || n["hub.topic"] || ""
  ).trim(), u = String(l.title || "").trim(), c = String(l.hostUserName || "").trim(), a = String(l.sceneLeaderTopic || "").trim(), g = String(
    l.leaderUserName || l.leaderLabel || ""
  ).trim(), y = g || a || c || t || "host", d = String(l.joinedTopic || "").trim();
  return {
    hubEvent: o,
    title: u,
    hostTopic: t,
    hostUserName: c,
    hostLabel: c || t || "host",
    sceneLeaderTopic: a,
    leaderUserName: g,
    leaderLabel: y,
    joinedTopic: d
  };
}
function M2(e, n) {
  return `${e}-${n}`;
}
function Qe2(e = {}) {
  const n = typeof e.onDecision == "function" ? e.onDecision : null, o = String(
    e.classPrefix || "hub-conference-invite"
  ).trim(), l = e.root || (typeof document < "u" ? document.body : null);
  if (!l)
    throw new Error("createHubConferenceInviteDialog requires a DOM root");
  let t = Q2(e.strings), u = null, c = false;
  const a = document.createElement("div");
  a.className = M2(o, "overlay"), a.hidden = true, a.innerHTML = `
    <div class="${M2(o, "dialog")}" role="dialog" aria-modal="true" aria-labelledby="${M2(o, "title")}" tabindex="-1">
      <div class="${M2(o, "header")}">
        <h2 id="${M2(o, "title")}" class="${M2(o, "title")}" data-hub-invite-title></h2>
        <button type="button" class="${M2(o, "close")}" data-hub-invite-close aria-label="">\xD7</button>
      </div>
      <div class="${M2(o, "body")}">
        <p class="${M2(o, "lead")}" data-hub-invite-lead></p>
        <p class="${M2(o, "status")}" data-hub-invite-status role="alert" hidden></p>
        <div class="${M2(o, "actions")}">
          <button type="button" class="${M2(o, "primary")}" data-hub-invite-follow></button>
          <button type="button" class="${M2(o, "secondary")}" data-hub-invite-join></button>
          <button type="button" class="${M2(o, "secondary")}" data-hub-invite-decline></button>
        </div>
      </div>
    </div>
  `, l.appendChild(a);
  const g = a.querySelector(`.${M2(o, "dialog")}`), y = a.querySelector("[data-hub-invite-title]"), d = a.querySelector("[data-hub-invite-lead]"), i = a.querySelector("[data-hub-invite-status]"), b = a.querySelector("[data-hub-invite-follow]"), p = a.querySelector("[data-hub-invite-join]"), C2 = a.querySelector("[data-hub-invite-decline]"), E2 = a.querySelector("[data-hub-invite-close]");
  function v2() {
    y && (y.textContent = t.inviteTitle), p && (p.textContent = t.joinNoFollow), C2 && (C2.textContent = t.doNotJoin), E2 instanceof HTMLElement && E2.setAttribute("aria-label", t.closeAria), b && u ? b.textContent = ae(
      t.joinAndFollowHost,
      { host: u.hostLabel || t.hostFallback }
    ) : b && (b.textContent = t.joinAndFollow);
  }
  v2();
  function w(S, U2) {
    if (!(i instanceof HTMLElement)) return;
    const H2 = String(U2 || "").trim();
    i.hidden = !H2, i.textContent = H2, i.classList.toggle(M2(o, "status-error"), S === "error");
  }
  function N(S) {
    c = S;
    for (const U2 of [b, p, C2])
      U2 instanceof HTMLButtonElement && (U2.disabled = S);
  }
  function $2() {
    a.hidden = true, u = null, w("", ""), N(false);
  }
  function D2(S) {
    const U2 = String(
      (S == null ? void 0 : S.hostLabel) || (S == null ? void 0 : S.hostUserName) || (S == null ? void 0 : S.hostTopic) || t.hostFallback
    ).trim() || t.hostFallback, H2 = String((S == null ? void 0 : S.title) || "").trim();
    u = {
      hubEvent: "conference-start",
      title: H2,
      hostTopic: String((S == null ? void 0 : S.hostTopic) || "").trim(),
      hostUserName: String((S == null ? void 0 : S.hostUserName) || "").trim(),
      hostLabel: U2
    }, d instanceof HTMLElement && (d.textContent = H2 ? ae(t.inviteLeadWithTitle, {
      title: H2,
      host: U2
    }) : ae(t.inviteLeadNoTitle, {
      host: U2
    })), b instanceof HTMLElement && (b.textContent = ae(
      t.joinAndFollowHost,
      { host: U2 }
    )), w("", ""), a.hidden = false, g instanceof HTMLElement && g.focus({ preventScroll: true });
  }
  async function I2(S) {
    if (c || !u) return;
    const U2 = u;
    N(true);
    try {
      n && await n(S, U2), $2();
    } catch (H2) {
      w(
        "error",
        H2 instanceof Error ? H2.message : t.failedUpdate
      ), N(false);
    }
  }
  return b == null || b.addEventListener("click", () => {
    I2("join-follow");
  }), p == null || p.addEventListener("click", () => {
    I2("join");
  }), C2 == null || C2.addEventListener("click", () => {
    I2("decline");
  }), a.querySelectorAll("[data-hub-invite-close]").forEach((S) => {
    S.addEventListener("click", () => $2());
  }), a.addEventListener("click", (S) => {
    S.target === a && $2();
  }), {
    open: D2,
    close: $2,
    /**
     * @param {Partial<import('./conferenceStrings.js').CastConferenceStrings> | null | undefined} next
     */
    setStrings(S) {
      t = Q2(S), v2(), u && !a.hidden && D2(u);
    },
    destroy() {
      $2(), a.remove();
    },
    isOpen() {
      return !a.hidden;
    },
    getInvite() {
      return u;
    },
    element: a
  };
}
function ft2(e) {
  const n = typeof (e == null ? void 0 : e.getSession) == "function" ? e.getSession : () => ({}), o = typeof (e == null ? void 0 : e.shouldShow) == "function" ? e.shouldShow : () => true, l = typeof (e == null ? void 0 : e.onConferenceChange) == "function" ? e.onConferenceChange : null, t = typeof (e == null ? void 0 : e.onFollowChange) == "function" ? e.onFollowChange : null, u = typeof (e == null ? void 0 : e.onLeadChange) == "function" ? e.onLeadChange : null, c = (e == null ? void 0 : e.dialog) || Qe2({
    root: e == null ? void 0 : e.root,
    classPrefix: e == null ? void 0 : e.classPrefix,
    strings: e == null ? void 0 : e.strings,
    onDecision: async (d, i) => {
      await g(d, i);
    }
  });
  async function a() {
    const d = n(), i = await ws(
      d.hubEndpoint || "",
      d.topic || "",
      d.subscriberName || "",
      d.userName || "",
      d.accessToken || ""
    );
    return l == null || l(i), i;
  }
  async function g(d, i) {
    const b = n(), p = String((i == null ? void 0 : i.hostTopic) || "").trim();
    if (!p)
      throw new Error("Missing conference host topic.");
    if (d === "decline") {
      const v2 = String(b.topic || "").trim();
      if (v2)
        try {
          await Ss(
            b.hubEndpoint || "",
            p,
            v2,
            b.accessToken || ""
          );
        } catch {
        }
      t == null || t(false), l == null || l(null);
      return;
    }
    const C2 = String(b.topic || "").trim();
    if (!C2)
      throw new Error("Hub topic is required to join a conference.");
    await ps(
      b.hubEndpoint || "",
      p,
      C2,
      b.userName || b.subscriberName || "",
      b.accessToken || ""
    );
    const E2 = d === "join-follow";
    t == null || t(E2, E2 ? i : void 0), await a();
  }
  function y(d) {
    const i = Xe(d);
    if (!i) return false;
    const b = n(), p = String(b.topic || "").trim();
    if (i.hubEvent === "conference-lead") {
      const E2 = String(i.sceneLeaderTopic || "").trim(), v2 = !!p && !!E2 && (p === E2 || p.toLowerCase() === E2.toLowerCase());
      return t == null || t(!v2, i), a().then(() => {
        u == null || u(i);
      }), true;
    }
    if (i.hubEvent === "conference-end") {
      const E2 = (
        /** @type {{ context?: Record<string, unknown> }} */
        d.event || {}
      ), v2 = E2.context && typeof E2.context == "object" ? E2.context : {}, w = String(v2.leaveTopic || "").trim();
      return !w || w === p ? (c.close(), t == null || t(false), l == null || l(null)) : a(), true;
    }
    if (p && i.hostTopic && (p === i.hostTopic || p.toLowerCase() === i.hostTopic.toLowerCase()))
      return t == null || t(false), a(), true;
    const C2 = String(i.joinedTopic || "").trim();
    return p && C2 && (p === C2 || p.toLowerCase() === C2.toLowerCase()) ? (t == null || t(true, i), a(), true) : o() ? (c.open(i), a(), true) : (a(), true);
  }
  return {
    handleHubMessage: y,
    open: (d) => c.open(d),
    close: () => c.close(),
    destroy: () => c.destroy(),
    refresh: a,
    /**
     * @param {Partial<import('./conferenceStrings.js').CastConferenceStrings> | null | undefined} next
     */
    setStrings(d) {
      var i;
      (i = c.setStrings) == null || i.call(c, d);
    },
    dialog: c
  };
}
function P2(e, n) {
  return `${e}-${n}`;
}
function $e2(e) {
  var l;
  if (!((l = e == null ? void 0 : e.places) != null && l.length)) return null;
  const n = e.places.find((t) => t && t.isLeading);
  if (n) return n;
  const o = String(e.leadingPlaceId || "").trim();
  return o && e.places.find(
    (t) => t && (t.placeId === o || t.placeId.toLowerCase() === o.toLowerCase())
  ) || null;
}
function et2(e, n = true) {
  return e != null && e.isFollowing ? n ? "Following" : "Skipping" : String((e == null ? void 0 : e.statusLabel) || "").trim();
}
function Ne(e, n, o = "short", l = true, t = "") {
  if ((n === "leading" || n === "following" ? n : e != null && e.isLeading ? "leading" : "following") === "leading")
    return o === "full" ? "You \xB7 leading" : "Leading";
  const c = String(t || "").trim();
  if (!l)
    return c ? `Skipping ${c}` : o === "full" ? "You \xB7 skipping" : "Skipping";
  if (c) return `Following ${c}`;
  if (o === "full") {
    const a = String((e == null ? void 0 : e.statusLabel) || "").trim();
    return a || "You";
  }
  return "Following";
}
function tt2(e, n, o = true) {
  if (!e) return "";
  if (e.isSelf) {
    const l = $e2(n);
    return Ne(
      e,
      n == null ? void 0 : n.selfRole,
      "short",
      o,
      l && !l.isSelf ? l.label : ""
    );
  }
  return et2(e, o);
}
function nt2(e, n) {
  e.classList.remove(n, `${n}-leading`);
  const o = e.querySelector("[data-hub-conference-role]");
  o instanceof HTMLElement && (o.hidden = true, o.textContent = "");
}
function He2(e, n, o, l, t) {
  const u = (n.places || []).filter((c) => c && (t || !c.isSelf));
  for (const c of u) {
    const a = document.createElement("div");
    a.className = P2(o, "chip"), a.setAttribute("role", "listitem"), c.isSelf && a.classList.add(P2(o, "chip-self")), c.isLeading && a.classList.add(P2(o, "chip-leading")), c.isFollowing && (a.classList.add(P2(o, "chip-following")), l || a.classList.add(P2(o, "chip-skipping")));
    const g = tt2(
      c,
      n,
      l
    ), y = document.createElement("span");
    y.className = P2(o, "chip-name"), y.textContent = c.label;
    const d = [c.label, g, c.placeId].map((i) => String(i || "").trim()).filter(Boolean).join(" \u2014 ");
    if (y.title = d, a.title = d, a.append(y), g) {
      const i = document.createElement("span");
      i.className = P2(o, "chip-status"), i.textContent = g, a.append(i);
    }
    e.append(a);
  }
}
function ht2(e) {
  var v2;
  const n = (e == null ? void 0 : e.view) ?? null, o = e == null ? void 0 : e.statusControl, l = (e == null ? void 0 : e.chipsHost) instanceof HTMLElement ? e.chipsHost : null, t = String((e == null ? void 0 : e.classPrefix) || "hub-conference").trim() || "hub-conference", u = String((e == null ? void 0 : e.statusClassPrefix) || P2(t, "user")).trim() || P2(t, "user"), c = (e == null ? void 0 : e.selfStatusMode) === "full" ? "full" : "short", a = (e == null ? void 0 : e.followHost) !== false, g = P2(t, "chip-status");
  if (!(o instanceof HTMLElement))
    return;
  if (!!!((v2 = n == null ? void 0 : n.places) != null && v2.length)) {
    nt2(o, u), l && (l.replaceChildren(), l.hidden = true), z();
    return;
  }
  const d = n.places.find((w) => w && w.isSelf) || null, i = $e2(n), b = n.selfRole === "leading" || !!(d != null && d.isLeading), p = i && !i.isSelf ? String(i.label || "").trim() : "";
  o.classList.add(u), o.classList.toggle(`${u}-leading`, b);
  let C2 = o.querySelector("[data-hub-conference-role]");
  if (C2 instanceof HTMLElement || (C2 = document.createElement("span"), C2.dataset.hubConferenceRole = "1", o.append(C2)), C2.className = g, C2.hidden = false, C2.textContent = Ne(
    d,
    n.selfRole,
    c,
    a,
    p
  ), !l)
    return;
  if (l.replaceChildren(), !n.places.filter((w) => w && !w.isSelf).length) {
    l.hidden = true;
    return;
  }
  l.hidden = false, He2(l, n, t, a, false);
}
var K = null;
function z() {
  K && (K.cleanup(), K = null);
}
function rt2(e = {}) {
  var b;
  const n = Q2(e.strings), o = e.view ?? null, l = !!e.followHost, t = !!e.connected, u = !!((b = o == null ? void 0 : o.places) != null && b.length), c = (o == null ? void 0 : o.selfRole) === "leading", g = !!(o != null && o.isConferenceOwner) ? n.endConference : n.leaveConference, y = u && !c && l, d = u && !c && !l, i = t ? n.conferencing : n.subscribeHubFirst;
  return {
    active: u,
    start: {
      // Keep Conferencing available while active so User/topic + Manage stay reachable.
      hidden: false,
      disabled: !t,
      label: n.conferencing,
      title: i,
      ariaLabel: n.conferencing
    },
    leave: {
      hidden: !u,
      disabled: !t || !u,
      label: g,
      title: g,
      ariaLabel: g
    },
    stopFollowing: {
      hidden: !y,
      label: n.stopFollowing,
      title: n.stopFollowing,
      ariaLabel: n.stopFollowing
    },
    resumeFollowing: {
      hidden: !d,
      label: n.resumeFollowing,
      title: n.resumeFollowing,
      ariaLabel: n.resumeFollowing
    },
    takeOver: {
      hidden: !d,
      disabled: !t || !d,
      label: n.takeOver,
      title: n.takeOver,
      ariaLabel: n.takeOver
    }
  };
}
function ne2(e, n) {
  e instanceof HTMLElement && (typeof n.hidden == "boolean" && (e.hidden = n.hidden), typeof n.disabled == "boolean" && "disabled" in e && (e.disabled = n.disabled, n.disabled || e.removeAttribute("disabled")), typeof n.label == "string" && !e.querySelector("svg") && (e.textContent = n.label), typeof n.title == "string" && (e.title = n.title), typeof n.ariaLabel == "string" && e.setAttribute("aria-label", n.ariaLabel));
}
function pt(e = {}) {
  const n = rt2({
    view: e.view,
    followHost: e.followHost,
    connected: e.connected,
    strings: e.strings
  });
  return ne2(e.startBtn, n.start), ne2(e.endBtn, n.leave), ne2(e.stopFollowBtn, n.stopFollowing), ne2(e.resumeFollowBtn, n.resumeFollowing), ne2(e.takeOverBtn, n.takeOver), n;
}
function yt(e, n = {}) {
  var g;
  const o = String(e || "").trim();
  if (!o || typeof document > "u")
    return;
  const l = Math.max(1e3, Number(n.ms) || 4e3), t = String(n.classPrefix || "hub-info-toast").trim(), u = n.root || (typeof document < "u" ? document.body : null);
  if (!u)
    return;
  const c = (g = u.querySelector) == null ? void 0 : g.call(u, `.${t}`);
  c && c.remove();
  const a = document.createElement("div");
  a.className = t, a.setAttribute("role", "status"), a.textContent = o, a.style.cssText = [
    "position:fixed",
    "left:50%",
    "bottom:28px",
    "transform:translateX(-50%)",
    "z-index:10050",
    "max-width:min(420px,calc(100vw - 32px))",
    "padding:10px 16px",
    "border-radius:8px",
    "background:#1a2332",
    "color:#e8eef8",
    "font:600 13px/1.35 -apple-system,system-ui,sans-serif",
    "box-shadow:0 8px 28px rgba(0,0,0,.35)",
    "pointer-events:none"
  ].join(";"), u.appendChild(a), window.setTimeout(() => {
    a.remove();
  }, l);
}
var at2 = "hub-radio-icon";
var ot2 = `<svg class="${at2}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"/></svg>`;
var st2 = "hub-conference-icon";
var St = `<svg class="${st2}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`;
function Ct(e, n = {}) {
  return n == null || n.conferenceActive, e === "connected" ? {
    tone: "connected",
    showSlash: false,
    pulse: false,
    conferencePulse: false
  } : e === "connecting" || e === "token-ready" ? {
    tone: "connecting",
    showSlash: false,
    pulse: true,
    conferencePulse: false
  } : e === "error" || e === "disconnected" ? {
    tone: "error",
    showSlash: true,
    pulse: false,
    conferencePulse: false
  } : {
    tone: "idle",
    showSlash: true,
    pulse: false,
    conferencePulse: false
  };
}

// ../i18n/storage.ts
var LOCALE_STORAGE_KEY = "pw46.locale";
var LEGACY_LOCALE_KEY = "wl-locale";
var LOCALE_COOKIE = "pw46.locale";
function isAppLocale(value) {
  return value === "en" || value === "ar" || value === "fr" || value === "es" || value === "ca" || value === "de" || value === "it" || value === "pt" || value === "ko" || value === "pl" || value === "uk" || value === "cs" || value === "nl" || value === "el" || value === "lv" || value === "hu" || value === "lt" || value === "ro" || value === "no";
}
function readCookie(name) {
  if (typeof document === "undefined") return null;
  const prefix = `${encodeURIComponent(name)}=`;
  for (const part of document.cookie.split(";")) {
    const s2 = part.trim();
    if (s2.startsWith(prefix)) {
      try {
        return decodeURIComponent(s2.slice(prefix.length));
      } catch {
        return s2.slice(prefix.length);
      }
    }
  }
  return null;
}
function writeCookie(name, value) {
  if (typeof document === "undefined") return;
  document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(
    value
  )}; path=/; max-age=31536000; SameSite=Lax`;
}
function fromNavigator() {
  const nav = (typeof navigator !== "undefined" ? navigator.language || "" : "").toLowerCase();
  if (nav.startsWith("ca")) return "ca";
  if (nav.startsWith("ar")) return "ar";
  if (nav.startsWith("es")) return "es";
  if (nav.startsWith("fr")) return "fr";
  if (nav.startsWith("de")) return "de";
  if (nav.startsWith("it")) return "it";
  if (nav.startsWith("pt")) return "pt";
  if (nav.startsWith("ko")) return "ko";
  if (nav.startsWith("pl")) return "pl";
  if (nav.startsWith("uk")) return "uk";
  if (nav.startsWith("cs")) return "cs";
  if (nav.startsWith("nl")) return "nl";
  if (nav.startsWith("el")) return "el";
  if (nav.startsWith("lv")) return "lv";
  if (nav.startsWith("hu")) return "hu";
  if (nav.startsWith("lt")) return "lt";
  if (nav.startsWith("ro")) return "ro";
  if (nav.startsWith("no") || nav.startsWith("nb") || nav.startsWith("nn"))
    return "no";
  return "en";
}
function resolveStoredLocale() {
  const cookie = readCookie(LOCALE_COOKIE)?.trim().toLowerCase();
  if (isAppLocale(cookie)) {
    try {
      localStorage.setItem(LOCALE_STORAGE_KEY, cookie);
      localStorage.removeItem(LEGACY_LOCALE_KEY);
    } catch {
    }
    return cookie;
  }
  try {
    const stored = localStorage.getItem(LOCALE_STORAGE_KEY)?.trim().toLowerCase();
    if (isAppLocale(stored)) {
      try {
        writeCookie(LOCALE_COOKIE, stored);
      } catch {
      }
      return stored;
    }
  } catch {
  }
  try {
    const legacy = localStorage.getItem(LEGACY_LOCALE_KEY)?.trim().toLowerCase();
    if (isAppLocale(legacy)) {
      persistLocale(legacy);
      return legacy;
    }
  } catch {
  }
  return fromNavigator();
}
function persistLocale(code) {
  try {
    localStorage.setItem(LOCALE_STORAGE_KEY, code);
    localStorage.removeItem(LEGACY_LOCALE_KEY);
  } catch {
  }
  try {
    writeCookie(LOCALE_COOKIE, code);
  } catch {
  }
  applyDocumentLocale(code);
}
function applyDocumentLocale(code) {
  if (typeof document === "undefined") return;
  document.documentElement.lang = code;
  document.documentElement.dir = code === "ar" ? "rtl" : "ltr";
}

// ../i18n/language-picker.ts
var APP_LOCALES = [
  { code: "en", nativeLabel: "English" },
  { code: "fr", nativeLabel: "Fran\xE7ais" },
  { code: "de", nativeLabel: "Deutsch" },
  { code: "es", nativeLabel: "Espa\xF1ol" },
  { code: "ca", nativeLabel: "Catal\xE0" },
  { code: "it", nativeLabel: "Italiano" },
  { code: "pt", nativeLabel: "Portugu\xEAs" },
  { code: "ko", nativeLabel: "\uD55C\uAD6D\uC5B4" },
  { code: "pl", nativeLabel: "Polski" },
  { code: "uk", nativeLabel: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430" },
  { code: "cs", nativeLabel: "\u010Ce\u0161tina" },
  { code: "nl", nativeLabel: "Nederlands" },
  { code: "el", nativeLabel: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC" },
  { code: "lv", nativeLabel: "Latvie\u0161u" },
  { code: "ar", nativeLabel: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" },
  { code: "hu", nativeLabel: "Magyar" },
  { code: "lt", nativeLabel: "Lietuvi\u0173" },
  { code: "ro", nativeLabel: "Rom\xE2n\u0103" },
  { code: "no", nativeLabel: "Norsk" }
];
function wireLanguagePicker(opts) {
  const btnId = opts.btnId ?? "langPickerBtn";
  const menuId = opts.menuId ?? "langPickerMenu";
  const btn = document.getElementById(btnId);
  const menu = document.getElementById(menuId);
  if (!(btn instanceof HTMLButtonElement) || !(menu instanceof HTMLElement)) {
    return;
  }
  const renderMenu = () => {
    const current = opts.getLocale();
    menu.replaceChildren();
    for (const { code, nativeLabel } of APP_LOCALES) {
      const li2 = document.createElement("li");
      li2.setAttribute("role", "option");
      li2.dataset.locale = code;
      li2.textContent = nativeLabel;
      li2.classList.toggle("is-active", code === current);
      li2.setAttribute("aria-selected", code === current ? "true" : "false");
      menu.appendChild(li2);
    }
  };
  const closeMenu = () => {
    menu.hidden = true;
    btn.setAttribute("aria-expanded", "false");
  };
  const openMenu = () => {
    renderMenu();
    menu.hidden = false;
    btn.setAttribute("aria-expanded", "true");
  };
  btn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (menu.hidden) openMenu();
    else closeMenu();
  });
  menu.addEventListener("click", (ev) => {
    const li2 = ev.target?.closest("li[data-locale]");
    if (!(li2 instanceof HTMLElement)) return;
    const code = li2.dataset.locale;
    if (!code) return;
    void Promise.resolve(opts.setLocale(code)).then(() => {
      closeMenu();
    });
  });
  document.addEventListener("click", (ev) => {
    if (menu.hidden) return;
    const target = ev.target;
    if (btn.contains(target) || menu.contains(target)) return;
    closeMenu();
  });
  renderMenu();
}

// ../i18n/conference.ts
var en2 = {
  dialogTitle: "Conferencing",
  close: "Close",
  closeAria: "Close",
  createSection: "Create a conference",
  conferenceTitle: "Conference title",
  selectConferenceTitle: "Select a conference title",
  otherTitle: "Other\u2026",
  customTitle: "Custom title",
  customTitlePlaceholder: "Enter conference title",
  users: "Users",
  loadingUsers: "Loading users\u2026",
  noUsers: "No users available",
  createConference: "Create conference",
  creating: "Creating\u2026",
  joinSection: "Join a conference",
  activeConferences: "Active conferences",
  noConferences: "No conferences available",
  selectConference: "Select a conference",
  untitled: "Untitled",
  joinConference: "Join conference",
  joining: "Joining\u2026",
  manageSection: "Manage conference",
  titleLabel: "Title:",
  na: "N/A",
  participants: "Participants",
  noPlaces: "No places",
  leaveConference: "Leave conference",
  endConference: "End conference",
  ending: "Ending\u2026",
  leaving: "Leaving\u2026",
  conferenceEnded: "Conference ended.",
  leftConference: "Left conference.",
  connectHubFirst: "Connect to the Slicer hub first.",
  topicRequiredHost: "Hub topic is required to host a conference.",
  topicRequiredJoin: "Hub topic is required to join a conference.",
  titleRequired: "Conference title is required.",
  selectAttendee: "Select at least one attendee topic.",
  selectConferenceToJoin: "Select a conference to join.",
  failedCreate: "Failed to create conference.",
  failedJoin: "Failed to join conference.",
  failedUpdate: "Failed to update conference.",
  inviteTitle: "Conference invitation",
  joinAndFollow: "Join and follow",
  joinNoFollow: "Join but do not follow",
  doNotJoin: "Do not join",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 join and follow {{host}}?",
  inviteLeadNoTitle: "Join conference and follow {{host}}?",
  joinAndFollowHost: "Join and follow {{host}}",
  takeoverTitle: "Take over?",
  takeoverBody: "The host and all participants will be notified that you are taking over. You will lead scene updates for this conference.",
  cancel: "Cancel",
  takeOver: "Take over",
  conferencing: "Conferencing",
  subscribeHubFirst: "Subscribe to the hub first",
  stopFollowing: "Stop following",
  resumeFollowing: "Resume following"
};
var de2 = {
  dialogTitle: "Konferenz",
  close: "Schlie\xDFen",
  closeAria: "Schlie\xDFen",
  createSection: "Konferenz erstellen",
  conferenceTitle: "Konferenztitel",
  selectConferenceTitle: "Titel ausw\xE4hlen",
  otherTitle: "Andere\u2026",
  customTitle: "Benutzerdefinierter Titel",
  customTitlePlaceholder: "Konferenztitel eingeben",
  users: "Benutzer",
  loadingUsers: "Benutzer werden geladen\u2026",
  noUsers: "Keine Benutzer verf\xFCgbar",
  createConference: "Konferenz erstellen",
  creating: "Wird erstellt\u2026",
  joinSection: "An einer Konferenz teilnehmen",
  activeConferences: "Aktive Konferenzen",
  noConferences: "Keine Konferenzen verf\xFCgbar",
  selectConference: "Konferenz ausw\xE4hlen",
  untitled: "Ohne Titel",
  joinConference: "Konferenz beitreten",
  joining: "Beitritt\u2026",
  manageSection: "Konferenz verwalten",
  titleLabel: "Titel:",
  na: "k. A.",
  participants: "Teilnehmer",
  noPlaces: "Keine Orte",
  leaveConference: "Konferenz verlassen",
  endConference: "Konferenz beenden",
  ending: "Wird beendet\u2026",
  leaving: "Verlassen\u2026",
  conferenceEnded: "Konferenz beendet.",
  leftConference: "Konferenz verlassen.",
  connectHubFirst: "Stellen Sie zuerst eine Verbindung zum Hub-Hub her.",
  topicRequiredHost: "Ein Hub-Topic ist erforderlich, um eine Konferenz zu hosten.",
  topicRequiredJoin: "Ein Hub-Topic ist erforderlich, um einer Konferenz beizutreten.",
  titleRequired: "Konferenztitel ist erforderlich.",
  selectAttendee: "W\xE4hlen Sie mindestens einen Teilnehmer aus.",
  selectConferenceToJoin: "W\xE4hlen Sie eine Konferenz zum Beitreten aus.",
  failedCreate: "Konferenz konnte nicht erstellt werden.",
  failedJoin: "Beitritt zur Konferenz fehlgeschlagen.",
  failedUpdate: "Aktualisierung der Konferenz fehlgeschlagen.",
  inviteTitle: "Konferenzeinladung",
  joinAndFollow: "Beitreten und folgen",
  joinNoFollow: "Beitreten, aber nicht folgen",
  doNotJoin: "Nicht beitreten",
  hostFallback: "Host",
  inviteLeadWithTitle: "{{title}} \u2014 beitreten und {{host}} folgen?",
  inviteLeadNoTitle: "Konferenz beitreten und {{host}} folgen?",
  joinAndFollowHost: "Beitreten und {{host}} folgen",
  takeoverTitle: "\xDCbernehmen?",
  takeoverBody: "Der Host und alle Teilnehmer werden benachrichtigt, dass Sie die F\xFChrung \xFCbernehmen. Sie leiten dann die Szenenaktualisierungen f\xFCr diese Konferenz.",
  cancel: "Abbrechen",
  takeOver: "\xDCbernehmen",
  conferencing: "Konferenz",
  subscribeHubFirst: "Zuerst am Hub anmelden",
  stopFollowing: "Folgen beenden",
  resumeFollowing: "Folgen fortsetzen"
};
var fr2 = {
  dialogTitle: "Conf\xE9rence",
  close: "Fermer",
  closeAria: "Fermer",
  createSection: "Cr\xE9er une conf\xE9rence",
  conferenceTitle: "Titre de la conf\xE9rence",
  selectConferenceTitle: "S\xE9lectionner un titre",
  otherTitle: "Autre\u2026",
  customTitle: "Titre personnalis\xE9",
  customTitlePlaceholder: "Saisir le titre de la conf\xE9rence",
  users: "Utilisateurs",
  loadingUsers: "Chargement des utilisateurs\u2026",
  noUsers: "Aucun utilisateur disponible",
  createConference: "Cr\xE9er la conf\xE9rence",
  creating: "Cr\xE9ation\u2026",
  joinSection: "Rejoindre une conf\xE9rence",
  activeConferences: "Conf\xE9rences actives",
  noConferences: "Aucune conf\xE9rence disponible",
  selectConference: "S\xE9lectionner une conf\xE9rence",
  untitled: "Sans titre",
  joinConference: "Rejoindre la conf\xE9rence",
  joining: "Connexion\u2026",
  manageSection: "G\xE9rer la conf\xE9rence",
  titleLabel: "Titre :",
  na: "N/D",
  participants: "Participants",
  noPlaces: "Aucun lieu",
  leaveConference: "Quitter la conf\xE9rence",
  endConference: "Terminer la conf\xE9rence",
  ending: "Fin\u2026",
  leaving: "D\xE9part\u2026",
  conferenceEnded: "Conf\xE9rence termin\xE9e.",
  leftConference: "Vous avez quitt\xE9 la conf\xE9rence.",
  connectHubFirst: "Connectez-vous d\u2019abord au hub Hub.",
  topicRequiredHost: "Un topic Hub est requis pour animer une conf\xE9rence.",
  topicRequiredJoin: "Un topic Hub est requis pour rejoindre une conf\xE9rence.",
  titleRequired: "Le titre de la conf\xE9rence est requis.",
  selectAttendee: "S\xE9lectionnez au moins un participant.",
  selectConferenceToJoin: "S\xE9lectionnez une conf\xE9rence \xE0 rejoindre.",
  failedCreate: "\xC9chec de la cr\xE9ation de la conf\xE9rence.",
  failedJoin: "\xC9chec de la connexion \xE0 la conf\xE9rence.",
  failedUpdate: "\xC9chec de la mise \xE0 jour de la conf\xE9rence.",
  inviteTitle: "Invitation \xE0 la conf\xE9rence",
  joinAndFollow: "Rejoindre et suivre",
  joinNoFollow: "Rejoindre sans suivre",
  doNotJoin: "Ne pas rejoindre",
  hostFallback: "h\xF4te",
  inviteLeadWithTitle: "{{title}} \u2014 rejoindre et suivre {{host}} ?",
  inviteLeadNoTitle: "Rejoindre la conf\xE9rence et suivre {{host}} ?",
  joinAndFollowHost: "Rejoindre et suivre {{host}}",
  takeoverTitle: "Prendre la main ?",
  takeoverBody: "L\u2019h\xF4te et tous les participants seront inform\xE9s que vous prenez la main. Vous dirigerez les mises \xE0 jour de sc\xE8ne pour cette conf\xE9rence.",
  cancel: "Annuler",
  takeOver: "Prendre la main",
  conferencing: "Conf\xE9rence",
  subscribeHubFirst: "Abonnez-vous d\u2019abord au hub",
  stopFollowing: "Arr\xEAter de suivre",
  resumeFollowing: "Reprendre le suivi"
};
var es = {
  dialogTitle: "Conferencia",
  close: "Cerrar",
  closeAria: "Cerrar",
  createSection: "Crear una conferencia",
  conferenceTitle: "T\xEDtulo de la conferencia",
  selectConferenceTitle: "Seleccionar un t\xEDtulo",
  otherTitle: "Otro\u2026",
  customTitle: "T\xEDtulo personalizado",
  customTitlePlaceholder: "Introducir el t\xEDtulo de la conferencia",
  users: "Usuarios",
  loadingUsers: "Cargando usuarios\u2026",
  noUsers: "No hay usuarios disponibles",
  createConference: "Crear conferencia",
  creating: "Creando\u2026",
  joinSection: "Unirse a una conferencia",
  activeConferences: "Conferencias activas",
  noConferences: "No hay conferencias disponibles",
  selectConference: "Seleccionar una conferencia",
  untitled: "Sin t\xEDtulo",
  joinConference: "Unirse a la conferencia",
  joining: "Uni\xE9ndose\u2026",
  manageSection: "Gestionar conferencia",
  titleLabel: "T\xEDtulo:",
  na: "N/D",
  participants: "Participantes",
  noPlaces: "Sin lugares",
  leaveConference: "Abandonar la conferencia",
  endConference: "Terminar la conferencia",
  ending: "Terminando\u2026",
  leaving: "Saliendo\u2026",
  conferenceEnded: "Conferencia terminada.",
  leftConference: "Has abandonado la conferencia.",
  connectHubFirst: "Con\xE9ctate primero al hub Hub.",
  topicRequiredHost: "Se requiere un topic Hub para organizar una conferencia.",
  topicRequiredJoin: "Se requiere un topic Hub para unirse a una conferencia.",
  titleRequired: "El t\xEDtulo de la conferencia es obligatorio.",
  selectAttendee: "Selecciona al menos un participante.",
  selectConferenceToJoin: "Selecciona una conferencia a la que unirte.",
  failedCreate: "Error al crear la conferencia.",
  failedJoin: "Error al unirse a la conferencia.",
  failedUpdate: "Error al actualizar la conferencia.",
  inviteTitle: "Invitaci\xF3n a la conferencia",
  joinAndFollow: "Unirse y seguir",
  joinNoFollow: "Unirse sin seguir",
  doNotJoin: "No unirse",
  hostFallback: "anfitri\xF3n",
  inviteLeadWithTitle: "{{title}} \u2014 \xBFunirse y seguir a {{host}}?",
  inviteLeadNoTitle: "\xBFUnirse a la conferencia y seguir a {{host}}?",
  joinAndFollowHost: "Unirse y seguir a {{host}}",
  takeoverTitle: "\xBFTomar el control?",
  takeoverBody: "Se notificar\xE1 al anfitri\xF3n y a todos los participantes de que tomas el control. Dirigir\xE1s las actualizaciones de escena de esta conferencia.",
  cancel: "Cancelar",
  takeOver: "Tomar el control",
  conferencing: "Conferencia",
  subscribeHubFirst: "Suscr\xEDbete primero al hub",
  stopFollowing: "Dejar de seguir",
  resumeFollowing: "Reanudar el seguimiento"
};
var ca = {
  dialogTitle: "Confer\xE8ncia",
  close: "Tancar",
  closeAria: "Tancar",
  createSection: "Crear una confer\xE8ncia",
  conferenceTitle: "T\xEDtol de la confer\xE8ncia",
  selectConferenceTitle: "Seleccionar un t\xEDtol",
  otherTitle: "Altre\u2026",
  customTitle: "T\xEDtol personalitzat",
  customTitlePlaceholder: "Introdu\xEFu el t\xEDtol de la confer\xE8ncia",
  users: "Usuaris",
  loadingUsers: "S\u2019estan carregant els usuaris\u2026",
  noUsers: "No hi ha usuaris disponibles",
  createConference: "Crear la confer\xE8ncia",
  creating: "S\u2019est\xE0 creant\u2026",
  joinSection: "Unir-se a una confer\xE8ncia",
  activeConferences: "Confer\xE8ncies actives",
  noConferences: "No hi ha confer\xE8ncies disponibles",
  selectConference: "Seleccionar una confer\xE8ncia",
  untitled: "Sense t\xEDtol",
  joinConference: "Unir-se a la confer\xE8ncia",
  joining: "S\u2019est\xE0 unint\u2026",
  manageSection: "Gestionar la confer\xE8ncia",
  titleLabel: "T\xEDtol:",
  na: "N/D",
  participants: "Participants",
  noPlaces: "Sense llocs",
  leaveConference: "Sortir de la confer\xE8ncia",
  endConference: "Acabar la confer\xE8ncia",
  ending: "S\u2019est\xE0 acabant\u2026",
  leaving: "S\u2019est\xE0 sortint\u2026",
  conferenceEnded: "Confer\xE8ncia acabada.",
  leftConference: "Heu sortit de la confer\xE8ncia.",
  connectHubFirst: "Connecteu-vos primer al hub Hub.",
  topicRequiredHost: "Cal un topic Hub per organitzar una confer\xE8ncia.",
  topicRequiredJoin: "Cal un topic Hub per unir-se a una confer\xE8ncia.",
  titleRequired: "El t\xEDtol de la confer\xE8ncia \xE9s obligatori.",
  selectAttendee: "Seleccioneu almenys un participant.",
  selectConferenceToJoin: "Seleccioneu una confer\xE8ncia a la qual unir-vos.",
  failedCreate: "No s\u2019ha pogut crear la confer\xE8ncia.",
  failedJoin: "No s\u2019ha pogut unir a la confer\xE8ncia.",
  failedUpdate: "No s\u2019ha pogut actualitzar la confer\xE8ncia.",
  inviteTitle: "Invitaci\xF3 a la confer\xE8ncia",
  joinAndFollow: "Unir-se i seguir",
  joinNoFollow: "Unir-se sense seguir",
  doNotJoin: "No unir-se",
  hostFallback: "amfitri\xF3",
  inviteLeadWithTitle: "{{title}} \u2014 unir-se i seguir {{host}}?",
  inviteLeadNoTitle: "Unir-se a la confer\xE8ncia i seguir {{host}}?",
  joinAndFollowHost: "Unir-se i seguir {{host}}",
  takeoverTitle: "Prendre el control?",
  takeoverBody: "Se notificar\xE0 a l\u2019amfitri\xF3 i a tots els participants que preneu el control. Direccioneu les actualitzacions d\u2019escena d\u2019aquesta confer\xE8ncia.",
  cancel: "Cancel\xB7lar",
  takeOver: "Prendre el control",
  conferencing: "Confer\xE8ncia",
  subscribeHubFirst: "Subscriviu-vos primer al hub",
  stopFollowing: "Deixar de seguir",
  resumeFollowing: "Reprendre el seguiment"
};
var it2 = {
  dialogTitle: "Conferenza",
  close: "Chiudi",
  closeAria: "Chiudi",
  createSection: "Crea una conferenza",
  conferenceTitle: "Titolo della conferenza",
  selectConferenceTitle: "Seleziona un titolo",
  otherTitle: "Altro\u2026",
  customTitle: "Titolo personalizzato",
  customTitlePlaceholder: "Inserisci il titolo della conferenza",
  users: "Utenti",
  loadingUsers: "Caricamento utenti\u2026",
  noUsers: "Nessun utente disponibile",
  createConference: "Crea conferenza",
  creating: "Creazione\u2026",
  joinSection: "Partecipa a una conferenza",
  activeConferences: "Conferenze attive",
  noConferences: "Nessuna conferenza disponibile",
  selectConference: "Seleziona una conferenza",
  untitled: "Senza titolo",
  joinConference: "Partecipa alla conferenza",
  joining: "Accesso\u2026",
  manageSection: "Gestisci conferenza",
  titleLabel: "Titolo:",
  na: "N/D",
  participants: "Partecipanti",
  noPlaces: "Nessun luogo",
  leaveConference: "Lascia la conferenza",
  endConference: "Termina la conferenza",
  ending: "Chiusura\u2026",
  leaving: "Uscita\u2026",
  conferenceEnded: "Conferenza terminata.",
  leftConference: "Hai lasciato la conferenza.",
  connectHubFirst: "Connettiti prima all\u2019hub Hub.",
  topicRequiredHost: "\xC8 richiesto un topic Hub per ospitare una conferenza.",
  topicRequiredJoin: "\xC8 richiesto un topic Hub per partecipare a una conferenza.",
  titleRequired: "Il titolo della conferenza \xE8 obbligatorio.",
  selectAttendee: "Seleziona almeno un partecipante.",
  selectConferenceToJoin: "Seleziona una conferenza a cui partecipare.",
  failedCreate: "Creazione della conferenza non riuscita.",
  failedJoin: "Partecipazione alla conferenza non riuscita.",
  failedUpdate: "Aggiornamento della conferenza non riuscito.",
  inviteTitle: "Invito alla conferenza",
  joinAndFollow: "Partecipa e segui",
  joinNoFollow: "Partecipa senza seguire",
  doNotJoin: "Non partecipare",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 partecipare e seguire {{host}}?",
  inviteLeadNoTitle: "Partecipare alla conferenza e seguire {{host}}?",
  joinAndFollowHost: "Partecipa e segui {{host}}",
  takeoverTitle: "Prendere il controllo?",
  takeoverBody: "L\u2019host e tutti i partecipanti saranno avvisati che stai prendendo il controllo. Dirigerai gli aggiornamenti di scena di questa conferenza.",
  cancel: "Annulla",
  takeOver: "Prendi il controllo",
  conferencing: "Conferenza",
  subscribeHubFirst: "Iscriviti prima all\u2019hub",
  stopFollowing: "Smetti di seguire",
  resumeFollowing: "Riprendi a seguire"
};
var pt2 = {
  dialogTitle: "Confer\xEAncia",
  close: "Fechar",
  closeAria: "Fechar",
  createSection: "Criar uma confer\xEAncia",
  conferenceTitle: "T\xEDtulo da confer\xEAncia",
  selectConferenceTitle: "Selecionar um t\xEDtulo",
  otherTitle: "Outro\u2026",
  customTitle: "T\xEDtulo personalizado",
  customTitlePlaceholder: "Introduza o t\xEDtulo da confer\xEAncia",
  users: "Utilizadores",
  loadingUsers: "A carregar utilizadores\u2026",
  noUsers: "Nenhum utilizador dispon\xEDvel",
  createConference: "Criar confer\xEAncia",
  creating: "A criar\u2026",
  joinSection: "Participar numa confer\xEAncia",
  activeConferences: "Confer\xEAncias ativas",
  noConferences: "Nenhuma confer\xEAncia dispon\xEDvel",
  selectConference: "Selecionar uma confer\xEAncia",
  untitled: "Sem t\xEDtulo",
  joinConference: "Participar na confer\xEAncia",
  joining: "A participar\u2026",
  manageSection: "Gerir confer\xEAncia",
  titleLabel: "T\xEDtulo:",
  na: "N/D",
  participants: "Participantes",
  noPlaces: "Sem locais",
  leaveConference: "Sair da confer\xEAncia",
  endConference: "Terminar a confer\xEAncia",
  ending: "A terminar\u2026",
  leaving: "A sair\u2026",
  conferenceEnded: "Confer\xEAncia terminada.",
  leftConference: "Saiu da confer\xEAncia.",
  connectHubFirst: "Ligue-se primeiro ao hub Hub.",
  topicRequiredHost: "\xC9 necess\xE1rio um topic Hub para organizar uma confer\xEAncia.",
  topicRequiredJoin: "\xC9 necess\xE1rio um topic Hub para participar numa confer\xEAncia.",
  titleRequired: "O t\xEDtulo da confer\xEAncia \xE9 obrigat\xF3rio.",
  selectAttendee: "Selecione pelo menos um participante.",
  selectConferenceToJoin: "Selecione uma confer\xEAncia a que participar.",
  failedCreate: "Falha ao criar a confer\xEAncia.",
  failedJoin: "Falha ao participar na confer\xEAncia.",
  failedUpdate: "Falha ao atualizar a confer\xEAncia.",
  inviteTitle: "Convite para a confer\xEAncia",
  joinAndFollow: "Participar e seguir",
  joinNoFollow: "Participar sem seguir",
  doNotJoin: "N\xE3o participar",
  hostFallback: "anfitri\xE3o",
  inviteLeadWithTitle: "{{title}} \u2014 participar e seguir {{host}}?",
  inviteLeadNoTitle: "Participar na confer\xEAncia e seguir {{host}}?",
  joinAndFollowHost: "Participar e seguir {{host}}",
  takeoverTitle: "Assumir o controlo?",
  takeoverBody: "O anfitri\xE3o e todos os participantes ser\xE3o notificados de que est\xE1 a assumir o controlo. Passar\xE1 a liderar as atualiza\xE7\xF5es de cena desta confer\xEAncia.",
  cancel: "Cancelar",
  takeOver: "Assumir o controlo",
  conferencing: "Confer\xEAncia",
  subscribeHubFirst: "Subscreva primeiro o hub",
  stopFollowing: "Parar de seguir",
  resumeFollowing: "Retomar o seguimento"
};
var ko = {
  dialogTitle: "\uD654\uC0C1\uD68C\uC758",
  close: "\uB2EB\uAE30",
  closeAria: "\uB2EB\uAE30",
  createSection: "\uD68C\uC758 \uB9CC\uB4E4\uAE30",
  conferenceTitle: "\uD68C\uC758 \uC81C\uBAA9",
  selectConferenceTitle: "\uC81C\uBAA9 \uC120\uD0DD",
  otherTitle: "\uAE30\uD0C0\u2026",
  customTitle: "\uC0AC\uC6A9\uC790 \uC9C0\uC815 \uC81C\uBAA9",
  customTitlePlaceholder: "\uD68C\uC758 \uC81C\uBAA9 \uC785\uB825",
  users: "\uC0AC\uC6A9\uC790",
  loadingUsers: "\uC0AC\uC6A9\uC790 \uBD88\uB7EC\uC624\uB294 \uC911\u2026",
  noUsers: "\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uC0AC\uC6A9\uC790 \uC5C6\uC74C",
  createConference: "\uD68C\uC758 \uB9CC\uB4E4\uAE30",
  creating: "\uB9CC\uB4DC\uB294 \uC911\u2026",
  joinSection: "\uD68C\uC758 \uCC38\uAC00",
  activeConferences: "\uC9C4\uD589 \uC911\uC778 \uD68C\uC758",
  noConferences: "\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uD68C\uC758 \uC5C6\uC74C",
  selectConference: "\uD68C\uC758 \uC120\uD0DD",
  untitled: "\uC81C\uBAA9 \uC5C6\uC74C",
  joinConference: "\uD68C\uC758 \uCC38\uAC00",
  joining: "\uCC38\uAC00 \uC911\u2026",
  manageSection: "\uD68C\uC758 \uAD00\uB9AC",
  titleLabel: "\uC81C\uBAA9:",
  na: "\uD574\uB2F9 \uC5C6\uC74C",
  participants: "\uCC38\uAC00\uC790",
  noPlaces: "\uC7A5\uC18C \uC5C6\uC74C",
  leaveConference: "\uD68C\uC758 \uB098\uAC00\uAE30",
  endConference: "\uD68C\uC758 \uC885\uB8CC",
  ending: "\uC885\uB8CC \uC911\u2026",
  leaving: "\uB098\uAC00\uB294 \uC911\u2026",
  conferenceEnded: "\uD68C\uC758\uAC00 \uC885\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  leftConference: "\uD68C\uC758\uC5D0\uC11C \uB098\uAC14\uC2B5\uB2C8\uB2E4.",
  connectHubFirst: "\uBA3C\uC800 Hub \uD5C8\uBE0C\uC5D0 \uC5F0\uACB0\uD558\uC138\uC694.",
  topicRequiredHost: "\uD68C\uC758\uB97C \uC8FC\uCD5C\uD558\uB824\uBA74 Hub \uD1A0\uD53D\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  topicRequiredJoin: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uB824\uBA74 Hub \uD1A0\uD53D\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  titleRequired: "\uD68C\uC758 \uC81C\uBAA9\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  selectAttendee: "\uCC38\uAC00\uC790\uB97C \uD55C \uBA85 \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694.",
  selectConferenceToJoin: "\uCC38\uAC00\uD560 \uD68C\uC758\uB97C \uC120\uD0DD\uD558\uC138\uC694.",
  failedCreate: "\uD68C\uC758\uB97C \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  failedJoin: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  failedUpdate: "\uD68C\uC758\uB97C \uC5C5\uB370\uC774\uD2B8\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  inviteTitle: "\uD68C\uC758 \uCD08\uB300",
  joinAndFollow: "\uCC38\uAC00\uD558\uACE0 \uB530\uB77C\uAC00\uAE30",
  joinNoFollow: "\uCC38\uAC00\uD558\uB418 \uB530\uB77C\uAC00\uC9C0 \uC54A\uAE30",
  doNotJoin: "\uCC38\uAC00\uD558\uC9C0 \uC54A\uAE30",
  hostFallback: "\uD638\uC2A4\uD2B8",
  inviteLeadWithTitle: "{{title}} \u2014 \uCC38\uAC00\uD558\uACE0 {{host}}\uB97C \uB530\uB77C\uAC08\uAE4C\uC694?",
  inviteLeadNoTitle: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uACE0 {{host}}\uB97C \uB530\uB77C\uAC08\uAE4C\uC694?",
  joinAndFollowHost: "{{host}}\uB97C \uB530\uB77C\uAC00\uBA70 \uCC38\uAC00",
  takeoverTitle: "\uC8FC\uB3C4\uAD8C\uC744 \uAC00\uC838\uC62C\uAE4C\uC694?",
  takeoverBody: "\uD638\uC2A4\uD2B8\uC640 \uBAA8\uB4E0 \uCC38\uAC00\uC790\uC5D0\uAC8C \uC8FC\uB3C4\uAD8C\uC744 \uAC00\uC838\uAC04\uB2E4\uB294 \uC54C\uB9BC\uC774 \uAC11\uB2C8\uB2E4. \uC774 \uD68C\uC758\uC758 \uC7A5\uBA74 \uC5C5\uB370\uC774\uD2B8\uB97C \uC774\uB04C\uAC8C \uB429\uB2C8\uB2E4.",
  cancel: "\uCDE8\uC18C",
  takeOver: "\uC8FC\uB3C4\uAD8C \uAC00\uC838\uC624\uAE30",
  conferencing: "\uD654\uC0C1\uD68C\uC758",
  subscribeHubFirst: "\uBA3C\uC800 \uD5C8\uBE0C\uC5D0 \uAD6C\uB3C5\uD558\uC138\uC694",
  stopFollowing: "\uB530\uB77C\uAC00\uAE30 \uC911\uC9C0",
  resumeFollowing: "\uB530\uB77C\uAC00\uAE30 \uC7AC\uAC1C"
};
var pl = {
  dialogTitle: "Konferencja",
  close: "Zamknij",
  closeAria: "Zamknij",
  createSection: "Utw\xF3rz konferencj\u0119",
  conferenceTitle: "Tytu\u0142 konferencji",
  selectConferenceTitle: "Wybierz tytu\u0142",
  otherTitle: "Inny\u2026",
  customTitle: "Tytu\u0142 niestandardowy",
  customTitlePlaceholder: "Wpisz tytu\u0142 konferencji",
  users: "U\u017Cytkownicy",
  loadingUsers: "\u0141adowanie u\u017Cytkownik\xF3w\u2026",
  noUsers: "Brak dost\u0119pnych u\u017Cytkownik\xF3w",
  createConference: "Utw\xF3rz konferencj\u0119",
  creating: "Tworzenie\u2026",
  joinSection: "Do\u0142\u0105cz do konferencji",
  activeConferences: "Aktywne konferencje",
  noConferences: "Brak dost\u0119pnych konferencji",
  selectConference: "Wybierz konferencj\u0119",
  untitled: "Bez tytu\u0142u",
  joinConference: "Do\u0142\u0105cz do konferencji",
  joining: "Do\u0142\u0105czanie\u2026",
  manageSection: "Zarz\u0105dzaj konferencj\u0105",
  titleLabel: "Tytu\u0142:",
  na: "nd.",
  participants: "Uczestnicy",
  noPlaces: "Brak miejsc",
  leaveConference: "Opu\u015B\u0107 konferencj\u0119",
  endConference: "Zako\u0144cz konferencj\u0119",
  ending: "Ko\u0144czenie\u2026",
  leaving: "Opuszczanie\u2026",
  conferenceEnded: "Konferencja zako\u0144czona.",
  leftConference: "Opuszczono konferencj\u0119.",
  connectHubFirst: "Najpierw po\u0142\u0105cz si\u0119 z hubem Hub.",
  topicRequiredHost: "Do prowadzenia konferencji wymagany jest topic Hub.",
  topicRequiredJoin: "Do do\u0142\u0105czenia do konferencji wymagany jest topic Hub.",
  titleRequired: "Tytu\u0142 konferencji jest wymagany.",
  selectAttendee: "Wybierz co najmniej jednego uczestnika.",
  selectConferenceToJoin: "Wybierz konferencj\u0119, do kt\xF3rej chcesz do\u0142\u0105czy\u0107.",
  failedCreate: "Nie uda\u0142o si\u0119 utworzy\u0107 konferencji.",
  failedJoin: "Nie uda\u0142o si\u0119 do\u0142\u0105czy\u0107 do konferencji.",
  failedUpdate: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 konferencji.",
  inviteTitle: "Zaproszenie na konferencj\u0119",
  joinAndFollow: "Do\u0142\u0105cz i \u015Bled\u017A",
  joinNoFollow: "Do\u0142\u0105cz, ale nie \u015Bled\u017A",
  doNotJoin: "Nie do\u0142\u0105czaj",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 do\u0142\u0105czy\u0107 i \u015Bledzi\u0107 {{host}}?",
  inviteLeadNoTitle: "Do\u0142\u0105czy\u0107 do konferencji i \u015Bledzi\u0107 {{host}}?",
  joinAndFollowHost: "Do\u0142\u0105cz i \u015Bled\u017A {{host}}",
  takeoverTitle: "Przej\u0105\u0107 prowadzenie?",
  takeoverBody: "Host i wszyscy uczestnicy zostan\u0105 powiadomieni, \u017Ce przejmujesz prowadzenie. B\u0119dziesz kierowa\u0107 aktualizacjami sceny tej konferencji.",
  cancel: "Anuluj",
  takeOver: "Przejmij",
  conferencing: "Konferencja",
  subscribeHubFirst: "Najpierw zasubskrybuj hub",
  stopFollowing: "Przesta\u0144 \u015Bledzi\u0107",
  resumeFollowing: "Wzn\xF3w \u015Bledzenie"
};
var uk = {
  dialogTitle: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F",
  close: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
  closeAria: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
  createSection: "\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  conferenceTitle: "\u041D\u0430\u0437\u0432\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  selectConferenceTitle: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043D\u0430\u0437\u0432\u0443",
  otherTitle: "\u0406\u043D\u0448\u0435\u2026",
  customTitle: "\u0412\u043B\u0430\u0441\u043D\u0430 \u043D\u0430\u0437\u0432\u0430",
  customTitlePlaceholder: "\u0412\u0432\u0435\u0434\u0456\u0442\u044C \u043D\u0430\u0437\u0432\u0443 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  users: "\u041A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456",
  loadingUsers: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0435\u043D\u043D\u044F \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456\u0432\u2026",
  noUsers: "\u041D\u0435\u043C\u0430\u0454 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0438\u0445 \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456\u0432",
  createConference: "\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  creating: "\u0421\u0442\u0432\u043E\u0440\u0435\u043D\u043D\u044F\u2026",
  joinSection: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  activeConferences: "\u0410\u043A\u0442\u0438\u0432\u043D\u0456 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  noConferences: "\u041D\u0435\u043C\u0430\u0454 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0438\u0445 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0439",
  selectConference: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  untitled: "\u0411\u0435\u0437 \u043D\u0430\u0437\u0432\u0438",
  joinConference: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  joining: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u043D\u043D\u044F\u2026",
  manageSection: "\u041A\u0435\u0440\u0443\u0432\u0430\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0454\u044E",
  titleLabel: "\u041D\u0430\u0437\u0432\u0430:",
  na: "\u043D/\u0434",
  participants: "\u0423\u0447\u0430\u0441\u043D\u0438\u043A\u0438",
  noPlaces: "\u041D\u0435\u043C\u0430\u0454 \u043C\u0456\u0441\u0446\u044C",
  leaveConference: "\u0412\u0438\u0439\u0442\u0438 \u0437 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  endConference: "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  ending: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u044F\u2026",
  leaving: "\u0412\u0438\u0445\u0456\u0434\u2026",
  conferenceEnded: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E.",
  leftConference: "\u0412\u0438 \u0432\u0438\u0439\u0448\u043B\u0438 \u0437 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  connectHubFirst: "\u0421\u043F\u043E\u0447\u0430\u0442\u043A\u0443 \u043F\u0456\u0434\u043A\u043B\u044E\u0447\u0456\u0442\u044C\u0441\u044F \u0434\u043E Hub-\u0445\u0430\u0431\u0443.",
  topicRequiredHost: "\u0414\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u043D\u044F \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457 \u043F\u043E\u0442\u0440\u0456\u0431\u0435\u043D Hub topic.",
  topicRequiredJoin: "\u0429\u043E\u0431 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457, \u043F\u043E\u0442\u0440\u0456\u0431\u0435\u043D Hub topic.",
  titleRequired: "\u041F\u043E\u0442\u0440\u0456\u0431\u043D\u0430 \u043D\u0430\u0437\u0432\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  selectAttendee: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043F\u0440\u0438\u043D\u0430\u0439\u043C\u043D\u0456 \u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0430\u0441\u043D\u0438\u043A\u0430.",
  selectConferenceToJoin: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E, \u0434\u043E \u044F\u043A\u043E\u0457 \u0445\u043E\u0447\u0435\u0442\u0435 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F.",
  failedCreate: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u0441\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.",
  failedJoin: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  failedUpdate: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u043E\u043D\u043E\u0432\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.",
  inviteTitle: "\u0417\u0430\u043F\u0440\u043E\u0448\u0435\u043D\u043D\u044F \u043D\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  joinAndFollow: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438",
  joinNoFollow: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F, \u0430\u043B\u0435 \u043D\u0435 \u0441\u0442\u0435\u0436\u0438\u0442\u0438",
  doNotJoin: "\u041D\u0435 \u043F\u0440\u0438\u0454\u0434\u043D\u0443\u0432\u0430\u0442\u0438\u0441\u044F",
  hostFallback: "\u0432\u0435\u0434\u0443\u0447\u0438\u0439",
  inviteLeadWithTitle: "{{title}} \u2014 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}?",
  inviteLeadNoTitle: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457 \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}?",
  joinAndFollowHost: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}",
  takeoverTitle: "\u041F\u0435\u0440\u0435\u0445\u043E\u043F\u0438\u0442\u0438 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F?",
  takeoverBody: "\u0412\u0435\u0434\u0443\u0447\u043E\u0433\u043E \u0442\u0430 \u0432\u0441\u0456\u0445 \u0443\u0447\u0430\u0441\u043D\u0438\u043A\u0456\u0432 \u0431\u0443\u0434\u0435 \u043F\u043E\u0432\u0456\u0434\u043E\u043C\u043B\u0435\u043D\u043E, \u0449\u043E \u0432\u0438 \u043F\u0435\u0440\u0435\u0445\u043E\u043F\u043B\u044E\u0454\u0442\u0435 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F. \u0412\u0438 \u043A\u0435\u0440\u0443\u0432\u0430\u0442\u0438\u043C\u0435\u0442\u0435 \u043E\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F\u043C\u0438 \u0441\u0446\u0435\u043D\u0438 \u0446\u0456\u0454\u0457 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  cancel: "\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438",
  takeOver: "\u041F\u0435\u0440\u0435\u0445\u043E\u043F\u0438\u0442\u0438",
  conferencing: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F",
  subscribeHubFirst: "\u0421\u043F\u043E\u0447\u0430\u0442\u043A\u0443 \u043F\u0456\u0434\u043F\u0438\u0448\u0456\u0442\u044C\u0441\u044F \u043D\u0430 \u0445\u0430\u0431",
  stopFollowing: "\u041F\u0440\u0438\u043F\u0438\u043D\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F",
  resumeFollowing: "\u0412\u0456\u0434\u043D\u043E\u0432\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F"
};
var cs = {
  dialogTitle: "Konference",
  close: "Zav\u0159\xEDt",
  closeAria: "Zav\u0159\xEDt",
  createSection: "Vytvo\u0159it konferenci",
  conferenceTitle: "N\xE1zev konference",
  selectConferenceTitle: "Vyberte n\xE1zev",
  otherTitle: "Jin\xFD\u2026",
  customTitle: "Vlastn\xED n\xE1zev",
  customTitlePlaceholder: "Zadejte n\xE1zev konference",
  users: "U\u017Eivatel\xE9",
  loadingUsers: "Na\u010D\xEDt\xE1n\xED u\u017Eivatel\u016F\u2026",
  noUsers: "\u017D\xE1dn\xED dostupn\xED u\u017Eivatel\xE9",
  createConference: "Vytvo\u0159it konferenci",
  creating: "Vytv\xE1\u0159en\xED\u2026",
  joinSection: "P\u0159ipojit se ke konferenci",
  activeConferences: "Aktivn\xED konference",
  noConferences: "\u017D\xE1dn\xE9 dostupn\xE9 konference",
  selectConference: "Vyberte konferenci",
  untitled: "Bez n\xE1zvu",
  joinConference: "P\u0159ipojit se ke konferenci",
  joining: "P\u0159ipojov\xE1n\xED\u2026",
  manageSection: "Spravovat konferenci",
  titleLabel: "N\xE1zev:",
  na: "n/a",
  participants: "\xDA\u010Dastn\xEDci",
  noPlaces: "\u017D\xE1dn\xE1 m\xEDsta",
  leaveConference: "Opustit konferenci",
  endConference: "Ukon\u010Dit konferenci",
  ending: "Ukon\u010Dov\xE1n\xED\u2026",
  leaving: "Opou\u0161t\u011Bn\xED\u2026",
  conferenceEnded: "Konference ukon\u010Dena.",
  leftConference: "Opustili jste konferenci.",
  connectHubFirst: "Nejprve se p\u0159ipojte k Hub hubu.",
  topicRequiredHost: "Pro po\u0159\xE1d\xE1n\xED konference je vy\u017Eadov\xE1n Hub topic.",
  topicRequiredJoin: "Pro p\u0159ipojen\xED ke konferenci je vy\u017Eadov\xE1n Hub topic.",
  titleRequired: "N\xE1zev konference je povinn\xFD.",
  selectAttendee: "Vyberte alespo\u0148 jednoho \xFA\u010Dastn\xEDka.",
  selectConferenceToJoin: "Vyberte konferenci, ke kter\xE9 se chcete p\u0159ipojit.",
  failedCreate: "Vytvo\u0159en\xED konference se nezda\u0159ilo.",
  failedJoin: "P\u0159ipojen\xED ke konferenci se nezda\u0159ilo.",
  failedUpdate: "Aktualizace konference se nezda\u0159ila.",
  inviteTitle: "Pozv\xE1nka na konferenci",
  joinAndFollow: "P\u0159ipojit se a sledovat",
  joinNoFollow: "P\u0159ipojit se, ale nesledovat",
  doNotJoin: "Nep\u0159ipojovat se",
  hostFallback: "hostitel",
  inviteLeadWithTitle: "{{title}} \u2014 p\u0159ipojit se a sledovat {{host}}?",
  inviteLeadNoTitle: "P\u0159ipojit se ke konferenci a sledovat {{host}}?",
  joinAndFollowHost: "P\u0159ipojit se a sledovat {{host}}",
  takeoverTitle: "P\u0159evz\xEDt veden\xED?",
  takeoverBody: "Hostitel a v\u0161ichni \xFA\u010Dastn\xEDci budou upozorn\u011Bni, \u017Ee p\u0159eb\xEDr\xE1te veden\xED. Budete \u0159\xEDdit aktualizace sc\xE9ny t\xE9to konference.",
  cancel: "Zru\u0161it",
  takeOver: "P\u0159evz\xEDt",
  conferencing: "Konference",
  subscribeHubFirst: "Nejprve se p\u0159ihlaste k hubu",
  stopFollowing: "P\u0159estat sledovat",
  resumeFollowing: "Obnovit sledov\xE1n\xED"
};
var nl = {
  dialogTitle: "Conferentie",
  close: "Sluiten",
  closeAria: "Sluiten",
  createSection: "Een conferentie maken",
  conferenceTitle: "Conferentietitel",
  selectConferenceTitle: "Selecteer een titel",
  otherTitle: "Anders\u2026",
  customTitle: "Aangepaste titel",
  customTitlePlaceholder: "Voer de conferentietitel in",
  users: "Gebruikers",
  loadingUsers: "Gebruikers laden\u2026",
  noUsers: "Geen gebruikers beschikbaar",
  createConference: "Conferentie maken",
  creating: "Bezig met maken\u2026",
  joinSection: "Deelnemen aan een conferentie",
  activeConferences: "Actieve conferenties",
  noConferences: "Geen conferenties beschikbaar",
  selectConference: "Selecteer een conferentie",
  untitled: "Zonder titel",
  joinConference: "Deelnemen aan conferentie",
  joining: "Bezig met deelnemen\u2026",
  manageSection: "Conferentie beheren",
  titleLabel: "Titel:",
  na: "n.v.t.",
  participants: "Deelnemers",
  noPlaces: "Geen plaatsen",
  leaveConference: "Conferentie verlaten",
  endConference: "Conferentie be\xEBindigen",
  ending: "Be\xEBindigen\u2026",
  leaving: "Verlaten\u2026",
  conferenceEnded: "Conferentie be\xEBindigd.",
  leftConference: "U hebt de conferentie verlaten.",
  connectHubFirst: "Maak eerst verbinding met de Hub-hub.",
  topicRequiredHost: "Een Hub-topic is vereist om een conferentie te hosten.",
  topicRequiredJoin: "Een Hub-topic is vereist om aan een conferentie deel te nemen.",
  titleRequired: "Conferentietitel is verplicht.",
  selectAttendee: "Selecteer minstens \xE9\xE9n deelnemer.",
  selectConferenceToJoin: "Selecteer een conferentie om deel te nemen.",
  failedCreate: "Conferentie maken mislukt.",
  failedJoin: "Deelnemen aan conferentie mislukt.",
  failedUpdate: "Conferentie bijwerken mislukt.",
  inviteTitle: "Conferentie-uitnodiging",
  joinAndFollow: "Deelnemen en volgen",
  joinNoFollow: "Deelnemen maar niet volgen",
  doNotJoin: "Niet deelnemen",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 deelnemen en {{host}} volgen?",
  inviteLeadNoTitle: "Deelnemen aan de conferentie en {{host}} volgen?",
  joinAndFollowHost: "Deelnemen en {{host}} volgen",
  takeoverTitle: "Overname?",
  takeoverBody: "De host en alle deelnemers worden ge\xEFnformeerd dat u de leiding overneemt. U leidt dan de sc\xE8ne-updates voor deze conferentie.",
  cancel: "Annuleren",
  takeOver: "Overnemen",
  conferencing: "Conferentie",
  subscribeHubFirst: "Abonneer u eerst op de hub",
  stopFollowing: "Stoppen met volgen",
  resumeFollowing: "Volgen hervatten"
};
var el = {
  dialogTitle: "\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  close: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
  closeAria: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
  createSection: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  conferenceTitle: "\u03A4\u03AF\u03C4\u03BB\u03BF\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  selectConferenceTitle: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03C4\u03AF\u03C4\u03BB\u03BF",
  otherTitle: "\u0386\u03BB\u03BB\u03BF\u2026",
  customTitle: "\u03A0\u03C1\u03BF\u03C3\u03B1\u03C1\u03BC\u03BF\u03C3\u03BC\u03AD\u03BD\u03BF\u03C2 \u03C4\u03AF\u03C4\u03BB\u03BF\u03C2",
  customTitlePlaceholder: "\u0395\u03B9\u03C3\u03B1\u03B3\u03AC\u03B3\u03B5\u03C4\u03B5 \u03C4\u03BF\u03BD \u03C4\u03AF\u03C4\u03BB\u03BF \u03C4\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  users: "\u03A7\u03C1\u03AE\u03C3\u03C4\u03B5\u03C2",
  loadingUsers: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03C7\u03C1\u03B7\u03C3\u03C4\u03CE\u03BD\u2026",
  noUsers: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B4\u03B9\u03B1\u03B8\u03AD\u03C3\u03B9\u03BC\u03BF\u03B9 \u03C7\u03C1\u03AE\u03C3\u03C4\u03B5\u03C2",
  createConference: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  creating: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1\u2026",
  joinSection: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  activeConferences: "\u0395\u03BD\u03B5\u03C1\u03B3\u03AD\u03C2 \u03B4\u03B9\u03B1\u03C3\u03BA\u03AD\u03C8\u03B5\u03B9\u03C2",
  noConferences: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B4\u03B9\u03B1\u03B8\u03AD\u03C3\u03B9\u03BC\u03B5\u03C2 \u03B4\u03B9\u03B1\u03C3\u03BA\u03AD\u03C8\u03B5\u03B9\u03C2",
  selectConference: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  untitled: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03C4\u03AF\u03C4\u03BB\u03BF",
  joinConference: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  joining: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE\u2026",
  manageSection: "\u0394\u03B9\u03B1\u03C7\u03B5\u03AF\u03C1\u03B9\u03C3\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  titleLabel: "\u03A4\u03AF\u03C4\u03BB\u03BF\u03C2:",
  na: "\u0394/\u03A5",
  participants: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B5\u03C2",
  noPlaces: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03B8\u03AD\u03C3\u03B5\u03B9\u03C2",
  leaveConference: "\u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7 \u03B1\u03C0\u03CC \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  endConference: "\u03A4\u03B5\u03C1\u03BC\u03B1\u03C4\u03B9\u03C3\u03BC\u03CC\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  ending: "\u03A4\u03B5\u03C1\u03BC\u03B1\u03C4\u03B9\u03C3\u03BC\u03CC\u03C2\u2026",
  leaving: "\u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7\u2026",
  conferenceEnded: "\u0397 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03C4\u03B5\u03C1\u03BC\u03B1\u03C4\u03AF\u03C3\u03C4\u03B7\u03BA\u03B5.",
  leftConference: "\u0391\u03C0\u03BF\u03C7\u03C9\u03C1\u03AE\u03C3\u03B1\u03C4\u03B5 \u03B1\u03C0\u03CC \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  connectHubFirst: "\u03A3\u03C5\u03BD\u03B4\u03B5\u03B8\u03B5\u03AF\u03C4\u03B5 \u03C0\u03C1\u03CE\u03C4\u03B1 \u03C3\u03C4\u03BF Slicer hub.",
  topicRequiredHost: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 Hub topic \u03B3\u03B9\u03B1 \u03C6\u03B9\u03BB\u03BF\u03BE\u03B5\u03BD\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  topicRequiredJoin: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 Hub topic \u03B3\u03B9\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  titleRequired: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 \u03C4\u03AF\u03C4\u03BB\u03BF\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  selectAttendee: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03C4\u03BF\u03C5\u03BB\u03AC\u03C7\u03B9\u03C3\u03C4\u03BF\u03BD \u03AD\u03BD\u03B1\u03BD \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B1.",
  selectConferenceToJoin: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03B3\u03B9\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE.",
  failedCreate: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03B4\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  failedJoin: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE\u03C2 \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  failedUpdate: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03B5\u03BD\u03B7\u03BC\u03AD\u03C1\u03C9\u03C3\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  inviteTitle: "\u03A0\u03C1\u03CC\u03C3\u03BA\u03BB\u03B7\u03C3\u03B7 \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  joinAndFollow: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7",
  joinNoFollow: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C7\u03C9\u03C1\u03AF\u03C2 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7",
  doNotJoin: "\u038C\u03C7\u03B9 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE",
  hostFallback: "\u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7\u03C2",
  inviteLeadWithTitle: "{{title}} \u2014 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}};",
  inviteLeadNoTitle: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}};",
  joinAndFollowHost: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}}",
  takeoverTitle: "\u0391\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7 \u03B5\u03BB\u03AD\u03B3\u03C7\u03BF\u03C5;",
  takeoverBody: "\u039F \u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7\u03C2 \u03BA\u03B1\u03B9 \u03CC\u03BB\u03BF\u03B9 \u03BF\u03B9 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B5\u03C2 \u03B8\u03B1 \u03B5\u03B9\u03B4\u03BF\u03C0\u03BF\u03B9\u03B7\u03B8\u03BF\u03CD\u03BD \u03CC\u03C4\u03B9 \u03B1\u03BD\u03B1\u03BB\u03B1\u03BC\u03B2\u03AC\u03BD\u03B5\u03C4\u03B5 \u03C4\u03BF\u03BD \u03AD\u03BB\u03B5\u03B3\u03C7\u03BF. \u0398\u03B1 \u03BF\u03B4\u03B7\u03B3\u03B5\u03AF\u03C4\u03B5 \u03C4\u03B9\u03C2 \u03B5\u03BD\u03B7\u03BC\u03B5\u03C1\u03CE\u03C3\u03B5\u03B9\u03C2 \u03C3\u03BA\u03B7\u03BD\u03AE\u03C2 \u03B1\u03C5\u03C4\u03AE\u03C2 \u03C4\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  cancel: "\u0391\u03BA\u03CD\u03C1\u03C9\u03C3\u03B7",
  takeOver: "\u0391\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7",
  conferencing: "\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  subscribeHubFirst: "\u0395\u03B3\u03B3\u03C1\u03B1\u03C6\u03B5\u03AF\u03C4\u03B5 \u03C0\u03C1\u03CE\u03C4\u03B1 \u03C3\u03C4\u03BF hub",
  stopFollowing: "\u0394\u03B9\u03B1\u03BA\u03BF\u03C0\u03AE \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7\u03C2",
  resumeFollowing: "\u0395\u03C0\u03B1\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7\u03C2"
};
var lv = {
  dialogTitle: "Konference",
  close: "Aizv\u0113rt",
  closeAria: "Aizv\u0113rt",
  createSection: "Izveidot konferenci",
  conferenceTitle: "Konferences nosaukums",
  selectConferenceTitle: "Atlas\u012Bt nosaukumu",
  otherTitle: "Cits\u2026",
  customTitle: "Piel\u0101gots nosaukums",
  customTitlePlaceholder: "Ievadiet konferences nosaukumu",
  users: "Lietot\u0101ji",
  loadingUsers: "Iel\u0101d\u0113 lietot\u0101jus\u2026",
  noUsers: "Nav pieejamu lietot\u0101ju",
  createConference: "Izveidot konferenci",
  creating: "Izveido\u2026",
  joinSection: "Pievienoties konferencei",
  activeConferences: "Akt\u012Bv\u0101s konferences",
  noConferences: "Nav pieejamu konferen\u010Du",
  selectConference: "Atlas\u012Bt konferenci",
  untitled: "Bez nosaukuma",
  joinConference: "Pievienoties konferencei",
  joining: "Pievienojas\u2026",
  manageSection: "P\u0101rvald\u012Bt konferenci",
  titleLabel: "Nosaukums:",
  na: "n/a",
  participants: "Dal\u012Bbnieki",
  noPlaces: "Nav vietu",
  leaveConference: "Atst\u0101t konferenci",
  endConference: "Beigt konferenci",
  ending: "Beidz\u2026",
  leaving: "Atst\u0101j\u2026",
  conferenceEnded: "Konference beigusies.",
  leftConference: "J\u016Bs atst\u0101j\u0101t konferenci.",
  connectHubFirst: "Vispirms piesl\u0113dzieties Slicer hub.",
  topicRequiredHost: "Lai r\u012Bkotu konferenci, nepiecie\u0161ams Hub topic.",
  topicRequiredJoin: "Lai pievienotos konferencei, nepiecie\u0161ams Hub topic.",
  titleRequired: "Nepiecie\u0161ams konferences nosaukums.",
  selectAttendee: "Atlasiet vismaz vienu dal\u012Bbnieku.",
  selectConferenceToJoin: "Atlasiet konferenci, kurai pievienoties.",
  failedCreate: "Neizdev\u0101s izveidot konferenci.",
  failedJoin: "Neizdev\u0101s pievienoties konferencei.",
  failedUpdate: "Neizdev\u0101s atjaunin\u0101t konferenci.",
  inviteTitle: "Uzaicin\u0101jums uz konferenci",
  joinAndFollow: "Pievienoties un sekot",
  joinNoFollow: "Pievienoties, bet nesekot",
  doNotJoin: "Nepievienoties",
  hostFallback: "vad\u012Bt\u0101js",
  inviteLeadWithTitle: "{{title}} \u2014 pievienoties un sekot {{host}}?",
  inviteLeadNoTitle: "Pievienoties konferencei un sekot {{host}}?",
  joinAndFollowHost: "Pievienoties un sekot {{host}}",
  takeoverTitle: "P\u0101r\u0146emt vad\u012Bbu?",
  takeoverBody: "Vad\u012Bt\u0101js un visi dal\u012Bbnieki tiks inform\u0113ti, ka j\u016Bs p\u0101r\u0146emat vad\u012Bbu. J\u016Bs vad\u012Bsiet \u0161\u012Bs konferences ainas atjaunin\u0101jumus.",
  cancel: "Atcelt",
  takeOver: "P\u0101r\u0146emt",
  conferencing: "Konference",
  subscribeHubFirst: "Vispirms abon\u0113jiet hub",
  stopFollowing: "P\u0101rtraukt seko\u0161anu",
  resumeFollowing: "Ats\u0101kt seko\u0161anu"
};
var hu = {
  dialogTitle: "Konferencia",
  close: "Bez\xE1r\xE1s",
  closeAria: "Bez\xE1r\xE1s",
  createSection: "Konferencia l\xE9trehoz\xE1sa",
  conferenceTitle: "Konferencia c\xEDme",
  selectConferenceTitle: "C\xEDm kiv\xE1laszt\xE1sa",
  otherTitle: "Egy\xE9b\u2026",
  customTitle: "Egy\xE9ni c\xEDm",
  customTitlePlaceholder: "Adja meg a konferencia c\xEDm\xE9t",
  users: "Felhaszn\xE1l\xF3k",
  loadingUsers: "Felhaszn\xE1l\xF3k bet\xF6lt\xE9se\u2026",
  noUsers: "Nincs el\xE9rhet\u0151 felhaszn\xE1l\xF3",
  createConference: "Konferencia l\xE9trehoz\xE1sa",
  creating: "L\xE9trehoz\xE1s\u2026",
  joinSection: "Csatlakoz\xE1s konferenci\xE1hoz",
  activeConferences: "Akt\xEDv konferenci\xE1k",
  noConferences: "Nincs el\xE9rhet\u0151 konferencia",
  selectConference: "Konferencia kiv\xE1laszt\xE1sa",
  untitled: "N\xE9vtelen",
  joinConference: "Csatlakoz\xE1s a konferenci\xE1hoz",
  joining: "Csatlakoz\xE1s\u2026",
  manageSection: "Konferencia kezel\xE9se",
  titleLabel: "C\xEDm:",
  na: "n/a",
  participants: "R\xE9sztvev\u0151k",
  noPlaces: "Nincs hely",
  leaveConference: "Kil\xE9p\xE9s a konferenci\xE1b\xF3l",
  endConference: "Konferencia befejez\xE9se",
  ending: "Befejez\xE9s\u2026",
  leaving: "Kil\xE9p\xE9s\u2026",
  conferenceEnded: "A konferencia v\xE9get \xE9rt.",
  leftConference: "Kil\xE9pett a konferenci\xE1b\xF3l.",
  connectHubFirst: "El\u0151sz\xF6r csatlakozzon a Hub hubhoz.",
  topicRequiredHost: "Konferencia ind\xEDt\xE1s\xE1hoz Hub topic sz\xFCks\xE9ges.",
  topicRequiredJoin: "Konferenci\xE1hoz csatlakoz\xE1shoz Hub topic sz\xFCks\xE9ges.",
  titleRequired: "A konferencia c\xEDme k\xF6telez\u0151.",
  selectAttendee: "V\xE1lasszon legal\xE1bb egy r\xE9sztvev\u0151t.",
  selectConferenceToJoin: "V\xE1lasszon konferenci\xE1t a csatlakoz\xE1shoz.",
  failedCreate: "Nem siker\xFClt l\xE9trehozni a konferenci\xE1t.",
  failedJoin: "Nem siker\xFClt csatlakozni a konferenci\xE1hoz.",
  failedUpdate: "Nem siker\xFClt friss\xEDteni a konferenci\xE1t.",
  inviteTitle: "Konferenciamegh\xEDv\xF3",
  joinAndFollow: "Csatlakoz\xE1s \xE9s k\xF6vet\xE9s",
  joinNoFollow: "Csatlakoz\xE1s k\xF6vet\xE9s n\xE9lk\xFCl",
  doNotJoin: "Nem csatlakozom",
  hostFallback: "h\xE1zigazda",
  inviteLeadWithTitle: "{{title}} \u2014 csatlakoz\xE1s \xE9s {{host}} k\xF6vet\xE9se?",
  inviteLeadNoTitle: "Csatlakoz\xE1s a konferenci\xE1hoz \xE9s {{host}} k\xF6vet\xE9se?",
  joinAndFollowHost: "Csatlakoz\xE1s \xE9s {{host}} k\xF6vet\xE9se",
  takeoverTitle: "\xC1tv\xE9tel?",
  takeoverBody: "A h\xE1zigazda \xE9s minden r\xE9sztvev\u0151 \xE9rtes\xEDt\xE9st kap, hogy \xD6n \xE1tveszi a vezet\xE9st. \xD6n ir\xE1ny\xEDtja majd a konferencia jelenetfriss\xEDt\xE9seit.",
  cancel: "M\xE9gse",
  takeOver: "\xC1tv\xE9tel",
  conferencing: "Konferencia",
  subscribeHubFirst: "El\u0151sz\xF6r iratkozzon fel a hubra",
  stopFollowing: "K\xF6vet\xE9s le\xE1ll\xEDt\xE1sa",
  resumeFollowing: "K\xF6vet\xE9s folytat\xE1sa"
};
var lt2 = {
  dialogTitle: "Konferencija",
  close: "U\u017Edaryti",
  closeAria: "U\u017Edaryti",
  createSection: "Sukurti konferencij\u0105",
  conferenceTitle: "Konferencijos pavadinimas",
  selectConferenceTitle: "Pasirinkite pavadinim\u0105",
  otherTitle: "Kita\u2026",
  customTitle: "Pasirinktinis pavadinimas",
  customTitlePlaceholder: "\u012Eveskite konferencijos pavadinim\u0105",
  users: "Naudotojai",
  loadingUsers: "\u012Ekeliami naudotojai\u2026",
  noUsers: "N\u0117ra galim\u0173 naudotoj\u0173",
  createConference: "Sukurti konferencij\u0105",
  creating: "Kuriama\u2026",
  joinSection: "Prisijungti prie konferencijos",
  activeConferences: "Aktyvios konferencijos",
  noConferences: "N\u0117ra galim\u0173 konferencij\u0173",
  selectConference: "Pasirinkite konferencij\u0105",
  untitled: "Be pavadinimo",
  joinConference: "Prisijungti prie konferencijos",
  joining: "Jungiamasi\u2026",
  manageSection: "Tvarkyti konferencij\u0105",
  titleLabel: "Pavadinimas:",
  na: "n/d",
  participants: "Dalyviai",
  noPlaces: "N\u0117ra viet\u0173",
  leaveConference: "I\u0161eiti i\u0161 konferencijos",
  endConference: "Baigti konferencij\u0105",
  ending: "Baigiama\u2026",
  leaving: "I\u0161einama\u2026",
  conferenceEnded: "Konferencija baigta.",
  leftConference: "I\u0161\u0117jote i\u0161 konferencijos.",
  connectHubFirst: "Pirmiausia prisijunkite prie Slicer hub.",
  topicRequiredHost: "Konferencijai vesti reikalingas Hub topic.",
  topicRequiredJoin: "Norint prisijungti prie konferencijos, reikalingas Hub topic.",
  titleRequired: "Reikalingas konferencijos pavadinimas.",
  selectAttendee: "Pasirinkite bent vien\u0105 dalyv\u012F.",
  selectConferenceToJoin: "Pasirinkite konferencij\u0105, prie kurios jungtis.",
  failedCreate: "Nepavyko sukurti konferencijos.",
  failedJoin: "Nepavyko prisijungti prie konferencijos.",
  failedUpdate: "Nepavyko atnaujinti konferencijos.",
  inviteTitle: "Kvietimas \u012F konferencij\u0105",
  joinAndFollow: "Prisijungti ir sekti",
  joinNoFollow: "Prisijungti, bet nesekti",
  doNotJoin: "Neprisijungti",
  hostFallback: "ved\u0117jas",
  inviteLeadWithTitle: "{{title}} \u2014 prisijungti ir sekti {{host}}?",
  inviteLeadNoTitle: "Prisijungti prie konferencijos ir sekti {{host}}?",
  joinAndFollowHost: "Prisijungti ir sekti {{host}}",
  takeoverTitle: "Perimti valdym\u0105?",
  takeoverBody: "Ved\u0117jas ir visi dalyviai bus informuoti, kad perimate valdym\u0105. V\u0117site \u0161ios konferencijos scenos atnaujinimus.",
  cancel: "At\u0161aukti",
  takeOver: "Perimti",
  conferencing: "Konferencija",
  subscribeHubFirst: "Pirmiausia u\u017Esiprenumeruokite hub",
  stopFollowing: "Nustoti sekti",
  resumeFollowing: "T\u0119sti sekim\u0105"
};
var ro2 = {
  dialogTitle: "Conferin\u021B\u0103",
  close: "\xCEnchide",
  closeAria: "\xCEnchide",
  createSection: "Creeaz\u0103 o conferin\u021B\u0103",
  conferenceTitle: "Titlul conferin\u021Bei",
  selectConferenceTitle: "Selecteaz\u0103 un titlu",
  otherTitle: "Altul\u2026",
  customTitle: "Titlu personalizat",
  customTitlePlaceholder: "Introduce\u021Bi titlul conferin\u021Bei",
  users: "Utilizatori",
  loadingUsers: "Se \xEEncarc\u0103 utilizatorii\u2026",
  noUsers: "Nu exist\u0103 utilizatori disponibili",
  createConference: "Creeaz\u0103 conferin\u021Ba",
  creating: "Se creeaz\u0103\u2026",
  joinSection: "Particip\u0103 la o conferin\u021B\u0103",
  activeConferences: "Conferin\u021Be active",
  noConferences: "Nu exist\u0103 conferin\u021Be disponibile",
  selectConference: "Selecteaz\u0103 o conferin\u021B\u0103",
  untitled: "F\u0103r\u0103 titlu",
  joinConference: "Particip\u0103 la conferin\u021B\u0103",
  joining: "Se particip\u0103\u2026",
  manageSection: "Gestioneaz\u0103 conferin\u021Ba",
  titleLabel: "Titlu:",
  na: "N/A",
  participants: "Participan\u021Bi",
  noPlaces: "F\u0103r\u0103 locuri",
  leaveConference: "P\u0103r\u0103se\u0219te conferin\u021Ba",
  endConference: "\xCEncheie conferin\u021Ba",
  ending: "Se \xEEncheie\u2026",
  leaving: "Se p\u0103r\u0103se\u0219te\u2026",
  conferenceEnded: "Conferin\u021Ba s-a \xEEncheiat.",
  leftConference: "A\u021Bi p\u0103r\u0103sit conferin\u021Ba.",
  connectHubFirst: "Conecta\u021Bi-v\u0103 mai \xEEnt\xE2i la hub-ul Hub.",
  topicRequiredHost: "Este necesar un topic Hub pentru a g\u0103zdui o conferin\u021B\u0103.",
  topicRequiredJoin: "Este necesar un topic Hub pentru a participa la o conferin\u021B\u0103.",
  titleRequired: "Titlul conferin\u021Bei este obligatoriu.",
  selectAttendee: "Selecta\u021Bi cel pu\u021Bin un participant.",
  selectConferenceToJoin: "Selecta\u021Bi o conferin\u021B\u0103 la care s\u0103 participa\u021Bi.",
  failedCreate: "Crearea conferin\u021Bei a e\u0219uat.",
  failedJoin: "Participarea la conferin\u021B\u0103 a e\u0219uat.",
  failedUpdate: "Actualizarea conferin\u021Bei a e\u0219uat.",
  inviteTitle: "Invita\u021Bie la conferin\u021B\u0103",
  joinAndFollow: "Particip\u0103 \u0219i urmeaz\u0103",
  joinNoFollow: "Particip\u0103, dar nu urma",
  doNotJoin: "Nu participa",
  hostFallback: "gazd\u0103",
  inviteLeadWithTitle: "{{title}} \u2014 participa\u021Bi \u0219i urma\u021Bi pe {{host}}?",
  inviteLeadNoTitle: "Participa\u021Bi la conferin\u021B\u0103 \u0219i urma\u021Bi pe {{host}}?",
  joinAndFollowHost: "Particip\u0103 \u0219i urmeaz\u0103 pe {{host}}",
  takeoverTitle: "Preia controlul?",
  takeoverBody: "Gazda \u0219i to\u021Bi participan\u021Bii vor fi anun\u021Ba\u021Bi c\u0103 prelua\u021Bi controlul. Ve\u021Bi conduce actualiz\u0103rile de scen\u0103 ale acestei conferin\u021Be.",
  cancel: "Anuleaz\u0103",
  takeOver: "Preia",
  conferencing: "Conferin\u021B\u0103",
  subscribeHubFirst: "Abona\u021Bi-v\u0103 mai \xEEnt\xE2i la hub",
  stopFollowing: "Opre\u0219te urm\u0103rirea",
  resumeFollowing: "Reia urm\u0103rirea"
};
var no2 = {
  dialogTitle: "Konferanse",
  close: "Lukk",
  closeAria: "Lukk",
  createSection: "Opprett en konferanse",
  conferenceTitle: "Konferansetittel",
  selectConferenceTitle: "Velg en tittel",
  otherTitle: "Annet\u2026",
  customTitle: "Egendefinert tittel",
  customTitlePlaceholder: "Skriv inn konferansetittel",
  users: "Brukere",
  loadingUsers: "Laster brukere\u2026",
  noUsers: "Ingen brukere tilgjengelig",
  createConference: "Opprett konferanse",
  creating: "Oppretter\u2026",
  joinSection: "Bli med i en konferanse",
  activeConferences: "Aktive konferanser",
  noConferences: "Ingen konferanser tilgjengelig",
  selectConference: "Velg en konferanse",
  untitled: "Uten tittel",
  joinConference: "Bli med i konferansen",
  joining: "Blir med\u2026",
  manageSection: "Administrer konferanse",
  titleLabel: "Tittel:",
  na: "i/t",
  participants: "Deltakere",
  noPlaces: "Ingen steder",
  leaveConference: "Forlat konferansen",
  endConference: "Avslutt konferansen",
  ending: "Avslutter\u2026",
  leaving: "Forlater\u2026",
  conferenceEnded: "Konferansen er avsluttet.",
  leftConference: "Du forlot konferansen.",
  connectHubFirst: "Koble til Hub-huben f\xF8rst.",
  topicRequiredHost: "Hub-topic kreves for \xE5 v\xE6re vert for en konferanse.",
  topicRequiredJoin: "Hub-topic kreves for \xE5 bli med i en konferanse.",
  titleRequired: "Konferansetittel er p\xE5krevd.",
  selectAttendee: "Velg minst \xE9n deltaker.",
  selectConferenceToJoin: "Velg en konferanse \xE5 bli med i.",
  failedCreate: "Kunne ikke opprette konferansen.",
  failedJoin: "Kunne ikke bli med i konferansen.",
  failedUpdate: "Kunne ikke oppdatere konferansen.",
  inviteTitle: "Konferanseinvitasjon",
  joinAndFollow: "Bli med og f\xF8lg",
  joinNoFollow: "Bli med, men ikke f\xF8lg",
  doNotJoin: "Ikke bli med",
  hostFallback: "vert",
  inviteLeadWithTitle: "{{title}} \u2014 bli med og f\xF8lge {{host}}?",
  inviteLeadNoTitle: "Bli med i konferansen og f\xF8lge {{host}}?",
  joinAndFollowHost: "Bli med og f\xF8lg {{host}}",
  takeoverTitle: "Ta over?",
  takeoverBody: "Verten og alle deltakere blir varslet om at du tar over. Du vil lede sceneoppdateringene for denne konferansen.",
  cancel: "Avbryt",
  takeOver: "Ta over",
  conferencing: "Konferanse",
  subscribeHubFirst: "Abonner p\xE5 huben f\xF8rst",
  stopFollowing: "Stopp \xE5 f\xF8lge",
  resumeFollowing: "Fortsett \xE5 f\xF8lge"
};
var ar2 = {
  dialogTitle: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  close: "\u0625\u063A\u0644\u0627\u0642",
  closeAria: "\u0625\u063A\u0644\u0627\u0642",
  createSection: "\u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631",
  conferenceTitle: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  selectConferenceTitle: "\u0627\u062E\u062A\u0631 \u0639\u0646\u0648\u0627\u0646 \u0645\u0624\u062A\u0645\u0631",
  otherTitle: "\u0623\u062E\u0631\u0649\u2026",
  customTitle: "\u0639\u0646\u0648\u0627\u0646 \u0645\u062E\u0635\u0635",
  customTitlePlaceholder: "\u0623\u062F\u062E\u0644 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  users: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646",
  loadingUsers: "\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646\u2026",
  noUsers: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646",
  createConference: "\u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631",
  creating: "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0646\u0634\u0627\u0621\u2026",
  joinSection: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631",
  activeConferences: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A \u0627\u0644\u0646\u0634\u0637\u0629",
  noConferences: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  selectConference: "\u0627\u062E\u062A\u0631 \u0645\u0624\u062A\u0645\u0631\u0627\u064B",
  untitled: "\u0628\u062F\u0648\u0646 \u0639\u0646\u0648\u0627\u0646",
  joinConference: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  joining: "\u062C\u0627\u0631\u064D \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645\u2026",
  manageSection: "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  titleLabel: "\u0627\u0644\u0639\u0646\u0648\u0627\u0646:",
  na: "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D",
  participants: "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0648\u0646",
  noPlaces: "\u0644\u0627 \u0623\u0645\u0627\u0643\u0646",
  leaveConference: "\u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  endConference: "\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  ending: "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0646\u0647\u0627\u0621\u2026",
  leaving: "\u062C\u0627\u0631\u064D \u0627\u0644\u0645\u063A\u0627\u062F\u0631\u0629\u2026",
  conferenceEnded: "\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  leftConference: "\u063A\u0627\u062F\u0631\u062A \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  connectHubFirst: "\u0627\u062A\u0635\u0644 \u0628\u0645\u0631\u0643\u0632 Hub \u0623\u0648\u0644\u0627\u064B.",
  topicRequiredHost: "\u0645\u0648\u0636\u0648\u0639 Hub \u0645\u0637\u0644\u0648\u0628 \u0644\u0627\u0633\u062A\u0636\u0627\u0641\u0629 \u0645\u0624\u062A\u0645\u0631.",
  topicRequiredJoin: "\u0645\u0648\u0636\u0648\u0639 Hub \u0645\u0637\u0644\u0648\u0628 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631.",
  titleRequired: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0645\u0637\u0644\u0648\u0628.",
  selectAttendee: "\u062D\u062F\u062F \u0645\u0648\u0636\u0648\u0639 \u0645\u0634\u0627\u0631\u0643 \u0648\u0627\u062D\u062F \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  selectConferenceToJoin: "\u0627\u062E\u062A\u0631 \u0645\u0624\u062A\u0645\u0631\u0627\u064B \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u064A\u0647.",
  failedCreate: "\u0641\u0634\u0644 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  failedJoin: "\u0641\u0634\u0644 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  failedUpdate: "\u0641\u0634\u0644 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  inviteTitle: "\u062F\u0639\u0648\u0629 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631",
  joinAndFollow: "\u0627\u0646\u0636\u0645 \u0648\u0627\u062A\u0628\u0639",
  joinNoFollow: "\u0627\u0646\u0636\u0645 \u062F\u0648\u0646 \u0645\u062A\u0627\u0628\u0639\u0629",
  doNotJoin: "\u0639\u062F\u0645 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  hostFallback: "\u0627\u0644\u0645\u0636\u064A\u0641",
  inviteLeadWithTitle: "{{title}} \u2014 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 {{host}}\u061F",
  inviteLeadNoTitle: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 {{host}}\u061F",
  joinAndFollowHost: "\u0627\u0646\u0636\u0645 \u0648\u0627\u062A\u0628\u0639 {{host}}",
  takeoverTitle: "\u062A\u0648\u0644\u064A \u0627\u0644\u0642\u064A\u0627\u062F\u0629\u061F",
  takeoverBody: "\u0633\u064A\u062A\u0645 \u0625\u062E\u0637\u0627\u0631 \u0627\u0644\u0645\u0636\u064A\u0641 \u0648\u062C\u0645\u064A\u0639 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646 \u0628\u0623\u0646\u0643 \u062A\u062A\u0648\u0644\u0649 \u0627\u0644\u0642\u064A\u0627\u062F\u0629. \u0633\u062A\u0642\u0648\u062F \u062A\u062D\u062F\u064A\u062B\u0627\u062A \u0627\u0644\u0645\u0634\u0647\u062F \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  cancel: "\u0625\u0644\u063A\u0627\u0621",
  takeOver: "\u062A\u0648\u0644\u064A \u0627\u0644\u0642\u064A\u0627\u062F\u0629",
  conferencing: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  subscribeHubFirst: "\u0627\u0634\u062A\u0631\u0643 \u0641\u064A \u0627\u0644\u0645\u0631\u0643\u0632 \u0623\u0648\u0644\u0627\u064B",
  stopFollowing: "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629",
  resumeFollowing: "\u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629"
};
var CONFERENCE_BY_LOCALE = {
  en: en2,
  ar: ar2,
  fr: fr2,
  es,
  ca,
  de: de2,
  it: it2,
  pt: pt2,
  ko,
  pl,
  uk,
  cs,
  nl,
  el,
  lv,
  hu,
  lt: lt2,
  ro: ro2,
  no: no2
};
function conferenceStringsFor(locale) {
  const code = locale || resolveStoredLocale();
  return { ...CONFERENCE_BY_LOCALE[code] };
}

// ../i18n/header.ts
var en3 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Open Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Open DICOM SR Report Creator",
  remoteAi: "Inference",
  remoteAiTitle: "Inference \u2014 inference servers",
  loadStudy: "Load study",
  loadStudyTitle: "Load study",
  sessionInfo: "Session info",
  language: "Language"
};
var de3 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Worklist \xF6ffnen",
  dicomSr: "DICOM SR",
  dicomSrTitle: "DICOM-SR-Report-Creator \xF6ffnen",
  remoteAi: "Remote-KI",
  remoteAiTitle: "Remote-KI \u2014 Inferenzserver",
  loadStudy: "Studie laden",
  loadStudyTitle: "Studie laden",
  sessionInfo: "Sitzungsinfo",
  language: "Sprache"
};
var fr3 = {
  reportingLabel: "Reporting :",
  worklist: "Worklist",
  worklistTitle: "Ouvrir Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Ouvrir le Report Creator DICOM SR",
  remoteAi: "IA distante",
  remoteAiTitle: "IA distante \u2014 serveurs d\u2019inf\xE9rence",
  loadStudy: "Charger une \xE9tude",
  loadStudyTitle: "Charger une \xE9tude",
  sessionInfo: "Info session",
  language: "Langue"
};
var es2 = {
  reportingLabel: "Informes:",
  worklist: "Worklist",
  worklistTitle: "Abrir Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Abrir el Report Creator DICOM SR",
  remoteAi: "IA remota",
  remoteAiTitle: "IA remota \u2014 servidores de inferencia",
  loadStudy: "Cargar estudio",
  loadStudyTitle: "Cargar estudio",
  sessionInfo: "Info de sesi\xF3n",
  language: "Idioma"
};
var ca2 = {
  reportingLabel: "Informes:",
  worklist: "Worklist",
  worklistTitle: "Obrir Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Obrir el Report Creator DICOM SR",
  remoteAi: "IA remota",
  remoteAiTitle: "IA remota \u2014 servidors d\u2019infer\xE8ncia",
  loadStudy: "Carregar estudi",
  loadStudyTitle: "Carregar estudi",
  sessionInfo: "Info de sessi\xF3",
  language: "Idioma"
};
var it3 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Apri Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Apri il Report Creator DICOM SR",
  remoteAi: "IA remota",
  remoteAiTitle: "IA remota \u2014 server di inferenza",
  loadStudy: "Carica studio",
  loadStudyTitle: "Carica studio",
  sessionInfo: "Info sessione",
  language: "Lingua"
};
var pt3 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Abrir Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Abrir o Report Creator DICOM SR",
  remoteAi: "IA remota",
  remoteAiTitle: "IA remota \u2014 servidores de infer\xEAncia",
  loadStudy: "Carregar estudo",
  loadStudyTitle: "Carregar estudo",
  sessionInfo: "Info da sess\xE3o",
  language: "Idioma"
};
var ko2 = {
  reportingLabel: "\uB9AC\uD3EC\uD305:",
  worklist: "Worklist",
  worklistTitle: "Worklist \uC5F4\uAE30",
  dicomSr: "DICOM SR",
  dicomSrTitle: "DICOM SR Report Creator \uC5F4\uAE30",
  remoteAi: "\uC6D0\uACA9 AI",
  remoteAiTitle: "\uC6D0\uACA9 AI \u2014 \uCD94\uB860 \uC11C\uBC84",
  loadStudy: "\uAC80\uC0AC \uBD88\uB7EC\uC624\uAE30",
  loadStudyTitle: "\uAC80\uC0AC \uBD88\uB7EC\uC624\uAE30",
  sessionInfo: "\uC138\uC158 \uC815\uBCF4",
  language: "\uC5B8\uC5B4"
};
var pl2 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Otw\xF3rz Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Otw\xF3rz Report Creator DICOM SR",
  remoteAi: "Zdalne AI",
  remoteAiTitle: "Zdalne AI \u2014 serwery wnioskowania",
  loadStudy: "Wczytaj badanie",
  loadStudyTitle: "Wczytaj badanie",
  sessionInfo: "Info o sesji",
  language: "J\u0119zyk"
};
var uk2 = {
  reportingLabel: "\u0417\u0432\u0456\u0442\u0443\u0432\u0430\u043D\u043D\u044F:",
  worklist: "Worklist",
  worklistTitle: "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438 Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438 Report Creator DICOM SR",
  remoteAi: "\u0412\u0456\u0434\u0434\u0430\u043B\u0435\u043D\u0438\u0439 \u0428\u0406",
  remoteAiTitle: "\u0412\u0456\u0434\u0434\u0430\u043B\u0435\u043D\u0438\u0439 \u0428\u0406 \u2014 \u0441\u0435\u0440\u0432\u0435\u0440\u0438 \u0432\u0438\u0441\u043D\u043E\u0432\u043A\u0443",
  loadStudy: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F",
  loadStudyTitle: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F",
  sessionInfo: "\u0406\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0456\u044F \u043F\u0440\u043E \u0441\u0435\u0430\u043D\u0441",
  language: "\u041C\u043E\u0432\u0430"
};
var cs2 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Otev\u0159\xEDt Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Otev\u0159\xEDt Report Creator DICOM SR",
  remoteAi: "Vzd\xE1len\xE1 AI",
  remoteAiTitle: "Vzd\xE1len\xE1 AI \u2014 inferen\u010Dn\xED servery",
  loadStudy: "Na\u010D\xEDst studii",
  loadStudyTitle: "Na\u010D\xEDst studii",
  sessionInfo: "Info o relaci",
  language: "Jazyk"
};
var nl2 = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "Worklist openen",
  dicomSr: "DICOM SR",
  dicomSrTitle: "DICOM SR Report Creator openen",
  remoteAi: "Externe AI",
  remoteAiTitle: "Externe AI \u2014 inferentieservers",
  loadStudy: "Studie laden",
  loadStudyTitle: "Studie laden",
  sessionInfo: "Sessie-info",
  language: "Taal"
};
var el2 = {
  reportingLabel: "\u0391\u03BD\u03B1\u03C6\u03BF\u03C1\u03AD\u03C2:",
  worklist: "Worklist",
  worklistTitle: "\u0386\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1 Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "\u0386\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1 Report Creator DICOM SR",
  remoteAi: "\u0391\u03C0\u03BF\u03BC\u03B1\u03BA\u03C1\u03C5\u03C3\u03BC\u03AD\u03BD\u03B7 \u03A4\u039D",
  remoteAiTitle: "\u0391\u03C0\u03BF\u03BC\u03B1\u03BA\u03C1\u03C5\u03C3\u03BC\u03AD\u03BD\u03B7 \u03A4\u039D \u2014 \u03B4\u03B9\u03B1\u03BA\u03BF\u03BC\u03B9\u03C3\u03C4\u03AD\u03C2 \u03C3\u03C5\u03BC\u03C0\u03B5\u03C1\u03B1\u03C3\u03BC\u03BF\u03CD",
  loadStudy: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7\u03C2",
  loadStudyTitle: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7\u03C2",
  sessionInfo: "\u03A0\u03BB\u03B7\u03C1\u03BF\u03C6\u03BF\u03C1\u03AF\u03B5\u03C2 \u03C3\u03C5\u03BD\u03B5\u03B4\u03C1\u03AF\u03B1\u03C2",
  language: "\u0393\u03BB\u03CE\u03C3\u03C3\u03B1"
};
var lv2 = {
  reportingLabel: "Zi\u0146o\u0161ana:",
  worklist: "Worklist",
  worklistTitle: "Atv\u0113rt Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Atv\u0113rt DICOM SR Report Creator",
  remoteAi: "Att\u0101lais MI",
  remoteAiTitle: "Att\u0101lais MI \u2014 secin\u0101\u0161anas serveri",
  loadStudy: "Iel\u0101d\u0113t p\u0113t\u012Bjumu",
  loadStudyTitle: "Iel\u0101d\u0113t p\u0113t\u012Bjumu",
  sessionInfo: "Sesijas info",
  language: "Valoda"
};
var hu2 = {
  reportingLabel: "Jelent\xE9s:",
  worklist: "Worklist",
  worklistTitle: "Worklist megnyit\xE1sa",
  dicomSr: "DICOM SR",
  dicomSrTitle: "DICOM SR Report Creator megnyit\xE1sa",
  remoteAi: "T\xE1voli MI",
  remoteAiTitle: "T\xE1voli MI \u2014 k\xF6vetkeztet\u0151 kiszolg\xE1l\xF3k",
  loadStudy: "Vizsg\xE1lat bet\xF6lt\xE9se",
  loadStudyTitle: "Vizsg\xE1lat bet\xF6lt\xE9se",
  sessionInfo: "Munkamenet-inf\xF3",
  language: "Nyelv"
};
var lt3 = {
  reportingLabel: "Ataskaitos:",
  worklist: "Worklist",
  worklistTitle: "Atidaryti Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Atidaryti DICOM SR Report Creator",
  remoteAi: "Nuotolinis DI",
  remoteAiTitle: "Nuotolinis DI \u2014 i\u0161vad\u0173 serveriai",
  loadStudy: "\u012Ekelti tyrim\u0105",
  loadStudyTitle: "\u012Ekelti tyrim\u0105",
  sessionInfo: "Sesijos info",
  language: "Kalba"
};
var ro3 = {
  reportingLabel: "Raportare:",
  worklist: "Worklist",
  worklistTitle: "Deschide Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "Deschide Report Creator DICOM SR",
  remoteAi: "IA la distan\u021B\u0103",
  remoteAiTitle: "IA la distan\u021B\u0103 \u2014 servere de inferen\u021B\u0103",
  loadStudy: "\xCEncarc\u0103 studiul",
  loadStudyTitle: "\xCEncarc\u0103 studiul",
  sessionInfo: "Info sesiune",
  language: "Limb\u0103"
};
var noNb = {
  reportingLabel: "Reporting:",
  worklist: "Worklist",
  worklistTitle: "\xC5pne Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "\xC5pne DICOM SR Report Creator",
  remoteAi: "Ekstern AI",
  remoteAiTitle: "Ekstern AI \u2014 inferensservere",
  loadStudy: "Last studie",
  loadStudyTitle: "Last studie",
  sessionInfo: "\xD8ktinfo",
  language: "Spr\xE5k"
};
var ar3 = {
  reportingLabel: "\u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631:",
  worklist: "Worklist",
  worklistTitle: "\u0641\u062A\u062D Worklist",
  dicomSr: "DICOM SR",
  dicomSrTitle: "\u0641\u062A\u062D \u0645\u0646\u0634\u0626 \u062A\u0642\u0627\u0631\u064A\u0631 DICOM SR",
  remoteAi: "\u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0639\u0646 \u0628\u064F\u0639\u062F",
  remoteAiTitle: "\u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0639\u0646 \u0628\u064F\u0639\u062F \u2014 \u062E\u0648\u0627\u062F\u0645 \u0627\u0644\u0627\u0633\u062A\u062F\u0644\u0627\u0644",
  loadStudy: "\u062A\u062D\u0645\u064A\u0644 \u062F\u0631\u0627\u0633\u0629",
  loadStudyTitle: "\u062A\u062D\u0645\u064A\u0644 \u062F\u0631\u0627\u0633\u0629",
  sessionInfo: "\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0644\u0633\u0629",
  language: "\u0627\u0644\u0644\u063A\u0629"
};
var HEADER_BY_LOCALE = {
  en: en3,
  ar: ar3,
  fr: fr3,
  es: es2,
  ca: ca2,
  de: de3,
  it: it3,
  pt: pt3,
  ko: ko2,
  pl: pl2,
  uk: uk2,
  cs: cs2,
  nl: nl2,
  el: el2,
  lv: lv2,
  hu: hu2,
  lt: lt3,
  ro: ro3,
  no: noNb
};
function headerChromeFor(locale) {
  const code = locale || resolveStoredLocale();
  return { ...HEADER_BY_LOCALE[code] };
}
function applyHeaderChrome(root = document, locale) {
  const h = headerChromeFor(locale);
  root.querySelectorAll("[data-i18n-header]").forEach((el4) => {
    const key = el4.getAttribute("data-i18n-header");
    if (!key || !(key in h)) return;
    el4.textContent = h[key];
  });
  root.querySelectorAll("[data-i18n-header-title]").forEach((el4) => {
    const key = el4.getAttribute(
      "data-i18n-header-title"
    );
    if (!key || !(key in h)) return;
    el4.title = h[key];
  });
  root.querySelectorAll("[data-i18n-header-aria]").forEach((el4) => {
    const key = el4.getAttribute(
      "data-i18n-header-aria"
    );
    if (!key || !(key in h)) return;
    el4.setAttribute("aria-label", h[key]);
  });
}

// ../i18n/reporting.ts
var en4 = {
  viewers: "Image Displays:",
  worklist: "Worklist",
  snapshots: "Snapshots",
  volumes: "Volumes",
  segmentations: "Segmentations",
  measurements: "Measurements",
  currentContext: "Current context:",
  none: "none",
  close: "Close",
  closeContext: "Close current context",
  colNum: "#",
  colThumb: "Thumb",
  colFilename: "Filename",
  colTime: "Time",
  colName: "Name",
  colCrop: "Crop",
  colBox: "Box",
  colShift: "Shift",
  colPreset: "Preset",
  colLabel: "Label",
  colSnomed: "SNOMED",
  colVoxels: "Voxels",
  colSegment: "Segment",
  colQuantity: "Quantity",
  colValue: "Value",
  colUnits: "Units",
  noReportSelected: "No report selected",
  noSnapshots: "No snapshots",
  noSegmentations: "No segmentations from Image Display yet. Refresh to load the SEG catalog.",
  noMeasurements: "No measurements yet. Use + on a segmentation to add one, or receive a TID1500 SR.",
  refreshFromImageDisplay: "Refresh from Image Display",
  notConnectedToHub: "Not connected to Slicer hub",
  worklistNoOpenStudy: "Worklist responded with no open study"
};
var de4 = {
  viewers: "Viewer:",
  worklist: "Worklist",
  snapshots: "Snapshots",
  volumes: "Volumina",
  segmentations: "Segmentierungen",
  measurements: "Messungen",
  currentContext: "Aktueller Kontext:",
  none: "keiner",
  close: "Schlie\xDFen",
  closeContext: "Aktuellen Kontext schlie\xDFen",
  colNum: "#",
  colThumb: "Vorschaubild",
  colFilename: "Dateiname",
  colTime: "Zeit",
  colName: "Name",
  colCrop: "Zuschneiden",
  colBox: "Box",
  colShift: "Verschiebung",
  colPreset: "Voreinstellung",
  colLabel: "Bezeichnung",
  colSnomed: "SNOMED",
  colVoxels: "Voxel",
  colSegment: "Segment",
  colQuantity: "Gr\xF6\xDFe",
  colValue: "Wert",
  colUnits: "Einheiten",
  noReportSelected: "Kein Bericht ausgew\xE4hlt",
  noSnapshots: "Keine Snapshots",
  noSegmentations: "Noch keine Segmentierungen vom Image Display. Aktualisieren, um den SEG-Katalog zu laden.",
  noMeasurements: "Noch keine Messungen. Mit + an einer Segmentierung eine hinzuf\xFCgen oder einen TID1500-SR empfangen.",
  refreshFromImageDisplay: "Vom Image Display aktualisieren",
  notConnectedToHub: "Nicht mit dem Hub-Hub verbunden",
  worklistNoOpenStudy: "Die Worklist meldete keine offene Studie"
};
var fr4 = {
  viewers: "Visionneuses :",
  worklist: "Worklist",
  snapshots: "Instantan\xE9s",
  volumes: "Volumes",
  segmentations: "Segmentations",
  measurements: "Mesures",
  currentContext: "Contexte actuel :",
  none: "aucun",
  close: "Fermer",
  closeContext: "Fermer le contexte actuel",
  colNum: "#",
  colThumb: "Vignette",
  colFilename: "Fichier",
  colTime: "Heure",
  colName: "Nom",
  colCrop: "Recadrage",
  colBox: "Bo\xEEte",
  colShift: "D\xE9calage",
  colPreset: "Pr\xE9r\xE9glage",
  colLabel: "Libell\xE9",
  colSnomed: "SNOMED",
  colVoxels: "Voxels",
  colSegment: "Segment",
  colQuantity: "Quantit\xE9",
  colValue: "Valeur",
  colUnits: "Unit\xE9s",
  noReportSelected: "Aucun rapport s\xE9lectionn\xE9",
  noSnapshots: "Aucun instantan\xE9",
  noSegmentations: "Aucune segmentation depuis Image Display pour le moment. Actualisez pour charger le catalogue SEG.",
  noMeasurements: "Aucune mesure pour le moment. Utilisez + sur une segmentation pour en ajouter une, ou recevez un SR TID1500.",
  refreshFromImageDisplay: "Actualiser depuis Image Display",
  notConnectedToHub: "Non connect\xE9 au hub Hub",
  worklistNoOpenStudy: "La liste de travail a r\xE9pondu sans \xE9tude ouverte"
};
var es3 = {
  viewers: "Visores:",
  worklist: "Worklist",
  snapshots: "Capturas",
  volumes: "Vol\xFAmenes",
  segmentations: "Segmentaciones",
  measurements: "Mediciones",
  currentContext: "Contexto actual:",
  none: "ninguno",
  close: "Cerrar",
  closeContext: "Cerrar el contexto actual",
  colNum: "#",
  colThumb: "Miniatura",
  colFilename: "Archivo",
  colTime: "Hora",
  colName: "Nombre",
  colCrop: "Recorte",
  colBox: "Caja",
  colShift: "Desplazamiento",
  colPreset: "Preajuste",
  colLabel: "Etiqueta",
  colSnomed: "SNOMED",
  colVoxels: "V\xF3xeles",
  colSegment: "Segmento",
  colQuantity: "Cantidad",
  colValue: "Valor",
  colUnits: "Unidades",
  noReportSelected: "Ning\xFAn informe seleccionado",
  noSnapshots: "No hay capturas",
  noSegmentations: "A\xFAn no hay segmentaciones desde Image Display. Actualiza para cargar el cat\xE1logo SEG.",
  noMeasurements: "A\xFAn no hay mediciones. Usa + en una segmentaci\xF3n para a\xF1adir una, o recibe un SR TID1500.",
  refreshFromImageDisplay: "Actualizar desde Image Display",
  notConnectedToHub: "Sin conexi\xF3n al hub Hub",
  worklistNoOpenStudy: "La lista de trabajo respondi\xF3 que no hay ning\xFAn estudio abierto"
};
var ca3 = {
  viewers: "Visualitzadors:",
  worklist: "Worklist",
  snapshots: "Captures",
  volumes: "Volums",
  segmentations: "Segmentacions",
  measurements: "Mesures",
  currentContext: "Context actual:",
  none: "cap",
  close: "Tancar",
  closeContext: "Tancar el context actual",
  colNum: "#",
  colThumb: "Miniatura",
  colFilename: "Fitxer",
  colTime: "Hora",
  colName: "Nom",
  colCrop: "Retall",
  colBox: "Caixa",
  colShift: "Despla\xE7ament",
  colPreset: "Predefinit",
  colLabel: "Etiqueta",
  colSnomed: "SNOMED",
  colVoxels: "V\xF2xels",
  colSegment: "Segment",
  colQuantity: "Quantitat",
  colValue: "Valor",
  colUnits: "Unitats",
  noReportSelected: "Cap informe seleccionat",
  noSnapshots: "No hi ha captures",
  noSegmentations: "Encara no hi ha segmentacions des d\u2019Image Display. Actualitzeu per carregar el cat\xE0leg SEG.",
  noMeasurements: "Encara no hi ha mesures. Useu + en una segmentaci\xF3 per afegir-ne una, o rebeu un SR TID1500.",
  refreshFromImageDisplay: "Actualitzar des d\u2019Image Display",
  notConnectedToHub: "No connectat al hub Hub",
  worklistNoOpenStudy: "La llista de treball ha respost sense estudi obert"
};
var it4 = {
  viewers: "Viewer:",
  worklist: "Worklist",
  snapshots: "Istantanee",
  volumes: "Volumi",
  segmentations: "Segmentazioni",
  measurements: "Misurazioni",
  currentContext: "Contesto attuale:",
  none: "nessuno",
  close: "Chiudi",
  closeContext: "Chiudi il contesto attuale",
  colNum: "#",
  colThumb: "Anteprima",
  colFilename: "Nome file",
  colTime: "Ora",
  colName: "Nome",
  colCrop: "Ritaglio",
  colBox: "Box",
  colShift: "Spostamento",
  colPreset: "Predefinito",
  colLabel: "Etichetta",
  colSnomed: "SNOMED",
  colVoxels: "Voxel",
  colSegment: "Segmento",
  colQuantity: "Quantit\xE0",
  colValue: "Valore",
  colUnits: "Unit\xE0",
  noReportSelected: "Nessun referto selezionato",
  noSnapshots: "Nessuna istantanea",
  noSegmentations: "Ancora nessuna segmentazione da Image Display. Aggiorna per caricare il catalogo SEG.",
  noMeasurements: "Ancora nessuna misurazione. Usa + su una segmentazione per aggiungerne una, oppure ricevi un SR TID1500.",
  refreshFromImageDisplay: "Aggiorna da Image Display",
  notConnectedToHub: "Non connesso all\u2019hub Hub",
  worklistNoOpenStudy: "La worklist ha risposto senza nessuno studio aperto"
};
var pt4 = {
  viewers: "Visualizadores:",
  worklist: "Worklist",
  snapshots: "Instant\xE2neos",
  volumes: "Volumes",
  segmentations: "Segmenta\xE7\xF5es",
  measurements: "Medi\xE7\xF5es",
  currentContext: "Contexto atual:",
  none: "nenhum",
  close: "Fechar",
  closeContext: "Fechar o contexto atual",
  colNum: "#",
  colThumb: "Miniatura",
  colFilename: "Ficheiro",
  colTime: "Hora",
  colName: "Nome",
  colCrop: "Recorte",
  colBox: "Caixa",
  colShift: "Deslocamento",
  colPreset: "Predefini\xE7\xE3o",
  colLabel: "Etiqueta",
  colSnomed: "SNOMED",
  colVoxels: "Voxels",
  colSegment: "Segmento",
  colQuantity: "Quantidade",
  colValue: "Valor",
  colUnits: "Unidades",
  noReportSelected: "Nenhum relat\xF3rio selecionado",
  noSnapshots: "Sem instant\xE2neos",
  noSegmentations: "Ainda n\xE3o h\xE1 segmenta\xE7\xF5es do Image Display. Atualize para carregar o cat\xE1logo SEG.",
  noMeasurements: "Ainda n\xE3o h\xE1 medi\xE7\xF5es. Use + numa segmenta\xE7\xE3o para adicionar uma, ou receba um SR TID1500.",
  refreshFromImageDisplay: "Atualizar a partir do Image Display",
  notConnectedToHub: "Sem liga\xE7\xE3o ao hub Hub",
  worklistNoOpenStudy: "A worklist respondeu sem nenhum estudo aberto"
};
var ko3 = {
  viewers: "\uBDF0\uC5B4:",
  worklist: "Worklist",
  snapshots: "\uC2A4\uB0C5\uC0F7",
  volumes: "\uBCFC\uB968",
  segmentations: "\uC138\uADF8\uBA58\uD14C\uC774\uC158",
  measurements: "\uCE21\uC815",
  currentContext: "\uD604\uC7AC \uCEE8\uD14D\uC2A4\uD2B8:",
  none: "\uC5C6\uC74C",
  close: "\uB2EB\uAE30",
  closeContext: "\uD604\uC7AC \uCEE8\uD14D\uC2A4\uD2B8 \uB2EB\uAE30",
  colNum: "#",
  colThumb: "\uBBF8\uB9AC\uBCF4\uAE30",
  colFilename: "\uD30C\uC77C \uC774\uB984",
  colTime: "\uC2DC\uAC04",
  colName: "\uC774\uB984",
  colCrop: "\uC790\uB974\uAE30",
  colBox: "\uBC15\uC2A4",
  colShift: "\uC2DC\uD504\uD2B8",
  colPreset: "\uD504\uB9AC\uC14B",
  colLabel: "\uB808\uC774\uBE14",
  colSnomed: "SNOMED",
  colVoxels: "\uBCF5\uC140",
  colSegment: "\uC138\uADF8\uBA3C\uD2B8",
  colQuantity: "\uC218\uB7C9",
  colValue: "\uAC12",
  colUnits: "\uB2E8\uC704",
  noReportSelected: "\uC120\uD0DD\uD55C \uBCF4\uACE0\uC11C \uC5C6\uC74C",
  noSnapshots: "\uC2A4\uB0C5\uC0F7 \uC5C6\uC74C",
  noSegmentations: "\uC544\uC9C1 Image Display\uC5D0\uC11C \uAC00\uC838\uC628 \uC138\uADF8\uBA58\uD14C\uC774\uC158\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC0C8\uB85C\uACE0\uCE68\uD558\uC5EC SEG \uCE74\uD0C8\uB85C\uADF8\uB97C \uBD88\uB7EC\uC624\uC138\uC694.",
  noMeasurements: "\uC544\uC9C1 \uCE21\uC815\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC138\uADF8\uBA58\uD14C\uC774\uC158\uC758 +\uB85C \uCD94\uAC00\uD558\uAC70\uB098 TID1500 SR\uC744 \uBC1B\uC73C\uC138\uC694.",
  refreshFromImageDisplay: "Image Display\uC5D0\uC11C \uC0C8\uB85C\uACE0\uCE68",
  notConnectedToHub: "Hub \uD5C8\uBE0C\uC5D0 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC74C",
  worklistNoOpenStudy: "\uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uAC00 \uC5F4\uB9B0 \uAC80\uC0AC \uC5C6\uC774 \uC751\uB2F5\uD588\uC2B5\uB2C8\uB2E4"
};
var pl3 = {
  viewers: "Przegl\u0105darki:",
  worklist: "Worklist",
  snapshots: "Migawki",
  volumes: "Wolumeny",
  segmentations: "Segmentacje",
  measurements: "Pomiary",
  currentContext: "Bie\u017C\u0105cy kontekst:",
  none: "brak",
  close: "Zamknij",
  closeContext: "Zamknij bie\u017C\u0105cy kontekst",
  colNum: "#",
  colThumb: "Miniatura",
  colFilename: "Nazwa pliku",
  colTime: "Czas",
  colName: "Nazwa",
  colCrop: "Przyci\u0119cie",
  colBox: "Box",
  colShift: "Przesuni\u0119cie",
  colPreset: "Preset",
  colLabel: "Etykieta",
  colSnomed: "SNOMED",
  colVoxels: "Woksele",
  colSegment: "Segment",
  colQuantity: "Wielko\u015B\u0107",
  colValue: "Warto\u015B\u0107",
  colUnits: "Jednostki",
  noReportSelected: "Nie wybrano raportu",
  noSnapshots: "Brak migawek",
  noSegmentations: "Brak jeszcze segmentacji z Image Display. Od\u015Bwie\u017C, aby wczyta\u0107 katalog SEG.",
  noMeasurements: "Brak jeszcze pomiar\xF3w. U\u017Cyj + przy segmentacji, aby doda\u0107, albo odbierz SR TID1500.",
  refreshFromImageDisplay: "Od\u015Bwie\u017C z Image Display",
  notConnectedToHub: "Brak po\u0142\u0105czenia z hubem Hub",
  worklistNoOpenStudy: "Worklist odpowiedzia\u0142a bez otwartego badania"
};
var uk3 = {
  viewers: "\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0447\u0456:",
  worklist: "Worklist",
  snapshots: "\u0417\u043D\u0456\u043C\u043A\u0438",
  volumes: "\u041E\u0431\u2019\u0454\u043C\u0438",
  segmentations: "\u0421\u0435\u0433\u043C\u0435\u043D\u0442\u0430\u0446\u0456\u0457",
  measurements: "\u0412\u0438\u043C\u0456\u0440\u044E\u0432\u0430\u043D\u043D\u044F",
  currentContext: "\u041F\u043E\u0442\u043E\u0447\u043D\u0438\u0439 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442:",
  none: "\u043D\u0435\u043C\u0430\u0454",
  close: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
  closeContext: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438 \u043F\u043E\u0442\u043E\u0447\u043D\u0438\u0439 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442",
  colNum: "#",
  colThumb: "\u041C\u0456\u043D\u0456\u0430\u0442\u044E\u0440\u0430",
  colFilename: "\u0406\u043C\u2019\u044F \u0444\u0430\u0439\u043B\u0443",
  colTime: "\u0427\u0430\u0441",
  colName: "\u041D\u0430\u0437\u0432\u0430",
  colCrop: "\u041E\u0431\u0440\u0456\u0437\u0430\u043D\u043D\u044F",
  colBox: "Box",
  colShift: "\u0417\u0441\u0443\u0432",
  colPreset: "\u041F\u0440\u0435\u0434\u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0430",
  colLabel: "\u041C\u0456\u0442\u043A\u0430",
  colSnomed: "SNOMED",
  colVoxels: "\u0412\u043E\u043A\u0441\u0435\u043B\u0456",
  colSegment: "\u0421\u0435\u0433\u043C\u0435\u043D\u0442",
  colQuantity: "\u0412\u0435\u043B\u0438\u0447\u0438\u043D\u0430",
  colValue: "\u0417\u043D\u0430\u0447\u0435\u043D\u043D\u044F",
  colUnits: "\u041E\u0434\u0438\u043D\u0438\u0446\u0456",
  noReportSelected: "\u0417\u0432\u0456\u0442 \u043D\u0435 \u0432\u0438\u0431\u0440\u0430\u043D\u043E",
  noSnapshots: "\u041D\u0435\u043C\u0430\u0454 \u0437\u043D\u0456\u043C\u043A\u0456\u0432",
  noSegmentations: "\u0429\u0435 \u043D\u0435\u043C\u0430\u0454 \u0441\u0435\u0433\u043C\u0435\u043D\u0442\u0430\u0446\u0456\u0439 \u0437 Image Display. \u041E\u043D\u043E\u0432\u0456\u0442\u044C, \u0449\u043E\u0431 \u0437\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438 \u043A\u0430\u0442\u0430\u043B\u043E\u0433 SEG.",
  noMeasurements: "\u0429\u0435 \u043D\u0435\u043C\u0430\u0454 \u0432\u0438\u043C\u0456\u0440\u044E\u0432\u0430\u043D\u044C. \u0412\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u0430\u0439\u0442\u0435 + \u043D\u0430 \u0441\u0435\u0433\u043C\u0435\u043D\u0442\u0430\u0446\u0456\u0457, \u0449\u043E\u0431 \u0434\u043E\u0434\u0430\u0442\u0438, \u0430\u0431\u043E \u043E\u0442\u0440\u0438\u043C\u0430\u0439\u0442\u0435 SR TID1500.",
  refreshFromImageDisplay: "\u041E\u043D\u043E\u0432\u0438\u0442\u0438 \u0437 Image Display",
  notConnectedToHub: "\u041D\u0435\u043C\u0430\u0454 \u0437\u2019\u0454\u0434\u043D\u0430\u043D\u043D\u044F \u0437 Hub-\u0445\u0430\u0431\u043E\u043C",
  worklistNoOpenStudy: "\u0420\u043E\u0431\u043E\u0447\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0432 \u0431\u0435\u0437 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u043E\u0433\u043E \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F"
};
var cs3 = {
  viewers: "Prohl\xED\u017Ee\u010De:",
  worklist: "Worklist",
  snapshots: "Sn\xEDmky",
  volumes: "Volumeny",
  segmentations: "Segmentace",
  measurements: "M\u011B\u0159en\xED",
  currentContext: "Aktu\xE1ln\xED kontext:",
  none: "\u017E\xE1dn\xFD",
  close: "Zav\u0159\xEDt",
  closeContext: "Zav\u0159\xEDt aktu\xE1ln\xED kontext",
  colNum: "#",
  colThumb: "N\xE1hled",
  colFilename: "N\xE1zev souboru",
  colTime: "\u010Cas",
  colName: "N\xE1zev",
  colCrop: "O\u0159ez",
  colBox: "Box",
  colShift: "Posun",
  colPreset: "P\u0159edvolba",
  colLabel: "\u0160t\xEDtek",
  colSnomed: "SNOMED",
  colVoxels: "Voxely",
  colSegment: "Segment",
  colQuantity: "Veli\u010Dina",
  colValue: "Hodnota",
  colUnits: "Jednotky",
  noReportSelected: "Nen\xED vybr\xE1na \u017E\xE1dn\xE1 zpr\xE1va",
  noSnapshots: "\u017D\xE1dn\xE9 sn\xEDmky",
  noSegmentations: "Zat\xEDm \u017E\xE1dn\xE9 segmentace z Image Display. Obnovte pro na\u010Dten\xED katalogu SEG.",
  noMeasurements: "Zat\xEDm \u017E\xE1dn\xE1 m\u011B\u0159en\xED. Pou\u017Eijte + u segmentace pro p\u0159id\xE1n\xED, nebo p\u0159ijm\u011Bte SR TID1500.",
  refreshFromImageDisplay: "Obnovit z Image Display",
  notConnectedToHub: "Nep\u0159ipojeno k Hub hubu",
  worklistNoOpenStudy: "Worklist odpov\u011Bd\u011Bla bez otev\u0159en\xE9 studie"
};
var nl3 = {
  viewers: "Viewers:",
  worklist: "Worklist",
  snapshots: "Snapshots",
  volumes: "Volumes",
  segmentations: "Segmentaties",
  measurements: "Metingen",
  currentContext: "Huidige context:",
  none: "geen",
  close: "Sluiten",
  closeContext: "Huidige context sluiten",
  colNum: "#",
  colThumb: "Miniatuur",
  colFilename: "Bestandsnaam",
  colTime: "Tijd",
  colName: "Naam",
  colCrop: "Bijsnijden",
  colBox: "Box",
  colShift: "Verschuiving",
  colPreset: "Voorinstelling",
  colLabel: "Label",
  colSnomed: "SNOMED",
  colVoxels: "Voxels",
  colSegment: "Segment",
  colQuantity: "Grootheid",
  colValue: "Waarde",
  colUnits: "Eenheden",
  noReportSelected: "Geen rapport geselecteerd",
  noSnapshots: "Geen snapshots",
  noSegmentations: "Nog geen segmentaties van Image Display. Vernieuw om de SEG-catalogus te laden.",
  noMeasurements: "Nog geen metingen. Gebruik + op een segmentatie om er een toe te voegen, of ontvang een TID1500-SR.",
  refreshFromImageDisplay: "Vernieuwen vanaf Image Display",
  notConnectedToHub: "Niet verbonden met de Hub-hub",
  worklistNoOpenStudy: "Worklist antwoordde zonder open studie"
};
var el3 = {
  viewers: "\u03A0\u03C1\u03BF\u03B2\u03BF\u03BB\u03B5\u03AF\u03C2:",
  worklist: "Worklist",
  snapshots: "\u03A3\u03C4\u03B9\u03B3\u03BC\u03B9\u03CC\u03C4\u03C5\u03C0\u03B1",
  volumes: "\u038C\u03B3\u03BA\u03BF\u03B9",
  segmentations: "\u03A4\u03BC\u03B7\u03BC\u03B1\u03C4\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03B5\u03B9\u03C2",
  measurements: "\u039C\u03B5\u03C4\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2",
  currentContext: "\u03A4\u03C1\u03AD\u03C7\u03BF\u03BD \u03C0\u03BB\u03B1\u03AF\u03C3\u03B9\u03BF:",
  none: "\u03BA\u03B1\u03BD\u03AD\u03BD\u03B1",
  close: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
  closeContext: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF \u03C4\u03C1\u03AD\u03C7\u03BF\u03BD\u03C4\u03BF\u03C2 \u03C0\u03BB\u03B1\u03B9\u03C3\u03AF\u03BF\u03C5",
  colNum: "#",
  colThumb: "\u039C\u03B9\u03BA\u03C1\u03BF\u03B3\u03C1\u03B1\u03C6\u03AF\u03B1",
  colFilename: "\u038C\u03BD\u03BF\u03BC\u03B1 \u03B1\u03C1\u03C7\u03B5\u03AF\u03BF\u03C5",
  colTime: "\u038F\u03C1\u03B1",
  colName: "\u038C\u03BD\u03BF\u03BC\u03B1",
  colCrop: "\u03A0\u03B5\u03C1\u03B9\u03BA\u03BF\u03C0\u03AE",
  colBox: "Box",
  colShift: "\u039C\u03B5\u03C4\u03B1\u03C4\u03CC\u03C0\u03B9\u03C3\u03B7",
  colPreset: "\u03A0\u03C1\u03BF\u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE",
  colLabel: "\u0395\u03C4\u03B9\u03BA\u03AD\u03C4\u03B1",
  colSnomed: "SNOMED",
  colVoxels: "Voxel",
  colSegment: "\u03A4\u03BC\u03AE\u03BC\u03B1",
  colQuantity: "\u03A0\u03BF\u03C3\u03CC\u03C4\u03B7\u03C4\u03B1",
  colValue: "\u03A4\u03B9\u03BC\u03AE",
  colUnits: "\u039C\u03BF\u03BD\u03AC\u03B4\u03B5\u03C2",
  noReportSelected: "\u0394\u03B5\u03BD \u03B5\u03C0\u03B9\u03BB\u03AD\u03C7\u03B8\u03B7\u03BA\u03B5 \u03B1\u03BD\u03B1\u03C6\u03BF\u03C1\u03AC",
  noSnapshots: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03C3\u03C4\u03B9\u03B3\u03BC\u03B9\u03CC\u03C4\u03C5\u03C0\u03B1",
  noSegmentations: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B1\u03BA\u03CC\u03BC\u03B7 \u03C4\u03BC\u03B7\u03BC\u03B1\u03C4\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03B5\u03B9\u03C2 \u03B1\u03C0\u03CC \u03C4\u03BF Image Display. \u0391\u03BD\u03B1\u03BD\u03B5\u03CE\u03C3\u03C4\u03B5 \u03B3\u03B9\u03B1 \u03C6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03C4\u03BF\u03C5 \u03BA\u03B1\u03C4\u03B1\u03BB\u03CC\u03B3\u03BF\u03C5 SEG.",
  noMeasurements: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B1\u03BA\u03CC\u03BC\u03B7 \u03BC\u03B5\u03C4\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2. \u03A7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF + \u03C3\u03B5 \u03BC\u03B9\u03B1 \u03C4\u03BC\u03B7\u03BC\u03B1\u03C4\u03BF\u03C0\u03BF\u03AF\u03B7\u03C3\u03B7 \u03B3\u03B9\u03B1 \u03C0\u03C1\u03BF\u03C3\u03B8\u03AE\u03BA\u03B7, \u03AE \u03BB\u03AC\u03B2\u03B5\u03C4\u03B5 SR TID1500.",
  refreshFromImageDisplay: "\u0391\u03BD\u03B1\u03BD\u03AD\u03C9\u03C3\u03B7 \u03B1\u03C0\u03CC Image Display",
  notConnectedToHub: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03C3\u03CD\u03BD\u03B4\u03B5\u03C3\u03B7 \u03C3\u03C4\u03BF Slicer hub",
  worklistNoOpenStudy: "\u0397 \u03BB\u03AF\u03C3\u03C4\u03B1 \u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1\u03C2 \u03B1\u03C0\u03AC\u03BD\u03C4\u03B7\u03C3\u03B5 \u03C7\u03C9\u03C1\u03AF\u03C2 \u03B1\u03BD\u03BF\u03B9\u03C7\u03C4\u03AE \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7"
};
var lv3 = {
  viewers: "Skat\u012Bt\u0101ji:",
  worklist: "Worklist",
  snapshots: "Momentuz\u0146\u0113mumi",
  volumes: "Tilpumi",
  segmentations: "Segment\u0101cijas",
  measurements: "M\u0113r\u012Bjumi",
  currentContext: "Pa\u0161reiz\u0113jais konteksts:",
  none: "nav",
  close: "Aizv\u0113rt",
  closeContext: "Aizv\u0113rt pa\u0161reiz\u0113jo kontekstu",
  colNum: "#",
  colThumb: "S\u012Bkt\u0113ls",
  colFilename: "Faila nosaukums",
  colTime: "Laiks",
  colName: "Nosaukums",
  colCrop: "Apgrie\u0161ana",
  colBox: "Box",
  colShift: "Nob\u012Bde",
  colPreset: "Priek\u0161iestat\u012Bjums",
  colLabel: "Eti\u0137ete",
  colSnomed: "SNOMED",
  colVoxels: "Vokse\u013Ci",
  colSegment: "Segments",
  colQuantity: "Lielums",
  colValue: "V\u0113rt\u012Bba",
  colUnits: "Vien\u012Bbas",
  noReportSelected: "Nav atlas\u012Bts zi\u0146ojums",
  noSnapshots: "Nav momentuz\u0146\u0113mumu",
  noSegmentations: "V\u0113l nav segment\u0101ciju no Image Display. Atsvaidziniet, lai iel\u0101d\u0113tu SEG katalogu.",
  noMeasurements: "V\u0113l nav m\u0113r\u012Bjumu. Izmantojiet + pie segment\u0101cijas, lai pievienotu, vai sa\u0146emiet TID1500 SR.",
  refreshFromImageDisplay: "Atsvaidzin\u0101t no Image Display",
  notConnectedToHub: "Nav savienojuma ar Slicer hub",
  worklistNoOpenStudy: "Darba saraksts atbild\u0113ja bez atv\u0113rta p\u0113t\u012Bjuma"
};
var hu3 = {
  viewers: "Megjelen\xEDt\u0151k:",
  worklist: "Worklist",
  snapshots: "Pillanatk\xE9pek",
  volumes: "T\xE9rfogatok",
  segmentations: "Szegment\xE1ci\xF3k",
  measurements: "M\xE9r\xE9sek",
  currentContext: "Aktu\xE1lis kontextus:",
  none: "nincs",
  close: "Bez\xE1r\xE1s",
  closeContext: "Aktu\xE1lis kontextus bez\xE1r\xE1sa",
  colNum: "#",
  colThumb: "Miniat\u0171r",
  colFilename: "F\xE1jln\xE9v",
  colTime: "Id\u0151",
  colName: "N\xE9v",
  colCrop: "V\xE1g\xE1s",
  colBox: "Box",
  colShift: "Eltol\xE1s",
  colPreset: "El\u0151be\xE1ll\xEDt\xE1s",
  colLabel: "C\xEDmke",
  colSnomed: "SNOMED",
  colVoxels: "Voxelek",
  colSegment: "Szegmens",
  colQuantity: "Mennyis\xE9g",
  colValue: "\xC9rt\xE9k",
  colUnits: "Egys\xE9gek",
  noReportSelected: "Nincs kiv\xE1lasztott jelent\xE9s",
  noSnapshots: "Nincs pillanatk\xE9p",
  noSegmentations: "M\xE9g nincs szegment\xE1ci\xF3 az Image Display-r\u0151l. Friss\xEDtsen a SEG-katal\xF3gus bet\xF6lt\xE9s\xE9hez.",
  noMeasurements: "M\xE9g nincs m\xE9r\xE9s. Haszn\xE1lja a + jelet egy szegment\xE1ci\xF3n\xE1l a hozz\xE1ad\xE1shoz, vagy fogadjon TID1500 SR-t.",
  refreshFromImageDisplay: "Friss\xEDt\xE9s az Image Display-r\u0151l",
  notConnectedToHub: "Nincs kapcsolat a Hub hubbal",
  worklistNoOpenStudy: "A munkalista nyitott vizsg\xE1lat n\xE9lk\xFCl v\xE1laszolt"
};
var lt4 = {
  viewers: "Per\u017Ei\u016Bros priemon\u0117s:",
  worklist: "Worklist",
  snapshots: "Momentin\u0117s nuotraukos",
  volumes: "T\u016Briai",
  segmentations: "Segmentacijos",
  measurements: "Matavimai",
  currentContext: "Dabartinis kontekstas:",
  none: "n\u0117ra",
  close: "U\u017Edaryti",
  closeContext: "U\u017Edaryti dabartin\u012F kontekst\u0105",
  colNum: "#",
  colThumb: "Miniati\u016Bra",
  colFilename: "Failo pavadinimas",
  colTime: "Laikas",
  colName: "Pavadinimas",
  colCrop: "Apkirpimas",
  colBox: "Box",
  colShift: "Poslinkis",
  colPreset: "I\u0161ankstin\u0117 nuostata",
  colLabel: "Etiket\u0117",
  colSnomed: "SNOMED",
  colVoxels: "Vokseliai",
  colSegment: "Segmentas",
  colQuantity: "Dydis",
  colValue: "Reik\u0161m\u0117",
  colUnits: "Vienetai",
  noReportSelected: "Nepasirinkta ataskaita",
  noSnapshots: "N\u0117ra momentini\u0173 nuotrauk\u0173",
  noSegmentations: "Dar n\u0117ra segmentacij\u0173 i\u0161 Image Display. Atnaujinkite, kad \u012Fkeltum\u0117te SEG katalog\u0105.",
  noMeasurements: "Dar n\u0117ra matavim\u0173. Naudokite + prie segmentacijos, kad prid\u0117tum\u0117te, arba gaukite TID1500 SR.",
  refreshFromImageDisplay: "Atnaujinti i\u0161 Image Display",
  notConnectedToHub: "N\u0117ra ry\u0161io su Slicer hub",
  worklistNoOpenStudy: "Darb\u0173 s\u0105ra\u0161as atsak\u0117 be atviro tyrimo"
};
var ro4 = {
  viewers: "Vizualizatoare:",
  worklist: "Worklist",
  snapshots: "Capturi",
  volumes: "Volume",
  segmentations: "Segment\u0103ri",
  measurements: "M\u0103sur\u0103tori",
  currentContext: "Context actual:",
  none: "niciunul",
  close: "\xCEnchide",
  closeContext: "\xCEnchide contextul actual",
  colNum: "#",
  colThumb: "Miniatur\u0103",
  colFilename: "Nume fi\u0219ier",
  colTime: "Or\u0103",
  colName: "Nume",
  colCrop: "Decupare",
  colBox: "Box",
  colShift: "Deplasare",
  colPreset: "Presetare",
  colLabel: "Etichet\u0103",
  colSnomed: "SNOMED",
  colVoxels: "Voxel",
  colSegment: "Segment",
  colQuantity: "Cantitate",
  colValue: "Valoare",
  colUnits: "Unit\u0103\u021Bi",
  noReportSelected: "Niciun raport selectat",
  noSnapshots: "Nicio captur\u0103",
  noSegmentations: "\xCEnc\u0103 nu exist\u0103 segment\u0103ri din Image Display. Re\xEEmprosp\u0103ta\u021Bi pentru a \xEEnc\u0103rca catalogul SEG.",
  noMeasurements: "\xCEnc\u0103 nu exist\u0103 m\u0103sur\u0103tori. Folosi\u021Bi + pe o segmentare pentru a ad\u0103uga una, sau primi\u021Bi un SR TID1500.",
  refreshFromImageDisplay: "Re\xEEmprosp\u0103teaz\u0103 din Image Display",
  notConnectedToHub: "Neconectat la hub-ul Hub",
  worklistNoOpenStudy: "Lista de lucru a r\u0103spuns f\u0103r\u0103 studiu deschis"
};
var noRp = {
  viewers: "Visningsprogrammer:",
  worklist: "Worklist",
  snapshots: "\xD8yeblikksbilder",
  volumes: "Volumer",
  segmentations: "Segmenteringer",
  measurements: "M\xE5linger",
  currentContext: "Gjeldende kontekst:",
  none: "ingen",
  close: "Lukk",
  closeContext: "Lukk gjeldende kontekst",
  colNum: "#",
  colThumb: "Miniatyr",
  colFilename: "Filnavn",
  colTime: "Tid",
  colName: "Navn",
  colCrop: "Beskj\xE6ring",
  colBox: "Box",
  colShift: "Forskyvning",
  colPreset: "Forh\xE5ndsinnstilling",
  colLabel: "Etikett",
  colSnomed: "SNOMED",
  colVoxels: "Voksler",
  colSegment: "Segment",
  colQuantity: "St\xF8rrelse",
  colValue: "Verdi",
  colUnits: "Enheter",
  noReportSelected: "Ingen rapport valgt",
  noSnapshots: "Ingen \xF8yeblikksbilder",
  noSegmentations: "Ingen segmenteringer fra Image Display enn\xE5. Oppdater for \xE5 laste SEG-katalogen.",
  noMeasurements: "Ingen m\xE5linger enn\xE5. Bruk + p\xE5 en segmentering for \xE5 legge til, eller motta en TID1500-SR.",
  refreshFromImageDisplay: "Oppdater fra Image Display",
  notConnectedToHub: "Ikke tilkoblet Hub-huben",
  worklistNoOpenStudy: "Worklisten svarte uten \xE5pen studie"
};
var ar4 = {
  viewers: "\u0627\u0644\u0639\u0627\u0631\u0636\u0627\u062A:",
  worklist: "Worklist",
  snapshots: "\u0644\u0642\u0637\u0627\u062A",
  volumes: "\u0627\u0644\u062D\u062C\u0645\u0627\u062A",
  segmentations: "\u0627\u0644\u062A\u062C\u0632\u0626\u0627\u062A",
  measurements: "\u0627\u0644\u0642\u064A\u0627\u0633\u0627\u062A",
  currentContext: "\u0627\u0644\u0633\u064A\u0627\u0642 \u0627\u0644\u062D\u0627\u0644\u064A:",
  none: "\u0644\u0627 \u0634\u064A\u0621",
  close: "\u0625\u063A\u0644\u0627\u0642",
  closeContext: "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0633\u064A\u0627\u0642 \u0627\u0644\u062D\u0627\u0644\u064A",
  colNum: "#",
  colThumb: "\u0645\u0635\u063A\u0651\u0631",
  colFilename: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0644\u0641",
  colTime: "\u0627\u0644\u0648\u0642\u062A",
  colName: "\u0627\u0644\u0627\u0633\u0645",
  colCrop: "\u0642\u0635",
  colBox: "\u0645\u0631\u0628\u0639",
  colShift: "\u0625\u0632\u0627\u062D\u0629",
  colPreset: "\u0625\u0639\u062F\u0627\u062F \u0645\u0633\u0628\u0642",
  colLabel: "\u0627\u0644\u062A\u0633\u0645\u064A\u0629",
  colSnomed: "SNOMED",
  colVoxels: "\u0641\u0648\u0643\u0633\u0644\u0627\u062A",
  colSegment: "\u0645\u0642\u0637\u0639",
  colQuantity: "\u0627\u0644\u0643\u0645\u064A\u0629",
  colValue: "\u0627\u0644\u0642\u064A\u0645\u0629",
  colUnits: "\u0627\u0644\u0648\u062D\u062F\u0627\u062A",
  noReportSelected: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u062E\u062A\u064A\u0627\u0631 \u062A\u0642\u0631\u064A\u0631",
  noSnapshots: "\u0644\u0627 \u0644\u0642\u0637\u0627\u062A",
  noSegmentations: "\u0644\u0627 \u062A\u062C\u0632\u0626\u0627\u062A \u0645\u0646 Image Display \u0628\u0639\u062F. \u062D\u062F\u0651\u062B \u0644\u062A\u062D\u0645\u064A\u0644 \u0643\u062A\u0627\u0644\u0648\u062C SEG.",
  noMeasurements: "\u0644\u0627 \u0642\u064A\u0627\u0633\u0627\u062A \u0628\u0639\u062F. \u0627\u0633\u062A\u062E\u062F\u0645 + \u0639\u0644\u0649 \u062A\u062C\u0632\u0626\u0629 \u0644\u0625\u0636\u0627\u0641\u0629 \u0642\u064A\u0627\u0633\u060C \u0623\u0648 \u0627\u0633\u062A\u0644\u0645 TID1500 SR.",
  refreshFromImageDisplay: "\u062A\u062D\u062F\u064A\u062B \u0645\u0646 Image Display",
  notConnectedToHub: "\u063A\u064A\u0631 \u0645\u062A\u0635\u0644 \u0628\u0645\u0631\u0643\u0632 Hub",
  worklistNoOpenStudy: "\u0627\u0633\u062A\u062C\u0627\u0628\u062A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644 \u0628\u062F\u0648\u0646 \u062F\u0631\u0627\u0633\u0629 \u0645\u0641\u062A\u0648\u062D\u0629"
};
var REPORTING_BY_LOCALE = {
  en: en4,
  ar: ar4,
  fr: fr4,
  es: es3,
  ca: ca3,
  de: de4,
  it: it4,
  pt: pt4,
  ko: ko3,
  pl: pl3,
  uk: uk3,
  cs: cs3,
  nl: nl3,
  el: el3,
  lv: lv3,
  hu: hu3,
  lt: lt4,
  ro: ro4,
  no: noRp
};
function reportingChromeFor(locale) {
  const code = locale || resolveStoredLocale();
  return { ...REPORTING_BY_LOCALE[code] };
}
function applyReportingChrome(root = document, locale) {
  const h = reportingChromeFor(locale);
  root.querySelectorAll("[data-i18n-rp]").forEach((el4) => {
    const key = el4.getAttribute("data-i18n-rp");
    if (!key || !(key in h)) return;
    el4.textContent = h[key];
  });
  root.querySelectorAll("[data-i18n-rp-title]").forEach((el4) => {
    const key = el4.getAttribute(
      "data-i18n-rp-title"
    );
    if (!key || !(key in h)) return;
    el4.title = h[key];
  });
  root.querySelectorAll("[data-i18n-rp-aria]").forEach((el4) => {
    const key = el4.getAttribute(
      "data-i18n-rp-aria"
    );
    if (!key || !(key in h)) return;
    el4.setAttribute("aria-label", h[key]);
  });
}

// ../i18n/segment-labels/fr.json
var fr_default = {
  aorta: "Aorte",
  "aortic valve": "Valve aortique",
  "artery (unspecific)": "Art\xE8re (non sp\xE9cifi\xE9e)",
  "atrioventricular conduction node": "N\u0153ud atrioventriculaire",
  "bile duct": "Voie biliaire",
  brain: "Cerveau",
  "circumflex branch of the coronary artery": "Art\xE8re circonflexe",
  colon: "C\xF4lon",
  "coronary artery": "Art\xE8re coronaire",
  cyst: "Kyste",
  duodenum: "Duod\xE9num",
  esophagus: "\u0152sophage",
  face: "Face",
  gallbladder: "V\xE9sicule biliaire",
  heart: "C\u0153ur",
  "inferior vena cava": "Veine cave inf\xE9rieure",
  kidney: "Rein",
  "left adrenal gland": "Glande surr\xE9nale gauche",
  "left anterior descending coronary artery": "Art\xE8re interventriculaire ant\xE9rieure",
  "left atrium": "Oreillette gauche",
  "left autochthonous back muscle": "Muscle autochthone du dos gauche",
  "left clavicle": "Clavicule gauche",
  "left coronary artery": "Art\xE8re coronaire gauche",
  "left femur": "F\xE9mur gauche",
  "left gluteus maximus": "Grand fessier gauche",
  "left gluteus medius": "Moyen fessier gauche",
  "left gluteus minimus": "Petit fessier gauche",
  "left hip": "Hanche gauche",
  "left humerus": "Hum\xE9rus gauche",
  "left iliac artery": "Art\xE8re iliaque gauche",
  "left iliac vein": "Veine iliaque gauche",
  "left iliopsoas": "Iliopsoas gauche",
  "left kidney": "Rein gauche",
  "left lower lung lobe": "Lobe inf\xE9rieur du poumon gauche",
  "left lung": "Poumon gauche",
  "left rib 1": "C\xF4te 1 gauche",
  "left rib 10": "C\xF4te 10 gauche",
  "left rib 11": "C\xF4te 11 gauche",
  "left rib 12": "C\xF4te 12 gauche",
  "left rib 2": "C\xF4te 2 gauche",
  "left rib 3": "C\xF4te 3 gauche",
  "left rib 4": "C\xF4te 4 gauche",
  "left rib 5": "C\xF4te 5 gauche",
  "left rib 6": "C\xF4te 6 gauche",
  "left rib 7": "C\xF4te 7 gauche",
  "left rib 8": "C\xF4te 8 gauche",
  "left rib 9": "C\xF4te 9 gauche",
  "left scapula": "Omoplate gauche",
  "left upper lung lobe": "Lobe sup\xE9rieur du poumon gauche",
  "left ventricle": "Ventricule gauche",
  liver: "Foie",
  "mitral valve": "Valve mitrale",
  myocardium: "Myocarde",
  pancreas: "Pancr\xE9as",
  "pancreatic duct": "Canal pancr\xE9atique",
  "pathologic calcification": "Calcification pathologique",
  "peripheral zone of prostate": "Zone p\xE9riph\xE9rique de la prostate",
  "portal and splenic vein": "Veine porte et veine spl\xE9nique",
  "primary malignant neoplasm": "N\xE9oplasie maligne primitive",
  prostate: "Prostate",
  "pulmonary artery": "Art\xE8re pulmonaire",
  "pulmonary valve": "Valve pulmonaire",
  "renal vein": "Veine r\xE9nale",
  "right adrenal gland": "Glande surr\xE9nale droite",
  "right atrium": "Oreillette droite",
  "right autochthonous back muscle": "Muscle autochthone du dos droit",
  "right clavicle": "Clavicule droite",
  "right coronary artery": "Art\xE8re coronaire droite",
  "right femur": "F\xE9mur droit",
  "right gluteus maximus": "Grand fessier droit",
  "right gluteus medius": "Moyen fessier droit",
  "right gluteus minimus": "Petit fessier droit",
  "right hip": "Hanche droite",
  "right humerus": "Hum\xE9rus droit",
  "right iliac artery": "Art\xE8re iliaque droite",
  "right iliac vein": "Veine iliaque droite",
  "right iliopsoas": "Iliopsoas droit",
  "right kidney": "Rein droit",
  "right lower lung lobe": "Lobe inf\xE9rieur du poumon droit",
  "right lung": "Poumon droit",
  "right middle lung lobe": "Lobe moyen du poumon droit",
  "right rib 1": "C\xF4te 1 droite",
  "right rib 10": "C\xF4te 10 droite",
  "right rib 11": "C\xF4te 11 droite",
  "right rib 12": "C\xF4te 12 droite",
  "right rib 2": "C\xF4te 2 droite",
  "right rib 3": "C\xF4te 3 droite",
  "right rib 4": "C\xF4te 4 droite",
  "right rib 5": "C\xF4te 5 droite",
  "right rib 6": "C\xF4te 6 droite",
  "right rib 7": "C\xF4te 7 droite",
  "right rib 8": "C\xF4te 8 droite",
  "right rib 9": "C\xF4te 9 droite",
  "right scapula": "Omoplate droite",
  "right upper lung lobe": "Lobe sup\xE9rieur du poumon droit",
  "right ventricle": "Ventricule droit",
  sacrum: "Sacrum",
  "sinoatrial conduction node": "N\u0153ud sinusal",
  "small intestine": "Intestin gr\xEAle",
  "spinal canal": "Canal rachidien",
  spleen: "Rate",
  stomach: "Estomac",
  "superior vena cava": "Veine cave sup\xE9rieure",
  trachea: "Trach\xE9e",
  "transition zone of prostate": "Zone de transition de la prostate",
  "tricuspid valve": "Valve tricuspide",
  "urinary bladder": "Vessie",
  "vein (unspecific)": "Veine (non sp\xE9cifi\xE9e)",
  "vertebrae c1": "Vert\xE8bre C1",
  "vertebrae c2": "Vert\xE8bre C2",
  "vertebrae c3": "Vert\xE8bre C3",
  "vertebrae c4": "Vert\xE8bre C4",
  "vertebrae c5": "Vert\xE8bre C5",
  "vertebrae c6": "Vert\xE8bre C6",
  "vertebrae c7": "Vert\xE8bre C7",
  "vertebrae disk c2/c3": "Disque intervert\xE9bral C2/C3",
  "vertebrae disk c3/c4": "Disque intervert\xE9bral C3/C4",
  "vertebrae disk c4/c5": "Disque intervert\xE9bral C4/C5",
  "vertebrae disk c5/c6": "Disque intervert\xE9bral C5/C6",
  "vertebrae disk c6/c7": "Disque intervert\xE9bral C6/C7",
  "vertebrae disk c7/t1": "Disque intervert\xE9bral C7/T1",
  "vertebrae disk l1/l2": "Disque intervert\xE9bral L1/L2",
  "vertebrae disk l2/l3": "Disque intervert\xE9bral L2/L3",
  "vertebrae disk l3/l4": "Disque intervert\xE9bral L3/L4",
  "vertebrae disk l4/l5": "Disque intervert\xE9bral L4/L5",
  "vertebrae disk t1/t2": "Disque intervert\xE9bral T1/T2",
  "vertebrae disk t10/t11": "Disque intervert\xE9bral T10/T11",
  "vertebrae disk t11/t12": "Disque intervert\xE9bral T11/T12",
  "vertebrae disk t12/l1": "Disque intervert\xE9bral T12/L1",
  "vertebrae disk t2/t3": "Disque intervert\xE9bral T2/T3",
  "vertebrae disk t3/t4": "Disque intervert\xE9bral T3/T4",
  "vertebrae disk t4/t5": "Disque intervert\xE9bral T4/T5",
  "vertebrae disk t5/t6": "Disque intervert\xE9bral T5/T6",
  "vertebrae disk t6/t7": "Disque intervert\xE9bral T6/T7",
  "vertebrae disk t7/t8": "Disque intervert\xE9bral T7/T8",
  "vertebrae disk t8/t9": "Disque intervert\xE9bral T8/T9",
  "vertebrae disk t9/t10": "Disque intervert\xE9bral T9/T10",
  "vertebrae l1": "Vert\xE8bre L1",
  "vertebrae l2": "Vert\xE8bre L2",
  "vertebrae l3": "Vert\xE8bre L3",
  "vertebrae l4": "Vert\xE8bre L4",
  "vertebrae l5": "Vert\xE8bre L5",
  "vertebrae t1": "Vert\xE8bre T1",
  "vertebrae t10": "Vert\xE8bre T10",
  "vertebrae t11": "Vert\xE8bre T11",
  "vertebrae t12": "Vert\xE8bre T12",
  "vertebrae t2": "Vert\xE8bre T2",
  "vertebrae t3": "Vert\xE8bre T3",
  "vertebrae t4": "Vert\xE8bre T4",
  "vertebrae t5": "Vert\xE8bre T5",
  "vertebrae t6": "Vert\xE8bre T6",
  "vertebrae t7": "Vert\xE8bre T7",
  "vertebrae t8": "Vert\xE8bre T8",
  "vertebrae t9": "Vert\xE8bre T9",
  "vertebrae disk l5/s1": "Disque intervert\xE9bral L5/S1"
};

// ../i18n/segment-labels.ts
var CACHE_STORAGE_KEY = "pw46.segmentLabelCache";
var SEGMENT_LABELS_STATIC = Object.freeze({
  fr: Object.freeze(fr_default)
});
function translateTargetForLocale(locale) {
  if (locale === "en") return null;
  const map = {
    ar: "ar",
    fr: "fr",
    es: "es",
    ca: "ca",
    de: "de",
    it: "it",
    pt: "pt",
    ko: "ko",
    pl: "pl",
    uk: "uk",
    cs: "cs",
    nl: "nl",
    el: "el",
    lv: "lv",
    hu: "hu",
    lt: "lt",
    ro: "ro",
    no: "no"
  };
  return map[locale] ?? null;
}
function normalizeEnglish(label) {
  return String(label || "").trim().replace(/\s+/g, " ");
}
function segmentLabelCacheKey(label, terminology) {
  const typeVal = String(terminology?.type?.value || "").trim();
  const modVal = String(terminology?.typeModifier?.value || "").trim();
  if (typeVal) return modVal ? `${typeVal}|${modVal}` : typeVal;
  return normalizeEnglish(label).toLowerCase();
}
function englishDisplay(label, terminology) {
  const fromLabel = normalizeEnglish(label);
  if (fromLabel) return fromLabel;
  return String(terminology?.type?.meaning || "").trim();
}
function loadPersistentCache() {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(CACHE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return {};
    const out = {};
    for (const [k2, v2] of Object.entries(parsed)) {
      if (typeof v2 === "string" && v2.trim()) out[k2] = v2.trim();
    }
    return out;
  } catch {
    return {};
  }
}
function savePersistentCache(store) {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(CACHE_STORAGE_KEY, JSON.stringify(store));
  } catch {
  }
}
var memoryCache = { ...loadPersistentCache() };
var inflight = /* @__PURE__ */ new Map();
function cacheGet(locale, key, english) {
  const full = `${locale}|${key}`;
  const staticMap = SEGMENT_LABELS_STATIC[locale];
  if (staticMap?.[key]) return staticMap[key];
  if (staticMap?.[full]) return staticMap[full];
  const enKey = normalizeEnglish(english || "").toLowerCase();
  if (enKey && staticMap?.[enKey]) return staticMap[enKey];
  return memoryCache[full] || (enKey ? memoryCache[`${locale}|${enKey}`] : void 0);
}
function cacheSet(locale, key, value, english) {
  const full = `${locale}|${key}`;
  memoryCache[full] = value;
  const enKey = normalizeEnglish(english || "").toLowerCase();
  if (enKey && enKey !== key) memoryCache[`${locale}|${enKey}`] = value;
  savePersistentCache(memoryCache);
}
function segmentDisplayNameSync(label, terminology, locale) {
  const code = locale || resolveStoredLocale();
  const en5 = englishDisplay(label, terminology);
  if (!en5) return "";
  if (code === "en") return en5;
  const key = segmentLabelCacheKey(en5, terminology);
  return cacheGet(code, key, en5) || en5;
}
async function translateViaHub(texts, target, hubOrigin) {
  const origin = String(hubOrigin || "").replace(/\/$/, "");
  if (!origin || !texts.length) return texts.map(() => null);
  const url = `${origin}/api/hub/translate`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ texts, target, source: "en" })
  });
  if (!res.ok) return texts.map(() => null);
  const data = await res.json();
  const list = Array.isArray(data.translations) ? data.translations : [];
  return texts.map((_2, i) => {
    const t = list[i];
    return typeof t === "string" && t.trim() ? t.trim() : null;
  });
}
async function ensureSegmentLabelsTranslated(items, opts) {
  const locale = opts.locale || resolveStoredLocale();
  const out = /* @__PURE__ */ new Map();
  const target = translateTargetForLocale(locale);
  const need = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of items) {
    const en5 = englishDisplay(item.label, item.terminology);
    if (!en5) continue;
    if (!target) {
      out.set(en5, en5);
      continue;
    }
    const key = segmentLabelCacheKey(en5, item.terminology);
    const hit = cacheGet(locale, key, en5);
    if (hit) {
      out.set(en5, hit);
      continue;
    }
    if (!seen.has(key)) {
      seen.add(key);
      need.push({ en: en5, key });
    }
  }
  if (!target || !need.length) {
    for (const item of items) {
      const en5 = englishDisplay(item.label, item.terminology);
      if (en5 && !out.has(en5)) out.set(en5, en5);
    }
    return out;
  }
  const batchKey = `${locale}|${need.map((n) => n.key).join(",")}`;
  let promise = inflight.get(batchKey);
  if (!promise) {
    promise = (async () => {
      const translated = await translateViaHub(
        need.map((n) => n.en),
        target,
        opts.hubOrigin
      );
      need.forEach((n, i) => {
        const t = translated[i];
        if (t && t !== n.en) cacheSet(locale, n.key, t, n.en);
      });
      return "";
    })();
    inflight.set(batchKey, promise);
    try {
      await promise;
    } finally {
      inflight.delete(batchKey);
    }
  } else {
    await promise;
  }
  for (const item of items) {
    const en5 = englishDisplay(item.label, item.terminology);
    if (!en5) continue;
    const key = segmentLabelCacheKey(en5, item.terminology);
    out.set(en5, cacheGet(locale, key, en5) || en5);
  }
  return out;
}

// config.ts
var LOG_PREFIX = "[@slicer-hub/reporting]";
var PRODUCT_NAME = "RPT";
var REPORTING_ACTOR = "REPORTING_CLIENT";
var SUBSCRIBE_EVENTS = [
  $i,
  xi,
  k("STATUS"),
  Zi,
  Be,
  Wi,
  Gi,
  Ji,
  Fi
];
var THEME_STORAGE_KEY = "pw46.reporting.theme";
var THEME_SLICERLIVE = "slicerlive";
var THEME_OHIF = "ohif";
var COLUMN_ORDER_STORAGE_KEY = "pw46.reporting.tableColumnOrder";
var TABLE_COLUMN_ORDER_DEFAULT = "controls-first";
var USER_NAME_KEY = "pw46.reporting.userName";
var USER_HUB_STARTED_AT_KEY = "pw46.reporting.userName.hubStartedAt";
var USER_HUB_ORIGIN_KEY = "pw46.reporting.userName.hubOrigin";
var HUB_CREDENTIALS = {
  client_id: "client_id_3d_Slicer",
  client_secret: "client_secret_3d_Slicer"
};
var HUB_DEFINITIONS = {
  local: {
    label: "3D Slicer local",
    hubEndpoint: "http://127.0.0.1:2018/api/hub",
    authorizeEndpoint: "http://127.0.0.1:2018/oauth/login",
    tokenEndpoint: "http://127.0.0.1:2018/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloud: {
    label: "3D Slicer cloud (mock)",
    hubEndpoint: "https://bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloudOidc: {
    label: "3D Slicer cloud (OIDC)",
    hubEndpoint: "https://oidc.bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  }
};
function isHostedOnCastHub(location = window.location) {
  const path = String(location.pathname || "");
  return path.startsWith("/worklist-client") || path.startsWith("/reporting-client");
}
function shouldUseSameOriginHub(location = window.location) {
  return isHostedOnCastHub(location) || Qt(location);
}
var SPA_SOURCE_KEY = "pw46.hub.spaSource";
var SPA_SOURCES = ["auto", "dev", "hub"];
function normalizeSpaSource(value) {
  return SPA_SOURCES.includes(value) ? value : "auto";
}
function getSpaSource(location = window.location) {
  try {
    const fromQuery = new URL(location.href).searchParams.get("spa");
    if (fromQuery) return normalizeSpaSource(fromQuery);
  } catch {
  }
  try {
    return normalizeSpaSource(localStorage.getItem(SPA_SOURCE_KEY));
  } catch {
    return "auto";
  }
}
function setSpaSource(next, location = window.location) {
  const value = normalizeSpaSource(next);
  try {
    localStorage.setItem(SPA_SOURCE_KEY, value);
  } catch {
  }
  try {
    const url = new URL(location.href);
    if (value === "auto") url.searchParams.delete("spa");
    else url.searchParams.set("spa", value);
    window.history.replaceState(null, "", url.toString());
  } catch {
  }
  return value;
}
function applySpaParam(url) {
  const spa = getSpaSource();
  if (spa === "auto") url.searchParams.delete("spa");
  else url.searchParams.set("spa", spa);
  return url;
}
function shouldUseHubMountUrls(location = window.location) {
  const spa = getSpaSource(location);
  if (spa === "dev") return false;
  if (spa === "hub") return true;
  return shouldUseSameOriginHub(location);
}
function resolveMountOrigin(location, hubOrigin) {
  const fromArg = String(hubOrigin || "").trim().replace(/\/$/, "");
  if (fromArg) return fromArg;
  if (shouldUseSameOriginHub(location)) return location.origin;
  try {
    return new URL(HUB_DEFINITIONS.local.hubEndpoint).origin;
  } catch {
    return location.origin;
  }
}
function sameOriginHubDefinition(origin, label) {
  return {
    label,
    hubEndpoint: `${origin}/api/hub`,
    authorizeEndpoint: `${origin}/oauth/login`,
    tokenEndpoint: `${origin}/oauth/token`,
    ...HUB_CREDENTIALS
  };
}
function getHubDefinitions(location = window.location) {
  if (!shouldUseSameOriginHub(location)) {
    return HUB_DEFINITIONS;
  }
  const origin = location.origin;
  const hosted = sameOriginHubDefinition(origin, "This Slicer hub");
  return {
    local: { ...hosted, label: "This Slicer hub" },
    cloud: { ...hosted, label: "This Slicer hub" }
  };
}
var VIEWER_URLS_LOCAL = {
  ira: "http://localhost:8130/ira/ira.html",
  ohif: "http://localhost:3000/viewer/",
  slim: "http://localhost:3001/"
};
var WORKLIST_URL_LOCAL = "http://localhost:8140/";
function resolveViewerUrls(location = window.location, opts = {}) {
  if (!shouldUseHubMountUrls(location)) {
    return { ...VIEWER_URLS_LOCAL };
  }
  const origin = resolveMountOrigin(location, opts.hubOrigin);
  return {
    ira: `${origin}/slicerlive/`,
    ohif: `${origin}/ohif/viewer/`,
    slim: `${origin}/slim/`
  };
}
function resolveWorklistUrl(location = window.location, opts = {}) {
  if (!shouldUseHubMountUrls(location)) {
    return WORKLIST_URL_LOCAL;
  }
  return `${resolveMountOrigin(location, opts.hubOrigin)}/worklist-client/`;
}
function hubOriginFromEndpoint(hubEndpoint2) {
  const trimmed = String(hubEndpoint2 || "").trim();
  if (!trimmed) return null;
  try {
    return new URL(trimmed).origin;
  } catch {
    return null;
  }
}
function resolveHubMetricsUrl(hubEndpoint2) {
  const trimmed = String(hubEndpoint2 || "").trim();
  if (!trimmed) return null;
  try {
    const base = trimmed.endsWith("/") ? trimmed : `${trimmed}/`;
    return new URL("admin/metrics", base).href;
  } catch {
    return null;
  }
}
function getStoredUserName() {
  try {
    return localStorage.getItem(USER_NAME_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function getStoredUserHubStartedAt() {
  try {
    return localStorage.getItem(USER_HUB_STARTED_AT_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function getStoredUserHubOrigin() {
  try {
    return localStorage.getItem(USER_HUB_ORIGIN_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function clearStoredUserName() {
  try {
    localStorage.removeItem(USER_NAME_KEY);
    localStorage.removeItem(USER_HUB_STARTED_AT_KEY);
    localStorage.removeItem(USER_HUB_ORIGIN_KEY);
  } catch {
  }
}
function setStoredUserName(userName, hubStartedAt, hubOrigin) {
  const trimmed = String(userName || "").trim();
  try {
    if (!trimmed) {
      clearStoredUserName();
      return;
    }
    localStorage.setItem(USER_NAME_KEY, trimmed);
    if (hubStartedAt) {
      localStorage.setItem(USER_HUB_STARTED_AT_KEY, hubStartedAt);
    }
    if (hubOrigin) {
      localStorage.setItem(USER_HUB_ORIGIN_KEY, hubOrigin);
    }
  } catch {
  }
}
async function fetchHubStartedAt(hubEndpoint2) {
  const metricsUrl = resolveHubMetricsUrl(hubEndpoint2);
  if (!metricsUrl) return null;
  try {
    const response = await fetch(metricsUrl, { method: "GET" });
    if (!response.ok) return null;
    const data = await response.json();
    const started = data?.started_at;
    return typeof started === "string" && started.trim() ? started.trim() : null;
  } catch {
    return null;
  }
}
function getStoredTheme() {
  try {
    const value = localStorage.getItem(THEME_STORAGE_KEY)?.trim();
    if (value === THEME_OHIF || value === THEME_SLICERLIVE) return value;
  } catch {
  }
  return THEME_SLICERLIVE;
}
function setStoredTheme(theme) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
  }
}
function getStoredTableColumnOrder() {
  try {
    const value = localStorage.getItem(COLUMN_ORDER_STORAGE_KEY)?.trim();
    if (value === "controls-first" || value === "identity-first") return value;
  } catch {
  }
  return TABLE_COLUMN_ORDER_DEFAULT;
}
function setStoredTableColumnOrder(order) {
  try {
    localStorage.setItem(COLUMN_ORDER_STORAGE_KEY, order);
  } catch {
  }
}

// segdb-lookup.ts
var SEGDB_BY_ID = Object.freeze(
  {
    "LEFT_ADRENAL_GLAND": {
      "name": "Left adrenal gland",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "23451007",
      "typeScheme": "SCT",
      "typeMeaning": "Adrenal structure",
      "modifier": "M_LEFT"
    },
    "RIGHT_ADRENAL_GLAND": {
      "name": "Right adrenal gland",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "23451007",
      "typeScheme": "SCT",
      "typeMeaning": "Adrenal structure",
      "modifier": "M_RIGHT"
    },
    "AORTA": {
      "name": "Aorta",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "15825003",
      "typeScheme": "SCT",
      "typeMeaning": "Aortic structure",
      "modifier": ""
    },
    "LEFT_AUTOCHTHONOUS_BACK_MUSCLE": {
      "name": "Left autochthonous back muscle",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "244849004",
      "typeScheme": "SCT",
      "typeMeaning": "Autochthonous back muscle structure",
      "modifier": "M_LEFT"
    },
    "RIGHT_AUTOCHTHONOUS_BACK_MUSCLE": {
      "name": "Right autochthonous back muscle",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "244849004",
      "typeScheme": "SCT",
      "typeMeaning": "Autochthonous back muscle structure",
      "modifier": "M_RIGHT"
    },
    "BRAIN": {
      "name": "Brain",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "12738006",
      "typeScheme": "SCT",
      "typeMeaning": "Brain structure",
      "modifier": ""
    },
    "LEFT_CLAVICLE": {
      "name": "Left clavicle",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "51299004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of clavicle",
      "modifier": "M_LEFT"
    },
    "RIGHT_CLAVICLE": {
      "name": "Right clavicle",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "51299004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of clavicle",
      "modifier": "M_RIGHT"
    },
    "COLON": {
      "name": "Colon",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "71854001",
      "typeScheme": "SCT",
      "typeMeaning": "Colon structure",
      "modifier": ""
    },
    "DUODENUM": {
      "name": "Duodenum",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "38848004",
      "typeScheme": "SCT",
      "typeMeaning": "Duodenal structure",
      "modifier": ""
    },
    "ESOPHAGUS": {
      "name": "Esophagus",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "32849002",
      "typeScheme": "SCT",
      "typeMeaning": "Esophageal structure",
      "modifier": ""
    },
    "FACE": {
      "name": "Face",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "89545001",
      "typeScheme": "SCT",
      "typeMeaning": "Face structure",
      "modifier": ""
    },
    "LEFT_FEMUR": {
      "name": "Left femur",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "71341001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of femur",
      "modifier": "M_LEFT"
    },
    "RIGHT_FEMUR": {
      "name": "Right femur",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "71341001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of femur",
      "modifier": "M_RIGHT"
    },
    "GALLBLADDER": {
      "name": "Gallbladder",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "28231008",
      "typeScheme": "SCT",
      "typeMeaning": "Gallbladder structure",
      "modifier": ""
    },
    "LEFT_GLUTEUS_MAXIMUS": {
      "name": "Left gluteus maximus",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "181674001",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus maximus",
      "modifier": "M_LEFT"
    },
    "RIGHT_GLUTEUS_MAXIMUS": {
      "name": "Right gluteus maximus",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "181674001",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus maximus",
      "modifier": "M_RIGHT"
    },
    "LEFT_GLUTEUS_MEDIUS": {
      "name": "Left gluteus medius",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "78333006",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus medius",
      "modifier": "M_LEFT"
    },
    "RIGHT_GLUTEUS_MEDIUS": {
      "name": "Right gluteus medius",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "78333006",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus medius",
      "modifier": "M_RIGHT"
    },
    "LEFT_GLUTEUS_MINIMUS": {
      "name": "Left gluteus minimus",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "75297007",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus minumus",
      "modifier": "M_LEFT"
    },
    "RIGHT_GLUTEUS_MINIMUS": {
      "name": "Right gluteus minimus",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "75297007",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the gluteus minumus",
      "modifier": "M_RIGHT"
    },
    "LEFT_ATRIUM": {
      "name": "Left atrium",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "59652004",
      "typeScheme": "SCT",
      "typeMeaning": "Atrial structure",
      "modifier": "M_LEFT"
    },
    "RIGHT_ATRIUM": {
      "name": "Right atrium",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "59652004",
      "typeScheme": "SCT",
      "typeMeaning": "Atrial structure",
      "modifier": "M_RIGHT"
    },
    "MYOCARDIUM": {
      "name": "Myocardium",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "74281007",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the myocardium",
      "modifier": ""
    },
    "LEFT_VENTRICLE": {
      "name": "Left ventricle",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "87878005",
      "typeScheme": "SCT",
      "typeMeaning": "Left cardiac ventricular structure",
      "modifier": ""
    },
    "RIGHT_VENTRICLE": {
      "name": "Right ventricle",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "53085002",
      "typeScheme": "SCT",
      "typeMeaning": "Right cardiac ventricular structure",
      "modifier": ""
    },
    "LEFT_HIP": {
      "name": "Left hip",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "29836001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of the hip",
      "modifier": ""
    },
    "RIGHT_HIP": {
      "name": "Right hip",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "29836001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of the hip",
      "modifier": ""
    },
    "LEFT_HUMERUS": {
      "name": "Left humerus",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "85050009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of humerus",
      "modifier": "M_LEFT"
    },
    "RIGHT_HUMERUS": {
      "name": "Right humerus",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "85050009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of humerus",
      "modifier": "M_RIGHT"
    },
    "LEFT_ILIAC_ARTERY": {
      "name": "Left iliac artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "73634005",
      "typeScheme": "SCT",
      "typeMeaning": "Common iliac artery structure",
      "modifier": "M_LEFT"
    },
    "RIGHT_ILIAC_ARTERY": {
      "name": "Right iliac artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "73634005",
      "typeScheme": "SCT",
      "typeMeaning": "Common iliac artery structure",
      "modifier": "M_RIGHT"
    },
    "LEFT_ILIAC_VEIN": {
      "name": "Left iliac vein",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "46027005",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of common iliac vein",
      "modifier": "M_LEFT"
    },
    "RIGHT_ILIAC_VEIN": {
      "name": "Right iliac vein",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "46027005",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of common iliac vein",
      "modifier": "M_RIGHT"
    },
    "LEFT_ILIOPSOAS": {
      "name": "Left iliopsoas",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "68455001",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the iliopsoas",
      "modifier": "M_LEFT"
    },
    "RIGHT_ILIOPSOAS": {
      "name": "Right iliopsoas",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "68455001",
      "typeScheme": "SCT",
      "typeMeaning": "Muscle structure of the iliopsoas",
      "modifier": "M_RIGHT"
    },
    "INFERIOR_VENA_CAVA": {
      "name": "Inferior vena cava",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "64131007",
      "typeScheme": "SCT",
      "typeMeaning": "Inferior vena cava structure",
      "modifier": ""
    },
    "SUPERIOR_VENA_CAVA": {
      "name": "Superior vena cava",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "48345005",
      "typeScheme": "SCT",
      "typeMeaning": "Superior vena cava structure",
      "modifier": ""
    },
    "LEFT_KIDNEY": {
      "name": "Left kidney",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "64033007",
      "typeScheme": "SCT",
      "typeMeaning": "Kidney structure",
      "modifier": "M_LEFT"
    },
    "RIGHT_KIDNEY": {
      "name": "Right kidney",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "64033007",
      "typeScheme": "SCT",
      "typeMeaning": "Kidney structure",
      "modifier": "M_RIGHT"
    },
    "KIDNEY": {
      "name": "Kidney",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "64033007",
      "typeScheme": "SCT",
      "typeMeaning": "Kidney structure",
      "modifier": ""
    },
    "LIVER": {
      "name": "Liver",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "10200004",
      "typeScheme": "SCT",
      "typeMeaning": "Liver structure",
      "modifier": ""
    },
    "LEFT_LUNG": {
      "name": "Left lung",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "39607008",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of lung",
      "modifier": "M_LEFT"
    },
    "RIGHT_LUNG": {
      "name": "Right lung",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "39607008",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of lung",
      "modifier": "M_RIGHT"
    },
    "LEFT_LOWER_LUNG_LOBE": {
      "name": "Left lower lung lobe",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "90572001",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of lower lobe of lung",
      "modifier": "M_LEFT"
    },
    "RIGHT_LOWER_LUNG_LOBE": {
      "name": "Right lower lung lobe",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "90572001",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of lower lobe of lung",
      "modifier": "M_RIGHT"
    },
    "RIGHT_MIDDLE_LUNG_LOBE": {
      "name": "Right middle lung lobe",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "72481006",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of middle lobe of right lung",
      "modifier": ""
    },
    "LEFT_UPPER_LUNG_LOBE": {
      "name": "Left upper lung lobe",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "45653009",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of upper lobe of lung",
      "modifier": "M_LEFT"
    },
    "RIGHT_UPPER_LUNG_LOBE": {
      "name": "Right upper lung lobe",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "45653009",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of upper lobe of lung",
      "modifier": "M_RIGHT"
    },
    "PANCREAS": {
      "name": "Pancreas",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "15776009",
      "typeScheme": "SCT",
      "typeMeaning": "Pancreatic structure",
      "modifier": ""
    },
    "PORTAL_AND_SPLENIC_VEIN": {
      "name": "Portal and splenic vein",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "29092000",
      "typeScheme": "SCT",
      "typeMeaning": "Venous structure",
      "modifier": ""
    },
    "PULMONARY_ARTERY": {
      "name": "Pulmonary artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "81040000",
      "typeScheme": "SCT",
      "typeMeaning": "Pulmonary artery structure",
      "modifier": ""
    },
    "LEFT_RIB_10": {
      "name": "Left rib 10",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "77644006",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of tenth rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_11": {
      "name": "Left rib 11",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "58830002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of eleventh rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_12": {
      "name": "Left rib 12",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "43993008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of twelfth rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_1": {
      "name": "Left rib 1",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "48535007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of first rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_2": {
      "name": "Left rib 2",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "78247007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of second rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_3": {
      "name": "Left rib 3",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "25888004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of third rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_4": {
      "name": "Left rib 4",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "25523003",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of fourth rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_5": {
      "name": "Left rib 5",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "15339008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of fifth rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_6": {
      "name": "Left rib 6",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "59558009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of sixth rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_7": {
      "name": "Left rib 7",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "24915002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of seventh rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_8": {
      "name": "Left rib 8",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "5953002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of eight rib",
      "modifier": "M_LEFT"
    },
    "LEFT_RIB_9": {
      "name": "Left rib 9",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "22565002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of ninth rib",
      "modifier": "M_LEFT"
    },
    "RIGHT_RIB_10": {
      "name": "Right rib 10",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "77644006",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of tenth rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_11": {
      "name": "Right rib 11",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "58830002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of eleventh rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_12": {
      "name": "Right rib 12",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "43993008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of twelfth rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_1": {
      "name": "Right rib 1",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "48535007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of first rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_2": {
      "name": "Right rib 2",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "78247007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of second rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_3": {
      "name": "Right rib 3",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "25888004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of third rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_4": {
      "name": "Right rib 4",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "25523003",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of fourth rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_5": {
      "name": "Right rib 5",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "15339008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of fifth rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_6": {
      "name": "Right rib 6",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "59558009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of sixth rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_7": {
      "name": "Right rib 7",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "24915002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of seventh rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_8": {
      "name": "Right rib 8",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "5953002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of eight rib",
      "modifier": "M_RIGHT"
    },
    "RIGHT_RIB_9": {
      "name": "Right rib 9",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "22565002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of ninth rib",
      "modifier": "M_RIGHT"
    },
    "SACRUM": {
      "name": "Sacrum",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "54735007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of sacrum",
      "modifier": ""
    },
    "LEFT_SCAPULA": {
      "name": "Left scapula",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "79601000",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of scapula",
      "modifier": "M_LEFT"
    },
    "RIGHT_SCAPULA": {
      "name": "Right scapula",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "79601000",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of scapula",
      "modifier": "M_RIGHT"
    },
    "SMALL_INTESTINE": {
      "name": "Small intestine",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "30315005",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of small intestine",
      "modifier": ""
    },
    "SPLEEN": {
      "name": "Spleen",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "78961009",
      "typeScheme": "SCT",
      "typeMeaning": "Splenic structure",
      "modifier": ""
    },
    "STOMACH": {
      "name": "Stomach",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "69695003",
      "typeScheme": "SCT",
      "typeMeaning": "Stomach structure",
      "modifier": ""
    },
    "TRACHEA": {
      "name": "Trachea",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "44567001",
      "typeScheme": "SCT",
      "typeMeaning": "Tracheal structure",
      "modifier": ""
    },
    "URINARY_BLADDER": {
      "name": "Urinary bladder",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "89837001",
      "typeScheme": "SCT",
      "typeMeaning": "Urinary bladder structure",
      "modifier": ""
    },
    "VERTEBRAE_C1": {
      "name": "Vertebrae C1",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "14806007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C1",
      "modifier": ""
    },
    "VERTEBRAE_C2": {
      "name": "Vertebrae C2",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "39976000",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C2",
      "modifier": ""
    },
    "VERTEBRAE_C3": {
      "name": "Vertebrae C3",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "113205007",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C3",
      "modifier": ""
    },
    "VERTEBRAE_C4": {
      "name": "Vertebrae C4",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "5329002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C4",
      "modifier": ""
    },
    "VERTEBRAE_C5": {
      "name": "Vertebrae C5",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "36978003",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C5",
      "modifier": ""
    },
    "VERTEBRAE_C6": {
      "name": "Vertebrae C6",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "36054005",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C6",
      "modifier": ""
    },
    "VERTEBRAE_C7": {
      "name": "Vertebrae C7",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "87391001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae C7",
      "modifier": ""
    },
    "VERTEBRAE_L1": {
      "name": "Vertebrae L1",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "66794005",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae L1",
      "modifier": ""
    },
    "VERTEBRAE_L2": {
      "name": "Vertebrae L2",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "14293000",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae L2",
      "modifier": ""
    },
    "VERTEBRAE_L3": {
      "name": "Vertebrae L3",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "36470004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae L3",
      "modifier": ""
    },
    "VERTEBRAE_L4": {
      "name": "Vertebrae L4",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "11994002",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae L4",
      "modifier": ""
    },
    "VERTEBRAE_L5": {
      "name": "Vertebrae L5",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "49668003",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae L5",
      "modifier": ""
    },
    "VERTEBRAE_T10": {
      "name": "Vertebrae T10",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "7610001",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T10",
      "modifier": ""
    },
    "VERTEBRAE_T11": {
      "name": "Vertebrae T11",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "12989004",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T11",
      "modifier": ""
    },
    "VERTEBRAE_T12": {
      "name": "Vertebrae T12",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "23215003",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T12",
      "modifier": ""
    },
    "VERTEBRAE_T1": {
      "name": "Vertebrae T1",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "64864005",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T1",
      "modifier": ""
    },
    "VERTEBRAE_T2": {
      "name": "Vertebrae T2",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "53733008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T2",
      "modifier": ""
    },
    "VERTEBRAE_T3": {
      "name": "Vertebrae T3",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "1626008",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T3",
      "modifier": ""
    },
    "VERTEBRAE_T4": {
      "name": "Vertebrae T4",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "73071006",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T4",
      "modifier": ""
    },
    "VERTEBRAE_T5": {
      "name": "Vertebrae T5",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "56401006",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T5",
      "modifier": ""
    },
    "VERTEBRAE_T6": {
      "name": "Vertebrae T6",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "45296009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T6",
      "modifier": ""
    },
    "VERTEBRAE_T7": {
      "name": "Vertebrae T7",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "62487009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T7",
      "modifier": ""
    },
    "VERTEBRAE_T8": {
      "name": "Vertebrae T8",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "11068009",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T8",
      "modifier": ""
    },
    "VERTEBRAE_T9": {
      "name": "Vertebrae T9",
      "categoryCode": "85756007",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body tissue structure",
      "typeCode": "82687006",
      "typeScheme": "SCT",
      "typeMeaning": "Bone structure of vertebrae T9",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C2C3": {
      "name": "Vertebrae Disk C2/C3",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "1078209008",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of second cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C3C4": {
      "name": "Vertebrae Disk C3/C4",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "58820006",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of third cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C4C5": {
      "name": "Vertebrae Disk C4/C5",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "49400002",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of fourth cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C5C6": {
      "name": "Vertebrae Disk C5/C6",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "73959003",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of fifth cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C6C7": {
      "name": "Vertebrae Disk C6/C7",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "75095006",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of sixth cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_C7T1": {
      "name": "Vertebrae Disk C7/T1",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "37414007",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of seventh cervical vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T1T2": {
      "name": "Vertebrae Disk T1/T2",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "40908007",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of first thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T2T3": {
      "name": "Vertebrae Disk T2/T3",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "6004007",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of second thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T3T4": {
      "name": "Vertebrae Disk T3/T4",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "2620004",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of third thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T4T5": {
      "name": "Vertebrae Disk T4/T5",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "82965004",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of fourth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T5T6": {
      "name": "Vertebrae Disk T5/T6",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "72692000",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of fifth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T6T7": {
      "name": "Vertebrae Disk T6/T7",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "74401007",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of sixth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T7T8": {
      "name": "Vertebrae Disk T7/T8",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "28693002",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of seventh thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T8T9": {
      "name": "Vertebrae Disk T8/T9",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "9188009",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of eighth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T9T10": {
      "name": "Vertebrae Disk T9/T10",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "113209001",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of ninth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T10T11": {
      "name": "Vertebrae Disk T10/T11",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "34959001",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of tenth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T11T12": {
      "name": "Vertebrae Disk T11/T12",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "1537001",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of eleventh thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_T12L1": {
      "name": "Vertebrae Disk T12/L1",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "76206002",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of twelfth thoracic vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_L1L2": {
      "name": "Vertebrae Disk L1/L2",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "80064006",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of first lumbar vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_L2L3": {
      "name": "Vertebrae Disk L2/L3",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "67459009",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of second lumbar vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_L3L4": {
      "name": "Vertebrae Disk L3/L4",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "62551000",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of third lumbar vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_L4L5": {
      "name": "Vertebrae Disk L4/L5",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "84020006",
      "typeScheme": "SCT",
      "typeMeaning": "Intervertebral disc structure of fourth lumbar vertebra (body structure)",
      "modifier": ""
    },
    "VERTEBRAE_DISK_L5S1": {
      "name": "Vertebrae Disk L5/S1",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "715056000",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of intervertebral disc of L5 and S1 (body structure)",
      "modifier": ""
    },
    "CORONARY_ARTERY_RIGHT": {
      "name": "Right Coronary Artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "13647002",
      "typeScheme": "SCT",
      "typeMeaning": "Right coronary artery structure",
      "modifier": ""
    },
    "CORONARY_ARTERY_LEFT": {
      "name": "Left Coronary Artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "3227004",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of left main coronary artery",
      "modifier": ""
    },
    "CORONARY_ARTERY_CFLX": {
      "name": "Circumflex Branch of the Coronary Artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "57396003",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of circumflex branch of left coronary artery",
      "modifier": ""
    },
    "CORONARY_ARTERY_LAD": {
      "name": "Left Anterior Descending Coronary Artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "59438005",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of left anterior descending artery",
      "modifier": ""
    },
    "CORONARY_ARTERY": {
      "name": "Coronary Artery",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "41801008",
      "typeScheme": "SCT",
      "typeMeaning": "Coronary artery structure (body structure)",
      "modifier": ""
    },
    "HEART": {
      "name": "Heart",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "80891009",
      "typeScheme": "SCT",
      "typeMeaning": "Heart structure",
      "modifier": ""
    },
    "NEOPLASM_MALIGNANT_PRIMARY": {
      "name": "Primary malignant neoplasm",
      "categoryCode": "49755003",
      "categoryScheme": "SCT",
      "categoryMeaning": "Morphologically abnormal structure",
      "typeCode": "86049000",
      "typeScheme": "SCT",
      "typeMeaning": "Malignant neoplasm, primary (morphologic abnormality)",
      "modifier": ""
    },
    "AORTIC_VALVE": {
      "name": "Aortic valve",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "34202007",
      "typeScheme": "SCT",
      "typeMeaning": "Aortic valve structure",
      "modifier": ""
    },
    "MITRAL_VALVE": {
      "name": "Mitral valve",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "91134007",
      "typeScheme": "SCT",
      "typeMeaning": "Mitral valve structure",
      "modifier": ""
    },
    "PULMONARY_VALVE": {
      "name": "Pulmonary valve",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "39057004",
      "typeScheme": "SCT",
      "typeMeaning": "Pulmonary valve structure",
      "modifier": ""
    },
    "TRICUSPID_VALVE": {
      "name": "Tricuspid valve",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "46030003",
      "typeScheme": "SCT",
      "typeMeaning": "Tricuspid valve structure",
      "modifier": ""
    },
    "SINOTRIAL_NODE": {
      "name": "Sinoatrial conduction node",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "88210001",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of sinoatrial node",
      "modifier": ""
    },
    "ATRIOVENTRICULAR_NODE": {
      "name": "Atrioventricular conduction node",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "25943004",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of atrioventricular node",
      "modifier": ""
    },
    "PROSTATE": {
      "name": "Prostate",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "41216001",
      "typeScheme": "SCT",
      "typeMeaning": "Prostatic structure",
      "modifier": ""
    },
    "PROSTATE_PERIPHERAL_ZONE": {
      "name": "Peripheral zone of prostate",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "279706003",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of peripheral glandular zone of prostate (body structure)",
      "modifier": ""
    },
    "PROSTATE_TRANSITION_ZONE": {
      "name": "Transition zone of prostate",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "399384005",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of transition zone of prostate (body structure)",
      "modifier": ""
    },
    "CYST": {
      "name": "Cyst",
      "categoryCode": "49755003",
      "categoryScheme": "SCT",
      "categoryMeaning": "Morphologically abnormal structure",
      "typeCode": "367643001",
      "typeScheme": "SCT",
      "typeMeaning": "Cyst (morphologic abnormality)",
      "modifier": ""
    },
    "SPINAL_CANAL": {
      "name": "Spinal canal",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "61853006",
      "typeScheme": "SCT",
      "typeMeaning": "Spinal canal structure (body structure)",
      "modifier": ""
    },
    "PATHOLOGIC_CALCIFICATION": {
      "name": "Pathologic calcification",
      "categoryCode": "49755003",
      "categoryScheme": "SCT",
      "categoryMeaning": "Morphologically abnormal structure",
      "typeCode": "18115005",
      "typeScheme": "SCT",
      "typeMeaning": "Pathologic calcification, calcified structure (morphologic abnormality)",
      "modifier": ""
    },
    "PANCREATIC_DUCT": {
      "name": "Pancreatic duct",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "69930009",
      "typeScheme": "SCT",
      "typeMeaning": "Pancreatic duct structure (body structure)",
      "modifier": ""
    },
    "BILE_DUCT": {
      "name": "Bile duct",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "28273000",
      "typeScheme": "SCT",
      "typeMeaning": "Bile duct structure (body structure)",
      "modifier": ""
    },
    "RENAL_VEIN": {
      "name": "Renal vein",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "56400007",
      "typeScheme": "SCT",
      "typeMeaning": "Structure of renal vein (body structure)",
      "modifier": ""
    },
    "ARTERY": {
      "name": "Artery (unspecific)",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "51114001",
      "typeScheme": "SCT",
      "typeMeaning": "Arterial structure (body structure)",
      "modifier": ""
    },
    "VEIN": {
      "name": "Vein (unspecific)",
      "categoryCode": "123037004",
      "categoryScheme": "SCT",
      "categoryMeaning": "Body structure",
      "typeCode": "29092000",
      "typeScheme": "SCT",
      "typeMeaning": "Venous structure",
      "modifier": ""
    }
  }
);
function normalizeSegKey(raw) {
  return String(raw || "").trim().toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}
function normalizeNameKey(raw) {
  return String(raw || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
var SEGDB_BY_NAME = (() => {
  const map = /* @__PURE__ */ new Map();
  for (const [id, entry] of Object.entries(SEGDB_BY_ID)) {
    const nameKey = normalizeNameKey(entry.name);
    if (nameKey && !map.has(nameKey)) map.set(nameKey, id);
    const idAsName = normalizeNameKey(id.replace(/_/g, " "));
    if (idAsName && !map.has(idAsName)) map.set(idAsName, id);
  }
  return map;
})();
function resolveSegdbId(labelOrId) {
  const raw = String(labelOrId || "").trim();
  if (!raw) return null;
  const asId = normalizeSegKey(raw);
  if (asId && SEGDB_BY_ID[asId]) return asId;
  const byName = SEGDB_BY_NAME.get(normalizeNameKey(raw));
  return byName || null;
}
function coded(scheme, value, meaning) {
  const v2 = String(value || "").trim();
  if (!v2) return null;
  return {
    scheme: String(scheme || "SCT"),
    value: v2,
    meaning: String(meaning || "").trim()
  };
}
function terminologyFromSegdbEntry(entry) {
  return {
    category: coded(
      entry.categoryScheme,
      entry.categoryCode,
      entry.categoryMeaning
    ),
    type: coded(entry.typeScheme, entry.typeCode, entry.typeMeaning),
    typeModifier: null,
    region: null
  };
}
function lookupSegdbTerminology(labelOrId) {
  const id = resolveSegdbId(labelOrId);
  if (!id) return null;
  const entry = SEGDB_BY_ID[id];
  if (!entry) return null;
  return terminologyFromSegdbEntry(entry);
}
function enrichTerminologyFromSegdb(label, terminology) {
  const hasType = Boolean(terminology?.type?.value);
  const hasCategory = Boolean(terminology?.category?.value);
  if (hasType && hasCategory) return terminology || void 0;
  const fromDb = lookupSegdbTerminology(label);
  if (!fromDb) return terminology || void 0;
  return {
    category: hasCategory ? terminology.category : fromDb.category,
    type: hasType ? terminology.type : fromDb.type,
    typeModifier: terminology?.typeModifier ?? fromDb.typeModifier,
    region: terminology?.region ?? fromDb.region
  };
}

// seg-catalog.ts
var EMPTY_SEG_CATALOG = { segmentations: [] };
function enrichSegCatalogFromSegdb(catalog) {
  if (!catalog?.segmentations?.length) return catalog;
  return {
    segmentations: catalog.segmentations.map((inst) => ({
      ...inst,
      segments: (inst.segments || []).map((seg) => ({
        ...seg,
        terminology: enrichTerminologyFromSegdb(seg.label, seg.terminology)
      }))
    }))
  };
}
function findCatalogSegment(catalog, segmentNumber, sopUid) {
  const num = Number(segmentNumber);
  if (!Number.isFinite(num)) return null;
  for (const instance of catalog.segmentations) {
    if (sopUid && instance.sopInstanceUID && instance.sopInstanceUID !== sopUid) {
      continue;
    }
    for (const segment of instance.segments || []) {
      if (Number(segment.number) === num) {
        return { instance, segment };
      }
    }
  }
  return null;
}
function firstCatalogSegment(catalog) {
  for (const instance of catalog.segmentations) {
    for (const segment of instance.segments || []) {
      return { instance, segment };
    }
  }
  return null;
}
function segCatalogFromContext(context) {
  if (!Array.isArray(context)) return null;
  for (const item of context) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    if (String(row.key || "").toLowerCase() !== "segmentation") continue;
    const resource = row.resource;
    if (!resource || typeof resource !== "object") {
      return { segmentations: [] };
    }
    const segs = resource.segmentations;
    if (!Array.isArray(segs)) return { segmentations: [] };
    return enrichSegCatalogFromSegdb({
      segmentations: segs
    });
  }
  return null;
}

// scene-update.ts
var IRA_SEG_NODE_ID = "seg1";
var IRA_VOL_NODE_ID = "vol1";
function sceneDocFromContext(context) {
  if (!Array.isArray(context)) return null;
  for (const item of context) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    if (String(row.key || "").toLowerCase() !== "scene") continue;
    const resource = row.resource;
    if (!resource || typeof resource !== "object") return null;
    return resource;
  }
  return null;
}
function primarySegNodeId(doc) {
  if (!doc?.nodes || typeof doc.nodes !== "object") return IRA_SEG_NODE_ID;
  if (doc.nodes[IRA_SEG_NODE_ID]) return IRA_SEG_NODE_ID;
  for (const [id, n] of Object.entries(doc.nodes)) {
    if (n && typeof n === "object" && n.type === "segmentation") {
      return id;
    }
  }
  return IRA_SEG_NODE_ID;
}
function primaryVolNodeId(doc) {
  if (!doc?.nodes || typeof doc.nodes !== "object") return IRA_VOL_NODE_ID;
  if (doc.nodes[IRA_VOL_NODE_ID]) return IRA_VOL_NODE_ID;
  for (const [id, n] of Object.entries(doc.nodes)) {
    if (n && typeof n === "object" && n.type === "volume") {
      return id;
    }
  }
  return IRA_VOL_NODE_ID;
}
function visibilityFromSceneDoc(doc) {
  const segmentVisible = {};
  const segmentOpacity = {};
  let labelsVisible = true;
  let opacity = 1;
  let volumeOpacity = 1;
  let volumeShift = 0;
  let volumeShiftRange = 500;
  let volumePreset = "";
  let volumeName = "";
  let volumeCropEnabled = false;
  let volumeRoiVisible = false;
  const id = primarySegNodeId(doc);
  const node = doc?.nodes?.[id];
  if (node) {
    if (typeof node.labelsVisible === "boolean") {
      labelsVisible = node.labelsVisible;
    }
    const o = Number(node.opacity);
    if (Number.isFinite(o)) opacity = Math.max(0, Math.min(1, o));
    for (const s2 of node.segments || []) {
      const lv4 = Number(s2.labelValue);
      if (!Number.isFinite(lv4)) continue;
      segmentVisible[lv4] = s2.visible !== false;
      const fromField = Number(s2.opacity);
      const fromColor = Number(s2.color?.[3]);
      const so = Number.isFinite(fromField) ? fromField : Number.isFinite(fromColor) ? fromColor : 1;
      segmentOpacity[lv4] = Math.max(0, Math.min(1, so));
    }
  }
  const volId = primaryVolNodeId(doc);
  const volNode = doc?.nodes?.[volId];
  const vo = Number(volNode?.opacity);
  if (Number.isFinite(vo)) volumeOpacity = Math.max(0, Math.min(1, vo));
  const vs2 = Number(volNode?.shift);
  if (Number.isFinite(vs2)) volumeShift = vs2;
  const vr2 = Number(volNode?.shiftRange);
  if (Number.isFinite(vr2) && vr2 > 0) {
    volumeShiftRange = Math.max(vr2, Math.abs(volumeShift), 200);
  } else {
    volumeShiftRange = Math.max(500, Math.abs(volumeShift), 200);
  }
  volumePreset = String(volNode?.preset ?? "").trim();
  volumeName = String(volNode?.name ?? "").trim();
  if (typeof volNode?.cropEnabled === "boolean") {
    volumeCropEnabled = volNode.cropEnabled;
  }
  if (typeof volNode?.roiVisible === "boolean") {
    volumeRoiVisible = volNode.roiVisible;
  }
  return {
    segmentVisible,
    segmentOpacity,
    labelsVisible,
    opacity,
    volumeOpacity,
    volumeShift,
    volumeShiftRange,
    volumePreset,
    volumeName,
    volumeCropEnabled,
    volumeRoiVisible
  };
}
function buildSegmentPatchOps(opts) {
  const ops = [];
  if (opts.segments) {
    ops.push({
      op: "patch",
      id: opts.segId,
      path: "#/segments",
      value: opts.segments
    });
  }
  if (typeof opts.labelsVisible === "boolean") {
    ops.push({
      op: "patch",
      id: opts.segId,
      path: "#/labelsVisible",
      value: opts.labelsVisible
    });
  }
  if (typeof opts.opacity === "number" && Number.isFinite(opts.opacity)) {
    ops.push({
      op: "patch",
      id: opts.segId,
      path: "#/opacity",
      value: Math.max(0, Math.min(1, opts.opacity))
    });
  }
  return ops;
}
function buildVolumeOpacityPatchOps(opts) {
  if (!Number.isFinite(opts.opacity)) return [];
  return [
    {
      op: "patch",
      id: opts.volId,
      path: "#/opacity",
      value: Math.max(0, Math.min(1, opts.opacity))
    }
  ];
}
function buildVolumeShiftPatchOps(opts) {
  if (!Number.isFinite(opts.shift)) return [];
  return [
    {
      op: "patch",
      id: opts.volId,
      path: "#/shift",
      value: opts.shift
    }
  ];
}
function buildVolumePresetPatchOps(opts) {
  return [
    {
      op: "patch",
      id: opts.volId,
      path: "#/preset",
      value: String(opts.preset || "")
    }
  ];
}
function buildVolumeCropPatchOps(opts) {
  return [
    {
      op: "patch",
      id: opts.volId,
      path: "#/cropEnabled",
      value: Boolean(opts.cropEnabled)
    }
  ];
}
function buildRoiVisiblePatchOps(opts) {
  return [
    {
      op: "patch",
      id: opts.volId,
      path: "#/roiVisible",
      value: Boolean(opts.roiVisible)
    }
  ];
}

// tid1500.ts
var dcmjsPromise = null;
var DCMJS_MIRRORS = [
  "https://cdn.jsdelivr.net/npm/dcmjs@0.41.0/build/dcmjs.min.js",
  "https://unpkg.com/dcmjs@0.41.0/build/dcmjs.min.js"
];
function loadDcmjs() {
  const w = globalThis;
  if (w.dcmjs) return Promise.resolve(w.dcmjs);
  if (!w.document) {
    return Promise.reject(new Error("dcmjs requires a browser document"));
  }
  if (!dcmjsPromise) {
    dcmjsPromise = new Promise((resolve, reject) => {
      let i = 0;
      const tryNext = () => {
        if (i >= DCMJS_MIRRORS.length) {
          reject(new Error("dcmjs: all CDN mirrors failed"));
          return;
        }
        const s2 = w.document.createElement("script");
        s2.src = DCMJS_MIRRORS[i++];
        s2.onload = () => w.dcmjs ? resolve(w.dcmjs) : tryNext();
        s2.onerror = () => {
          s2.remove();
          tryNext();
        };
        w.document.head.appendChild(s2);
      };
      tryNext();
    });
  }
  return dcmjsPromise;
}
function asSeq(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}
function codeMeaning(seq) {
  const c = asSeq(seq)[0];
  if (!c) return "";
  return String(c.CodeMeaning || c.codeMeaning || c.CodeValue || "");
}
function isSrDataset(ds) {
  const mod = String(ds.Modality || "").toUpperCase();
  if (mod === "SR") return true;
  const sop = String(ds.SOPClassUID || "");
  return sop.includes("1.2.840.10008.5.1.4.1.1.88");
}
function walkContent(items, into, groupState) {
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const item = raw;
    const vt2 = String(item.ValueType || item.valueType || "").toUpperCase();
    const concept = codeMeaning(
      item.ConceptNameCodeSequence || item.ConceptNameCode
    );
    if (vt2 === "TEXT" && /tracking/i.test(concept)) {
      groupState.trackingIdentifier = String(
        item.TextValue || item.textValue || groupState.trackingIdentifier
      );
    }
    if (vt2 === "CODE" && /finding/i.test(concept)) {
      groupState.finding = codeMeaning(
        item.ConceptCodeSequence || item.ConceptCode
      );
    }
    if (vt2 === "UIDREF" && /segmentation/i.test(concept)) {
      groupState.segmentationSOPInstanceUID = String(
        item.UID || item.uid || groupState.segmentationSOPInstanceUID
      );
    }
    if ((vt2 === "SCOORD" || vt2 === "SCOORD3D" || vt2 === "IMAGE") && item.ReferencedSOPSequence) {
      const ref = asSeq(item.ReferencedSOPSequence)[0];
      if (ref?.ReferencedSOPInstanceUID) {
        groupState.segmentationSOPInstanceUID = String(
          ref.ReferencedSOPInstanceUID
        );
      }
    }
    if (/referenced.?segment/i.test(concept) || item.ReferencedSegmentNumber != null) {
      const n = Number(
        item.ReferencedSegmentNumber ?? item.NumericValue ?? item.TextValue
      );
      if (Number.isFinite(n)) groupState.segmentNumber = n;
    }
    if (vt2 === "NUM") {
      const measured = asSeq(
        item.MeasuredValueSequence || item.MeasuredValue
      )[0];
      const value = measured?.NumericValue ?? item.NumericValue;
      const units = codeMeaning(
        measured?.MeasurementUnitsCodeSequence || measured?.MeasurementUnitsCode || item.MeasurementUnitsCodeSequence
      );
      into.push({
        quantity: concept || "Measurement",
        value: value == null ? "\u2014" : value,
        units: units || "",
        segmentNumber: groupState.segmentNumber,
        segmentLabel: groupState.finding || groupState.trackingIdentifier || (groupState.segmentNumber != null ? `Segment ${groupState.segmentNumber}` : ""),
        segmentationSOPInstanceUID: groupState.segmentationSOPInstanceUID,
        trackingIdentifier: groupState.trackingIdentifier
      });
    }
    const child = asSeq(item.ContentSequence || item.Content);
    if (child.length) {
      const next = { ...groupState };
      if (/measurement.?group/i.test(concept)) {
        next.trackingIdentifier = groupState.trackingIdentifier;
      }
      walkContent(child, into, next);
    }
  }
}
async function parseTid1500FromBuffer(bytes) {
  try {
    const dcmjs = await loadDcmjs();
    const buf = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength ? bytes.buffer : bytes.slice().buffer;
    const ds = dcmjs.data.DicomMetaDictionary.naturalizeDataset(
      dcmjs.data.DicomMessage.readFile(buf).dict
    );
    if (!isSrDataset(ds)) {
      return {
        ok: false,
        error: `Not an SR (Modality=${String(ds.Modality || "?")})`
      };
    }
    const measurements = [];
    walkContent(asSeq(ds.ContentSequence), measurements, {
      trackingIdentifier: "",
      segmentNumber: null,
      segmentationSOPInstanceUID: "",
      finding: ""
    });
    return {
      ok: true,
      measurements,
      sopInstanceUID: String(ds.SOPInstanceUID || "")
    };
  } catch (err) {
    return {
      ok: false,
      error: `SR parse failed: ${err?.message ?? err}`
    };
  }
}

// hub.ts
var onStatusChange = null;
var onStudyChange = null;
function createInitialState() {
  const hubs = getHubDefinitions();
  const pageInCloud = Qt();
  const hubKey = Is(
    hubs,
    ["local", "cloud", "cloudOidc"],
    pageInCloud
  ) || (pageInCloud ? "cloud" : "local");
  const params = new URLSearchParams(window.location.search);
  const hubOverride = params.get("hub");
  let resolvedKey = hubKey;
  if (hubOverride === "local" || hubOverride === "cloud" || hubOverride === "cloudOidc") {
    resolvedKey = hubOverride;
  }
  const urlUserName = String(params.get("userName") || "").trim();
  const urlTopic = String(params.get("topic") || "").trim();
  return {
    client: null,
    hubKey: resolvedKey,
    topic: urlTopic,
    subscriberName: Pe(PRODUCT_NAME),
    userName: urlUserName || getStoredUserName(),
    hubStartedAt: "",
    lastAuthCode: "",
    connection: "idle",
    connectionDetail: "Not connected",
    openStudy: null,
    lastImagingStudyOpenContext: [],
    segCatalog: EMPTY_SEG_CATALOG,
    measurements: [],
    segLoadDetail: "",
    selectedMeasurementId: null,
    selectedSegmentNumber: null,
    selectedSegmentSopUid: "",
    sceneDoc: null,
    segmentVisible: {},
    segmentOpacity: {},
    labelsVisible: true,
    segOpacity: 1,
    volumeOpacity: 1,
    volumeShift: 0,
    volumeShiftRange: 500,
    volumePreset: "",
    volumeName: "",
    volumeCropEnabled: false,
    volumeRoiVisible: false,
    snapshots: [],
    conference: null,
    conferenceFollowHost: false,
    conferenceFollowChoice: null,
    worklistOnline: false,
    iraOnline: false,
    connectedApps: /* @__PURE__ */ new Map()
  };
}
function setStatusListener(fn) {
  onStatusChange = fn;
}
function setStudyListener(fn) {
  onStudyChange = fn;
}
function setConferenceView(state, view) {
  state.conference = view;
  if (!view) {
    state.conferenceFollowHost = false;
    state.conferenceFollowChoice = null;
  } else if (view.selfRole === "leading") {
    state.conferenceFollowHost = false;
    state.conferenceFollowChoice = null;
  } else if (view.selfRole === "following") {
    if (state.conferenceFollowChoice === null) {
      state.conferenceFollowChoice = true;
      state.conferenceFollowHost = true;
    } else {
      state.conferenceFollowHost = state.conferenceFollowChoice;
    }
  }
  notifyStatus(state);
}
function setConferenceFollowHost(state, followHost) {
  state.conferenceFollowChoice = Boolean(followHost);
  if (state.conference?.selfRole === "leading") {
    state.conferenceFollowHost = false;
    notifyStatus(state);
    return;
  }
  state.conferenceFollowHost = state.conferenceFollowChoice;
  notifyStatus(state);
}
var conferenceHubHandler = null;
function setConferenceHubHandler(fn) {
  conferenceHubHandler = fn;
}
async function syncConferenceView(state) {
  if (state.connection !== "connected") {
    setConferenceView(state, null);
    return;
  }
  const token = state.client?.getConnectionState?.()?.token?.trim() || "";
  if (!token) {
    return;
  }
  try {
    const view = await ws(
      hubEndpoint(state),
      state.topic,
      state.subscriberName,
      state.userName,
      token
    );
    setConferenceView(state, view);
  } catch {
  }
}
function handleConferenceHubEvent(state, message) {
  if (conferenceHubHandler?.(message)) {
    return true;
  }
  const event = message?.event;
  const hubEvent = te(event);
  if (hubEvent === "conference-start") {
    void syncConferenceView(state);
    return true;
  }
  if (hubEvent === "conference-end") {
    const context = event?.context && typeof event.context === "object" ? event.context : {};
    const leaveTopic = String(context.leaveTopic ?? "").trim();
    if (!leaveTopic || leaveTopic === state.topic) {
      setConferenceView(state, null);
    } else {
      void syncConferenceView(state);
    }
    return true;
  }
  return false;
}
function notifyStatus(state) {
  onStatusChange?.(state);
}
function notifyStudy(state) {
  onStudyChange?.(state);
}
function fileBytes(entry) {
  const data = entry.data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (data instanceof Uint8Array) return data;
  return null;
}
function applyCatalogMeasurements(state) {
  const next = [];
  for (const m of state.measurements) {
    if (m.source === "sr") {
      next.push(m);
      continue;
    }
    if (m.source !== "manual") continue;
    if (m.segmentNumber == null) {
      next.push(m);
      continue;
    }
    const match = findCatalogSegment(
      state.segCatalog,
      m.segmentNumber,
      m.segmentationSOPInstanceUID || void 0
    );
    if (!match) continue;
    const label = String(match.segment.label || `Segment ${match.segment.number}`);
    if (/^volume$/i.test(m.quantity)) {
      next.push({
        ...m,
        segmentLabel: label,
        trackingIdentifier: label,
        value: Number.isFinite(match.segment.volumeMm3) ? match.segment.volumeMm3 : m.value,
        units: "mm3",
        segmentationSOPInstanceUID: String(
          match.instance.sopInstanceUID || m.segmentationSOPInstanceUID
        )
      });
    } else {
      next.push({
        ...m,
        segmentLabel: label,
        trackingIdentifier: label,
        segmentationSOPInstanceUID: String(
          match.instance.sopInstanceUID || m.segmentationSOPInstanceUID
        )
      });
    }
  }
  state.measurements = next;
  if (state.selectedMeasurementId && !next.some((m) => m.id === state.selectedMeasurementId)) {
    state.selectedMeasurementId = null;
  }
}
var WORKLIST_ACTOR = "WORKLIST_CLIENT";
var IMAGE_DISPLAY_ACTOR = "ID";
async function requestStatus(state, targetActor = "*") {
  const subscriber = state.subscriberName || state.client?.getSessionConfig?.()?.subscriberName?.trim() || "";
  if (!state.client || !subscriber) return [];
  const result = await It(state.client, {
    subscriberName: subscriber,
    subscriberProductName: PRODUCT_NAME,
    subscriberActor: REPORTING_ACTOR,
    topic: state.topic || void 0,
    targetActor
  });
  const { responses } = de(
    result?.data ?? result
  );
  return responses;
}
function statusRowActor(row) {
  return String(row.actor ?? "").trim().toUpperCase();
}
function statusRowProduct(row) {
  const fromEnvelope = String(row.productName ?? "").trim();
  if (fromEnvelope) return fromEnvelope;
  const data = row.data;
  if (data && typeof data === "object") {
    return String(
      data.product ?? ""
    ).trim();
  }
  return "";
}
function isWorklistStatusRow(row) {
  if (statusRowActor(row) === WORKLIST_ACTOR) return true;
  const product = statusRowProduct(row).toUpperCase();
  return product === "WKLST" || product.startsWith("WKLST-") || product === "CAST-WKLST" || product.startsWith("CAST-WKLST");
}
function isReportingStatusRow(row) {
  const actor = statusRowActor(row);
  if (actor === REPORTING_ACTOR || actor === "REPORTING_CLIENT") return true;
  const product = statusRowProduct(row).toUpperCase();
  return product === "RPT" || product.startsWith("RPT-") || product === "CAST-RPT" || product.startsWith("CAST-RPT");
}
function isIdStatusRow(row) {
  if (statusRowActor(row) === IMAGE_DISPLAY_ACTOR) return true;
  return As(statusRowProduct(row), "ira");
}
function isIraStatusRow(row) {
  return As(statusRowProduct(row), "ira");
}
function isIraPeer(productName, actor, subscriber = "") {
  if (As(productName, "ira")) return true;
  const sub = String(subscriber || "").trim().toUpperCase();
  if (sub.startsWith("IRA-") || sub.startsWith("SLICERLIVE-IRA")) return true;
  const actorKey = String(actor || "").trim().toUpperCase();
  const product = String(productName || "").trim().toUpperCase();
  if (actorKey === IMAGE_DISPLAY_ACTOR && product.includes("IRA")) return true;
  return false;
}
function isWorklistPeer(productName, actor) {
  const actorKey = String(actor || "").trim().toUpperCase();
  if (actorKey === WORKLIST_ACTOR) return true;
  const product = String(productName || "").trim().toUpperCase();
  return product === "WKLST" || product.startsWith("WKLST-") || product === "CAST-WKLST" || product.startsWith("CAST-WKLST");
}
function syncPresenceFlags(state) {
  let iraOnline = false;
  let worklistOnline = false;
  for (const [subscriber, info] of state.connectedApps) {
    if (isIraPeer(info.productName, info.actor, subscriber)) iraOnline = true;
    if (isWorklistPeer(info.productName, info.actor)) worklistOnline = true;
  }
  state.iraOnline = iraOnline;
  state.worklistOnline = worklistOnline;
}
function markConnectedAppFromMessage(state, message) {
  const subscriber = no(message);
  if (!subscriber) return;
  const productName = ro(message);
  const actor = io(message);
  if (!isIraPeer(productName, actor, subscriber) && !isWorklistPeer(productName, actor)) {
    return;
  }
  upsertConnectedApp(state, { subscriber, productName, actor });
}
function upsertConnectedApp(state, info) {
  const subscriber = String(info.subscriber || "").trim();
  if (!subscriber) return;
  const productName = String(info.productName || "").trim();
  const actor = String(info.actor || "").trim();
  const productKey = productName.toUpperCase();
  if (productKey) {
    for (const [name, existing] of state.connectedApps) {
      if (name !== subscriber && existing.productName.trim().toUpperCase() === productKey) {
        state.connectedApps.delete(name);
      }
    }
  }
  state.connectedApps.set(subscriber, { productName, actor });
  syncPresenceFlags(state);
}
function applyConnectedAppsFromStatusResponses(state, responses) {
  for (const item of responses) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    const subscriber = String(row.subscriber ?? "").trim();
    if (!subscriber) continue;
    const productName = statusRowProduct(row);
    const actor = statusRowActor(row);
    if (!isIraPeer(productName, actor, subscriber) && !isWorklistPeer(productName, actor)) {
      continue;
    }
    upsertConnectedApp(state, { subscriber, productName, actor });
  }
  syncPresenceFlags(state);
}
function clearConnectedApps(state) {
  if (state.connectedApps.size === 0) {
    state.worklistOnline = false;
    state.iraOnline = false;
    return;
  }
  state.connectedApps.clear();
  state.worklistOnline = false;
  state.iraOnline = false;
}
function handleSubscriptionRemoved(state, message) {
  const event = message?.event;
  if (!event || te(event) !== "subscription-removed") {
    return false;
  }
  const subscriber = no(message);
  if (!subscriber || !state.connectedApps.has(subscriber)) return false;
  state.connectedApps.delete(subscriber);
  syncPresenceFlags(state);
  notifyStatus(state);
  return true;
}
function parseStatusResponses(responses) {
  let foundIdResponder = false;
  let foundWorklistResponder = false;
  let foundIraResponder = false;
  let catalog = null;
  let idImagingContext = null;
  let worklistImagingContext = null;
  let sceneDoc = null;
  let idResponderSubscriber = "";
  for (const item of responses) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    const data = row.data;
    if (!data || typeof data !== "object") continue;
    const fromWorklist = isWorklistStatusRow(row);
    const fromIra = isIraStatusRow(row);
    const fromId = isIdStatusRow(row);
    const fromReporting = isReportingStatusRow(row);
    if (fromIra) foundIraResponder = true;
    if (fromWorklist) {
      foundWorklistResponder = true;
      const payload2 = data;
      const ctx2 = payload2.context;
      if (payload2["context.type"] === "ImagingStudy" && Array.isArray(ctx2) && ctx2.length > 0 && !worklistImagingContext) {
        worklistImagingContext = eo(ctx2);
      }
      continue;
    }
    if (fromReporting) continue;
    if (fromId) {
      foundIdResponder = true;
      if (!idResponderSubscriber) {
        idResponderSubscriber = String(
          row.subscriber ?? row["subscriber.name"] ?? ""
        ).trim();
      }
    }
    const payload = data;
    const ctx = payload.context;
    const imaging = payload["context.type"] === "ImagingStudy" && Array.isArray(ctx) && ctx.length > 0 ? eo(ctx) : null;
    const parsedCat = segCatalogFromContext(ctx);
    if (parsedCat && !catalog) {
      catalog = parsedCat;
      foundIdResponder = true;
    }
    const scene = sceneDocFromContext(ctx);
    if (scene && !sceneDoc) {
      sceneDoc = scene;
      foundIdResponder = true;
    }
    if (imaging && fromId && !idImagingContext) {
      idImagingContext = imaging;
    }
  }
  return {
    foundIdResponder,
    foundWorklistResponder,
    foundIraResponder,
    catalog,
    idImagingContext,
    worklistImagingContext,
    sceneDoc,
    idResponderSubscriber
  };
}
function withResponderName(base, subscriber) {
  const name = String(subscriber || "").trim();
  return name ? `${base} ${name}` : base;
}
function adoptSceneVisibility(state, sceneDoc) {
  state.sceneDoc = sceneDoc;
  if (!sceneDoc) {
    const next2 = {};
    for (const inst of state.segCatalog.segmentations) {
      for (const seg of inst.segments || []) {
        const n = Number(seg.number);
        if (Number.isFinite(n)) next2[n] = true;
      }
    }
    state.segmentVisible = next2;
    state.labelsVisible = true;
    state.segOpacity = 1;
    state.segmentOpacity = {};
    state.volumeOpacity = 1;
    state.volumeShift = 0;
    state.volumeShiftRange = 500;
    state.volumePreset = "";
    state.volumeName = "";
    state.volumeCropEnabled = false;
    state.volumeRoiVisible = false;
    return;
  }
  const vis = visibilityFromSceneDoc(sceneDoc);
  state.labelsVisible = vis.labelsVisible;
  state.segOpacity = vis.opacity;
  state.volumeOpacity = vis.volumeOpacity;
  state.volumeShift = vis.volumeShift;
  state.volumeShiftRange = vis.volumeShiftRange;
  state.volumePreset = vis.volumePreset;
  state.volumeName = vis.volumeName;
  state.volumeCropEnabled = vis.volumeCropEnabled;
  state.volumeRoiVisible = vis.volumeRoiVisible;
  const next = { ...vis.segmentVisible };
  const nextOp = { ...vis.segmentOpacity };
  for (const inst of state.segCatalog.segmentations) {
    for (const seg of inst.segments || []) {
      const n = Number(seg.number);
      if (!Number.isFinite(n)) continue;
      if (!(n in next)) next[n] = true;
      if (!(n in nextOp)) nextOp[n] = 1;
    }
  }
  state.segmentVisible = next;
  state.segmentOpacity = nextOp;
}
function catalogSegmentsAsSceneEntries(state) {
  const out = [];
  for (const inst of state.segCatalog.segmentations) {
    for (const seg of inst.segments || []) {
      const n = Number(seg.number);
      if (!Number.isFinite(n)) continue;
      const op = Math.max(
        0,
        Math.min(1, Number(state.segmentOpacity[n] ?? 1))
      );
      out.push({
        id: `Segment_${n}`,
        name: String(seg.label || `Segment ${n}`),
        labelValue: n,
        color: [
          seg.color?.[0] ?? 1,
          seg.color?.[1] ?? 1,
          seg.color?.[2] ?? 1,
          op
        ],
        opacity: op,
        visible: state.segmentVisible[n] !== false
      });
    }
  }
  return out;
}
async function publishSceneUpdate(state, opts = {}) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} scene-update: not connected`);
    return false;
  }
  if (opts.segmentVisible) {
    state.segmentVisible = { ...state.segmentVisible, ...opts.segmentVisible };
  }
  if (opts.segmentOpacity) {
    const next = { ...state.segmentOpacity };
    for (const [k2, v2] of Object.entries(opts.segmentOpacity)) {
      const n = Number(k2);
      const o = Number(v2);
      if (!Number.isFinite(n) || !Number.isFinite(o)) continue;
      next[n] = Math.max(0, Math.min(1, o));
    }
    state.segmentOpacity = next;
  }
  if (typeof opts.labelsVisible === "boolean") {
    state.labelsVisible = opts.labelsVisible;
  }
  if (typeof opts.opacity === "number" && Number.isFinite(opts.opacity)) {
    state.segOpacity = Math.max(0, Math.min(1, opts.opacity));
  }
  const segId = primarySegNodeId(state.sceneDoc);
  if (!opts.opacityOnly) {
    const segments = catalogSegmentsAsSceneEntries(state);
    if (!segments.length) {
      console.warn(`${LOG_PREFIX} scene-update: no segments`);
      return false;
    }
  }
  const ops = opts.opacityOnly ? buildSegmentPatchOps({
    segId,
    opacity: state.segOpacity
  }) : buildSegmentPatchOps({
    segId,
    segments: catalogSegmentsAsSceneEntries(state),
    labelsVisible: state.labelsVisible,
    opacity: state.segOpacity
  });
  if (!ops.length) return false;
  try {
    const res = await state.client.publish({
      event: {
        "hub.topic": state.topic,
        "hub.event": "scene-update",
        context: [{ key: "scene", resource: { ops } }]
      },
      actor: REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*"
    });
    const ok = Boolean(res && res.ok);
    if (!ok) {
      console.warn(
        `${LOG_PREFIX} scene-update failed`,
        res ? `HTTP ${res.status}` : "No response"
      );
    }
    return ok;
  } catch (err) {
    console.error(`${LOG_PREFIX} scene-update exception`, err);
    return false;
  }
}
async function toggleSegmentVisibility(state, segmentNumber) {
  const n = Number(segmentNumber);
  if (!Number.isFinite(n)) return;
  const next = state.segmentVisible[n] === false;
  await publishSceneUpdate(state, {
    segmentVisible: { [n]: next }
  });
  notifyStudy(state);
}
var segmentOpacityPublishRaf = 0;
var segmentOpacityPublishPending = null;
function setSegmentOpacity(state, segmentNumber, opacity) {
  const n = Number(segmentNumber);
  const o = Math.max(0, Math.min(1, Number(opacity)));
  if (!Number.isFinite(n) || !Number.isFinite(o)) return;
  state.segmentOpacity = { ...state.segmentOpacity, [n]: o };
  segmentOpacityPublishPending = {
    ...segmentOpacityPublishPending || {},
    [n]: o
  };
  if (segmentOpacityPublishRaf) return;
  segmentOpacityPublishRaf = requestAnimationFrame(() => {
    segmentOpacityPublishRaf = 0;
    const pending = segmentOpacityPublishPending;
    segmentOpacityPublishPending = null;
    if (!pending) return;
    void publishSceneUpdate(state, { segmentOpacity: pending }).then(() => {
    });
  });
}
async function toggleAllSegmentVisibility(state) {
  const anyOff = Object.values(state.segmentVisible).some((v2) => v2 === false);
  const on2 = anyOff;
  const segmentVisible = {};
  for (const inst of state.segCatalog.segmentations) {
    for (const seg of inst.segments || []) {
      const n = Number(seg.number);
      if (Number.isFinite(n)) segmentVisible[n] = on2;
    }
  }
  await publishSceneUpdate(state, { segmentVisible });
  notifyStudy(state);
}
async function toggleLabelsVisibility(state) {
  await publishSceneUpdate(state, {
    labelsVisible: state.labelsVisible === false
  });
  notifyStudy(state);
}
var opacityPublishRaf = 0;
var opacityPublishPending = null;
function setSegOpacity(state, opacity) {
  const o = Math.max(0, Math.min(1, Number(opacity)));
  if (!Number.isFinite(o)) return;
  state.segOpacity = o;
  opacityPublishPending = o;
  if (opacityPublishRaf) return;
  opacityPublishRaf = requestAnimationFrame(() => {
    opacityPublishRaf = 0;
    const v2 = opacityPublishPending;
    opacityPublishPending = null;
    if (v2 == null) return;
    void publishSceneUpdate(state, { opacity: v2, opacityOnly: true });
  });
}
var volumeOpacityPublishRaf = 0;
var volumeOpacityPublishPending = null;
async function publishVolumeOpacity(state, opacity) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} volume opacity: not connected`);
    return false;
  }
  const o = Math.max(0, Math.min(1, Number(opacity)));
  if (!Number.isFinite(o)) return false;
  state.volumeOpacity = o;
  const volId = primaryVolNodeId(state.sceneDoc);
  const ops = buildVolumeOpacityPatchOps({ volId, opacity: o });
  if (!ops.length) return false;
  try {
    const res = await state.client.publish({
      event: {
        "hub.topic": state.topic,
        "hub.event": "scene-update",
        context: [{ key: "scene", resource: { ops } }]
      },
      actor: REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*"
    });
    const ok = Boolean(res && res.ok);
    if (!ok) {
      console.warn(
        `${LOG_PREFIX} volume opacity failed`,
        res ? `HTTP ${res.status}` : "No response"
      );
    }
    return ok;
  } catch (err) {
    console.error(`${LOG_PREFIX} volume opacity exception`, err);
    return false;
  }
}
function setVolumeOpacity(state, opacity) {
  const o = Math.max(0, Math.min(1, Number(opacity)));
  if (!Number.isFinite(o)) return;
  if (o > 0.02) lastVolumeOpacityWhenVisible = o;
  state.volumeOpacity = o;
  volumeOpacityPublishPending = o;
  if (volumeOpacityPublishRaf) return;
  volumeOpacityPublishRaf = requestAnimationFrame(() => {
    volumeOpacityPublishRaf = 0;
    const v2 = volumeOpacityPublishPending;
    volumeOpacityPublishPending = null;
    if (v2 == null) return;
    void publishVolumeOpacity(state, v2);
  });
}
var lastVolumeOpacityWhenVisible = 1;
function toggleVolumeVisibility(state) {
  if (state.volumeOpacity > 0.02) {
    lastVolumeOpacityWhenVisible = state.volumeOpacity;
    setVolumeOpacity(state, 0);
  } else {
    setVolumeOpacity(state, lastVolumeOpacityWhenVisible > 0.02 ? lastVolumeOpacityWhenVisible : 1);
  }
  notifyStudy(state);
}
var volumeShiftPublishRaf = 0;
var volumeShiftPublishPending = null;
async function publishVolumeShift(state, shift) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} volume shift: not connected`);
    return false;
  }
  const s2 = Number(shift);
  if (!Number.isFinite(s2)) return false;
  state.volumeShift = s2;
  const volId = primaryVolNodeId(state.sceneDoc);
  const ops = buildVolumeShiftPatchOps({ volId, shift: s2 });
  if (!ops.length) return false;
  try {
    const res = await state.client.publish({
      event: {
        "hub.topic": state.topic,
        "hub.event": "scene-update",
        context: [{ key: "scene", resource: { ops } }]
      },
      actor: REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*"
    });
    const ok = Boolean(res && res.ok);
    if (!ok) {
      console.warn(
        `${LOG_PREFIX} volume shift failed`,
        res ? `HTTP ${res.status}` : "No response"
      );
    }
    return ok;
  } catch (err) {
    console.error(`${LOG_PREFIX} volume shift exception`, err);
    return false;
  }
}
function setVolumeShift(state, shift) {
  const s2 = Number(shift);
  if (!Number.isFinite(s2)) return;
  state.volumeShift = s2;
  volumeShiftPublishPending = s2;
  if (volumeShiftPublishRaf) return;
  volumeShiftPublishRaf = requestAnimationFrame(() => {
    volumeShiftPublishRaf = 0;
    const v2 = volumeShiftPublishPending;
    volumeShiftPublishPending = null;
    if (v2 == null) return;
    void publishVolumeShift(state, v2);
  });
}
async function publishVolumePreset(state, preset) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} volume preset: not connected`);
    return false;
  }
  const name = String(preset || "").trim();
  state.volumePreset = name;
  const volId = primaryVolNodeId(state.sceneDoc);
  const ops = buildVolumePresetPatchOps({ volId, preset: name });
  if (!ops.length) return false;
  try {
    const res = await state.client.publish({
      event: {
        "hub.topic": state.topic,
        "hub.event": "scene-update",
        context: [{ key: "scene", resource: { ops } }]
      },
      actor: REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*"
    });
    const ok = Boolean(res && res.ok);
    if (!ok) {
      console.warn(
        `${LOG_PREFIX} volume preset failed`,
        res ? `HTTP ${res.status}` : "No response"
      );
    }
    return ok;
  } catch (err) {
    console.error(`${LOG_PREFIX} volume preset exception`, err);
    return false;
  }
}
function setVolumePreset(state, preset) {
  const name = String(preset || "").trim();
  state.volumePreset = name;
  void publishVolumePreset(state, name);
}
var volumeCropFirstEnable = true;
async function publishVolumeCropOps(state, ops) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} volume crop: not connected`);
    return false;
  }
  if (!ops.length) return false;
  try {
    const res = await state.client.publish({
      event: {
        "hub.topic": state.topic,
        "hub.event": "scene-update",
        context: [{ key: "scene", resource: { ops } }]
      },
      actor: REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*"
    });
    const ok = Boolean(res && res.ok);
    if (!ok) {
      console.warn(
        `${LOG_PREFIX} volume crop failed`,
        res ? `HTTP ${res.status}` : "No response"
      );
    }
    return ok;
  } catch (err) {
    console.error(`${LOG_PREFIX} volume crop exception`, err);
    return false;
  }
}
function setVolumeCropEnabled(state, on2) {
  const enabled = Boolean(on2);
  state.volumeCropEnabled = enabled;
  const volId = primaryVolNodeId(state.sceneDoc);
  const ops = buildVolumeCropPatchOps({ volId, cropEnabled: enabled });
  if (enabled && volumeCropFirstEnable) {
    volumeCropFirstEnable = false;
    state.volumeRoiVisible = true;
    ops.push(...buildRoiVisiblePatchOps({ volId, roiVisible: true }));
  }
  notifyStudy(state);
  void publishVolumeCropOps(state, ops);
}
function setVolumeRoiVisible(state, on2) {
  const visible = Boolean(on2);
  state.volumeRoiVisible = visible;
  const volId = primaryVolNodeId(state.sceneDoc);
  notifyStudy(state);
  void publishVolumeCropOps(
    state,
    buildRoiVisiblePatchOps({ volId, roiVisible: visible })
  );
}
function adoptImagingStudyContext(state, context) {
  if (!context?.length) return false;
  state.lastImagingStudyOpenContext = eo(context);
  state.openStudy = studyInfoFromContext(context);
  return true;
}
async function refreshReportContextFromStatus(state) {
  if (!state.client || state.connection !== "connected") {
    state.segLoadDetail = "Not connected to Slicer hub";
    notifyStudy(state);
    return;
  }
  const subscriber = state.subscriberName || state.client.getSessionConfig?.()?.subscriberName?.trim() || "";
  if (!subscriber) {
    state.segLoadDetail = "No subscriber name";
    notifyStudy(state);
    return;
  }
  state.segLoadDetail = "Requesting status\u2026";
  notifyStudy(state);
  try {
    const responses = await requestStatus(state, "*");
    const parsed = parseStatusResponses(responses);
    applyConnectedAppsFromStatusResponses(state, responses);
    notifyStatus(state);
    if (parsed.foundIdResponder) {
      const adoptedFromWorklist = adoptImagingStudyContext(
        state,
        parsed.worklistImagingContext
      );
      if (!adoptedFromWorklist) {
        adoptImagingStudyContext(state, parsed.idImagingContext);
      }
      state.segCatalog = parsed.catalog ?? EMPTY_SEG_CATALOG;
      applyCatalogMeasurements(state);
      adoptSceneVisibility(state, parsed.sceneDoc);
      const n = state.segCatalog.segmentations.reduce(
        (acc, s2) => acc + (s2.segments?.length || 0),
        0
      );
      if (adoptedFromWorklist) {
        state.segLoadDetail = withResponderName(
          n > 0 ? `Loaded ${n} segment${n === 1 ? "" : "s"} from Image Display; study from worklist` : "Image Display online (no SEG); adopted study context from worklist",
          parsed.idResponderSubscriber
        );
        notifyStudy(state);
        return;
      }
      state.segLoadDetail = withResponderName(
        n > 0 ? `Loaded ${n} segment${n === 1 ? "" : "s"} from Image Display` : "Image Display has no segmentation loaded",
        parsed.idResponderSubscriber
      );
      notifyStudy(state);
      return;
    }
    state.segCatalog = EMPTY_SEG_CATALOG;
    applyCatalogMeasurements(state);
    adoptSceneVisibility(state, null);
    if (parsed.worklistImagingContext) {
      adoptImagingStudyContext(state, parsed.worklistImagingContext);
      state.segLoadDetail = "Adopted study context from worklist (no Image Display)";
    } else if (parsed.foundWorklistResponder) {
      state.openStudy = null;
      state.lastImagingStudyOpenContext = [];
      state.segLoadDetail = reportingChromeFor().worklistNoOpenStudy;
    } else {
      state.segLoadDetail = "No Image Display or worklist responded on this topic";
    }
    notifyStudy(state);
  } catch (err) {
    clearConnectedApps(state);
    notifyStatus(state);
    state.segLoadDetail = `STATUS failed: ${err?.message ?? err}`;
    console.error(`${LOG_PREFIX} refreshReportContextFromStatus`, err);
    notifyStudy(state);
  }
}
function selectMeasurement(state, measurementId) {
  state.selectedMeasurementId = measurementId;
  if (measurementId) {
    const m = state.measurements.find((row) => row.id === measurementId);
    if (m?.segmentNumber != null) {
      state.selectedSegmentNumber = m.segmentNumber;
      state.selectedSegmentSopUid = m.segmentationSOPInstanceUID || "";
    }
  }
  notifyStudy(state);
}
function selectSegment(state, segmentNumber, sopUid = "") {
  state.selectedSegmentNumber = segmentNumber;
  state.selectedSegmentSopUid = sopUid;
  notifyStudy(state);
}
function addMeasurementForSegment(state, segmentNumber, sopUid) {
  const match = findCatalogSegment(
    state.segCatalog,
    segmentNumber,
    sopUid || void 0
  );
  if (!match) {
    state.segLoadDetail = "No segment to measure";
    notifyStudy(state);
    return;
  }
  const num = Number(match.segment.number);
  const sop = String(match.instance.sopInstanceUID || "");
  const existing = state.measurements.find(
    (m) => /^volume$/i.test(m.quantity) && Number(m.segmentNumber) === num && (!m.segmentationSOPInstanceUID || !sop || m.segmentationSOPInstanceUID === sop)
  );
  if (existing) {
    state.selectedMeasurementId = existing.id;
    state.selectedSegmentNumber = num;
    state.selectedSegmentSopUid = sop;
    state.segLoadDetail = `Selected Volume for ${existing.segmentLabel}`;
    notifyStudy(state);
    return;
  }
  const label = String(match.segment.label || `Segment ${num}`);
  const id = `manual:${sop || "seg"}:${num}:volume:${Date.now()}`;
  state.measurements.push({
    id,
    quantity: "Volume",
    value: Number.isFinite(match.segment.volumeMm3) ? match.segment.volumeMm3 : "\u2014",
    units: "mm3",
    segmentNumber: Number.isFinite(num) ? num : null,
    segmentLabel: label,
    segmentationSOPInstanceUID: sop,
    trackingIdentifier: label,
    source: "manual"
  });
  state.selectedMeasurementId = id;
  state.selectedSegmentNumber = Number.isFinite(num) ? num : null;
  state.selectedSegmentSopUid = sop;
  state.segLoadDetail = `Added Volume for ${label}`;
  notifyStudy(state);
}
function addMeasurementForSelectedOrFirst(state) {
  if (state.selectedSegmentNumber != null) {
    addMeasurementForSegment(
      state,
      state.selectedSegmentNumber,
      state.selectedSegmentSopUid || void 0
    );
    return;
  }
  const first = firstCatalogSegment(state.segCatalog);
  if (!first) {
    state.segLoadDetail = "No segmentations yet \u2014 refresh from Image Display";
    notifyStudy(state);
    return;
  }
  addMeasurementForSegment(
    state,
    Number(first.segment.number),
    first.instance.sopInstanceUID || void 0
  );
}
function removeMeasurement(state, measurementId) {
  const before = state.measurements.length;
  state.measurements = state.measurements.filter((m) => m.id !== measurementId);
  if (state.selectedMeasurementId === measurementId) {
    state.selectedMeasurementId = null;
  }
  if (state.measurements.length < before) {
    state.segLoadDetail = "Removed measurement";
  }
  notifyStudy(state);
}
function nextSnapshotFilename(state) {
  const n = state.snapshots.length + 1;
  return `snapshot-${String(n).padStart(3, "0")}.png`;
}
function parsePngFullSizeResponse(responses) {
  for (const item of responses) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    const data = row.data;
    if (!data || typeof data !== "object") continue;
    const payload = data;
    const dataBase64 = String(payload.data || "").trim();
    if (!dataBase64) continue;
    const contentType = String(payload.contentType || "image/png").trim();
    const width = typeof payload.width === "number" && Number.isFinite(payload.width) ? payload.width : void 0;
    const height = typeof payload.height === "number" && Number.isFinite(payload.height) ? payload.height : void 0;
    return { contentType, dataBase64, width, height };
  }
  return null;
}
function makeSnapshotThumbnail(dataBase64, contentType = "image/png", maxWidth = 96) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxWidth / Math.max(1, img.naturalWidth));
      const width = Math.max(1, Math.round(img.naturalWidth * scale));
      const height = Math.max(1, Math.round(img.naturalHeight * scale));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("No 2d context"));
        return;
      }
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL("image/png");
      const comma = dataUrl.indexOf(",");
      resolve({
        thumbBase64: comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl,
        width,
        height
      });
    };
    img.onerror = () => reject(new Error("Failed to decode PNG"));
    img.src = `data:${contentType};base64,${dataBase64}`;
  });
}
async function requestPngFullSize(state) {
  const subscriber = state.subscriberName || state.client?.getSessionConfig?.()?.subscriberName?.trim() || "";
  if (!state.client || !subscriber) {
    return { ok: false, detail: "Not connected to Slicer hub" };
  }
  try {
    const result = await state.client.request({
      "subscriber.name": subscriber,
      "subscriber.product.name": PRODUCT_NAME,
      "subscriber.actor": REPORTING_ACTOR,
      "target.actor": "ID",
      "target.product.name": "*",
      event: {
        "hub.event": k("PNGFULLSIZE"),
        ...state.topic ? { "hub.topic": state.topic } : {},
        context: { dataType: "PNGFULLSIZE" }
      }
    });
    const body = result?.data ?? result;
    const { responses, timedOut, missing } = de(body);
    const parsed = parsePngFullSizeResponse(responses);
    if (parsed) {
      return { ok: true, ...parsed };
    }
    if (timedOut || missing && missing.length) {
      return { ok: false, detail: "Image Display did not respond in time" };
    }
    return { ok: false, detail: "No PNG in response" };
  } catch (err) {
    return {
      ok: false,
      detail: `PNGFULLSIZE failed: ${err?.message ?? err}`
    };
  }
}
function uint8ToBase64(bytes) {
  let binary = "";
  const chunk = 32768;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
var seenPngSendMessageIds = /* @__PURE__ */ new Set();
async function handlePngSend(state, message) {
  const event = message?.event;
  if (te(event) !== "png-send") return false;
  if (!state.client) return true;
  const ctx = event?.context && typeof event.context === "object" && !Array.isArray(event.context) ? event.context : {};
  const messageId = String(ctx.messageId || "").trim();
  if (messageId) {
    if (seenPngSendMessageIds.has(messageId)) return true;
    seenPngSendMessageIds.add(messageId);
    if (seenPngSendMessageIds.size > 200) {
      const first = seenPngSendMessageIds.values().next().value;
      if (first) seenPngSendMessageIds.delete(first);
    }
  }
  try {
    const resolved = await mo(
      state.client,
      message
    );
    const resolvedEvent = resolved?.event ?? message.event;
    const files = Ei(resolvedEvent);
    let added = 0;
    for (const entry of files) {
      const bytes = fileBytes(entry);
      if (!bytes?.length) continue;
      const dataBase64 = uint8ToBase64(bytes);
      const contentType = String(entry.mimeType || "image/png").trim() || "image/png";
      const width = typeof ctx.width === "number" && Number.isFinite(ctx.width) ? ctx.width : void 0;
      const height = typeof ctx.height === "number" && Number.isFinite(ctx.height) ? ctx.height : void 0;
      let thumbBase64 = "";
      try {
        const thumb = await makeSnapshotThumbnail(dataBase64, contentType);
        thumbBase64 = thumb.thumbBase64;
      } catch (err) {
        console.warn(`${LOG_PREFIX} png-send thumb failed`, err);
      }
      const id = `snap-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
      const row = {
        id,
        filename: nextSnapshotFilename(state),
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "ready",
        contentType,
        dataBase64,
        thumbBase64: thumbBase64 || void 0,
        width,
        height
      };
      state.snapshots = [...state.snapshots, row];
      added++;
    }
    if (added) notifyStudy(state);
  } catch (err) {
    console.warn(`${LOG_PREFIX} png-send handler`, err);
  }
  return true;
}
async function addSnapshotAndRequestPng(state) {
  const id = `snap-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const row = {
    id,
    filename: nextSnapshotFilename(state),
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    status: "pending",
    detail: "Requesting PNG from Image Display\u2026"
  };
  state.snapshots = [...state.snapshots, row];
  notifyStudy(state);
  const result = await requestPngFullSize(state);
  const idx = state.snapshots.findIndex((s2) => s2.id === id);
  if (idx < 0) return;
  const next = [...state.snapshots];
  if (result.ok && result.dataBase64) {
    let thumbBase64 = "";
    try {
      const thumb = await makeSnapshotThumbnail(
        result.dataBase64,
        result.contentType || "image/png"
      );
      thumbBase64 = thumb.thumbBase64;
    } catch (err) {
      console.warn(`${LOG_PREFIX} snapshot thumb failed`, err);
    }
    next[idx] = {
      ...next[idx],
      status: "ready",
      detail: void 0,
      contentType: result.contentType || "image/png",
      dataBase64: result.dataBase64,
      thumbBase64: thumbBase64 || void 0,
      width: result.width,
      height: result.height
    };
  } else {
    next[idx] = {
      ...next[idx],
      status: "error",
      detail: result.detail || "Capture failed"
    };
  }
  state.snapshots = next;
  notifyStudy(state);
}
function removeSnapshot(state, snapshotId) {
  const next = state.snapshots.filter((s2) => s2.id !== snapshotId);
  if (next.length === state.snapshots.length) return;
  state.snapshots = next;
  notifyStudy(state);
}
function downloadSnapshotLocally(state, snapshotId) {
  const snap = state.snapshots.find((s2) => s2.id === snapshotId);
  if (!snap?.dataBase64 || snap.status !== "ready") return;
  const contentType = snap.contentType || "image/png";
  const binary = atob(snap.dataBase64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const blob = new Blob([bytes], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = snap.filename || "snapshot.png";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
function openSnapshotFullView(state, snapshotId) {
  const snap = state.snapshots.find((s2) => s2.id === snapshotId);
  if (!snap?.dataBase64 || snap.status !== "ready") return;
  const contentType = snap.contentType || "image/png";
  let backdrop = document.getElementById("snapshotViewModal");
  if (!backdrop) {
    backdrop = document.createElement("div");
    backdrop.id = "snapshotViewModal";
    backdrop.className = "rp-modal-backdrop";
    backdrop.innerHTML = `
      <div class="rp-modal rp-snapshot-view-modal" role="dialog" aria-labelledby="snapshotViewTitle">
        <div class="rp-modal-header">
          <h2 id="snapshotViewTitle">Snapshot</h2>
          <button type="button" class="rp-modal-close" data-close-snapshot-view aria-label="Close">\xD7</button>
        </div>
        <div class="rp-modal-body rp-snapshot-view-body">
          <img id="snapshotViewImg" alt="" />
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (ev) => {
      const t = ev.target;
      if (t === backdrop || t?.closest("[data-close-snapshot-view]")) {
        backdrop.hidden = true;
        const img2 = document.getElementById(
          "snapshotViewImg"
        );
        if (img2) img2.removeAttribute("src");
      }
    });
  }
  const title = document.getElementById("snapshotViewTitle");
  if (title) title.textContent = snap.filename || "Snapshot";
  const img = document.getElementById(
    "snapshotViewImg"
  );
  if (img) {
    img.src = `data:${contentType};base64,${snap.dataBase64}`;
    img.alt = snap.filename || "Snapshot";
  }
  backdrop.hidden = false;
}
async function handleDicomSendMessage(state, message) {
  const event = message?.event;
  if (te(event) !== "dicom-send") return false;
  if (!state.client) return true;
  try {
    const resolved = await mo(
      state.client,
      message
    );
    const resolvedEvent = resolved?.event ?? message.event;
    const files = Ei(resolvedEvent);
    let added = 0;
    for (const entry of files) {
      const bytes = fileBytes(entry);
      if (!bytes?.length) continue;
      const parsed = await parseTid1500FromBuffer(bytes);
      if (!parsed.ok) continue;
      for (const m of parsed.measurements) {
        const id = `sr:${parsed.sopInstanceUID}:${m.quantity}:${m.segmentNumber}:${added}`;
        state.measurements.push({
          id,
          quantity: m.quantity,
          value: m.value,
          units: m.units,
          segmentNumber: m.segmentNumber,
          segmentLabel: m.segmentLabel,
          segmentationSOPInstanceUID: m.segmentationSOPInstanceUID,
          trackingIdentifier: m.trackingIdentifier,
          source: "sr"
        });
        added++;
      }
    }
    if (added) {
      state.segLoadDetail = `Added ${added} measurement${added === 1 ? "" : "s"} from DICOM SR`;
      notifyStudy(state);
    }
  } catch (err) {
    console.warn(`${LOG_PREFIX} dicom-send SR handler`, err);
  }
  return true;
}
function setConnection(state, connection, detail) {
  const wasConnected = state.connection === "connected";
  state.connection = connection;
  state.connectionDetail = detail;
  if (wasConnected && connection !== "connected") {
    setConferenceView(state, null);
    clearConnectedApps(state);
  }
  notifyStatus(state);
  if (connection === "connected") {
    void syncConferenceView(state);
  }
}
function hubDef(state) {
  return getHubDefinitions()[state.hubKey];
}
function hubEndpoint(state) {
  return hubDef(state).hubEndpoint;
}
function studyInfoFromContext(context) {
  const normalized = Ce(context);
  const files = P(normalized);
  return {
    sampleId: G(normalized) || "",
    openMode: un(normalized) || "",
    studyUid: E(normalized) || "",
    seriesUid: I(normalized) || "",
    dicomwebRoot: Ve(normalized) || "",
    fileCount: files.length,
    fileNames: files.map((f) => f.fileName || f.label || "").filter(Boolean).slice(0, 8)
  };
}
function extractActorKeywords(actor) {
  if (actor == null) return [];
  if (typeof actor === "string") {
    const keyword = actor.trim();
    return keyword ? [keyword] : [];
  }
  if (Array.isArray(actor)) {
    return actor.flatMap((entry) => extractActorKeywords(entry));
  }
  if (typeof actor === "object") {
    const obj = actor;
    const candidate = obj.id || obj.key || obj.name;
    if (candidate == null) return [];
    const keyword = String(candidate).trim();
    return keyword ? [keyword] : [];
  }
  return [];
}
function handleIncomingStatusRequest(state, message) {
  const event = message?.event;
  if (!event || !Qi(te(event))) return false;
  const context = event.context && typeof event.context === "object" ? event.context : {};
  const correlationId = context.id;
  if (typeof correlationId !== "string" || !correlationId) return false;
  const requestedTargets = extractActorKeywords(message["target.actor"]);
  if (requestedTargets.length > 0 && !requestedTargets.includes("*") && !requestedTargets.includes(REPORTING_ACTOR)) {
    return false;
  }
  if (String(context.dataType || "").toUpperCase() !== "STATUS") return false;
  markConnectedAppFromMessage(state, message);
  notifyStatus(state);
  const responseData = state.lastImagingStudyOpenContext.length ? {
    "context.type": "ImagingStudy",
    context: eo(state.lastImagingStudyOpenContext)
  } : {
    source: "status",
    product: PRODUCT_NAME,
    items: [{ key: "availability", value: "online" }]
  };
  state.client?.sendHubRequestResponse(
    correlationId,
    "STATUS",
    responseData,
    event["hub.topic"]
  );
  return true;
}
function clearOpenStudyLocal(state) {
  state.openStudy = null;
  state.lastImagingStudyOpenContext = [];
  state.segCatalog = EMPTY_SEG_CATALOG;
  state.measurements = [];
  state.selectedMeasurementId = null;
  state.selectedSegmentNumber = null;
  state.selectedSegmentSopUid = "";
  state.segLoadDetail = "";
  state.sceneDoc = null;
  state.segmentVisible = {};
  state.segmentOpacity = {};
  state.labelsVisible = true;
  state.segOpacity = 1;
  state.volumeOpacity = 1;
  state.volumeShift = 0;
  state.volumeShiftRange = 500;
  state.volumePreset = "";
  state.volumeName = "";
  state.volumeCropEnabled = false;
  state.volumeRoiVisible = false;
  state.snapshots = [];
  volumeCropFirstEnable = true;
}
function handleImagingStudyMessage(state, message) {
  const event = message?.event;
  const name = te(event);
  if (name === "imagingstudy-close") {
    clearOpenStudyLocal(state);
    console.info(`${LOG_PREFIX} ImagingStudy-close`);
    notifyStudy(state);
    return true;
  }
  if (name !== "imagingstudy-open") return false;
  if (state.conference && !state.conferenceFollowHost && state.conference.selfRole !== "leading") {
    return true;
  }
  const context = eo(to(message));
  state.lastImagingStudyOpenContext = context;
  state.openStudy = studyInfoFromContext(context);
  console.info(
    `${LOG_PREFIX} ImagingStudy-open`,
    state.openStudy.sampleId || "(no sample id)",
    "mode=",
    state.openStudy.openMode || "(none)"
  );
  notifyStudy(state);
  void refreshReportContextFromStatus(state);
  return true;
}
function countCatalogSegments(catalog) {
  return catalog.segmentations.reduce(
    (acc, s2) => acc + (s2.segments?.length || 0),
    0
  );
}
function handleStructureReportUpdate(state, message) {
  const event = message?.event;
  if (te(event) !== Ji) return false;
  const prevCount = countCatalogSegments(state.segCatalog);
  const context = eo(to(message));
  const catalog = segCatalogFromContext(context) ?? EMPTY_SEG_CATALOG;
  state.segCatalog = catalog;
  applyCatalogMeasurements(state);
  adoptSceneVisibility(state, state.sceneDoc);
  const n = countCatalogSegments(catalog);
  state.segLoadDetail = withResponderName(
    n > 0 ? `Updated ${n} segment${n === 1 ? "" : "s"} from Image Display` : "Image Display has no segmentation loaded",
    no(message)
  );
  console.info(`${LOG_PREFIX} StructureReport-update segments=`, n);
  notifyStudy(state);
  if (n > prevCount) {
    try {
      document.title = `\u25CF DICOM SR \u2014 ${n} segments`;
      window.setTimeout(() => {
        document.title = "DICOM SR \u2014 Measurements";
      }, 2500);
    } catch {
    }
  }
  return true;
}
function stripCastParamsFromUrl() {
  const url = new URL(window.location.href);
  let changed = false;
  for (const key of ["topic", "id-token", "hub"]) {
    if (url.searchParams.has(key)) {
      url.searchParams.delete(key);
      changed = true;
    }
  }
  if (changed) {
    window.history.replaceState({}, "", url.pathname + url.search + url.hash);
  }
}
async function syncStoredUserNameWithHub(state) {
  const endpoint = hubEndpoint(state);
  const currentOrigin = hubOriginFromEndpoint(endpoint) || "";
  const currentStartedAt = await fetchHubStartedAt(endpoint);
  if (currentStartedAt) state.hubStartedAt = currentStartedAt;
  const storedUser = getStoredUserName();
  if (!storedUser) return;
  const storedStartedAt = getStoredUserHubStartedAt();
  const storedOrigin = getStoredUserHubOrigin();
  const hubRestarted = Boolean(currentStartedAt && storedStartedAt) && storedStartedAt !== currentStartedAt;
  const hubChanged = Boolean(storedOrigin && currentOrigin) && storedOrigin !== currentOrigin;
  const missingHubBinding = Boolean(currentStartedAt) && (!storedStartedAt || !storedOrigin);
  if (hubRestarted || hubChanged || missingHubBinding) {
    console.info(
      `${LOG_PREFIX} discarding stored user name (hub restarted or changed)`
    );
    clearStoredUserName();
    state.userName = "";
    state.client?.setUserName("");
  }
}
function ensureClient(state, recreate = false, opts) {
  if (!state.client || recreate) {
    state.client?.close();
    const hub = hubDef(state);
    state.client = new fe(
      {
        name: "demo",
        version: "1.0",
        hub_endpoint: hub.hubEndpoint,
        authorization_endpoint: hub.authorizeEndpoint,
        token_endpoint: hub.tokenEndpoint,
        client_id: hub.client_id,
        client_secret: hub.client_secret
      },
      {
        subscriberName: state.subscriberName,
        productName: PRODUCT_NAME,
        productVersion: "1.0",
        actors: [REPORTING_ACTOR],
        topic: state.topic,
        events: SUBSCRIBE_EVENTS,
        lease: 7200,
        defaultTargetActor: "*",
        userName: getStoredUserName() || void 0
      },
      {
        callbackUrl: `${window.location.origin}/castCallback`,
        preserveSessionTopicFromToken: Boolean(opts?.preserveSessionTopicFromToken),
        autoReconnect: true
      }
    );
    state.client.onMessage((message) => {
      if (handleConferenceHubEvent(state, message)) return;
      if (handleSubscriptionRemoved(state, message)) return;
      if (handleIncomingStatusRequest(state, message)) return;
      if (handleImagingStudyMessage(state, message)) return;
      if (handleStructureReportUpdate(state, message)) return;
      void handleDicomSendMessage(state, message);
      void handlePngSend(state, message);
    });
    state.client.onConnectionStateChange((wsState) => {
      if (wsState === "connecting") {
        setConnection(state, "connecting", "Websocket connecting");
      } else if (wsState === "connected") {
        setConnection(state, "connected", "Websocket connected");
      } else if (wsState === "error") {
        setConnection(state, "error", "Websocket error");
      } else {
        setConnection(state, "disconnected", "Websocket disconnected");
      }
    });
  }
  state.client.setTopic(state.topic);
  const storedUserName = getStoredUserName();
  if (storedUserName) state.client.setUserName(storedUserName);
  return state.client;
}
function buildPublishPayload(state, hubEvent, context) {
  return {
    event: {
      "hub.topic": state.topic,
      "hub.event": hubEvent,
      context
    },
    actor: REPORTING_ACTOR,
    "target.actor": "*",
    "target.product.name": "*"
  };
}
async function publishImagingStudyClose(state) {
  if (!state.client) {
    console.warn(`${LOG_PREFIX} close study: subscribe first`);
    return false;
  }
  if (!state.lastImagingStudyOpenContext.length) {
    console.warn(`${LOG_PREFIX} close study: no open context`);
    return false;
  }
  const context = eo(state.lastImagingStudyOpenContext);
  const payload = buildPublishPayload(state, xi, context);
  try {
    const res = await state.client.publish(payload);
    if (res && res.ok) {
      clearOpenStudyLocal(state);
      notifyStudy(state);
      return true;
    }
    console.warn(
      `${LOG_PREFIX} close study failed`,
      res ? `HTTP ${res.status}` : "No response"
    );
    return false;
  } catch (err) {
    console.error(`${LOG_PREFIX} close study exception`, err);
    return false;
  }
}
async function handleReportingClose(state) {
  await publishImagingStudyClose(state);
}
async function requestStatusFromHostWorklist(state, hostTopic) {
  const topic = String(hostTopic || "").trim();
  if (!topic) {
    console.warn(`${LOG_PREFIX} host STATUS skip: no host topic`);
    return;
  }
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} host STATUS skip: not connected`);
    return;
  }
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) {
    console.warn(`${LOG_PREFIX} host STATUS skip: no subscriber name`);
    return;
  }
  try {
    console.info(`${LOG_PREFIX} STATUS request \u2192 * topic=`, topic);
    const result = await state.client.request({
      "subscriber.name": subscriber,
      "subscriber.product.name": PRODUCT_NAME,
      "subscriber.actor": REPORTING_ACTOR,
      "target.actor": "*",
      event: {
        "hub.event": k("STATUS"),
        "hub.topic": topic,
        context: { dataType: "STATUS" }
      }
    });
    if (!result.ok) {
      console.warn(
        `${LOG_PREFIX} host STATUS failed`,
        `HTTP ${result.status ?? "?"}`
      );
      return;
    }
    const envelope = result.data && typeof result.data === "object" ? result.data : {};
    const responses = Array.isArray(envelope.responses) ? envelope.responses : [];
    let chosen;
    for (const item of responses) {
      const itemData = item?.data;
      if (!itemData || typeof itemData !== "object" || itemData["context.type"] !== "ImagingStudy") {
        continue;
      }
      const actor = String(item?.actor ?? "").trim().toUpperCase();
      if (actor === WORKLIST_ACTOR || chosen === void 0) {
        chosen = itemData;
        if (actor === WORKLIST_ACTOR) break;
      }
    }
    if (!chosen) {
      console.info(
        `${LOG_PREFIX} host STATUS: no ImagingStudy in ${responses.length} response(s)`
      );
      return;
    }
    const context = eo(chosen.context);
    if (!context.length) {
      console.info(`${LOG_PREFIX} host STATUS: ImagingStudy context empty`);
      return;
    }
    if (Rs(context, state.lastImagingStudyOpenContext)) {
      console.info(
        `${LOG_PREFIX} host STATUS: same study already open \u2014 skip refresh`
      );
      yt(vs);
      return;
    }
    state.lastImagingStudyOpenContext = context;
    state.openStudy = studyInfoFromContext(context);
    notifyStudy(state);
    void refreshReportContextFromStatus(state);
    console.info(
      `${LOG_PREFIX} host STATUS applied ImagingStudy items=`,
      context.length
    );
  } catch (err) {
    console.error(`${LOG_PREFIX} host STATUS exception`, err);
  }
}
async function rebindSessionUserName(state, userName) {
  const next = String(userName || "").trim();
  if (!next) throw new Error("User name is required");
  const client = state.client;
  if (!client) {
    state.userName = next;
    setStoredUserName(next);
    notifyStatus(state);
    return;
  }
  setConnection(state, "connecting", "Switching user");
  try {
    const result = await client.rebindUserName(next);
    const session = client.getSessionConfig();
    state.userName = String(result.user_name || next).trim() || next;
    state.topic = String(result.topic || session.topic || next).trim() || next;
    if (session.subscriberName) state.subscriberName = session.subscriberName;
    const startedAt = state.hubStartedAt || await fetchHubStartedAt(hubEndpoint(state));
    if (startedAt) state.hubStartedAt = startedAt;
    setStoredUserName(
      state.userName,
      startedAt,
      hubOriginFromEndpoint(hubEndpoint(state))
    );
    if (result.status === 202) {
      setConnection(state, "connected", "Websocket connected");
    } else {
      setConnection(
        state,
        "disconnected",
        `Subscribe failed (${String(result.status)})`
      );
    }
  } catch (err) {
    setConnection(
      state,
      "error",
      err instanceof Error ? err.message : String(err)
    );
    throw err;
  }
}
async function autoConnect(state) {
  await Es();
  const params = new URLSearchParams(window.location.search);
  const urlToken = params.get("id-token")?.trim() || "";
  if (params.get("topic")?.trim()) {
    state.topic = params.get("topic").trim();
  }
  if (params.get("userName")?.trim()) {
    state.userName = params.get("userName").trim();
  }
  await syncStoredUserNameWithHub(state);
  setConnection(state, "connecting", "Authenticating");
  try {
    const client = ensureClient(state, true, {
      preserveSessionTopicFromToken: Boolean(state.topic && urlToken)
    });
    const preferredName = String(state.userName || "").trim() || getStoredUserName();
    if (urlToken && state.topic) {
      client.setUserName(state.topic);
    } else if (preferredName) {
      client.setUserName(preferredName);
    } else {
      client.setUserName("");
    }
    if (state.topic && !urlToken) client.setTopic(state.topic);
    if (urlToken) {
      console.info(`${LOG_PREFIX} auto-connect: id-token deep-link`);
      client.setToken(urlToken);
      stripCastParamsFromUrl();
    } else {
      console.info(`${LOG_PREFIX} auto-connect: authenticate`);
      const result = await client.authenticate();
      const userName = result?.user_name || preferredName || "";
      const code = result?.code || "";
      const tokensReady = Boolean(result?.tokensReady);
      const redirecting = Boolean(result?.redirecting);
      if (redirecting) {
        setConnection(state, "connecting", "Redirecting to login");
        return;
      }
      if (userName) {
        const startedAt = state.hubStartedAt || await fetchHubStartedAt(hubEndpoint(state));
        if (startedAt) state.hubStartedAt = startedAt;
        setStoredUserName(
          userName,
          startedAt,
          hubOriginFromEndpoint(hubEndpoint(state))
        );
        state.userName = userName;
      }
      state.lastAuthCode = code;
      if (!tokensReady && !code) {
        setConnection(state, "disconnected", "Authenticate failed");
        return;
      }
      console.info(`${LOG_PREFIX} auto-connect: authorize`);
      setConnection(state, "connecting", "Getting token");
      const authCode = state.lastAuthCode;
      state.lastAuthCode = "";
      const ok = await client.getToken(authCode || "");
      if (!ok) {
        setConnection(state, "disconnected", "Token failed");
        return;
      }
    }
    if (state.topic) client.setTopic(state.topic);
    const session = client.getSessionConfig();
    if (session.subscriberName) state.subscriberName = session.subscriberName;
    if (session.topic) state.topic = session.topic;
    const alignedUser = String(session.userName || "").trim() || String(state.topic || "").trim() || preferredName;
    if (alignedUser) {
      state.userName = alignedUser;
      client.setUserName(alignedUser);
      const startedAt = state.hubStartedAt || await fetchHubStartedAt(hubEndpoint(state));
      if (startedAt) state.hubStartedAt = startedAt;
      setStoredUserName(
        alignedUser,
        startedAt,
        hubOriginFromEndpoint(hubEndpoint(state))
      );
    }
    notifyStatus(state);
    console.info(`${LOG_PREFIX} auto-connect: subscribe`);
    const status = await client.subscribe();
    if (status === 202) {
      setConnection(state, "connected", "Websocket connected");
      console.info(
        `${LOG_PREFIX} auto-connect done topic=`,
        state.topic,
        "user=",
        state.userName
      );
      void refreshReportContextFromStatus(state);
    } else {
      setConnection(
        state,
        "disconnected",
        `Subscribe failed (${String(status)})`
      );
    }
  } catch (err) {
    console.error(`${LOG_PREFIX} auto-connect failed`, err);
    setConnection(
      state,
      "error",
      err instanceof Error ? err.message : String(err)
    );
  }
}

// vr-preset-menu.ts
function openVrPresetMenu(opts) {
  if (document.getElementById("vr-preset-menu")) return;
  const overlay = document.createElement("div");
  overlay.id = "vr-preset-menu";
  overlay.style.cssText = "position:fixed;inset:0;z-index:2100;background:rgba(5,6,10,.82);display:flex;align-items:center;justify-content:center;";
  const card = document.createElement("div");
  card.style.cssText = "background:#11141d;border:1px solid #33507e;border-radius:12px;padding:18px 20px;max-width:min(720px,94vw);max-height:88vh;overflow-y:auto;font:13px -apple-system,system-ui,sans-serif;color:#d6e2f2;";
  card.innerHTML = `<div style="display:flex;align-items:baseline;justify-content:space-between;margin-bottom:12px;"><h3 style="margin:0;color:#fff;font-size:16px;">Volume rendering preset</h3><span style="color:#5a6b85;font-size:11px;">Slicer CT presets</span></div>`;
  const grid = document.createElement("div");
  grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px;";
  card.appendChild(grid);
  const close = () => overlay.remove();
  for (const it5 of opts.items) {
    const cell = document.createElement("button");
    const sel = it5.name === opts.current;
    cell.type = "button";
    cell.style.cssText = "display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px 6px 7px;cursor:pointer;background:" + (sel ? "rgba(84,198,240,.18)" : "rgba(255,255,255,.04)") + ";border:1px solid " + (sel ? "#54c6f0" : "rgba(255,255,255,.12)") + ";border-radius:10px;color:#eaf0ff;";
    it5.canvas.style.cssText = "width:110px;height:110px;border-radius:7px;background:#05060a;display:block;";
    const lab = document.createElement("div");
    lab.textContent = it5.label;
    lab.style.cssText = "font:600 11.5px -apple-system,system-ui,sans-serif;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:110px;" + (sel ? "color:#9fe9ff;" : "");
    cell.appendChild(it5.canvas);
    cell.appendChild(lab);
    cell.onclick = () => {
      opts.onPick(it5.name);
      close();
    };
    grid.appendChild(cell);
  }
  overlay.appendChild(card);
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) close();
  });
  const esc = (e) => {
    if (e.key === "Escape") {
      close();
      document.removeEventListener("keydown", esc, true);
    }
  };
  document.addEventListener("keydown", esc, true);
  document.body.appendChild(overlay);
}

// vr-presets.ts
var VR_PRESET_DEFAULT = {
  name: "",
  label: "Default (W/L)",
  colorTF: [
    [-1e3, 0, 0, 0],
    [0, 0.35, 0.35, 0.35],
    [400, 0.85, 0.85, 0.85],
    [1e3, 1, 1, 1]
  ],
  opacityTF: [
    [-1e3, 0],
    [0, 0.15],
    [400, 0.85],
    [1e3, 1]
  ]
};
var VR_PRESET_OPTIONS = [
  {
    name: "CT-AAA",
    label: "CT AAA (angio)",
    colorTF: [
      [-3024, 0, 0, 0],
      [143.556, 0.6157, 0.3569, 0.1843],
      [166.222, 0.8824, 0.6039, 0.2902],
      [214.389, 1, 1, 1],
      [419.736, 1, 0.937, 0.9545],
      [3071, 0.8275, 0.6588, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [143.556, 0],
      [166.222, 0.6863],
      [214.389, 0.6961],
      [419.736, 0.8333],
      [3071, 0.8039]
    ]
  },
  {
    name: "CT-Bone",
    label: "CT Bone",
    colorTF: [
      [-3024, 0, 0, 0],
      [-16.446, 0.7294, 0.2549, 0.302],
      [641.385, 0.9059, 0.8157, 0.5529],
      [3071, 1, 1, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [-16.446, 0],
      [641.385, 0.7157],
      [3071, 0.7059]
    ]
  },
  {
    name: "CT-Bones",
    label: "CT Bones",
    colorTF: [
      [-1e3, 0.3, 0.3, 1],
      [-488, 0.3, 1, 0.3],
      [463.28, 1, 0, 0],
      [659.15, 1, 0.9125, 0.0375],
      [953, 1, 0.3, 0.3]
    ],
    opacityTF: [
      [-1e3, 0],
      [152.19, 0],
      [278.93, 0.1905],
      [952, 0.2]
    ]
  },
  {
    name: "CT-Cardiac",
    label: "CT Cardiac",
    colorTF: [
      [-3024, 0, 0, 0],
      [-77.688, 0.549, 0.251, 0.149],
      [94.952, 0.8824, 0.6039, 0.2902],
      [179.052, 1, 0.937, 0.9545],
      [260.439, 0.6157, 0, 0],
      [3071, 0.8275, 0.6588, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [-77.688, 0],
      [94.952, 0.2857],
      [179.052, 0.5536],
      [260.439, 0.8482],
      [3071, 0.875]
    ]
  },
  {
    name: "CT-Chest-Contrast-Enhanced",
    label: "CT Chest (contrast)",
    colorTF: [
      [-3024, 0, 0, 0],
      [67.011, 0.549, 0.251, 0.149],
      [251.105, 0.8824, 0.6039, 0.2902],
      [439.291, 1, 0.937, 0.9545],
      [3071, 0.8275, 0.6588, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [67.011, 0],
      [251.105, 0.4464],
      [439.291, 0.625],
      [3071, 0.6161]
    ]
  },
  {
    name: "CT-Coronary-Arteries",
    label: "CT Coronary",
    colorTF: [
      [-2048, 0, 0, 0],
      [136.47, 0, 0, 0],
      [159.215, 0.1598, 0.1598, 0.1598],
      [318.43, 0.7647, 0.7647, 0.7647],
      [478.693, 1, 1, 1],
      [3661, 1, 1, 1]
    ],
    opacityTF: [
      [-2048, 0],
      [136.47, 0],
      [159.215, 0.2589],
      [318.43, 0.5714],
      [478.693, 0.7768],
      [3661, 1]
    ]
  },
  {
    name: "CT-Fat",
    label: "CT Fat",
    colorTF: [
      [-1e3, 0.3, 0.3, 1],
      [-497.5, 0.3, 1, 0.3],
      [-99, 0, 0, 1],
      [-76.946, 0, 1, 0],
      [-65.481, 0.8354, 0.8889, 0.0165],
      [83.89, 1, 0, 0],
      [463.28, 1, 0, 0],
      [659.15, 1, 0.9125, 0.0375],
      [2952, 1, 0.3003, 0.2999]
    ],
    opacityTF: [
      [-1e3, 0],
      [-100, 0],
      [-99, 0.15],
      [-60, 0.15],
      [-59, 0],
      [101.2, 0],
      [952, 0]
    ]
  },
  {
    name: "CT-Lung",
    label: "CT Lung",
    colorTF: [
      [-1e3, 0.3, 0.3, 1],
      [-600, 0, 0, 1],
      [-530, 0.1347, 0.7817, 0.0725],
      [-460, 0.9292, 1, 0.1095],
      [-400, 0.8889, 0.2549, 0.024],
      [2952, 1, 0.3, 0.3]
    ],
    opacityTF: [
      [-1e3, 0],
      [-600, 0],
      [-599, 0.15],
      [-400, 0.15],
      [-399, 0],
      [2952, 0]
    ]
  },
  {
    name: "CT-MIP",
    label: "CT MIP",
    colorTF: [
      [-3024, 0, 0, 0],
      [-637.62, 1, 1, 1],
      [700, 1, 1, 1],
      [3071, 1, 1, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [-637.62, 0],
      [700, 1],
      [3071, 1]
    ]
  },
  {
    name: "CT-Muscle",
    label: "CT Muscle",
    colorTF: [
      [-3024, 0, 0, 0],
      [-155.407, 0.549, 0.251, 0.149],
      [217.641, 0.8824, 0.6039, 0.2902],
      [419.736, 1, 0.937, 0.9545],
      [3071, 0.8275, 0.6588, 1]
    ],
    opacityTF: [
      [-3024, 0],
      [-155.407, 0],
      [217.641, 0.6765],
      [419.736, 0.8333],
      [3071, 0.8039]
    ]
  },
  {
    name: "CT-Pulmonary-Arteries",
    label: "CT Pulmonary",
    colorTF: [
      [-2048, 0, 0, 0],
      [-568.625, 0, 0, 0],
      [-364.081, 0.3961, 0.302, 0.1804],
      [-244.813, 0.6118, 0.3529, 0.0706],
      [18.277, 0.8431, 0.0157, 0.1569],
      [447.798, 0.7529, 0.7529, 0.7529],
      [3592.73, 1, 1, 1]
    ],
    opacityTF: [
      [-2048, 0],
      [-568.625, 0],
      [-364.081, 0.0714],
      [-244.813, 0.4018],
      [18.277, 0.6071],
      [447.798, 0.8304],
      [3592.73, 0.8393]
    ]
  },
  {
    name: "CT-Soft-Tissue",
    label: "CT Soft Tissue",
    colorTF: [
      [-2048, 0, 0, 0],
      [-167.01, 0, 0, 0],
      [-160, 0.0556, 0.0556, 0.0556],
      [240, 1, 1, 1],
      [3661, 1, 1, 1]
    ],
    opacityTF: [
      [-2048, 0],
      [-167.01, 0],
      [-160, 1],
      [240, 1],
      [3661, 1]
    ]
  }
];
function vrPresetLabel(name) {
  const key = String(name || "").trim();
  if (!key) return VR_PRESET_DEFAULT.label;
  return VR_PRESET_OPTIONS.find((p) => p.name === key)?.label || key;
}
function sampleTf(tf, t, comps) {
  if (!tf.length) return Array(comps).fill(0);
  if (t <= tf[0][0]) return tf[0].slice(1, 1 + comps);
  const last = tf[tf.length - 1];
  if (t >= last[0]) return last.slice(1, 1 + comps);
  for (let i = 0; i < tf.length - 1; i++) {
    const a = tf[i];
    const b = tf[i + 1];
    if (t < a[0] || t > b[0]) continue;
    const u = (t - a[0]) / (b[0] - a[0] || 1);
    const out = [];
    for (let c = 0; c < comps; c++) {
      out.push(a[1 + c] + (b[1 + c] - a[1 + c]) * u);
    }
    return out;
  }
  return last.slice(1, 1 + comps);
}
function paintVrPresetThumbnail(canvas, preset) {
  const size = 110;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const colorTF = preset.colorTF || VR_PRESET_DEFAULT.colorTF;
  const opacityTF = preset.opacityTF || VR_PRESET_DEFAULT.opacityTF;
  const lo = colorTF[0][0];
  const hi2 = colorTF[colorTF.length - 1][0];
  const img = ctx.createImageData(size, size);
  const cx = (size - 1) / 2;
  const cy = (size - 1) / 2;
  const rMax = size * 0.42;
  for (let y = 0; y < size; y++) {
    for (let x2 = 0; x2 < size; x2++) {
      const dx = x2 - cx;
      const dy = y - cy;
      const r = Math.sqrt(dx * dx + dy * dy);
      const i = (y * size + x2) * 4;
      if (r > rMax) {
        img.data[i] = 5;
        img.data[i + 1] = 6;
        img.data[i + 2] = 10;
        img.data[i + 3] = 255;
        continue;
      }
      const depth = 1 - r / rMax;
      const hu4 = lo + (hi2 - lo) * (0.15 + 0.75 * depth);
      const [cr2, cg, cb] = sampleTf(colorTF, hu4, 3);
      const [a] = sampleTf(opacityTF, hu4, 1);
      const shade = 0.55 + 0.45 * Math.max(0, (dx * 0.35 - dy * 0.55) / rMax + 0.35);
      const alpha = Math.max(0.08, Math.min(1, a)) * (0.35 + 0.65 * depth);
      const bg = 0.02;
      img.data[i] = Math.round((bg * (1 - alpha) + cr2 * shade * alpha) * 255);
      img.data[i + 1] = Math.round((bg * (1 - alpha) + cg * shade * alpha) * 255);
      img.data[i + 2] = Math.round((bg * (1 - alpha) + cb * shade * alpha) * 255);
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}

// reporting-ui.ts
function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function formatVolumeFromMm3(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) return String(value);
  const cc = value / 1e3;
  if (Math.abs(cc) >= 100) return cc.toFixed(1);
  if (Math.abs(cc) >= 1) return cc.toFixed(2);
  if (Math.abs(cc) >= 0.01) return cc.toFixed(3);
  return cc.toPrecision(3);
}
function formatVolumeAlreadyCc(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) return String(value);
  if (Math.abs(value) >= 100) return value.toFixed(1);
  if (Math.abs(value) >= 1) return value.toFixed(2);
  if (Math.abs(value) >= 0.01) return value.toFixed(3);
  return value.toPrecision(3);
}
function volumeDisplay(value, units) {
  const u = String(units || "").trim().toLowerCase();
  const isCc = u === "cc" || u === "cm3" || u === "cm\xB3" || u.includes("cubic centimeter");
  if (isCc) {
    return { text: formatVolumeAlreadyCc(value), units: "cc" };
  }
  return { text: formatVolumeFromMm3(value), units: "cc" };
}
function measurementVolumeDisplay(m) {
  const u = String(m.units || "").trim().toLowerCase();
  const isVolumeQty = /^volume$/i.test(String(m.quantity || ""));
  const isMm3 = !u || u === "mm3" || u === "mm\xB3" || u.includes("cubic millimeter") || u.includes("millimetre");
  const isCc = u === "cc" || u === "cm3" || u === "cm\xB3" || u.includes("cubic centimeter");
  if (isVolumeQty || isMm3 || isCc) {
    return volumeDisplay(m.value, m.units);
  }
  return {
    text: typeof m.value === "number" && Number.isFinite(m.value) ? String(m.value) : String(m.value ?? "\u2014"),
    units: m.units || "\u2014"
  };
}
function truncUid(uid, keep = 12) {
  const s2 = String(uid || "").trim();
  if (!s2) return "";
  if (s2.length <= keep + 3) return s2;
  return `${s2.slice(0, keep)}\u2026`;
}
function imagingStudyContextDescription(ctx) {
  if (!Array.isArray(ctx)) return "";
  for (const item of ctx) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    const key = String(row.key || "");
    if (key !== "study" && key !== "scene") continue;
    const description = String(row.resource?.description ?? "").trim();
    if (description) return description;
  }
  return "";
}
function studyContextLabel(study) {
  if (!study) {
    return { text: "none", title: "" };
  }
  const parts = [];
  if (study.sampleId) parts.push(study.sampleId);
  if (study.openMode) parts.push(study.openMode);
  if (study.studyUid) parts.push(`Study ${truncUid(study.studyUid)}`);
  if (study.seriesUid) parts.push(`Series ${truncUid(study.seriesUid)}`);
  if (!parts.length && study.fileCount) {
    parts.push(`${study.fileCount} file${study.fileCount === 1 ? "" : "s"}`);
  }
  const text = parts.length ? parts.join(" \xB7 ") : "Study open";
  const title = [
    study.sampleId && `Sample: ${study.sampleId}`,
    study.openMode && `Mode: ${study.openMode}`,
    study.studyUid && `Study UID: ${study.studyUid}`,
    study.seriesUid && `Series UID: ${study.seriesUid}`,
    study.dicomwebRoot && `DICOMweb: ${study.dicomwebRoot}`
  ].filter(Boolean).join("\n");
  return { text, title };
}
function renderReportContext(state) {
  const el4 = document.getElementById("reportContext");
  if (!el4) return;
  const capsule = el4.closest(".rp-capsule");
  const open = state.lastImagingStudyOpenContext.length > 0;
  const fromContext = open ? imagingStudyContextDescription(state.lastImagingStudyOpenContext) : "";
  const fallback = open ? studyContextLabel(state.openStudy).text : "";
  const description = fromContext || (fallback && fallback !== "none" ? fallback : "");
  const hasContext = Boolean(open && description);
  capsule?.classList.toggle("is-open", hasContext);
  const rp = reportingChromeFor();
  el4.replaceChildren();
  const label = document.createElement("span");
  label.className = "rp-context-label";
  label.textContent = rp.currentContext;
  const value = document.createElement("span");
  value.className = "rp-context-value";
  value.textContent = hasContext ? description : rp.none;
  value.title = description || studyContextLabel(state.openStudy).title;
  el4.append(label, " ", value);
  const closeBtn = document.getElementById(
    "closeContextBtn"
  );
  if (closeBtn) {
    closeBtn.hidden = !hasContext;
    closeBtn.disabled = !hasContext;
  }
}
var sessionStatusControl = null;
var sessionStatusLabel = null;
function setSessionStatusControl(control) {
  sessionStatusControl = control.button;
  sessionStatusLabel = control.label;
}
function updateConnectionStatusUi(statusWrap, state) {
  const wrap = sessionStatusLabel || statusWrap;
  if (!wrap) {
    renderConferenceRoster(state);
    return;
  }
  const visual = Ct(state.connection, {
    conferenceActive: Boolean(state.conference)
  });
  wrap.classList.remove(
    "rp-status-idle",
    "rp-status-connecting",
    "rp-status-connected",
    "rp-status-disconnected",
    "rp-status-error",
    "rp-status-pulse"
  );
  wrap.classList.add(`rp-status-${visual.tone}`);
  wrap.classList.toggle("rp-status-pulse", visual.pulse);
  const label = String(state.topic || "").trim() || "\u2014";
  wrap.textContent = label;
  const tip = state.conference?.title ? `${state.connectionDetail} \xB7 ${state.conference.title}` : state.connectionDetail;
  wrap.title = tip;
  const btn = sessionStatusControl || wrap.closest("button");
  if (btn) {
    if (state.conference?.places?.length) {
      btn.title = tip ? `Participants \u2014 ${tip}` : "Participants";
      btn.setAttribute("aria-label", `Participants (${label})`);
    } else {
      btn.title = tip ? `Session info \u2014 ${tip}` : "Session info";
      btn.setAttribute("aria-label", `Session info (${label})`);
    }
  }
  renderConferenceRoster(state);
}
function renderConferenceRoster(state) {
  const statusControl = sessionStatusControl;
  const statusLabelEl = sessionStatusLabel;
  const startBtn = document.getElementById(
    "startConferenceBtn"
  );
  const endBtn = document.getElementById(
    "endConferenceBtn"
  );
  const view = state.conference;
  const connected = state.connection === "connected";
  const followHost = Boolean(state.conferenceFollowHost);
  if (statusControl instanceof HTMLElement) {
    ht2({
      view,
      statusControl,
      statusLabelEl,
      classPrefix: "rp-conference",
      selfStatusMode: "short",
      followHost
    });
  }
  pt({
    view,
    followHost,
    connected,
    strings: conferenceStringsFor(resolveStoredLocale()),
    startBtn,
    endBtn
  });
}
var REFRESH_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M21 12a9 9 0 1 1-3.16-6.74" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
  <path d="M21 3v6h-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
var EYE_ON_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" stroke="currentColor" stroke-width="1.7"/>
  <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.7"/>
</svg>`;
var EYE_OFF_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M3 3l18 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
  <path d="M10.6 10.6A3 3 0 0 0 12 15a3 3 0 0 0 2.4-1.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
  <path d="M6.7 6.8C4.1 8.3 2.5 11 2.5 11S6 18 12 18c1.5 0 2.9-.3 4.1-.8M17.2 14.5c1.7-1.2 2.9-2.8 3.3-3.5 0 0-3.5-7-10-7-1 0-1.9.1-2.8.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
</svg>`;
var LABEL_CARD_ON_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H14l7 7-7 7H5.5A2.5 2.5 0 0 1 3 16.5v-9Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
  <circle cx="8" cy="12" r="1.4" fill="currentColor"/>
</svg>`;
var LABEL_CARD_OFF_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H14l7 7-7 7H5.5A2.5 2.5 0 0 1 3 16.5v-9Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
  <circle cx="8" cy="12" r="1.4" fill="currentColor"/>
  <path d="M3 3l18 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
</svg>`;
var PLUS_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
</svg>`;
var STL_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M7 9l5-3 5 3v6l-5 3-5-3z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
  <path d="M7 9l5 3 5-3M12 12v6" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
  <path d="M18 3v4m0 0l-2-2m2 2l2-2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
var TRASH_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M3 6h18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
  <path d="M8 6V4h8v2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M19 6l-1 14H6L5 6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M10 11v6M14 11v6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
</svg>`;
var CAMERA_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M4 8h3l1.5-2h7L17 8h3a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
  <circle cx="12" cy="14" r="3.5" stroke="currentColor" stroke-width="1.7"/>
</svg>`;
var DOWNLOAD_ICON = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <path d="M12 3v11m0 0l-4-4m4 4l4-4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
function formatSnapshotTime(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso || "\u2014";
  return d.toLocaleTimeString(void 0, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}
function snapshotsTableHtml(state) {
  const rows = state.snapshots || [];
  const rp = reportingChromeFor();
  if (!rows.length) {
    return `<p class="rp-muted">${escapeHtml(rp.noSnapshots)}</p>`;
  }
  const body = rows.map((snap, i) => {
    const ready = snap.status === "ready" && snap.dataBase64;
    const thumbSrc = snap.thumbBase64 || snap.dataBase64;
    const thumb = ready && thumbSrc ? `<button
            type="button"
            class="rp-snapshot-thumb-btn"
            data-view-snapshot="${escapeHtml(snap.id)}"
            title="View ${escapeHtml(snap.filename)}"
            aria-label="View ${escapeHtml(snap.filename)}"
          ><img
            class="rp-snapshot-thumb"
            src="data:image/png;base64,${thumbSrc}"
            alt=""
          /></button>` : `<span class="rp-snapshot-thumb-ph" aria-hidden="true">\u2026</span>`;
    return `
        <tr class="rp-measure-row" data-snapshot-id="${escapeHtml(snap.id)}">
          <td class="rp-num">${i + 1}</td>
          <td class="rp-snapshot-thumb-cell">${thumb}</td>
          <td class="rp-mono">${escapeHtml(snap.filename)}</td>
          <td>${escapeHtml(formatSnapshotTime(snap.createdAt))}</td>
          <td class="rp-vis-cell">
            <button
              type="button"
              class="rp-eye-btn"
              data-download-snapshot="${escapeHtml(snap.id)}"
              title="Download ${escapeHtml(snap.filename)}"
              aria-label="Download ${escapeHtml(snap.filename)}"
              ${ready ? "" : "disabled"}
            >${DOWNLOAD_ICON}</button>
            <button
              type="button"
              class="rp-eye-btn"
              data-delete-snapshot="${escapeHtml(snap.id)}"
              title="Delete ${escapeHtml(snap.filename)}"
              aria-label="Delete ${escapeHtml(snap.filename)}"
            >${TRASH_ICON}</button>
          </td>
        </tr>`;
  }).join("");
  return `
    <table class="rp-table">
      <thead>
        <tr>
          <th class="rp-num">${escapeHtml(rp.colNum)}</th>
          <th class="rp-snapshot-thumb-col">${escapeHtml(rp.colThumb)}</th>
          <th>${escapeHtml(rp.colFilename)}</th>
          <th>${escapeHtml(rp.colTime)}</th>
          <th class="rp-vis-col"></th>
        </tr>
      </thead>
      <tbody>${body}</tbody>
    </table>`;
}
function loadStatusHtml(state) {
  const rp = reportingChromeFor();
  const detail = state.segLoadDetail?.trim() || (state.connection === "connected" ? rp.refreshFromImageDisplay : rp.notConnectedToHub);
  return `
    <div class="rp-load-status">
      <p class="rp-load-detail">${escapeHtml(detail)}</p>
      <button
        type="button"
        id="rpRefreshIdBtn"
        class="rp-refresh-btn"
        title="${escapeHtml(rp.refreshFromImageDisplay)}"
        aria-label="${escapeHtml(rp.refreshFromImageDisplay)}"
      >${REFRESH_ICON}</button>
    </div>
  `;
}
function orderedCells(order, identityFirstCells) {
  const cells = order === "controls-first" ? [...identityFirstCells].reverse() : identityFirstCells;
  return cells.join("");
}
function columnOrderSwitchHtml(id) {
  const controlsFirst = getStoredTableColumnOrder() === "controls-first";
  return `
    <div class="rp-section-controls">
      <span class="rp-column-order-label">Controls first</span>
      <button
        type="button"
        id="${escapeHtml(id)}"
        class="rp-switch"
        data-column-order-switch
        role="switch"
        aria-checked="${controlsFirst ? "true" : "false"}"
        title="Column order"
        aria-label="Controls first column order"
      ><span class="rp-switch-thumb" aria-hidden="true"></span></button>
    </div>
  `;
}
function volumesTableHtml(state) {
  const shift = Math.round(Number(state.volumeShift) || 0);
  const shiftRange = Math.max(
    200,
    Math.round(Number(state.volumeShiftRange) || 500),
    Math.abs(shift)
  );
  const shiftLabel = (shift > 0 ? "+" : "") + String(shift);
  const volOff = state.volumeOpacity <= 0.02;
  const preset = String(state.volumePreset || "");
  const name = String(state.volumeName || "").trim() || "Volume";
  const cropOn = Boolean(state.volumeCropEnabled);
  const boxOn = Boolean(state.volumeRoiVisible);
  const rp = reportingChromeFor();
  const order = getStoredTableColumnOrder();
  const head = orderedCells(order, [
    `<th>${escapeHtml(rp.colName)}</th>`,
    `<th class="rp-switch-col">${escapeHtml(rp.colCrop)}</th>`,
    `<th class="rp-switch-col">${escapeHtml(rp.colBox)}</th>`,
    `<th>${escapeHtml(rp.colShift)}</th>`,
    `<th>${escapeHtml(rp.colPreset)}</th>`,
    `<th class="rp-opacity-col"></th>`,
    `<th class="rp-vis-col"></th>`
  ]);
  const body = orderedCells(order, [
    `<td>
            <span class="rp-volume-name" title="${escapeHtml(name)}">${escapeHtml(
      name
    )}</span>
          </td>`,
    `<td class="rp-switch-cell">
            <button
              type="button"
              id="rpVolCropSwitch"
              class="rp-switch"
              role="switch"
              aria-checked="${cropOn ? "true" : "false"}"
              ${volOff ? "disabled" : ""}
              title="Crop volume (3D)"
              aria-label="Crop volume"
            ><span class="rp-switch-thumb" aria-hidden="true"></span></button>
          </td>`,
    `<td class="rp-switch-cell">
            <button
              type="button"
              id="rpVolRoiBoxSwitch"
              class="rp-switch"
              role="switch"
              aria-checked="${boxOn ? "true" : "false"}"
              ${volOff ? "disabled" : ""}
              title="Show ROI box"
              aria-label="Show ROI box"
            ><span class="rp-switch-thumb" aria-hidden="true"></span></button>
          </td>`,
    `<td class="rp-shift-cell">
            <input
              type="range"
              id="rpVolShiftSlider"
              class="rp-shift-slider"
              min="${-shiftRange}"
              max="${shiftRange}"
              step="${Math.max(1, Math.round(shiftRange / 200))}"
              value="${shift}"
              ${volOff ? "disabled" : ""}
              aria-valuemin="${-shiftRange}"
              aria-valuemax="${shiftRange}"
              aria-valuenow="${shift}"
              aria-label="Volume shift"
              title="Volume-render shift (HU)"
            />
            <span id="rpVolShiftValue" class="rp-shift-value">${escapeHtml(
      shiftLabel
    )}</span>
          </td>`,
    `<td>
            <button
              type="button"
              id="rpVolPresetBtn"
              class="rp-preset-btn"
              ${volOff ? "disabled" : ""}
              aria-label="Volume-render preset"
              title="Volume-rendering transfer-function preset"
            >${escapeHtml(vrPresetLabel(preset))}</button>
          </td>`,
    `<td class="rp-opacity-cell">
            <div
              id="rpVolOpacityChip"
              class="rp-opacity-chip"
              role="slider"
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow="${Math.round(state.volumeOpacity * 100)}"
              aria-label="Volume opacity"
              title="Click: 100% \u2192 50% \u2192 off \xB7 Drag sideways for a live opacity slider"
            ></div>
          </td>`,
    `<td class="rp-vis-cell">
            <button
              type="button"
              id="rpVolVisBtn"
              class="rp-eye-btn"
              aria-pressed="${volOff ? "false" : "true"}"
              title="${volOff ? "Show volume" : "Hide volume"}"
              aria-label="${volOff ? "Show volume" : "Hide volume"}"
            >${volOff ? EYE_OFF_ICON : EYE_ON_ICON}</button>
          </td>`
  ]);
  return `
    <table class="rp-table">
      <thead>
        <tr>
          ${head}
        </tr>
      </thead>
      <tbody>
        <tr class="rp-measure-row">
          ${body}
        </tr>
      </tbody>
    </table>
  `;
}
function formatSnomed(terminology, label) {
  const filled = enrichTerminologyFromSegdb(label, terminology) || terminology;
  const coded2 = filled?.type || filled?.category || null;
  if (!coded2?.value) {
    return { text: "\u2014", title: "" };
  }
  const meaning = String(coded2.meaning || "").trim();
  const scheme = String(coded2.scheme || "").trim();
  const text = meaning ? `${coded2.value} \xB7 ${meaning}` : String(coded2.value);
  const title = [scheme && `Scheme: ${scheme}`, `Code: ${coded2.value}`, meaning && `Meaning: ${meaning}`].filter(Boolean).join("\n");
  return { text, title };
}
function segmentationsTableHtml(catalog, selectedSegNumber, selectedSegSop, segmentVisible, segmentOpacity, allVisible, labelsVisible, segOpacity) {
  const rows = [];
  const order = getStoredTableColumnOrder();
  for (const inst of catalog.segmentations) {
    for (const seg of inst.segments || []) {
      const num = Number(seg.number);
      const sop = String(inst.sopInstanceUID || "");
      const visible = segmentVisible[num] !== false;
      const rowOpacity = Math.max(
        0,
        Math.min(1, Number(segmentOpacity[num] ?? 1))
      );
      const swatch = `rgb(${Math.round((seg.color?.[0] ?? 1) * 255)}, ${Math.round(
        (seg.color?.[1] ?? 1) * 255
      )}, ${Math.round((seg.color?.[2] ?? 1) * 255)})`;
      const snomed = formatSnomed(seg.terminology, seg.label);
      const displayLabel = segmentDisplayNameSync(
        String(seg.label || ""),
        seg.terminology
      );
      const selected = selectedSegNumber != null && Number(selectedSegNumber) === num && (!selectedSegSop || !sop || selectedSegSop === sop) ? " rp-row-selected" : "";
      const body = orderedCells(order, [
        `<td><span class="rp-swatch" style="background:${swatch}"></span>${escapeHtml(
          seg.number
        )}</td>`,
        `<td class="rp-label-cell">
            <span class="rp-seg-label" data-seg-label-en="${escapeHtml(
          seg.label || ""
        )}">${escapeHtml(displayLabel)}</span>
          </td>`,
        `<td class="rp-mono" title="${escapeHtml(snomed.title)}">${escapeHtml(
          snomed.text
        )}</td>`,
        `<td class="rp-num">${escapeHtml(seg.voxelCount)}</td>`,
        `<td class="rp-vis-cell">
            <button
              type="button"
              class="rp-eye-btn"
              data-add-measurement
              data-seg-number="${escapeHtml(num)}"
              data-seg-sop="${escapeHtml(sop)}"
              title="Add measurement for segment"
              aria-label="Add measurement for segment ${escapeHtml(displayLabel || num)}"
            >${PLUS_ICON}</button>
            <button
              type="button"
              class="rp-eye-btn"
              data-seg-stl
              data-seg-number="${escapeHtml(num)}"
              data-seg-sop="${escapeHtml(sop)}"
              title="Save segment as STL for 3D printing"
              aria-label="Save segment ${escapeHtml(displayLabel || num)} as STL"
            >${STL_ICON}</button>
            <button
              type="button"
              class="rp-eye-btn"
              title="Delete segment"
              aria-label="Delete segment ${escapeHtml(displayLabel || num)}"
            >${TRASH_ICON}</button>
            <div
              class="rp-opacity-chip"
              data-seg-opacity="${escapeHtml(num)}"
              role="slider"
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow="${Math.round(rowOpacity * 100)}"
              aria-label="Opacity for segment ${escapeHtml(displayLabel || num)}"
              title="Click: 100% \u2192 50% \u2192 off \xB7 Drag sideways for a live opacity slider"
            ></div>
            <button
              type="button"
              class="rp-eye-btn"
              data-seg-vis="${escapeHtml(num)}"
              aria-pressed="${visible ? "true" : "false"}"
              title="${visible ? "Hide segment" : "Show segment"}"
              aria-label="${visible ? "Hide" : "Show"} segment ${escapeHtml(displayLabel || num)}"
            >${visible ? EYE_ON_ICON : EYE_OFF_ICON}</button>
          </td>`
      ]);
      rows.push(`
        <tr class="rp-measure-row${selected}" data-seg-number="${escapeHtml(
        num
      )}" data-seg-sop="${escapeHtml(sop)}" tabindex="0">
          ${body}
        </tr>
      `);
    }
  }
  const rp = reportingChromeFor();
  if (!rows.length) {
    return `<p class="rp-muted">${escapeHtml(rp.noSegmentations)}</p>`;
  }
  const head = orderedCells(order, [
    `<th>${escapeHtml(rp.colNum)}</th>`,
    `<th class="rp-label-col">
            ${escapeHtml(rp.colLabel)}
            <button
              type="button"
              id="rpLabelsVisSwitch"
              class="rp-eye-btn"
              aria-pressed="${labelsVisible ? "true" : "false"}"
              title="${labelsVisible ? "Hide 3D segment label cards" : "Show 3D segment label cards"}"
              aria-label="${labelsVisible ? "Hide 3D segment label cards" : "Show 3D segment label cards"}"
            >${labelsVisible ? LABEL_CARD_ON_ICON : LABEL_CARD_OFF_ICON}</button>
          </th>`,
    `<th>${escapeHtml(rp.colSnomed)}</th>`,
    `<th class="rp-num">${escapeHtml(rp.colVoxels)}</th>`,
    `<th class="rp-vis-col">
            <button
              type="button"
              class="rp-eye-btn"
              data-add-measurement
              title="Add measurement for selected segment"
              aria-label="Add measurement for selected segment"
            >${PLUS_ICON}</button>
            <button
              type="button"
              class="rp-eye-btn"
              data-seg-stl
              title="Save segment as STL for 3D printing"
              aria-label="Save segment as STL for 3D printing"
            >${STL_ICON}</button>
            <button
              type="button"
              class="rp-eye-btn"
              title="Delete segment"
              aria-label="Delete segment"
            >${TRASH_ICON}</button>
            <div
              id="rpSegOpacityChip"
              class="rp-opacity-chip"
              role="slider"
              aria-valuemin="0"
              aria-valuemax="100"
              aria-valuenow="${Math.round(segOpacity * 100)}"
              aria-label="Segmentation opacity"
              title="Click: 100% \u2192 50% \u2192 off \xB7 Drag sideways for a live opacity slider"
            ></div>
            <button
              type="button"
              id="rpSegAllVisBtn"
              class="rp-eye-btn"
              aria-pressed="${allVisible ? "true" : "false"}"
              title="${allVisible ? "Hide all segmentations" : "Show all segmentations"}"
              aria-label="${allVisible ? "Hide all segmentations" : "Show all segmentations"}"
            >${allVisible ? EYE_ON_ICON : EYE_OFF_ICON}</button>
          </th>`
  ]);
  return `
    <table class="rp-table">
      <thead>
        <tr>
          ${head}
        </tr>
      </thead>
      <tbody>${rows.join("")}</tbody>
    </table>
  `;
}
function measurementsTableHtml(measurements, selectedId) {
  const rp = reportingChromeFor();
  if (!measurements.length) {
    return `<p class="rp-muted">${escapeHtml(rp.noMeasurements)}</p>`;
  }
  const rows = measurements.map((m) => {
    const selected = m.id === selectedId ? " rp-row-selected" : "";
    const segment = m.segmentNumber != null ? `${m.segmentLabel || m.trackingIdentifier || "\u2014"} (#${m.segmentNumber})` : m.segmentLabel || m.trackingIdentifier || "\u2014";
    const vol = measurementVolumeDisplay(m);
    return `
      <tr class="rp-measure-row${selected}" data-measurement-id="${escapeHtml(
      m.id
    )}" tabindex="0">
        <td>${escapeHtml(segment)}</td>
        <td>${escapeHtml(m.quantity || "\u2014")}</td>
        <td class="rp-num">${escapeHtml(vol.text)}</td>
        <td>${escapeHtml(vol.units)}</td>
        <td class="rp-vis-cell">
          <button
            type="button"
            class="rp-eye-btn"
            data-remove-measurement="${escapeHtml(m.id)}"
            title="Remove measurement"
            aria-label="Remove measurement ${escapeHtml(m.quantity || m.id)}"
          >${TRASH_ICON}</button>
        </td>
      </tr>
    `;
  });
  return `
    <table class="rp-table">
      <thead>
        <tr>
          <th>${escapeHtml(rp.colSegment)}</th>
          <th>${escapeHtml(rp.colQuantity)}</th>
          <th class="rp-num">${escapeHtml(rp.colValue)}</th>
          <th>${escapeHtml(rp.colUnits)}</th>
          <th class="rp-vis-col"></th>
        </tr>
      </thead>
      <tbody>${rows.join("")}</tbody>
    </table>
  `;
}
function segsAllVisible(state) {
  return !Object.values(state.segmentVisible).some((v2) => v2 === false);
}
function renderReportDisplay(container, state) {
  const allOn = segsAllVisible(state);
  const rp = reportingChromeFor();
  container.innerHTML = `
    <div class="rp-section">
      <div class="rp-section-head">
        <h2 class="rp-section-title">${escapeHtml(rp.snapshots)}</h2>
        <button
          type="button"
          id="rpAddSnapshotBtn"
          class="rp-eye-btn rp-section-title-btn"
          data-add-snapshot
          title="Capture snapshot from Image Display"
          aria-label="Capture snapshot"
        >${CAMERA_ICON}</button>
      </div>
      ${snapshotsTableHtml(state)}
    </div>
    <div class="rp-section">
      <div class="rp-section-head">
        <h2 class="rp-section-title">${escapeHtml(rp.volumes)}</h2>
        ${columnOrderSwitchHtml("rpColumnOrderSwitch")}
      </div>
      ${volumesTableHtml(state)}
    </div>
    <div class="rp-section">
      <div class="rp-section-head">
        <h2 class="rp-section-title">${escapeHtml(rp.segmentations)}</h2>
        ${loadStatusHtml(state)}
        ${columnOrderSwitchHtml("rpColumnOrderSwitchSeg")}
      </div>
      ${segmentationsTableHtml(
    state.segCatalog,
    state.selectedSegmentNumber,
    state.selectedSegmentSopUid,
    state.segmentVisible,
    state.segmentOpacity,
    allOn,
    state.labelsVisible !== false,
    state.segOpacity
  )}
    </div>
    <div class="rp-section">
      <div class="rp-section-head">
        <h2 class="rp-section-title">${escapeHtml(rp.measurements)}</h2>
      </div>
      ${measurementsTableHtml(state.measurements, state.selectedMeasurementId)}
    </div>
  `;
  void refreshSegmentLabelTranslations(container, state);
}
async function refreshSegmentLabelTranslations(container, state) {
  const locale = resolveStoredLocale();
  if (locale === "en") return;
  const origin = hubOriginFromEndpoint(hubEndpoint(state));
  if (!origin) return;
  const items = [];
  for (const inst of state.segCatalog?.segmentations || []) {
    for (const seg of inst.segments || []) {
      const label = String(seg.label || "").trim();
      if (!label) continue;
      items.push({ label, terminology: seg.terminology });
    }
  }
  if (!items.length) return;
  try {
    const map = await ensureSegmentLabelsTranslated(items, {
      hubOrigin: origin,
      locale
    });
    container.querySelectorAll(".rp-seg-label").forEach((el4) => {
      const en5 = el4.getAttribute("data-seg-label-en") || el4.textContent || "";
      const next = map.get(en5);
      if (next && next !== el4.textContent) el4.textContent = next;
    });
  } catch {
  }
}
var SEG_OPACITY_COLOR = [0.62, 0.9, 1];
var VOL_OPACITY_COLOR = [0.75, 0.78, 0.85];
function paintOpacityChip(box, level, color) {
  const pct = Math.round(Math.max(0, Math.min(1, level)) * 100);
  const c = `rgb(${Math.round(color[0] * 255)},${Math.round(color[1] * 255)},${Math.round(
    color[2] * 255
  )})`;
  box.style.opacity = level < 0.02 ? "0.75" : "1";
  box.setAttribute("aria-valuenow", String(pct));
  box.innerHTML = `<span class="rp-opacity-fill" style="width:${pct}%;background:${c}"></span><span class="rp-opacity-label">${pct}%</span>`;
}
function mountOpacityChip(container, selector, get, set, color) {
  const box = container.querySelector(selector);
  if (!box) return;
  attachOpacityChip(box, get, set, color);
}
function attachOpacityChip(box, get, set, color) {
  const triNext = (v2) => v2 > 0.66 ? 0.5 : v2 > 0.04 ? 0 : 1;
  const paint = () => paintOpacityChip(box, get(), color);
  paint();
  let startX = 0;
  let startV = 0;
  let dragged = false;
  let pid = -1;
  box.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    e.stopPropagation();
    startX = e.clientX;
    startV = get();
    dragged = false;
    pid = e.pointerId;
    try {
      box.setPointerCapture(pid);
    } catch {
    }
  });
  box.addEventListener("pointermove", (e) => {
    if (pid < 0) return;
    const dx = e.clientX - startX;
    if (Math.abs(dx) > 3) dragged = true;
    if (dragged) {
      set(Math.max(0, Math.min(1, startV + dx / 130)));
      paint();
    }
  });
  const end = () => {
    if (pid < 0) return;
    if (!dragged) {
      set(triNext(get()));
      paint();
    }
    try {
      box.releasePointerCapture(pid);
    } catch {
    }
    pid = -1;
  };
  box.addEventListener("pointerup", end);
  box.addEventListener("pointercancel", end);
}
function mountSegOpacityChip(container, get, set) {
  mountOpacityChip(container, "#rpSegOpacityChip", get, set, SEG_OPACITY_COLOR);
}
function mountSegmentOpacityChips(container, get, set) {
  container.querySelectorAll("[data-seg-opacity]").forEach((box) => {
    const num = Number(box.dataset.segOpacity);
    if (!Number.isFinite(num)) return;
    attachOpacityChip(
      box,
      () => get(num),
      (o) => set(num, o),
      SEG_OPACITY_COLOR
    );
  });
}
function mountVolOpacityChip(container, get, set) {
  mountOpacityChip(container, "#rpVolOpacityChip", get, set, VOL_OPACITY_COLOR);
}
function mountVolShiftSlider(container, get, set, getVolumeOpacity) {
  const slider = container.querySelector(
    "#rpVolShiftSlider"
  );
  const valueEl = container.querySelector("#rpVolShiftValue");
  if (!slider) return;
  const paint = () => {
    const hu4 = Math.round(Number(get()) || 0);
    const min = Number(slider.min);
    const max = Number(slider.max);
    const clamped = Number.isFinite(min) && Number.isFinite(max) ? Math.max(min, Math.min(max, hu4)) : hu4;
    slider.value = String(clamped);
    slider.setAttribute("aria-valuenow", String(clamped));
    slider.disabled = getVolumeOpacity() <= 0.02;
    if (valueEl) {
      valueEl.textContent = (clamped > 0 ? "+" : "") + String(clamped);
    }
  };
  paint();
  slider.addEventListener("input", () => {
    const hu4 = Number(slider.value);
    if (!Number.isFinite(hu4)) return;
    set(hu4);
    if (valueEl) {
      const r = Math.round(hu4);
      valueEl.textContent = (r > 0 ? "+" : "") + String(r);
    }
  });
}
function mountVolPresetButton(container, get, set, getVolumeOpacity) {
  const btn = container.querySelector(
    "#rpVolPresetBtn"
  );
  if (!btn) return;
  const paint = () => {
    btn.textContent = vrPresetLabel(get());
    btn.disabled = getVolumeOpacity() <= 0.02;
  };
  paint();
  btn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (getVolumeOpacity() <= 0.02) return;
    const current = String(get() || "") || null;
    const entries = [VR_PRESET_DEFAULT, ...VR_PRESET_OPTIONS];
    const items = entries.map((p) => {
      const canvas = document.createElement("canvas");
      paintVrPresetThumbnail(canvas, p);
      return {
        name: p.name ? p.name : null,
        label: p.label,
        canvas
      };
    });
    openVrPresetMenu({
      items,
      current,
      onPick: (name) => {
        set(name || "");
        paint();
      }
    });
  });
}
function closeMenus(...menus) {
  for (const m of menus) m.hidden = true;
}

// viewers.ts
var TITLE_DISABLED = "Subscribe to the hub first";
var TITLE_SLICER = "3D Slicer Image Display (connect from Slicer)";
var TITLE_IRA = "Open SlicerLive";
var TITLE_IRA_ONLINE = "SlicerLive is connected on this topic";
var TITLE_IRA_OFFLINE = "Open SlicerLive (no IRA responded on this topic)";
var TITLE_WORKLIST = "Open Worklist";
var TITLE_WORKLIST_ONLINE = "Worklist is connected on this topic";
var TITLE_WORKLIST_OFFLINE = "Open Worklist (no worklist responded on this topic)";
var WORKLIST_WINDOW_NAME = as;
var worklistWindow = null;
var iraWindow = null;
function sessionToken(state) {
  try {
    return String(state.client?.getConnectionState?.()?.token || "").trim();
  } catch {
    return "";
  }
}
function spaResolveOpts(state) {
  const def = getHubDefinitions()[state.hubKey];
  return {
    hubOrigin: hubOriginFromEndpoint(def?.hubEndpoint || "")
  };
}
function withSessionParams(url, state) {
  if (state.topic) url.searchParams.set("topic", state.topic);
  const token = sessionToken(state);
  if (token) url.searchParams.set("id-token", token);
  applySpaParam(url);
}
function popupFeatures(width, height) {
  const left = Math.max(0, Math.floor((window.screen.width - width) / 2));
  const top = Math.max(0, Math.floor((window.screen.height - height) / 2));
  return [
    "popup",
    `width=${width}`,
    `height=${height}`,
    `left=${left}`,
    `top=${top}`
  ].join(",");
}
function iraWindowName(state) {
  return `hubViewer-ira-${String(state.topic || "anon").replace(/[^\w.-]+/g, "_")}`;
}
function openerHasName(expected) {
  const opener = window.opener;
  if (!opener || opener.closed) return null;
  let name = "";
  try {
    name = String(opener.name || "");
  } catch {
    return null;
  }
  return name === expected ? opener : null;
}
function focusHeldWindow(held) {
  if (!held || held.closed) return false;
  try {
    held.focus();
  } catch {
  }
  return true;
}
function focusExistingWorklistWindow() {
  if (focusHeldWindow(worklistWindow)) return true;
  worklistWindow = null;
  const opener = openerHasName(WORKLIST_WINDOW_NAME);
  if (!opener) return false;
  worklistWindow = opener;
  return focusHeldWindow(opener);
}
function focusExistingIraWindow(state) {
  if (focusHeldWindow(iraWindow)) return true;
  iraWindow = null;
  const opener = openerHasName(iraWindowName(state));
  if (!opener) return false;
  iraWindow = opener;
  return focusHeldWindow(opener);
}
function openHubViewer(state, kind) {
  if (state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} open viewer skipped: not connected`);
    return;
  }
  if (kind === "ira") {
    if (focusExistingIraWindow(state)) return;
    const url2 = new URL(resolveViewerUrls(void 0, spaResolveOpts(state)).ira);
    withSessionParams(url2, state);
    const win = window.open(url2.toString(), iraWindowName(state));
    if (win) iraWindow = win;
    return;
  }
  const url = new URL(resolveViewerUrls(void 0, spaResolveOpts(state))[kind]);
  withSessionParams(url, state);
  const size = { width: 800, height: 600 };
  const name = `hubViewer-${kind}`;
  window.open(url.toString(), name, popupFeatures(size.width, size.height));
}
function openWorklist(state) {
  if (state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} open worklist skipped: not connected`);
    return;
  }
  if (focusExistingWorklistWindow()) return;
  const url = new URL(resolveWorklistUrl(void 0, spaResolveOpts(state)));
  withSessionParams(url, state);
  const win = window.open(url.toString(), WORKLIST_WINDOW_NAME);
  if (win) worklistWindow = win;
}
function setDisabled(btn, disabled, title) {
  btn.disabled = disabled;
  if (disabled) btn.setAttribute("disabled", "");
  else btn.removeAttribute("disabled");
  btn.title = title;
}
function updateViewerPresenceButtons(state) {
  const hubOn = state.connection === "connected";
  const ira = document.getElementById(
    "openIraBtn"
  );
  if (ira) {
    const online = Boolean(state.iraOnline);
    ira.classList.toggle(
      "rp-viewer-btn-connected",
      hubOn && online && !ira.disabled
    );
    if (!ira.disabled) {
      ira.title = online ? TITLE_IRA_ONLINE : TITLE_IRA_OFFLINE;
    }
  }
  const worklist = document.getElementById(
    "openWorklistBtn"
  );
  if (worklist) {
    const online = Boolean(state.worklistOnline);
    worklist.classList.toggle(
      "rp-viewer-btn-connected",
      hubOn && online && !worklist.disabled
    );
    if (!worklist.disabled) {
      worklist.title = online ? TITLE_WORKLIST_ONLINE : TITLE_WORKLIST_OFFLINE;
    }
  }
}
function setViewerButtonsEnabled(enabled, state) {
  const byId = (id) => document.getElementById(id);
  const slicer = byId("openSlicerBtn");
  if (slicer) setDisabled(slicer, true, enabled ? TITLE_SLICER : TITLE_DISABLED);
  const ira = byId("openIraBtn");
  if (ira) {
    setDisabled(ira, !enabled, enabled ? TITLE_IRA : TITLE_DISABLED);
  }
  const ohif = byId("openOhifBtn");
  if (ohif) {
    setDisabled(
      ohif,
      true,
      enabled ? "OHIF viewer is temporarily unavailable" : TITLE_DISABLED
    );
    ohif.classList.toggle("rp-viewer-btn-inert", enabled);
  }
  const slim = byId("openSlimBtn");
  if (slim) {
    setDisabled(slim, !enabled, enabled ? "Open Slim" : TITLE_DISABLED);
  }
  const worklist = byId("openWorklistBtn");
  if (worklist) {
    setDisabled(worklist, !enabled, enabled ? TITLE_WORKLIST : TITLE_DISABLED);
  }
  if (state) updateViewerPresenceButtons(state);
  for (const id of ["startConferenceBtn", "endConferenceBtn"]) {
    const btn = byId(id);
    if (!btn) continue;
    btn.disabled = !enabled || btn.hidden;
    if (enabled && !btn.hidden) {
      btn.removeAttribute("disabled");
      btn.title = id === "startConferenceBtn" ? conferenceStringsFor(resolveStoredLocale()).conferencing : btn.title;
    } else if (!enabled) {
      btn.title = TITLE_DISABLED;
    }
  }
}
function wireViewerButtons(state) {
  const map = [
    { id: "openIraBtn", open: () => openHubViewer(state, "ira") },
    { id: "openSlimBtn", open: () => openHubViewer(state, "slim") },
    { id: "openWorklistBtn", open: () => openWorklist(state) }
  ];
  for (const { id, open } of map) {
    document.getElementById(id)?.addEventListener("click", () => open());
  }
  setViewerButtonsEnabled(state.connection === "connected", state);
}

// reporting.ts
function applyTheme(theme) {
  const next = theme === THEME_OHIF ? THEME_OHIF : THEME_SLICERLIVE;
  document.documentElement.dataset.theme = next;
  setStoredTheme(next);
  document.querySelectorAll("[data-theme-option]").forEach((btn) => {
    const active = btn.dataset.themeOption === next;
    btn.setAttribute("aria-checked", active ? "true" : "false");
  });
}
function remountDisplay(state, reportDisplay) {
  renderReportDisplay(reportDisplay, state);
  mountVolOpacityChip(
    reportDisplay,
    () => state.volumeOpacity,
    (o) => {
      setVolumeOpacity(state, o);
      const slider = reportDisplay.querySelector(
        "#rpVolShiftSlider"
      );
      if (slider) slider.disabled = o <= 0.02;
      const preset = reportDisplay.querySelector(
        "#rpVolPresetBtn"
      );
      if (preset) preset.disabled = o <= 0.02;
      for (const id of ["rpVolCropSwitch", "rpVolRoiBoxSwitch"]) {
        const sw = reportDisplay.querySelector(
          `#${id}`
        );
        if (sw) sw.disabled = o <= 0.02;
      }
    }
  );
  mountVolShiftSlider(
    reportDisplay,
    () => state.volumeShift,
    (hu4) => setVolumeShift(state, hu4),
    () => state.volumeOpacity
  );
  mountVolPresetButton(
    reportDisplay,
    () => state.volumePreset,
    (preset) => setVolumePreset(state, preset),
    () => state.volumeOpacity
  );
  mountSegOpacityChip(
    reportDisplay,
    () => state.segOpacity,
    (o) => setSegOpacity(state, o)
  );
  mountSegmentOpacityChips(
    reportDisplay,
    (n) => state.segmentOpacity[n] ?? 1,
    (n, o) => setSegmentOpacity(state, n, o)
  );
}
function wireReportDisplay(state, reportDisplay) {
  reportDisplay.addEventListener("click", (ev) => {
    const t = ev.target;
    if (t?.closest("#rpRefreshIdBtn")) {
      void refreshReportContextFromStatus(state);
      return;
    }
    if (t?.closest("[data-add-snapshot]")) {
      void addSnapshotAndRequestPng(state);
      return;
    }
    const viewSnap = t?.closest(
      "[data-view-snapshot]"
    );
    if (viewSnap?.dataset.viewSnapshot) {
      ev.stopPropagation();
      openSnapshotFullView(state, viewSnap.dataset.viewSnapshot);
      return;
    }
    const downloadSnap = t?.closest(
      "[data-download-snapshot]"
    );
    if (downloadSnap?.dataset.downloadSnapshot) {
      ev.stopPropagation();
      downloadSnapshotLocally(state, downloadSnap.dataset.downloadSnapshot);
      return;
    }
    const deleteSnap = t?.closest(
      "[data-delete-snapshot]"
    );
    if (deleteSnap?.dataset.deleteSnapshot) {
      ev.stopPropagation();
      removeSnapshot(state, deleteSnap.dataset.deleteSnapshot);
      return;
    }
    if (t?.closest("#rpVolVisBtn")) {
      toggleVolumeVisibility(state);
      return;
    }
    if (t?.closest("[data-column-order-switch]")) {
      const next = getStoredTableColumnOrder() === "controls-first" ? "identity-first" : "controls-first";
      setStoredTableColumnOrder(next);
      remountDisplay(state, reportDisplay);
      return;
    }
    const cropSw = t?.closest("#rpVolCropSwitch");
    if (cropSw && !cropSw.disabled) {
      setVolumeCropEnabled(
        state,
        cropSw.getAttribute("aria-checked") !== "true"
      );
      return;
    }
    const boxSw = t?.closest("#rpVolRoiBoxSwitch");
    if (boxSw && !boxSw.disabled) {
      setVolumeRoiVisible(
        state,
        boxSw.getAttribute("aria-checked") !== "true"
      );
      return;
    }
    if (t?.closest("#rpVolOpacityChip") || t?.closest("#rpSegOpacityChip") || t?.closest("[data-seg-opacity]") || t?.closest("#rpVolShiftSlider") || t?.closest("#rpVolPresetBtn")) {
      return;
    }
    if (t?.closest("#rpSegAllVisBtn")) {
      void toggleAllSegmentVisibility(state);
      return;
    }
    if (t?.closest("#rpLabelsVisSwitch")) {
      void toggleLabelsVisibility(state);
      return;
    }
    const removeBtn = t?.closest(
      "[data-remove-measurement]"
    );
    if (removeBtn?.dataset.removeMeasurement) {
      ev.stopPropagation();
      removeMeasurement(state, removeBtn.dataset.removeMeasurement);
      return;
    }
    const addBtn = t?.closest("[data-add-measurement]");
    if (addBtn) {
      ev.stopPropagation();
      const segNum = Number(addBtn.dataset.segNumber);
      if (Number.isFinite(segNum)) {
        addMeasurementForSegment(
          state,
          segNum,
          addBtn.dataset.segSop || void 0
        );
      } else {
        addMeasurementForSelectedOrFirst(state);
      }
      return;
    }
    if (t?.closest("[data-seg-stl]")) {
      ev.stopPropagation();
      return;
    }
    const eye = t?.closest("[data-seg-vis]");
    if (eye?.dataset.segVis != null) {
      ev.stopPropagation();
      void toggleSegmentVisibility(state, Number(eye.dataset.segVis));
      return;
    }
    const measRow = t?.closest("[data-measurement-id]");
    if (measRow?.dataset.measurementId) {
      selectMeasurement(state, measRow.dataset.measurementId);
      return;
    }
    const segRow = t?.closest("[data-seg-number]");
    if (segRow?.dataset.segNumber != null) {
      const num = Number(segRow.dataset.segNumber);
      if (Number.isFinite(num)) {
        selectSegment(state, num, segRow.dataset.segSop || "");
      }
    }
  });
}
function wireMenus(_state) {
  const settingsBtn = document.getElementById(
    "castSettingsBtn"
  );
  const settingsMenu = document.getElementById(
    "castSettingsMenu"
  );
  const aboutModal = document.getElementById("aboutModal");
  const closeAllMenus = () => {
    closeMenus(settingsMenu);
  };
  settingsBtn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    const open = settingsMenu.hidden;
    closeAllMenus();
    settingsMenu.hidden = !open;
    settingsBtn.setAttribute("aria-expanded", open ? "true" : "false");
  });
  document.addEventListener("click", () => {
    closeAllMenus();
    settingsBtn.setAttribute("aria-expanded", "false");
  });
  settingsMenu.addEventListener("click", (ev) => ev.stopPropagation());
  document.querySelectorAll("[data-theme-option]").forEach((btn) => {
    btn.addEventListener("click", () => {
      applyTheme(btn.dataset.themeOption || THEME_SLICERLIVE);
      closeAllMenus();
    });
  });
  document.getElementById("castAboutBtn")?.addEventListener("click", () => {
    aboutModal.hidden = false;
    closeAllMenus();
  });
  document.querySelectorAll("[data-close-modal]").forEach((el4) => {
    el4.addEventListener("click", () => {
      aboutModal.hidden = true;
    });
  });
}
function boot() {
  const locale = resolveStoredLocale();
  applyDocumentLocale(locale);
  applyHeaderChrome(document, locale);
  applyReportingChrome(document, locale);
  const conf = conferenceStringsFor(locale);
  const startBtn = document.getElementById(
    "startConferenceBtn"
  );
  if (startBtn) {
    startBtn.innerHTML = St;
    startBtn.setAttribute("aria-label", conf.conferencing);
    if (!startBtn.disabled) startBtn.title = conf.conferencing;
    else startBtn.title = conf.subscribeHubFirst;
  }
  const endBtn0 = document.getElementById(
    "endConferenceBtn"
  );
  if (endBtn0) {
    endBtn0.textContent = conf.leaveConference;
    endBtn0.setAttribute("aria-label", conf.leaveConference);
    endBtn0.title = conf.leaveConference;
  }
  applyTheme(getStoredTheme());
  const state = createInitialState();
  const spaSelect = document.getElementById(
    "spaSourceSelect"
  );
  if (spaSelect) {
    spaSelect.value = getSpaSource();
    spaSelect.addEventListener("change", () => {
      setSpaSource(normalizeSpaSource(spaSelect.value));
    });
  }
  let statusWrap = null;
  const reportDisplay = document.getElementById("reportDisplay");
  const confStrings = () => conferenceStringsFor(resolveStoredLocale());
  setStatusListener((s2) => {
    updateConnectionStatusUi(statusWrap, s2);
    setViewerButtonsEnabled(s2.connection === "connected", s2);
  });
  setStudyListener((s2) => {
    renderReportContext(s2);
    remountDisplay(s2, reportDisplay);
    updateViewerPresenceButtons(s2);
  });
  let conferenceDialog = null;
  let inviteController = null;
  let openConferenceDialog = (_anchor) => {
    console.warn("[@slicer-hub/reporting] conference dialog not available");
  };
  try {
    conferenceDialog = ut2({
      classPrefix: "hub-conference",
      strings: confStrings(),
      getSession: () => ({
        hubEndpoint: hubEndpoint(state),
        topic: state.topic,
        subscriberName: state.subscriberName,
        userName: state.userName,
        connected: state.connection === "connected",
        accessToken: state.client?.getConnectionState?.()?.token?.trim() || ""
      }),
      onConferenceChange: (view) => {
        setConferenceView(state, view);
      },
      onFollowChange: (followHost) => {
        setConferenceFollowHost(state, followHost);
      },
      onUserNameChange: async (userName) => {
        await rebindSessionUserName(state, userName);
      }
    });
    setSessionStatusControl(conferenceDialog.getSessionControl());
    statusWrap = conferenceDialog.getSessionControl().label;
    openConferenceDialog = (anchor) => conferenceDialog.open(anchor ?? null);
  } catch (err) {
    console.error("[@slicer-hub/reporting] conference dialog init failed", err);
  }
  try {
    inviteController = ft2({
      classPrefix: "hub-conference-invite",
      strings: confStrings(),
      getSession: () => ({
        hubEndpoint: hubEndpoint(state),
        topic: state.topic,
        subscriberName: state.subscriberName,
        userName: state.userName,
        connected: state.connection === "connected",
        accessToken: state.client?.getConnectionState?.()?.token?.trim() || ""
      }),
      shouldShow: () => dt2({
        selfActors: [REPORTING_ACTOR],
        connectedActors: []
      }),
      onConferenceChange: (view) => {
        setConferenceView(state, view);
      },
      onFollowChange: (followHost, invite) => {
        setConferenceFollowHost(state, followHost);
        const hostTopic = String(invite?.hostTopic || "").trim();
        if (followHost && hostTopic) {
          void requestStatusFromHostWorklist(state, hostTopic);
        }
      },
      onLeadChange: (info) => {
        const label = String(info?.leaderLabel || info?.leaderUserName || "").trim() || "Someone";
        yt(`${label} took over`);
      }
    });
    setConferenceHubHandler(
      (message) => inviteController.handleHubMessage(message)
    );
  } catch (err) {
    console.error("[@slicer-hub/reporting] conference invite init failed", err);
  }
  wireLanguagePicker({
    getLocale: resolveStoredLocale,
    setLocale: (code) => {
      persistLocale(code);
      applyHeaderChrome(document, code);
      applyReportingChrome(document, code);
      const strings = conferenceStringsFor(code);
      conferenceDialog?.setStrings?.(strings);
      inviteController?.setStrings?.(strings);
      const startBtn2 = document.getElementById(
        "startConferenceBtn"
      );
      if (startBtn2) {
        if (!startBtn2.querySelector("svg")) {
          startBtn2.innerHTML = St;
        }
        startBtn2.setAttribute("aria-label", strings.conferencing);
        if (!startBtn2.disabled) startBtn2.title = strings.conferencing;
        else startBtn2.title = strings.subscribeHubFirst;
      }
      const endBtn = document.getElementById(
        "endConferenceBtn"
      );
      if (endBtn) {
        endBtn.textContent = strings.leaveConference;
        endBtn.setAttribute("aria-label", strings.leaveConference);
        endBtn.title = strings.leaveConference;
      }
      renderConferenceRoster(state);
      renderReportContext(state);
    }
  });
  document.getElementById("closeContextBtn")?.addEventListener("click", () => {
    void handleReportingClose(state).catch((err) => {
      console.error("[@slicer-hub/reporting] close context failed", err);
    });
  });
  for (const id of [
    "reportSaveBtn",
    "reportCompleteBtn",
    "reportCancelBtn"
  ]) {
    document.getElementById(id)?.addEventListener("click", () => {
      window.close();
    });
  }
  document.getElementById("startConferenceBtn")?.addEventListener("click", (ev) => {
    const btn = ev.currentTarget instanceof HTMLElement ? ev.currentTarget : null;
    openConferenceDialog(btn);
  });
  document.getElementById("endConferenceBtn")?.addEventListener("click", () => {
    const view = state.conference;
    if (!view || state.connection !== "connected") return;
    const endBtn = document.getElementById(
      "endConferenceBtn"
    );
    const hostAction = Boolean(view.isConferenceOwner);
    if (endBtn) {
      endBtn.disabled = true;
      const s2 = conferenceStringsFor(resolveStoredLocale());
      endBtn.textContent = hostAction ? s2.ending : s2.leaving;
    }
    void Ss(
      hubEndpoint(state),
      view.hostTopic,
      hostAction ? void 0 : state.topic,
      state.client?.getConnectionState?.()?.token?.trim() || ""
    ).then(() => {
      setConferenceView(state, null);
    }).catch((err) => {
      console.error("[@slicer-hub/reporting] end conference failed", err);
    }).finally(() => {
      updateConnectionStatusUi(statusWrap, state);
    });
  });
  wireMenus(state);
  wireViewerButtons(state);
  wireReportDisplay(state, reportDisplay);
  updateConnectionStatusUi(statusWrap, state);
  setViewerButtonsEnabled(state.connection === "connected", state);
  renderReportContext(state);
  remountDisplay(state, reportDisplay);
  console.info(
    "[@slicer-hub/reporting] boot hub=",
    state.hubKey,
    hubEndpoint(state),
    "topic=",
    state.topic || "(from token)"
  );
  autoConnect(state).catch((err) => {
    console.error("[@slicer-hub/reporting] auto-connect error", err);
  });
}
boot();
