(function () {
  var pathname = window.location.pathname || '/'
  var isSlimSubpath =
    pathname === '/slim' || pathname.indexOf('/slim/') === 0
  var isLocalHost =
    window.location.hostname === 'localhost' ||
    window.location.hostname === '127.0.0.1'

  window.config = {
    path: isSlimSubpath ? '/slim/' : '/',
    servers: [
      {
        id: 'idc',
        url: 'https://idc-external-006.uc.r.appspot.com/dcm4chee-arc/aets/DCM4CHEE/rs',
        write: false
      }
    ],
    disableWorklist: true,
    disableAnnotationTools: false,
    mode: 'light',
    preload: true,
    annotations: [
      {
        finding: { value: '85756007', schemeDesignator: 'SCT', meaning: 'Tissue' },
        findingCategory: {
          value: '91723000',
          schemeDesignator: 'SCT',
          meaning: 'Anatomical structure'
        },
        geometryTypes: ['polygon', 'freehandpolygon'],
        style: {
          stroke: { color: [255, 255, 0, 1], width: 2 },
          fill: { color: [255, 255, 255, 0.2] }
        }
      },
      {
        finding: { value: '108369006', schemeDesignator: 'SCT', meaning: 'Tumor' },
        findingCategory: {
          value: '49755003',
          schemeDesignator: 'SCT',
          meaning: 'Morphologically abnormal structure'
        },
        geometryTypes: ['polygon', 'freehandpolygon'],
        style: {
          stroke: { color: [255, 0, 255, 1], width: 2 },
          fill: { color: [255, 255, 255, 0.2] }
        }
      }
    ],
    logger: {
      level: isLocalHost ? 'DEBUG' : 'WARN',
      enableInProduction: false,
      enableInDevelopment: isLocalHost
    },
    cast: {
      defaultHubName: 'SLICER-HUB',
      productName: 'SLIM',
      productVersion: '1.0',
      autoSelectHub: true,
      autoReconnect: true,
      actors: ['ID'],
      hubs: [
        {
          name: 'SLICER-HUB-CLOUD',
          friendlyName: '3D Slicer Cast Hub',
          productName: 'SLICER-HUB',
          client_id: '130c3d9c-4157-4dd1-aa1d-slicer',
          client_secret: '0c931e4163c1bc984b5266735dc652a2f1e3e6e8d8cfe5b0855f433cc8ff018f',
          events: [
            'imagingstudy-open',
            'imagingstudy-close',
            'annotation-update',
            'annotation-delete',
            'dicom-send',
            'nifti-send',
            'status-request',
            'status-update',
            'conference-start',
            'conference-end'
          ],
          lease: 999,
          hub_endpoint: 'https://slicerhub-azejffgnb7dve8es.canadaeast-01.azurewebsites.net/api/hub',
          authorization_endpoint:
            'https://slicerhub-azejffgnb7dve8es.canadaeast-01.azurewebsites.net/oauth/authorize',
          token_endpoint:
            'https://slicerhub-azejffgnb7dve8es.canadaeast-01.azurewebsites.net/oauth/token'
        },
        {
          name: 'SLICER-HUB',
          friendlyName: '3D Slicer Cast Hub (local)',
          productName: 'SLICER-HUB',
          client_id: '130c3d9c-4157-4dd1-aa1d-slicer',
          client_secret: '0c931e4163c1bc984b5266735dc652a2f1e3e6e8d8cfe5b0855f433cc8ff018f',
          events: [
            'imagingstudy-open',
            'imagingstudy-close',
            'annotation-update',
            'annotation-delete',
            'dicom-send',
            'nifti-send',
            'status-request',
            'status-update',
            'conference-start',
            'conference-end'
          ],
          lease: 999,
          hub_endpoint: 'http://127.0.0.1:2018/api/hub',
          authorization_endpoint: 'http://127.0.0.1:2018/oauth/authorize',
          token_endpoint: 'http://127.0.0.1:2018/oauth/token'
        }
      ]
    }
  }
})()
