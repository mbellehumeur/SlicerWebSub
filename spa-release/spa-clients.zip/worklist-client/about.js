// ../client/dist/hub-client.js
var B = "-request";
var $i = "imagingstudy-open";
var xi = "imagingstudy-close";
var Be = "status-update";
var Ji = "dicomsr-update";
var Zi = "subscription-removed";
function rt(e) {
  return typeof e != "string" ? "" : e.trim().toLowerCase();
}
function k(e) {
  const t = rt(e);
  return t ? `${t}${B}` : "";
}
function ut(e, t) {
  if (t === "file:")
    return true;
  const n = String(e || "").toLowerCase();
  return !!(n === "localhost" || n === "127.0.0.1" || n === "[::1]" || /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(n) || /^192\.168\.\d{1,3}\.\d{1,3}$/.test(n) || /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(n));
}
function Qt(e = typeof window < "u" ? window.location : null) {
  return e ? !ut(e.hostname, e.protocol) : false;
}
var sn = Object.freeze({
  ira: (e) => e === "SLICERLIVE-IRA" || e.startsWith("SLICERLIVE-IRA"),
  ohif: (e) => e === "OHIF" || e.startsWith("OHIF"),
  volview: (e) => e === "VOLVIEW" || e.startsWith("VOLVIEW"),
  slicer: (e) => e === "3DSLICER-ID" || e === "SLICER-HUB" || e.startsWith("3DSLICER") || e.startsWith("SLICER-HUB"),
  /** slicer-mirror Four-Up LiveScene stream client (not desktop Image Display). */
  slicerMirror: (e) => e === "SLICER-MIRROR" || e.startsWith("SLICER-MIRROR"),
  mhub: (e) => e === "MHUB" || e.startsWith("MHUB") || e === "MHUB_AI" || e.startsWith("MHUB_AI") || e === "MHUBAI" || e.startsWith("MHUBAI"),
  eucaim: (e) => e === "EUCAIM" || e.startsWith("EUCAIM") || e === "NNUNET_EUCAIM" || e.startsWith("NNUNET_EUCAIM") || e === "NNUNET-EUCAIM" || e.startsWith("NNUNET-EUCAIM"),
  vox2seglam: (e) => e === "VOX2SEGLAM" || e.startsWith("VOX2SEGLAM") || e === "VOX2_SEG_LAM" || e.startsWith("VOX2_SEG_LAM") || e === "VOX2-SEG-LAM" || e.startsWith("VOX2-SEG-LAM"),
  lung: (e) => e === "LUNGSCREENING" || e.startsWith("LUNGSCREENING"),
  totalseg: (e) => e === "TOTALSEG" || e.startsWith("TOTALSEG") || e === "TOTAL_SEGMENTATOR" || e.startsWith("TOTAL_SEGMENTATOR") || e === "TOTAL-SEGMENTATOR" || e.startsWith("TOTAL-SEGMENTATOR"),
  neuro: (e) => e === "NEURO_SEG" || e.startsWith("NEURO_SEG") || e === "NEUROSEG" || e.startsWith("NEUROSEG"),
  dental: (e) => e === "DENTAL_SEG" || e.startsWith("DENTAL_SEG") || e === "DENTALSEG" || e.startsWith("DENTALSEG") || e === "DENTALSEGMENTATOR" || e.startsWith("DENTALSEGMENTATOR"),
  txrv: (e) => e === "TORCHXRAYVISION" || e.startsWith("TORCHXRAYVISION") || e === "TXRV" || e.startsWith("TXRV") || e === "TORCH_XRAY_VISION" || e.startsWith("TORCH_XRAY_VISION") || e === "TORCH-XRAY-VISION" || e.startsWith("TORCH-XRAY-VISION"),
  flexray: (e) => e === "FLEXRAY" || e.startsWith("FLEXRAY") || e === "FLEX_RAY" || e.startsWith("FLEX_RAY"),
  reporting: (e) => e === "RPT" || e.startsWith("RPT-") || e === "CAST-RPT" || e.startsWith("CAST-RPT"),
  classroom: (e) => e === "CLASSROOM" || e.startsWith("CLASSROOM-") || e === "CAST-CLASSROOM" || e.startsWith("CAST-CLASSROOM")
});
var kn = "mhub";
var vn = "MHUB";
var Rn = "MHub models";
var On = "Boston, USA";
var Pn = "Medical Imaging Model Hub \u2014 peer-reviewed deep learning models via standardized Docker I/O.";
var Dn = "https://github.com/MHubAI/";
var Mn = "https://mhub.ai";
var Hn = "Apache-2.0";
var $n = "https://www.apache.org/licenses/LICENSE-2.0";
var xn = "Models may use different licenses; check each model";
var Fn = "dicom-send";
var Bn = true;
var jn = "https://github.com/MHubAI.png";
var Wn = {
  id: kn,
  product: vn,
  title: Rn,
  location: On,
  summary: Pn,
  githubUrl: Dn,
  websiteUrl: Mn,
  license: Hn,
  licenseUrl: $n,
  licenseRestriction: xn,
  hubEvent: Fn,
  enabled: Bn,
  iconUrl: jn
};
var Vn = "eucaim";
var Gn = "EUCAIM";
var zn = "EUCAIM nnU-Net";
var qn = "Heidelberg, Germany";
var Xn = "MIC-DKFZ EUCAIM nnU-Net Docker tasks \u2014 DICOM series in, DICOM SEG out.";
var Yn = "https://github.com/MIC-DKFZ/nnunet-eucaim-docker";
var Jn = "https://cancerimage.eu/";
var Zn = "Apache-2.0";
var Kn = "https://www.apache.org/licenses/LICENSE-2.0";
var Qn = "dicom-send";
var er = true;
var tr = "https://github.com/MIC-DKFZ.png";
var nr = {
  id: Vn,
  product: Gn,
  title: zn,
  location: qn,
  summary: Xn,
  githubUrl: Yn,
  websiteUrl: Jn,
  license: Zn,
  licenseUrl: Kn,
  hubEvent: Qn,
  enabled: er,
  iconUrl: tr
};
var rr = "vox2seglam";
var ir = "VOX2SEGLAM";
var sr = "Vox2SegLAM";
var or = "Montreal, Canada";
var cr = "Joint subcortical segmentation and anatomical landmark detection on T1-weighted brain MRI (Harvard\u2013Oxford Atlas 2.0 protocol). DICOM in \u2192 DICOM SEG/SR out; NIfTI in \u2192 NIfTI out.";
var ar = "https://github.com/Neuro-iX/Vox2SegLAM";
var ur = "https://github.com/Neuro-iX/Vox2SegLAM";
var lr = "MIT";
var fr = "https://opensource.org/licenses/MIT";
var dr = "dicom-send";
var hr = true;
var br = {
  id: rr,
  product: ir,
  title: sr,
  location: or,
  summary: cr,
  githubUrl: ar,
  websiteUrl: ur,
  license: lr,
  licenseUrl: fr,
  hubEvent: dr,
  enabled: hr
};
var mr = "totalseg";
var gr = "TOTALSEG";
var yr = "Total Segmentator";
var pr = "Basel, Switzerland";
var Sr = "Whole-body CT/MR multi-organ segmentation.";
var _r = "https://github.com/wasserth/TotalSegmentator";
var Cr = "https://totalsegmentator.com/";
var wr = "https://www.buymeacoffee.com/totalsegmentator";
var Ir = "Apache-2.0";
var Er = "https://www.apache.org/licenses/LICENSE-2.0";
var Ar = "dicom-send";
var Nr = true;
var Tr = "https://pubs.rsna.org/doi/10.1148/ryai.230024";
var Ur = {
  id: mr,
  product: gr,
  title: yr,
  location: pr,
  summary: Sr,
  githubUrl: _r,
  websiteUrl: Cr,
  buyMeACoffeeUrl: wr,
  license: Ir,
  licenseUrl: Er,
  hubEvent: Ar,
  enabled: Nr,
  citeUrl: Tr
};
var Lr = "dental";
var kr = "DENTAL_SEG";
var vr = "Dental Segmentator";
var Rr = "Paris, France";
var Or = "Fully automatic CT/CBCT dental segmentation (maxilla, mandible, upper/lower teeth, mandibular canal).";
var Pr = "https://github.com/gaudot/SlicerDentalSegmentator";
var Dr = "https://www.kitware.com/dental-segmentator/";
var Mr = "Apache-2.0";
var Hr = "https://www.apache.org/licenses/LICENSE-2.0";
var $r = "dicom-send";
var xr = true;
var Fr = {
  id: Lr,
  product: kr,
  title: vr,
  location: Rr,
  summary: Or,
  githubUrl: Pr,
  websiteUrl: Dr,
  license: Mr,
  licenseUrl: Hr,
  hubEvent: $r,
  enabled: xr
};
var Br = "txrv";
var jr = "TORCHXRAYVISION";
var Wr = "TorchXRayVision";
var Vr = "Montreal, Canada";
var Gr = "Chest X-ray pathology classification (18 findings) and lung/heart anatomy segmentation.";
var zr = "https://github.com/mlmed/torchxrayvision";
var qr = "https://mlmed.org/torchxrayvision/";
var Xr = "Cohen et al., TorchXRayVision: A library of chest X-ray datasets and models, MIDL 2022";
var Yr = "https://arxiv.org/abs/2111.00595";
var Jr = "Apache-2.0";
var Zr = "https://www.apache.org/licenses/LICENSE-2.0";
var Kr = "dicom-send";
var Qr = true;
var ei = {
  id: Br,
  product: jr,
  title: Wr,
  location: Vr,
  summary: Gr,
  githubUrl: zr,
  websiteUrl: qr,
  cite: Xr,
  citeUrl: Yr,
  license: Jr,
  licenseUrl: Zr,
  hubEvent: Kr,
  enabled: Qr
};
var ti = "flexray";
var ni = "FLEXRAY";
var ri = "FleXray";
var ii = "local - in browser";
var si = "Foundation model for universal clinical X-ray anatomy segmentation (60 structures) across body regions, views, and acquisition settings. Designed for on-device / local inference.";
var oi = "https://flexray.csail.mit.edu/";
var ci = "https://github.com/VictorButoi/FleXray";
var ai = "CC-BY-NC-4.0";
var ui = "https://creativecommons.org/licenses/by-nc/4.0/";
var li = "Not for commercial use";
var fi = "Victor Ion Butoi, Vivek Gopalakrishnan, John V. Guttag, Adrian V. Dalca, and Neel Dey (2026). FleXray: Universal Clinical X-ray Segmentation. arXiv:2609.26756";
var di = "https://arxiv.org/abs/2609.26756";
var hi = "dicom-send";
var bi = true;
var mi = true;
var gi = {
  id: ti,
  product: ni,
  title: ri,
  location: ii,
  summary: si,
  websiteUrl: oi,
  githubUrl: ci,
  license: ai,
  licenseUrl: ui,
  licenseRestriction: li,
  cite: fi,
  citeUrl: di,
  hubEvent: hi,
  enabled: bi,
  localCapable: mi
};
function pi(e) {
  const t = String(e.summary || e.capabilities || "").trim(), n = e.hubEvent === "nifti-send" ? "nifti-send" : "dicom-send", r = {
    id: String(e.id || "").trim(),
    product: String(e.product || "").trim(),
    title: String(e.title || "").trim(),
    location: String(e.location || "").trim(),
    summary: t,
    capabilities: t,
    hubEvent: n
  }, i = String(e.githubUrl || "").trim();
  i && (r.githubUrl = i);
  const s = String(e.websiteUrl || "").trim();
  s && (r.websiteUrl = s);
  const o = String(e.buyMeACoffeeUrl || "").trim();
  o && (r.buyMeACoffeeUrl = o);
  const c = String(e.iconUrl || "").trim();
  c && (r.iconUrl = c);
  const a = String(e.cite || "").trim();
  a && (r.cite = a);
  const u = String(e.citeUrl || "").trim();
  u && (r.citeUrl = u);
  const l = String(e.license || "").trim();
  l && (r.license = l);
  const d = String(e.licenseUrl || "").trim();
  d && (r.licenseUrl = d);
  const b = String(e.licenseRestriction || "").trim();
  return b && (r.licenseRestriction = b), e.localCapable === true && (r.localCapable = true), r;
}
function Si(e) {
  return (e == null ? void 0 : e.enabled) !== false;
}
var A = Object.freeze(
  [
    br,
    Wn,
    Ur,
    Fr,
    ei,
    gi,
    nr
  ].filter(Si).map(pi)
);
var zs = Object.freeze(
  A.filter((e) => e.localCapable === true)
);

// config.ts
var LOG_PREFIX = "[@slicer-hub/worklist]";
var SUBSCRIBE_EVENTS = [
  $i,
  xi,
  k("STATUS"),
  Zi,
  Be,
  Ji
];
var IDC_AGENT_URL = "https://learn.canceridc.dev/ai-assistants/agents";
var IDC_CHEST_SUBCATEGORIES = [
  {
    id: "CHEST:NODULES_LIDC",
    label: "IDC \xB7 CHEST \xB7 Nodules (LIDC)",
    namePrefix: "CHEST \xB7 Nodules",
    collections: ["lidc_idri"]
  },
  {
    id: "CHEST:MEDIASTINAL_LN",
    label: "IDC \xB7 CHEST \xB7 Mediastinal LN",
    namePrefix: "CHEST \xB7 Mediastinal LN",
    collections: ["mediastinal_lymph_node_seg"]
  },
  {
    id: "CHEST:NLST_TOTALSEG",
    label: "IDC \xB7 CHEST \xB7 NLST (TotalSeg)",
    namePrefix: "CHEST \xB7 NLST",
    collections: ["nlst"]
  },
  {
    id: "CHEST:AIMI_LUNG_FDG",
    label: "IDC \xB7 CHEST \xB7 AIMI lung/FDG",
    namePrefix: "CHEST \xB7 AIMI",
    collections: ["acrin_nsclc_fdg_pet", "lung_pet_ct_dx", "rider_lung_pet_ct"]
  },
  {
    id: "CHEST:OTHER",
    label: "IDC \xB7 CHEST \xB7 Other",
    namePrefix: "CHEST \xB7 Other",
    collections: "other"
  }
];
var CHEST_COLLECTION_TO_SUBCATEGORY = (() => {
  const map = /* @__PURE__ */ new Map();
  for (const sub of IDC_CHEST_SUBCATEGORIES) {
    if (sub.collections === "other") continue;
    for (const col of sub.collections) {
      map.set(col, sub);
    }
  }
  return map;
})();
var CHEST_OTHER_SUBCATEGORY = IDC_CHEST_SUBCATEGORIES.find((s) => s.collections === "other");
var IDC_KITS_CATEGORY = {
  id: "KIDNEY:KITS",
  label: "IDC \xB7 KIDNEY \xB7 KiTS",
  namePrefix: "KiTS",
  collectionId: "c4kc_kits"
};
var IDC_MODALITY_SPLIT_BASES = [
  "ABDOMEN",
  "BREAST",
  "LIVER",
  "LUNG",
  "CHEST:AIMI_LUNG_FDG",
  "CHEST:OTHER"
];
var MODALITY_SPLIT_BASE_SET = new Set(IDC_MODALITY_SPLIT_BASES);
var IDC_CATEGORIES = [
  "ABDOMEN:CT",
  "ABDOMEN:PT",
  "ABDOMEN:MR",
  "ADRENAL",
  "BRAIN",
  "BREAST:MR",
  "BREAST:PT",
  "CHEST:NODULES_LIDC",
  "CHEST:MEDIASTINAL_LN",
  "CHEST:NLST_TOTALSEG",
  "CHEST:AIMI_LUNG_FDG:CT",
  "CHEST:AIMI_LUNG_FDG:PT",
  "CHEST:OTHER:CT",
  "CHEST:OTHER:PT",
  "KIDNEY",
  IDC_KITS_CATEGORY.id,
  "LIVER:CT",
  "LIVER:MR",
  "LUNG:CT",
  "LUNG:PT",
  "PANCREAS",
  "PELVIS",
  "PROSTATE",
  "WHOLEBODY"
];
var THEME_STORAGE_KEY = "pw46.worklist.theme";
var THEME_SLICERLIVE = "slicerlive";
var HUB_CREDENTIALS = {
  client_id: "client_id_3d_Slicer",
  client_secret: "client_secret_3d_Slicer"
};
var HUB_DEFINITIONS = {
  local: {
    label: "3D Slicer local",
    hubEndpoint: "http://127.0.0.1:2018/api/hub",
    authorizeEndpoint: "http://127.0.0.1:2018/oauth/login",
    tokenEndpoint: "http://127.0.0.1:2018/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloud: {
    label: "3D Slicer cloud (mock)",
    hubEndpoint: "https://bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloudOidc: {
    label: "3D Slicer cloud (OIDC)",
    hubEndpoint: "https://oidc.bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  }
};
function isHostedOnCastHub(location = window.location) {
  const path = String(location.pathname || "");
  return path.startsWith("/worklist-client") || path.startsWith("/reporting-client") || path.startsWith("/classroom-client");
}
function shouldUseSameOriginHub(location = window.location) {
  return isHostedOnCastHub(location) || Qt(location);
}
function hubOriginFromEndpoint(hubEndpoint) {
  const trimmed = String(hubEndpoint || "").trim();
  if (!trimmed) return null;
  try {
    return new URL(trimmed).origin;
  } catch {
    return null;
  }
}
function setStoredTheme(theme) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
  }
}

// about-content.ts
var DEFAULT_ABOUT_NAME = "Hub Interface worklist example client";
var DEFAULT_ABOUT_DESCRIPTION = "3D Slicer extension for desktop integration workflows for healthcare providers and researchers.";
var DEFAULT_ABOUT_HOMEPAGE = "https://github.com/mbellehumeur/SlicerWebSub/";
var IDC_PORTAL_URL = "https://portal.imaging.datacommons.cancer.gov/";
var KITWARE_DATA_URL = "https://data.kitware.com/";
var TOTALSEG_CT_PAPER_URL = "https://arxiv.org/abs/2208.05868";
var TOTALSEG_MRI_PAPER_URL = "https://arxiv.org/abs/2405.19492";
var NNUNET_PAPER_URL = "https://arxiv.org/abs/1809.10486";
var IDC_INDEX_URL = "https://github.com/ImagingDataCommons/idc-index";
var IDC_PAPER_URL = "https://doi.org/10.1148/rg.230180";
var SLICERLIVE_GITHUB_URL = "https://github.com/pieper/SlicerLive";
var SLICERLIVE_GALLERY_URL = "https://pieper.github.io/live";
var SLICERHEART_GITHUB_URL = "https://github.com/SlicerHeart/SlicerHeart";
var SLICERHEART_PAPER_URL = "https://doi.org/10.3389/fcvm.2022.886549";
var OHIF_URL = "https://ohif.org/";
var SLIM_GITHUB_URL = "https://github.com/ImagingDataCommons/slim";
function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function aboutLicenseAckHtml(homepage) {
  const licenseUrl = `${String(homepage || "").replace(/\/$/, "")}/blob/main/LICENSE.txt`;
  return `
    <div class="about-disclaimer">
      <h4>License</h4>
      <p>Hub Interface is distributed under the <a href="${escapeHtml(licenseUrl)}" target="_blank" rel="noopener noreferrer">MIT License</a>.</p>
      <h4>Acknowledgements</h4>
      <p><strong>3D Slicer</strong> &mdash; open-source platform for medical image computing from the <a href="https://www.slicer.org/" target="_blank" rel="noopener noreferrer">3D Slicer community</a>.</p>
      <p><strong>OHIF</strong> &mdash; open-source zero-footprint viewer from the <a href="${escapeHtml(OHIF_URL)}" target="_blank" rel="noopener noreferrer">Open Health Imaging Foundation</a>.</p>
      <p><strong>Slim</strong> &mdash; interoperable slide microscopy viewer from the <a href="${escapeHtml(SLIM_GITHUB_URL)}" target="_blank" rel="noopener noreferrer">Imaging Data Commons</a> (National Cancer Institute).</p>
      <p><strong>SlicerLive</strong> &mdash; live 3D Slicer scenes on the web (render MRML/MRB in the browser, no install). See <a href="${escapeHtml(SLICERLIVE_GITHUB_URL)}" target="_blank" rel="noopener noreferrer">github.com/pieper/SlicerLive</a> and the <a href="${escapeHtml(SLICERLIVE_GALLERY_URL)}" target="_blank" rel="noopener noreferrer">SlicerLive gallery</a>.</p>
      <p><strong>SlicerHeart</strong> &mdash; 3D Slicer extension for cardiac image analysis and modeling. See <a href="${escapeHtml(SLICERHEART_GITHUB_URL)}" target="_blank" rel="noopener noreferrer">github.com/SlicerHeart/SlicerHeart</a>. If you use it in research, cite Lasso A, et al., <em>Frontiers in Cardiovascular Medicine</em> (<a href="${escapeHtml(SLICERHEART_PAPER_URL)}" target="_blank" rel="noopener noreferrer">2022</a>).</p>
    </div>`;
}
var ABOUT_SAMPLE_DATA_ACK_HTML = `
  <div class="about-disclaimer">
    <h4>Sample data acknowledgement</h4>
    <p>Worklist demo studies are provided courtesy of the <a href="${escapeHtml(IDC_PORTAL_URL)}" target="_blank" rel="noopener noreferrer">Imaging Data Commons</a> (National Cancer Institute) and the <a href="${escapeHtml(KITWARE_DATA_URL)}" target="_blank" rel="noopener noreferrer">Kitware sample data repository</a>. IDC entries are loaded from public IDC collections; VolView sample entries mirror datasets hosted on Kitware&rsquo;s data portal. The hub example does not redistribute these studies; it links to or loads them from their original sources.</p>
  </div>`;
var ABOUT_RESOURCE_SERVERS_ACK_HTML = `
  <div class="about-disclaimer">
    <h4>Service providers acknowledgement</h4>
    <p><strong>TotalSegmentator</strong> was created by the Department of Research and Analysis at University Hospital Basel. If you use it, please cite our Radiology: Artificial Intelligence paper (<a href="${escapeHtml(TOTALSEG_CT_PAPER_URL)}" target="_blank" rel="noopener noreferrer">free preprint</a>). If you use it for MR images, please cite the TotalSegmentator MRI <em>Radiology</em> paper (<a href="${escapeHtml(TOTALSEG_MRI_PAPER_URL)}" target="_blank" rel="noopener noreferrer">free preprint</a>).</p>
    <p><strong>nnU-Net</strong> &mdash; TotalSegmentator is heavily based on nnU-Net; (<a href="${escapeHtml(NNUNET_PAPER_URL)}" target="_blank" rel="noopener noreferrer">preprint</a>).</p>
    <p><strong>IDC Claude / NL search</strong> &mdash; Anthropic on the Slicer hub translates natural-language IDC requests into a structured SearchQuery; the worklist executes it against the public IDC REST API. Query guidance follows the <a href="${escapeHtml(IDC_AGENT_URL)}" target="_blank" rel="noopener noreferrer">IDC AI assistants</a> docs.</p>
    <p><strong>idc-index</strong> &mdash; official Imaging Data Commons Python package for local DuckDB SQL against IDC metadata and DICOM series download URLs; used by the IDC Claude service provider. If you use it in research, cite Fedorov A, et al., <em>Radiographics</em> (<a href="${escapeHtml(IDC_PAPER_URL)}" target="_blank" rel="noopener noreferrer">2023</a>). See also <a href="${escapeHtml(IDC_INDEX_URL)}" target="_blank" rel="noopener noreferrer">idc-index</a>.</p>
  </div>`;
var ABOUT_TRADEMARK_HTML = `
  <div class="about-disclaimer">
    <h4>Standards and trademarks</h4>
    <p>DICOM&reg; is the registered trademark of the National Electrical Manufacturers Association (NEMA) for its standards publications relating to digital imaging and communications in medicine. FHIR&reg; and related HL7 marks are registered trademarks of Health Level Seven International (HL7). IHE&reg; is a registered trademark of HIMSS. VolView&reg; is a trademark of Kitware, Inc. OHIF&reg; is a trademark of the Open Health Imaging Foundation. Imaging Data Commons&reg; is a trademark of the National Cancer Institute.</p>
    <p>The Hub Interface (including its hub, clients, and documentation) references ideas, workflows, and vocabulary drawn from these standards&mdash;such as DICOM objects and metadata, FHIR and FHIRcast-style context and events, and IHE actor roles (for example, Image Display and Evidence Creator)&mdash;and product names such as VolView, OHIF, and Imaging Data Commons solely to describe interoperability behavior.</p>
    <p><strong>Hub Interface is not part of these standards.</strong> It is not published by NEMA, HL7, or HIMSS, and is not an IHE Integration Profile, a FHIR implementation guide, or a DICOM conformance statement. Use of standard names and terms does not imply endorsement, certification, or official status. All other product and company names are trademarks of their respective owners.</p>
  </div>`;
function resolveAboutHubOrigin(location = window.location) {
  if (shouldUseSameOriginHub(location)) {
    return location.origin;
  }
  return hubOriginFromEndpoint(HUB_DEFINITIONS.local.hubEndpoint);
}
async function fetchAboutMeta(origin) {
  const meta = {
    name: DEFAULT_ABOUT_NAME,
    description: DEFAULT_ABOUT_DESCRIPTION,
    homepage: DEFAULT_ABOUT_HOMEPAGE
  };
  if (!origin) return meta;
  try {
    const response = await fetch(`${origin}/api/hub/admin/about`);
    if (!response.ok) return meta;
    const data = await response.json();
    if (data.name) meta.name = String(data.name);
    if (data.description) meta.description = String(data.description);
    if (data.homepage) meta.homepage = String(data.homepage);
  } catch (err) {
    console.warn(`${LOG_PREFIX} About metadata unavailable:`, err);
  }
  return meta;
}
function aboutBannerSrc(origin) {
  const base = origin || "";
  return `${base}/static/images/banner.jpg`;
}
function renderAboutContent(content, titleEl, meta, origin) {
  if (titleEl) {
    titleEl.textContent = `About ${meta.name}`;
  }
  content.innerHTML = `
    <div class="about-banner-wrap">
      <img class="about-banner" src="${escapeHtml(aboutBannerSrc(origin))}"
           alt="${escapeHtml(meta.name)}">
    </div>
    <p class="about-body">${escapeHtml(meta.description)} This Integrated Worklist client connects to a Slicer hub as <code>WORKLIST_CLIENT</code>. See the <a href="${escapeHtml(meta.homepage)}" target="_blank" rel="noopener noreferrer">3D Slicer WebSub interface extension</a> documentation.</p>
    ${aboutLicenseAckHtml(meta.homepage)}
    ${ABOUT_SAMPLE_DATA_ACK_HTML}
    ${ABOUT_RESOURCE_SERVERS_ACK_HTML}
    ${ABOUT_TRADEMARK_HTML}
  `;
}
async function fillAboutContent(content, titleEl, origin) {
  content.innerHTML = `<p class="wl-muted">Loading\u2026</p>`;
  const meta = await fetchAboutMeta(origin);
  renderAboutContent(content, titleEl, meta, origin);
}
async function mountAboutPage(root = document, location = window.location) {
  const content = root.querySelector(
    "#aboutPageContent"
  );
  const titleEl = root.querySelector("#aboutPageTitle");
  if (!content) return;
  const origin = resolveAboutHubOrigin(location);
  await fillAboutContent(content, titleEl, origin);
}

// about-page.ts
document.documentElement.dataset.theme = THEME_SLICERLIVE;
setStoredTheme(THEME_SLICERLIVE);
void mountAboutPage();
