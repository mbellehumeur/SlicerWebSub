// ../client/dist/hub-client.js
var ue = "UNKNOWN";
var Oe = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function Ke(e, t3 = ue) {
  return String(e || t3).trim().replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "") || t3;
}
function At(e) {
  return `${Ke(e)}-`;
}
function F(e) {
  return typeof crypto < "u" && crypto.randomUUID ? e + crypto.randomUUID().replace(/-/g, "").slice(0, 16) : e + Math.random().toString(36).substring(2, 18);
}
function Pe(e = ue) {
  const t3 = Ke(e);
  let n = "";
  for (let r = 0; r < 6; r++) {
    const i = Math.floor(Math.random() * Oe.length);
    n += Oe[i];
  }
  return `${t3}-${n}`;
}
var De = [
  "dicom",
  "nifti",
  "jpg",
  "png",
  "nrrd",
  "imagingstudy",
  "scene"
  // scene-update (LiveSync HubBlobs multipart)
];
function X(e) {
  if (typeof e != "string") return false;
  const t3 = e.trim().toLowerCase();
  if (!t3) return false;
  for (let n = 0; n < De.length; n++) {
    const r = De[n];
    if (t3 === r || t3.startsWith(`${r}-`) || t3.startsWith(`${r}_`))
      return true;
  }
  return false;
}
function Nt(e) {
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView(e);
}
async function Y(e) {
  if (e instanceof ArrayBuffer)
    return e;
  if (Nt(e)) {
    const { buffer: t3, byteOffset: n, byteLength: r } = e;
    return t3.slice(n, n + r);
  }
  if (typeof Blob < "u" && e instanceof Blob && typeof e.arrayBuffer == "function")
    return e.arrayBuffer();
  throw new Error(
    "HubClient: binary resource.data must be ArrayBuffer, TypedArray, DataView, Blob, or File"
  );
}
function M(e) {
  const t3 = e && e.context;
  if (!t3 || typeof t3 != "object" || Array.isArray(t3))
    return [];
  const n = t3.files;
  return Array.isArray(n) ? n.filter((r) => r && typeof r == "object") : [];
}
function le(e) {
  if (!e || typeof e != "object" || e.data != null)
    return { payloadIds: [], chunkByteLengths: [] };
  const t3 = e.payloadIds;
  if (Array.isArray(t3) && t3.length) {
    const r = t3.map((s2) => typeof s2 == "string" ? s2.trim() : "").filter(Boolean), i = Array.isArray(e.chunkByteLengths) ? e.chunkByteLengths.filter((s2) => typeof s2 == "number" && s2 >= 0) : [];
    if (i.length === r.length)
      return { payloadIds: r, chunkByteLengths: i };
    if (r.length === 1) {
      const s2 = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
      return {
        payloadIds: r,
        chunkByteLengths: s2 != null ? [s2] : []
      };
    }
  }
  const n = typeof e.payloadId == "string" ? e.payloadId.trim() : "";
  if (n) {
    const r = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
    return {
      payloadIds: [n],
      chunkByteLengths: r != null ? [r] : []
    };
  }
  return { payloadIds: [], chunkByteLengths: [] };
}
function Tt(e) {
  const t3 = M(e);
  for (let n = 0; n < t3.length; n++) {
    const r = t3[n];
    if (r.data == null) {
      const i = le(r);
      if (i.payloadIds.length)
        return {
          kind: "files",
          index: n,
          chunkIndex: 0,
          payloadId: i.payloadIds[0],
          expectedChunkBytes: i.chunkByteLengths[0] ?? null
        };
    }
  }
  return null;
}
function Qe(e) {
  return Tt(e);
}
function se(e) {
  return !!Qe(e);
}
function oe(e, t3) {
  return (typeof e == "string" ? e.trim().toLowerCase() : "").startsWith("nifti") ? t3 === 0 ? "nifti-send.nii.gz" : `nifti-send-${t3 + 1}.nii.gz` : t3 === 0 ? "dicom-send.dcm" : `dicom-send-${t3 + 1}.dcm`;
}
function ce(e) {
  return (typeof e == "string" ? e.trim().toLowerCase() : "").startsWith("nifti") ? "application/octet-stream" : "application/dicom";
}
function ne(e) {
  const t3 = e && e.event;
  if (!t3 || !X(t3["hub.event"]) || M(t3).length)
    return e;
  const n = t3["hub.event"], r = t3.context;
  let i = [];
  Array.isArray(r) ? i = r : r != null && (i = [r]);
  const s2 = [];
  for (let o = 0; o < i.length; o++) {
    const c = i[o];
    if (c && typeof c == "object") {
      const a = c.resource;
      if (a && typeof a == "object" && a.data != null) {
        const u = { ...a };
        (typeof u.fileName != "string" || !u.fileName.trim()) && (u.fileName = oe(n, o)), (typeof u.mimeType != "string" || !u.mimeType.trim()) && (u.mimeType = ce(n)), s2.push(u);
      }
    }
  }
  return s2.length ? {
    ...e,
    event: {
      ...t3,
      context: {
        files: s2
      }
    }
  } : e;
}
function et(e, t3) {
  const n = e && e.event, r = n && n.context;
  let i = [];
  Array.isArray(r) ? i = r : r != null && (i = [r]);
  for (let s2 = 0; s2 < i.length; s2++) {
    const o = i[s2];
    if (o && typeof o == "object") {
      const c = o.resource;
      if (c && typeof c == "object") {
        const a = typeof c.fileName == "string" ? c.fileName.trim() : "";
        if (a)
          return a;
      }
    }
  }
  return t3;
}
function J(e) {
  if (!e || typeof e != "object")
    return false;
  const t3 = typeof e.url == "string" ? e.url.trim() : "";
  if (!t3)
    return false;
  const n = t3.toLowerCase();
  return n.startsWith("http://") || n.startsWith("https://");
}
function Ut(e) {
  const t3 = [];
  for (let n = 0; n < e.length; n += 1)
    J(e[n]) || t3.push(n);
  return t3;
}
function Lt(e) {
  const t3 = e && e.event;
  if (!t3 || !X(t3["hub.event"]))
    return false;
  const n = M(t3);
  return n.length ? n.some(
    (r) => r.data != null && !J(r)
  ) : false;
}
async function kt(e, t3 = "", n = 0) {
  if (!e || typeof e != "object")
    throw new Error(
      "HubClient: binary batch publish files[] entries must be objects"
    );
  const r = J(e);
  let i = typeof e.byteLength == "number" && e.byteLength >= 0 ? e.byteLength : null;
  if ("data" in e && e.data != null) {
    if (typeof e.data == "string")
      throw new Error(
        "HubClient: binary batch publish string payloads are not supported; pass binary input instead"
      );
    i = (await Y(e.data)).byteLength;
  }
  if (i == null && r) {
    const o = { ...e };
    return delete o.data, delete o.binaryTransfer, delete o.payloadId, delete o.payloadIds, delete o.chunkByteLengths, delete o.expiresAt, (typeof o.fileName != "string" || !o.fileName.trim()) && (o.fileName = oe(t3, n)), (typeof o.mimeType != "string" || !o.mimeType.trim()) && (o.mimeType = ce(t3)), o;
  }
  if (i == null)
    throw new Error(
      "HubClient: binary batch publish requires files[].data or files[].byteLength"
    );
  const s2 = { ...e };
  return delete s2.data, delete s2.binaryTransfer, r || delete s2.url, delete s2.payloadId, delete s2.payloadIds, delete s2.chunkByteLengths, delete s2.expiresAt, s2.byteLength = i, (typeof s2.fileName != "string" || !s2.fileName.trim()) && (s2.fileName = oe(t3, n)), (typeof s2.mimeType != "string" || !s2.mimeType.trim()) && (s2.mimeType = ce(t3)), s2;
}
async function vt(e) {
  if (!e.event || typeof e.event != "object")
    throw new Error("HubClient: binary batch publish requires event object");
  const t3 = e.event;
  if (!X(t3["hub.event"]))
    return e;
  const n = t3.context;
  if (!n || typeof n != "object" || Array.isArray(n))
    throw new Error(
      "HubClient: binary batch publish requires event.context object"
    );
  const r = n.files;
  if (!Array.isArray(r) || !r.length)
    throw new Error(
      "HubClient: binary batch publish requires non-empty event.context.files[]"
    );
  const i = t3["hub.event"], s2 = await Promise.all(
    r.map(
      (o, c) => kt(o, i, c)
    )
  );
  return {
    ...e,
    event: {
      ...t3,
      context: {
        ...n,
        files: s2
      }
    }
  };
}
async function Me(e) {
  const t3 = e && e.event;
  if (!t3)
    return [];
  const r = M(t3).filter(
    (i) => i && typeof i == "object" && i.data != null && !J(i)
  );
  return Promise.all(r.map((i) => Y(i.data)));
}
function Rt(e, t3, n) {
  const r = new TextEncoder(), i = r.encode(`\r
`), s2 = [], o = (c) => {
    s2.push(r.encode(c));
  };
  o(
    `--${e}\r
Content-Type: application/dicom+json\r
\r
${t3}\r
`
  );
  for (let c = 0; c < n.length; c++) {
    const a = n[c], u = a && a.mimeType && String(a.mimeType).trim() || "application/octet-stream";
    o(`--${e}\r
Content-Type: ${u}\r
\r
`), s2.push(new Uint8Array(a.buffer)), s2.push(i);
  }
  return o(`--${e}--\r
`), new Blob(s2);
}
async function Ot({
  msg: e,
  fileBytesList: t3,
  hub: n,
  messageIdPrefix: r
}) {
  const i = await vt(e), s2 = await Promise.all(
    (t3 || []).map((d) => Y(d))
  ), o = M(i.event), c = Ut(o);
  if (s2.length !== c.length)
    throw new Error(
      `HubClient: binary batch publish expected ${c.length} file part(s), got ${s2.length}`
    );
  const a = s2.map((d, b) => {
    const f2 = c[b];
    return {
      buffer: d,
      mimeType: o[f2] && o[f2].mimeType || "application/octet-stream"
    };
  }), u = `hub-batch-${F(r())}`, l = Rt(
    u,
    JSON.stringify(i),
    a
  );
  try {
    return await fetch(n.hub_endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${n.token}`,
        "Content-Type": `multipart/related; boundary="${u}"; type="application/dicom"`
      },
      body: l
    });
  } catch (d) {
    const b = d instanceof Error ? d.message : String(d);
    return console.debug("HubClient:", b), null;
  }
}
function Pt() {
  return {
    name: "",
    friendlyName: "",
    version: "",
    hub_endpoint: "",
    authorization_endpoint: "",
    token_endpoint: "",
    client_id: "",
    client_secret: ""
  };
}
function Dt() {
  return {
    subscriberName: "",
    productName: "",
    productVersion: "",
    actors: [],
    topic: "",
    events: [],
    lease: 999,
    userName: "",
    defaultTargetActor: ""
  };
}
function re(e) {
  if (e == null)
    return;
  const t3 = String(e).trim();
  if (!(!t3 || t3 === "*"))
    return t3;
}
function Mt(e) {
  if (e == null)
    return;
  const t3 = String(e).trim();
  if (!(!t3 || t3 === "*"))
    return t3;
}
function Ht() {
  return {
    token: "",
    lastIdToken: "",
    lastPublishedMessageID: "",
    subscribed: false,
    resubscribeRequested: false,
    websocket: null,
    /** ``mock`` | ``oidc`` from GET /api/hub/auth/config (when known). */
    authMode: "",
    /** True after tokens were applied from an OIDC redirect fragment. */
    oidcSession: false
  };
}
function $t() {
  if (typeof navigator > "u")
    return null;
  const e = {};
  typeof navigator.userAgent == "string" && navigator.userAgent.trim() && (e.userAgent = navigator.userAgent.trim()), typeof navigator.platform == "string" && navigator.platform.trim() && (e.platform = navigator.platform.trim()), typeof navigator.language == "string" && navigator.language.trim() && (e.language = navigator.language.trim());
  try {
    const t3 = Intl.DateTimeFormat().resolvedOptions().timeZone;
    typeof t3 == "string" && t3.trim() && (e.timezone = t3.trim());
  } catch {
  }
  return Object.keys(e).length ? e : null;
}
function He(e) {
  return e || (typeof window < "u" ? `${window.location.origin}/castCallback` : "");
}
function $e(e, t3, n, r = "") {
  const i = new URLSearchParams();
  i.append("hub.mode", e), i.append("hub.channel.type", "websocket"), i.append("hub.callback", n), i.append("hub.events", (t3.events || []).toString()), i.append("hub.topic", t3.topic || ""), i.append("hub.lease", String(t3.lease || 999)), i.append("subscriber.name", t3.subscriberName || ""), i.append("subscriber.product.name", t3.productName || ""), i.append(
    "subscriber.product.version",
    t3.productVersion || r || ""
  );
  const s2 = (t3.actors || []).map((c) => c.trim()).filter(Boolean);
  s2.length && i.append("subscriber.actors", JSON.stringify(s2));
  const o = $t();
  return o && i.append("subscriber.client_info", JSON.stringify(o)), i;
}
var U = 25;
function xt(e) {
  try {
    const t3 = new URL(e);
    return t3.hostname.toLowerCase() === "localhost" && (t3.hostname = "127.0.0.1"), t3.toString();
  } catch {
    return e;
  }
}
function Ft(e) {
  if (!(e instanceof Error))
    return false;
  const t3 = e.name || "";
  return t3 === "TypeError" || t3 === "NetworkError";
}
function Bt(e, t3) {
  if (!e)
    return "";
  try {
    const n = `/api/hub/payloads/${encodeURIComponent(e)}`;
    return xt(new URL(n, t3).toString());
  } catch (n) {
    return console.warn("HubClient: invalid payloadId url", e, n), "";
  }
}
function jt(e) {
  delete e.binaryTransfer, delete e.url, delete e.payloadId, delete e.payloadIds, delete e.chunkByteLengths, delete e.expiresAt;
}
function tt(e, t3) {
  const n = e.reduce((s2, o) => s2 + o.byteLength, 0);
  if (typeof t3 == "number" && t3 >= 0 && n !== t3)
    throw new Error(
      `HubClient: payload size mismatch expected=${t3} received=${n}`
    );
  const r = new Uint8Array(n);
  let i = 0;
  for (let s2 = 0; s2 < e.length; s2++)
    r.set(new Uint8Array(e[s2]), i), i += e[s2].byteLength;
  return r.buffer;
}
function xe(e, t3, n) {
  const r = e && e.event, i = r && r.context, s2 = i && i.files, o = s2 && s2[t3];
  return !o || typeof o != "object" ? false : (jt(o), o.data = n, o.byteLength = n.byteLength, true);
}
async function nt(e, t3, { hubEndpoint: n, accessToken: r }) {
  const i = Bt(e, n);
  if (!i)
    throw new Error("HubClient.fetchPayload: missing or invalid payloadId");
  const s2 = {};
  r && (s2.Authorization = `Bearer ${r}`);
  async function o() {
    const c = await fetch(i, {
      method: "GET",
      credentials: "omit",
      headers: s2
    });
    if (!c.ok)
      throw new Error(
        `HubClient.fetchPayload: GET ${c.status} ${c.statusText}`
      );
    const a = await c.arrayBuffer();
    if (typeof t3 == "number" && t3 >= 0 && a.byteLength !== t3)
      throw new Error(
        `HubClient.fetchPayload: chunk size mismatch payloadId=${e.slice(
          0,
          8
        )} expected=${t3} received=${a.byteLength}`
      );
    return a;
  }
  try {
    return await o();
  } catch (c) {
    if (Ft(c))
      return o();
    throw c;
  }
}
async function Wt(e, t3) {
  const n = le(e);
  if (!n.payloadIds.length)
    throw new Error("HubClient.fetchPayload: no payloadIds on file entry");
  const r = [];
  for (let i = 0; i < n.payloadIds.length; i += U) {
    const s2 = n.payloadIds.slice(
      i,
      i + U
    ), o = n.chunkByteLengths.slice(
      i,
      i + U
    ), c = await Promise.all(
      s2.map(
        (a, u) => nt(a, o[u] ?? null, t3)
      )
    );
    r.push(...c);
  }
  return tt(
    r,
    typeof e.byteLength == "number" ? e.byteLength : null
  );
}
async function Vt(e, t3, n = U) {
  if (!e.length)
    return [];
  const r = Math.max(1, n | 0), i = new Array(e.length);
  let s2 = 0;
  async function o() {
    for (; s2 < e.length; ) {
      const a = s2++, u = e[a];
      i[a] = await nt(
        u.payloadId,
        u.expectedLength ?? null,
        t3
      );
    }
  }
  const c = Array.from(
    { length: Math.min(r, e.length) },
    () => o()
  );
  return await Promise.all(c), i;
}
function Fe(e) {
  return JSON.parse(JSON.stringify(e));
}
function Gt(e) {
  const t3 = () => e();
  return {
    hasPendingPayload(n) {
      const r = n && n.event;
      return !!(r && se(r));
    },
    async fetchPayload(n) {
      const r = n && n.event;
      if (!r || !se(r))
        return n;
      const i = Qe(r);
      if (!i)
        return n;
      const s2 = typeof performance < "u" && performance.now ? performance.now() : Date.now(), o = r.context.files[i.index], c = await Wt(o, t3()), a = Fe(n);
      if (!xe(a, i.index, c))
        throw new Error("HubClient.fetchPayload: no payload slot on message");
      const l = (typeof performance < "u" && performance.now ? performance.now() : Date.now()) - s2;
      return console.debug(
        `HubClient: payload fetched fileIndex=${i.index} bytes=${c.byteLength} elapsed=${(l / 1e3).toFixed(2)}s`
      ), a;
    },
    async fetchAllPayloads(n) {
      const r = n && n.event, i = r && r.context, s2 = i && typeof i == "object" && !Array.isArray(i) && Array.isArray(i.files) ? i.files : [], o = [];
      for (let f2 = 0; f2 < s2.length; f2++) {
        const h = s2[f2];
        if (!h || typeof h != "object" || h.data != null)
          continue;
        const g = le(h);
        if (g.payloadIds.length)
          for (let m = 0; m < g.payloadIds.length; m++)
            o.push({
              fileIndex: f2,
              chunkIndex: m,
              payloadId: g.payloadIds[m],
              expectedLength: typeof g.chunkByteLengths[m] == "number" ? g.chunkByteLengths[m] : null
            });
      }
      if (!o.length)
        return n;
      const c = typeof performance < "u" && performance.now ? performance.now() : Date.now(), a = t3(), u = await Vt(
        o,
        a,
        U
      ), l = /* @__PURE__ */ new Map();
      for (let f2 = 0; f2 < o.length; f2++) {
        const { fileIndex: h, chunkIndex: g } = o[f2];
        let m = l.get(h);
        m || (m = [], l.set(h, m)), m[g] = u[f2];
      }
      const d = Fe(n);
      for (const [f2, h] of l) {
        const g = d.event.context.files[f2], m = typeof g.byteLength == "number" ? g.byteLength : null, y = tt(h, m);
        if (!xe(d, f2, y))
          throw new Error("HubClient.fetchAllPayloads: attach failed");
      }
      const b = (typeof performance < "u" && performance.now ? performance.now() : Date.now()) - c;
      return console.debug(
        `HubClient: fetchAllPayloads files=${l.size} chunks=${o.length} concurrent=${U} elapsed=${(b / 1e3).toFixed(2)}s`
      ), d;
    }
  };
}
var B = "-request";
var j = "-response";
var $i = "imagingstudy-open";
var xi = "imagingstudy-close";
var Be = "status-update";
var Ji = "dicomsr-update";
var Zi = "subscription-removed";
function rt(e) {
  return typeof e != "string" ? "" : e.trim().toLowerCase();
}
function k(e) {
  const t3 = rt(e);
  return t3 ? `${t3}${B}` : "";
}
function zt(e) {
  const t3 = rt(e);
  return t3 ? `${t3}${j}` : "";
}
function Qi(e) {
  return typeof e != "string" ? false : e.endsWith(B);
}
var Xt = 1e4;
var je = 5e3;
var Yt = {
  hub: {},
  session: {},
  productName: void 0,
  productVersion: void 0,
  callbackUrl: void 0,
  autoStart: false,
  autoReconnect: false,
  preserveSessionTopicFromToken: false
};
var fe = class _fe {
  constructor(t3 = {}, n = {}, r = {}) {
    this._config = { ...Yt, ...r }, this._session = {
      ...Dt(),
      ...n || {}
    }, (!this._session.subscriberName || !String(this._session.subscriberName).trim()) && (this._session.subscriberName = Pe(
      this._session.productName || this._config.productName || "UNKNOWN"
    )), this._hub = {
      ...Pt(),
      ...t3 || {},
      ...Ht()
    }, this._reconnectInterval = null, this._onMessageCallback = null, this._onConnectionStateChangeCallback = null, this._payloadFetchApi = Gt(() => ({
      hubEndpoint: this._hub.hub_endpoint,
      accessToken: this._hub.token
    })), this._websocketClose = this._websocketClose.bind(this), this._checkWebsocket = this._checkWebsocket.bind(this), this._config.autoReconnect && (this._reconnectInterval = setInterval(
      this._checkWebsocket,
      Xt
    ));
  }
  static newInstance(t3 = {}) {
    const { hub: n = {}, session: r = {}, ...i } = t3 || {};
    return new _fe(n, r, i);
  }
  onMessage(t3) {
    this._onMessageCallback = t3;
  }
  onConnectionStateChange(t3) {
    this._onConnectionStateChangeCallback = t3;
  }
  _emitConnectionState(t3, n) {
    this._onConnectionStateChangeCallback && this._onConnectionStateChangeCallback(t3, n);
  }
  _messageIdPrefix() {
    const t3 = this._session.productName || this._config.productName || ue;
    return At(t3);
  }
  _resolveHubOrigin() {
    try {
      return new URL(this._hub.hub_endpoint).origin;
    } catch {
      try {
        return new URL(this._hub.token_endpoint).origin;
      } catch {
        return "";
      }
    }
  }
  async _fetchHubAuthConfig() {
    const t3 = this._resolveHubOrigin();
    if (!t3)
      return { mode: "mock" };
    try {
      const n = await fetch(`${t3}/api/hub/auth/config`, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (!n.ok)
        return { mode: "mock" };
      const r = await n.json();
      return r && typeof r == "object" ? r : { mode: "mock" };
    } catch {
      return console.debug("HubClient: auth/config unavailable; assuming mock mode"), { mode: "mock" };
    }
  }
  _parseOidcHashTokens() {
    if (typeof window > "u" || !window.location)
      return null;
    const t3 = String(window.location.hash || "").replace(/^#/, "");
    if (!t3)
      return null;
    const n = new URLSearchParams(t3);
    if (n.get("hub_auth") !== "oidc")
      return null;
    const r = n.get("access_token") || "";
    return r ? {
      access_token: r,
      id_token: n.get("id_token") || "",
      topic: n.get("topic") || "",
      user_name: n.get("user_name") || "",
      expires_in: n.get("expires_in") || ""
    } : null;
  }
  _clearOidcHashFromUrl() {
    if (typeof window > "u" || !window.history || !window.location)
      return;
    const t3 = `${window.location.pathname}${window.location.search}`;
    window.history.replaceState(null, "", t3);
  }
  _applySessionTokens(t3) {
    this._hub.token = t3.access_token, t3.id_token && (this._hub.lastIdToken = t3.id_token), this._hub.oidcSession = true, t3.user_name && (this._session.userName = t3.user_name), t3.topic && !this._config.preserveSessionTopicFromToken && this.setTopic(t3.topic);
  }
  /** @deprecated Use _applySessionTokens */
  _applyOidcSessionTokens(t3) {
    this._applySessionTokens(t3);
  }
  _resolveLoginUrl(t3) {
    const n = typeof (t3 == null ? void 0 : t3.login_url) == "string" && t3.login_url.trim();
    if (n)
      return n.trim();
    const r = this._resolveHubOrigin();
    return r ? `${r}/oauth/login` : "";
  }
  _websocketClose() {
    console.debug("HubClient: websocket is closed."), this._hub.resubscribeRequested = true, this._emitConnectionState("disconnected");
  }
  _processTextMessage(t3) {
    try {
      const n = JSON.parse(t3);
      if (n["hub.mode"])
        return;
      const r = n.event;
      if (!r || r["hub.event"] === "heartbeat" || n.id === this._hub.lastPublishedMessageID)
        return;
      this._onMessageCallback && this._onMessageCallback(n);
    } catch (n) {
      console.warn("HubClient: websocket processing error:", n);
    }
  }
  async _checkWebsocket() {
    this._hub.resubscribeRequested && this._hub.subscribed && this._config.autoReconnect ? (console.debug("HubClient: Try to resubscribe"), this._hub.resubscribeRequested = false, await this.subscribe() !== 202 && (this._hub.resubscribeRequested = true)) : !this._hub.subscribed && this._hub.resubscribeRequested && (this._hub.resubscribeRequested = false);
  }
  getConfig() {
    return this._config;
  }
  getHubConfig() {
    const t3 = this._hub;
    return {
      name: t3.name,
      friendlyName: t3.friendlyName,
      version: t3.version,
      hub_endpoint: t3.hub_endpoint,
      authorization_endpoint: t3.authorization_endpoint,
      token_endpoint: t3.token_endpoint,
      client_id: t3.client_id,
      client_secret: t3.client_secret
    };
  }
  getSessionConfig() {
    const t3 = this._session;
    return {
      subscriberName: t3.subscriberName,
      productName: t3.productName,
      productVersion: t3.productVersion,
      actors: t3.actors,
      topic: t3.topic,
      events: t3.events,
      lease: t3.lease,
      userName: t3.userName,
      defaultTargetActor: t3.defaultTargetActor
    };
  }
  getConnectionState() {
    const t3 = this._hub;
    return {
      token: t3.token,
      subscribed: t3.subscribed,
      resubscribeRequested: t3.resubscribeRequested,
      websocket: t3.websocket,
      lastPublishedMessageID: t3.lastPublishedMessageID
    };
  }
  setTopic(t3) {
    console.debug("HubClient: setting topic to", t3), this._session.topic = t3;
  }
  setToken(t3) {
    this._hub.token = t3;
  }
  setSubscriberName(t3) {
    this._session.subscriberName = t3;
  }
  setUserName(t3) {
    this._session.userName = t3 || "";
  }
  async authenticate() {
    const t3 = this._parseOidcHashTokens();
    if (t3)
      return this._applySessionTokens(t3), this._clearOidcHashFromUrl(), console.debug("HubClient: Applied OIDC session tokens from redirect"), {
        user_name: t3.user_name || this._session.userName || "",
        code: "",
        expires_in: t3.expires_in && Number(t3.expires_in) || void 0,
        mode: "oidc",
        tokensReady: true
      };
    if (this._hub.oidcSession && this._hub.token)
      return {
        user_name: this._session.userName || "",
        code: "",
        mode: this._hub.authMode || "oidc",
        tokensReady: true
      };
    const n = await this._fetchHubAuthConfig();
    if (this._hub.authMode = n.mode || "mock", n.mode === "oidc") {
      if (typeof window > "u" || !window.location)
        throw new Error(
          "HubClient.authenticate: OIDC mode requires a browser environment"
        );
      const l = this._resolveLoginUrl(n), d = `${window.location.origin}${window.location.pathname}${window.location.search}`, b = `${l}?return_to=${encodeURIComponent(d)}`;
      return console.debug("HubClient: Redirecting to OIDC login", b), window.location.assign(b), {
        user_name: "",
        code: "",
        mode: "oidc",
        redirecting: true
      };
    }
    const r = this._resolveLoginUrl(n);
    if (!r)
      throw new Error(
        "HubClient.authenticate: no login_url or hub origin configured."
      );
    const i = this._session.productName || this._config.productName || "UNKNOWN", s2 = new URLSearchParams();
    this._hub.lastIdToken ? s2.set("id_token", this._hub.lastIdToken) : this._session.userName && s2.set("user_name", this._session.userName), s2.set("client_product_name", i), this._session.topic && s2.set("topic", this._session.topic);
    const o = `${r}?${s2.toString()}`;
    try {
      const l = new URL(r);
      console.debug("HubClient: Mock login at:", `${l.origin}${l.pathname}`);
    } catch {
      console.debug("HubClient: Mock login at hub");
    }
    let c;
    try {
      c = await fetch(o, {
        method: "GET",
        headers: { Accept: "application/json" }
      });
    } catch (l) {
      const d = l instanceof Error ? l.message : String(l);
      throw console.error("HubClient: Exception during authenticate:", d), l;
    }
    if (c.status !== 200) {
      const l = await c.text().catch(() => "");
      throw console.error("HubClient: Authenticate failed. Status:", c.status, l), new Error(`HubClient.authenticate failed (HTTP ${c.status})`);
    }
    const a = await c.json(), u = typeof a.access_token == "string" ? a.access_token : "";
    if (!u)
      throw new Error("HubClient.authenticate: mock login missing access_token");
    return this._applySessionTokens({
      access_token: u,
      id_token: typeof a.id_token == "string" ? a.id_token : "",
      topic: typeof a.topic == "string" ? a.topic : "",
      user_name: typeof a.user_name == "string" ? a.user_name : ""
    }), {
      user_name: this._session.userName || a.user_name || "",
      code: "",
      expires_in: typeof a.expires_in == "number" ? a.expires_in : void 0,
      mode: "mock",
      tokensReady: true
    };
  }
  async getToken(t3) {
    if (this._hub.oidcSession && this._hub.token)
      return this._config.autoStart && this.subscribe(), true;
    const n = this._parseOidcHashTokens();
    if (n)
      return this._applySessionTokens(n), this._clearOidcHashFromUrl(), this._config.autoStart && this.subscribe(), !!this._hub.token;
    if (typeof t3 != "string" || !t3)
      return console.error(
        "HubClient.getToken: code is required (call authenticate() first)."
      ), false;
    try {
      const i = new URL(this._hub.token_endpoint);
      console.debug("HubClient: Exchanging code at:", `${i.origin}${i.pathname}`);
    } catch {
      console.debug("HubClient: Exchanging code at hub");
    }
    const r = new URLSearchParams();
    r.append("grant_type", "authorization_code"), r.append("code", t3), r.append("client_id", this._hub.client_id || ""), r.append("client_secret", this._hub.client_secret || ""), r.append(
      "client_product_name",
      this._session.productName || this._config.productName || "UNKNOWN"
    );
    try {
      const i = await fetch(this._hub.token_endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: r
      });
      if (i.status === 200) {
        const s2 = await i.json();
        return typeof s2.access_token == "string" && s2.access_token && (this._hub.token = s2.access_token), typeof s2.id_token == "string" && s2.id_token && (this._hub.lastIdToken = s2.id_token), s2.topic && typeof s2.topic == "string" && (this._config.preserveSessionTopicFromToken || this.setTopic(s2.topic), this._config.autoStart && this.subscribe()), !!this._hub.token;
      }
      return await i.text(), console.error("HubClient: Error getting token. Status:", i.status), false;
    } catch (i) {
      const s2 = i instanceof Error ? i.message : String(i);
      return console.error("HubClient: Exception getting token:", s2), false;
    }
  }
  async connect() {
    const t3 = await this.authenticate();
    if (t3 != null && t3.redirecting)
      return t3;
    if (!(t3 != null && t3.tokensReady)) {
      const n = this._config.autoStart;
      this._config.autoStart = false;
      let r = false;
      try {
        r = await this.getToken((t3 == null ? void 0 : t3.code) || "");
      } finally {
        this._config.autoStart = n;
      }
      if (!r)
        return false;
    }
    return this.subscribe();
  }
  async subscribe(t3 = false) {
    const n = this._session.topic && this._session.topic.trim();
    if (!n)
      return console.warn("HubClient: Error. subscription not sent. No topic defined."), "error: topic not defined";
    if ((!this._session.subscriberName || !String(this._session.subscriberName).trim()) && (this._session.subscriberName = Pe(
      this._session.productName || this._config.productName || "UNKNOWN"
    )), !this._hub.token)
      return console.warn("HubClient: Error. subscription not sent. No token available."), "error: no token";
    const r = He(this._config.callbackUrl), i = $e(
      "subscribe",
      { ...this._session, topic: n, subscriberName: this._session.subscriberName },
      r,
      this._config.productVersion
    );
    try {
      this._emitConnectionState("connecting");
      const s2 = await fetch(this._hub.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Bearer ${this._hub.token}`
        },
        body: i,
        signal: typeof AbortSignal < "u" && AbortSignal.timeout ? AbortSignal.timeout(je) : void 0
      });
      if (s2.status === 202) {
        this._hub.resubscribeRequested = false;
        let o;
        try {
          o = await s2.json();
        } catch (l) {
          return this._hub.subscribed = false, console.error(
            "HubClient: Subscribe 202 body was not valid JSON:",
            l instanceof Error ? l.message : String(l)
          ), this._emitConnectionState("error"), 0;
        }
        const c = o["hub.channel.endpoint"];
        if (!c || typeof c != "string")
          return this._hub.subscribed = false, console.error("HubClient: Subscribe 202 missing hub.channel.endpoint"), this._emitConnectionState("error"), 0;
        let a = c;
        try {
          const l = new URL(this._hub.hub_endpoint), d = new URL(c);
          a = c.replace(
            d.origin,
            `${l.protocol === "https:" ? "wss:" : "ws:"}//${l.host}`
          );
        } catch {
        }
        if (this._hub.websocket) {
          try {
            this._hub.websocket.removeEventListener("close", this._websocketClose), this._hub.websocket.close();
          } catch {
          }
          this._hub.websocket = null;
        }
        let u;
        try {
          u = new WebSocket(a);
        } catch (l) {
          return this._hub.subscribed = false, console.error(
            "HubClient: Failed to open WebSocket after subscribe:",
            l instanceof Error ? l.message : String(l)
          ), this._emitConnectionState("error"), 0;
        }
        return this._hub.subscribed = true, this._hub.websocket = u, u.onopen = () => {
          u.send(JSON.stringify({ "hub.channel.endpoint": a })), this._emitConnectionState("connected");
        }, u.addEventListener("message", (l) => {
          typeof l.data == "string" && this._processTextMessage(l.data);
        }), u.addEventListener("close", this._websocketClose), u.onerror = () => {
          console.warn("HubClient: Error reported on websocket"), this._emitConnectionState("error");
        }, s2.status;
      }
      if (s2.status === 401) {
        if (console.warn("HubClient: Subscription response 401 - Token refresh needed."), t3)
          return s2.status;
        try {
          const o = await this.authenticate();
          if (o != null && o.tokensReady ? true : !!(o != null && o.code && await this.getToken(o.code)))
            return await this.subscribe(true);
        } catch (o) {
          console.error(
            "HubClient: Token refresh after 401 failed:",
            o instanceof Error ? o.message : String(o)
          );
        }
      } else
        console.error(
          "HubClient: Subscription rejected by hub. Status:",
          s2.status
        );
      return s2.status;
    } catch (s2) {
      return this._hub.subscribed = false, console.error(
        "HubClient: Exception subscribing to the hub:",
        s2 instanceof Error ? s2.message : String(s2)
      ), 0;
    }
  }
  async unsubscribe() {
    this._hub.subscribed = false, this._hub.resubscribeRequested = false;
    const t3 = $e(
      "unsubscribe",
      this._session,
      He(this._config.callbackUrl),
      this._config.productVersion
    );
    try {
      (await fetch(this._hub.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Bearer ${this._hub.token}`
        },
        body: t3,
        signal: typeof AbortSignal < "u" && AbortSignal.timeout ? AbortSignal.timeout(je) : void 0
      })).status === 202 && console.debug("HubClient: Unsubscribe successfully from hub", this._hub.name);
    } catch (n) {
      console.warn(
        "HubClient: Error unsubscribing from the hub.",
        n instanceof Error ? n.message : String(n)
      );
    }
    this._closeWebsocket(), this._emitConnectionState("disconnected");
  }
  _closeWebsocket() {
    this._hub.websocket && (this._hub.websocket.close(), this._hub.websocket = null);
  }
  async close({ hubUnsubscribe: t3 = true } = {}) {
    this._reconnectInterval && (clearInterval(this._reconnectInterval), this._reconnectInterval = null), t3 ? await this.unsubscribe() : (this._hub.subscribed = false, this._hub.resubscribeRequested = false, this._closeWebsocket(), this._emitConnectionState("disconnected"));
  }
  delete() {
    return this.close();
  }
  async rebindUserName(t3) {
    const n = String(t3 || "").trim();
    if (!n)
      throw new Error("HubClient.rebindUserName: user name is required");
    const r = String(this._session.userName || "").trim(), i = String(this._session.topic || "").trim();
    if (n === r && (i === n || i === r) && this._hub.subscribed)
      return { user_name: r, topic: i, status: 202 };
    await this.unsubscribe(), this._hub.lastIdToken = "", this.setUserName(n), this.setTopic("");
    const s2 = await this.authenticate(), { code: o, user_name: c, tokensReady: a, redirecting: u } = s2 || {};
    if (u)
      throw new Error(
        "HubClient.rebindUserName: OIDC redirect in progress; complete login in the browser"
      );
    if (!a && !o)
      throw new Error("HubClient.rebindUserName: authenticate failed");
    const l = this._config.autoStart;
    this._config.autoStart = false;
    let d = false;
    try {
      d = await this.getToken(o || "");
    } finally {
      this._config.autoStart = l;
    }
    if (!d)
      throw new Error("HubClient.rebindUserName: token exchange failed");
    const b = await this.subscribe();
    return {
      user_name: String(c || this._session.userName || n).trim() || n,
      topic: String(this._session.topic || "").trim(),
      status: b
    };
  }
  _preparePublishMessage(t3, n = this._hub) {
    const r = { ...t3, timestamp: (/* @__PURE__ */ new Date()).toJSON() };
    r.id = F(this._messageIdPrefix()), n.lastPublishedMessageID = r.id;
    const i = this._session.subscriberName && this._session.subscriberName.trim(), s2 = this._session.productName && this._session.productName.trim();
    if (i && r["subscriber.name"] === void 0 && (r["subscriber.name"] = i), s2 && r["subscriber.product.name"] === void 0 && (r["subscriber.product.name"] = s2), r.event && !r.event["hub.topic"] && (r.event["hub.topic"] = this._session.topic), r["target.actor"] === void 0 && this._session.defaultTargetActor && !String(r["target.subscriber.name"] || "").trim()) {
      const c = re(
        this._session.defaultTargetActor
      );
      c && (r["target.actor"] = c);
    }
    return r;
  }
  fetchPayload(t3) {
    return this._payloadFetchApi.fetchPayload(t3);
  }
  fetchAllPayloads(t3) {
    return this._payloadFetchApi.fetchAllPayloads(t3);
  }
  hasPendingPayload(t3) {
    return this._payloadFetchApi.hasPendingPayload(t3);
  }
  async publishMultipart(t3, n, r = this._hub) {
    let i = this._preparePublishMessage(t3, r);
    const s2 = await Y(n);
    i = ne(i);
    let o = await Me(i);
    if (!o.length) {
      const a = (i.event && typeof i.event["hub.event"] == "string" ? i.event["hub.event"] : "") === "dicom-send" ? "dicom-send.dcm" : "nifti-send.nii.gz";
      i.event.context = {
        files: [
          {
            data: s2,
            fileName: et(i, a),
            mimeType: "application/octet-stream",
            byteLength: s2.byteLength
          }
        ]
      }, o = [s2];
    }
    return this.publishBinaryBatch(i, o, r);
  }
  async publishBinaryBatch(t3, n, r = this._hub) {
    const i = ne(
      this._preparePublishMessage(t3, r)
    );
    return Ot({
      msg: i,
      fileBytesList: n,
      hub: r,
      messageIdPrefix: () => this._messageIdPrefix()
    });
  }
  async publish(t3, n = this._hub) {
    let r = this._preparePublishMessage(t3, n);
    if (r = ne(r), Lt(r)) {
      const i = await Me(r);
      if (i.length)
        return this.publishBinaryBatch(r, i, n);
    }
    try {
      return await fetch(n.hub_endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${n.token}`
        },
        body: JSON.stringify(r)
      });
    } catch (i) {
      return console.debug("HubClient:", i instanceof Error ? i.message : String(i)), null;
    }
  }
  publishNiftiMultipart(t3, n, r) {
    return this.publishBinaryBatch(t3, [n], r);
  }
  async request(t3 = {}) {
    const n = String(t3["subscriber.name"] || "").trim();
    if (!n)
      throw new Error('HubClient.request: "subscriber.name" is required.');
    const r = this._hub.token && this._hub.token.trim();
    if (!r)
      throw new Error(
        "HubClient.request: token is required (call authenticate() then getToken(code) first)."
      );
    const i = {
      "subscriber.name": n,
      id: t3.id && String(t3.id).trim() || F(this._messageIdPrefix()),
      timestamp: t3.timestamp && String(t3.timestamp).trim() || (/* @__PURE__ */ new Date()).toJSON()
    };
    if (t3.event && typeof t3.event == "object") {
      i.event = { ...t3.event };
      const d = this._session.topic && String(this._session.topic).trim();
      d && !i.event["hub.topic"] && (i.event["hub.topic"] = d);
    } else
      throw new Error('HubClient.request: "event" with hub.event is required.');
    if (!i.event["hub.event"] || !String(i.event["hub.event"]).trim())
      throw new Error(
        'HubClient.request: event["hub.event"] must be a *-request event name.'
      );
    t3["subscriber.actor"] && String(t3["subscriber.actor"]).trim() && (i["subscriber.actor"] = String(t3["subscriber.actor"]).trim());
    const s2 = Object.prototype.hasOwnProperty.call(t3, "target.actor");
    let o = s2 ? re(t3["target.actor"]) : void 0;
    o === void 0 && !s2 && this._session.defaultTargetActor && (o = re(this._session.defaultTargetActor)), o !== void 0 && (i["target.actor"] = o);
    const c = t3["target.product.name"] !== void 0 ? t3["target.product.name"] : t3.targetProductName, a = Mt(c);
    a !== void 0 && (i["target.product.name"] = a);
    const u = await fetch(
      (this._hub.hub_endpoint || "").replace(/\/+$/, ""),
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${r}`
        },
        body: JSON.stringify(i)
      }
    );
    let l;
    if ((u.headers.get("content-type") || "").includes("application/json"))
      try {
        l = await u.json();
      } catch {
        l = "";
      }
    else
      l = await u.text();
    return { ok: u.ok, status: u.status, data: l };
  }
  sendHubRequestResponse(t3, n, r, i) {
    if (!this._hub.websocket || typeof WebSocket > "u" || this._hub.websocket.readyState !== WebSocket.OPEN)
      return;
    const s2 = typeof n == "string" ? n.trim() : n == null ? "" : String(n).trim();
    if (!s2) {
      console.error(
        "HubClient.sendHubRequestResponse requires a non-empty dataType."
      );
      return;
    }
    const o = {
      timestamp: (/* @__PURE__ */ new Date()).toJSON(),
      id: F(this._messageIdPrefix()),
      "subscriber.name": this._session.subscriberName || void 0,
      "subscriber.product.name": this._session.productName || void 0,
      event: {
        "hub.topic": i || this._session.topic,
        "hub.event": zt(s2),
        context: { id: t3, dataType: s2, data: r }
      }
    };
    Array.isArray(this._session.actors) && this._session.actors.length && (o.actor = this._session.actors[0]), this._hub.websocket.send(JSON.stringify(o));
  }
  sendCastRequestResponse(t3, n, r, i) {
    return this.sendHubRequestResponse(t3, n, r, i);
  }
};
function de(e) {
  const t3 = {
    responses: [],
    expected: [],
    missing: [],
    timedOut: false,
    ok: false,
    id: null,
    actor: null,
    productName: null
  };
  if (!e || typeof e != "object")
    return t3;
  const n = (
    /** @type {Record<string, unknown>} */
    e
  ), r = Array.isArray(n.responses) ? n.responses.filter((o) => o && typeof o == "object") : [], i = Array.isArray(n.expected) ? n.expected.map((o) => String(o)) : [], s2 = Array.isArray(n.missing) ? n.missing.map((o) => String(o)) : [];
  return {
    responses: r,
    expected: i,
    missing: s2,
    timedOut: !!n.timedOut,
    ok: !!n.ok,
    id: n.id != null ? String(n.id) : null,
    actor: n.actor != null ? String(n.actor) : null,
    productName: n.productName != null ? String(n.productName) : null
  };
}
function he(e) {
  const t3 = String(e ?? "").trim();
  if (!t3)
    return null;
  try {
    const n = new URL(t3);
    return n.protocol === "ws:" ? n.protocol = "http:" : n.protocol === "wss:" && (n.protocol = "https:"), n;
  } catch {
    return null;
  }
}
var os = "hubViewer-reporting";
var cs = "hubViewer-classroom";
var as = "hubViewer-worklist";
function us(e = null) {
  const t3 = typeof globalThis < "u" ? globalThis.screen : null, n = typeof globalThis < "u" && globalThis.window ? globalThis.window : null, r = Number(t3 == null ? void 0 : t3.availLeft) || 0, i = Number(t3 == null ? void 0 : t3.availTop) || 0, s2 = (t3 == null ? void 0 : t3.availWidth) || (t3 == null ? void 0 : t3.width) || 1200, o = (t3 == null ? void 0 : t3.availHeight) || (t3 == null ? void 0 : t3.height) || 800, c = (e == null ? void 0 : e.left) ?? (n == null ? void 0 : n.screenX) ?? (n == null ? void 0 : n.screenLeft) ?? 0, a = (e == null ? void 0 : e.top) ?? (n == null ? void 0 : n.screenY) ?? (n == null ? void 0 : n.screenTop) ?? 0, u = Math.max(
    1,
    Number(
      (e == null ? void 0 : e.width) ?? (n == null ? void 0 : n.outerWidth) ?? Math.floor(s2 * 0.5)
    ) || Math.floor(s2 * 0.5)
  ), l = Math.min(756, Math.max(600, Math.floor(s2 * 0.444))), d = Math.min(784, Math.max(624, Math.floor(o * 0.688))), b = Math.max(0, Math.floor(u * 0.1));
  let f2 = c + u - b, h = a;
  return f2 + l > r + s2 && (f2 = Math.max(r, r + s2 - l)), h + d > i + o && (h = Math.max(i, i + o - d)), f2 = Math.max(r, Math.min(f2, r + s2 - l)), h = Math.max(i, Math.min(h, i + o - d)), {
    width: l,
    height: d,
    left: Math.floor(f2),
    top: Math.floor(h)
  };
}
function fs(e, t3) {
  if (!(!e || !t3))
    try {
      e.resizeTo(t3.width, t3.height), e.moveTo(t3.left, t3.top), e.focus();
    } catch {
    }
}
var ms = [
  "Anatomy class",
  "Tumor Board",
  "Case discussion",
  "Pedicle screw"
];
function H(e, t3) {
  const n = he(e);
  return n ? new URL(t3, n.origin).href : null;
}
function v(e, t3 = false) {
  const n = {};
  t3 && (n["Content-Type"] = "application/json");
  const r = String(e ?? "").trim();
  if (!r)
    throw new Error(
      "Hub conference APIs require a Bearer access token (authenticate first)"
    );
  return n.Authorization = `Bearer ${r}`, n;
}
function it(e) {
  if (!Array.isArray(e))
    return [];
  const t3 = /* @__PURE__ */ new Set();
  return e.map((n) => String(n ?? "").trim()).filter((n) => !n || t3.has(n) ? false : (t3.add(n), true));
}
function Z(e) {
  return String((e == null ? void 0 : e.hostTopic) ?? (e == null ? void 0 : e.user) ?? "").trim();
}
function st(e) {
  const t3 = Z(e);
  return String((e == null ? void 0 : e.sceneLeaderTopic) ?? "").trim() || t3;
}
function Jt(e, t3) {
  const n = Z(t3), r = String(e ?? "").trim();
  return !r || !n ? false : r === n || r.toLowerCase() === n.toLowerCase();
}
function Zt(e, t3) {
  const n = st(t3), r = String(e ?? "").trim();
  return !r || !n ? false : r === n || r.toLowerCase() === n.toLowerCase();
}
function ot(e, t3, n) {
  const r = String(e ?? "").trim(), i = String(t3 ?? "").trim(), s2 = Z(n), o = Array.isArray(n == null ? void 0 : n.topics) ? n.topics.map((c) => String(c).trim()).filter(Boolean) : [];
  return !!(r && (r === s2 || o.includes(r)) || i && i === s2);
}
function ct(e, t3, n) {
  return n.find(
    (r) => ot(e, t3, r)
  ) || null;
}
async function gs(e, t3) {
  const n = H(e, "/api/hub/conference-topics");
  if (!n)
    return [];
  try {
    const r = await fetch(n, {
      headers: v(t3)
    });
    if (!r.ok)
      return [];
    const i = await r.json();
    if (!Array.isArray(i))
      return [];
    const s2 = [];
    for (const o of i) {
      if (o && typeof o == "object") {
        const a = String(o.topic ?? "").trim();
        if (!a || a === "*") continue;
        s2.push({
          topic: a,
          timezone: String(o.timezone ?? "").trim()
        });
        continue;
      }
      const c = String(o ?? "").trim();
      !c || c === "*" || s2.push({ topic: c, timezone: "" });
    }
    return s2;
  } catch {
    return [];
  }
}
async function at(e, t3) {
  const n = he(e);
  if (!n)
    return [];
  const r = new URL("/api/hub/conference", n.origin).href;
  try {
    const i = await fetch(r, {
      headers: v(t3)
    });
    if (!i.ok)
      return [];
    const s2 = await i.json();
    return Array.isArray(s2) ? s2 : [];
  } catch {
    return [];
  }
}
async function ys(e, t3, n, r, i, s2) {
  const o = H(e, "/api/hub/conference");
  if (!o)
    throw new Error("Invalid hub endpoint");
  const c = {
    hostTopic: String(t3).trim(),
    title: String(n).trim(),
    topics: r
  }, a = String(i ?? "").trim();
  a && (c.hostUserName = a);
  const u = await fetch(o, {
    method: "POST",
    headers: v(s2, true),
    body: JSON.stringify(c)
  });
  if (!u.ok) {
    const l = await u.text();
    throw new Error(l || `HTTP ${u.status}`);
  }
}
async function ps(e, t3, n, r, i) {
  const s2 = H(e, "/api/hub/conference/join");
  if (!s2)
    throw new Error("Invalid hub endpoint");
  const o = {
    hostTopic: String(t3).trim(),
    joinTopic: String(n).trim()
  }, c = String(r ?? "").trim();
  c && (o.joinUserName = c);
  const a = await fetch(s2, {
    method: "PATCH",
    headers: v(i, true),
    body: JSON.stringify(o)
  });
  if (!a.ok) {
    const u = await a.text();
    throw new Error(u || `HTTP ${a.status}`);
  }
}
async function Ss(e, t3, n, r) {
  const i = H(e, "/api/hub/conference");
  if (!i)
    throw new Error("Invalid hub endpoint");
  const s2 = { hostTopic: String(t3).trim() }, o = n == null ? void 0 : n.trim();
  o && (s2.leaveTopic = o);
  const c = await fetch(i, {
    method: "DELETE",
    headers: v(r, true),
    body: JSON.stringify(s2)
  });
  if (!c.ok) {
    const a = await c.text();
    throw new Error(a || `HTTP ${c.status}`);
  }
}
async function _s(e, t3, n, r, i) {
  const s2 = H(e, "/api/hub/conference/lead");
  if (!s2)
    throw new Error("Invalid hub endpoint");
  const o = {
    hostTopic: String(t3).trim(),
    sceneLeaderTopic: String(n).trim()
  }, c = String(r ?? "").trim();
  c && (o.leaderUserName = c);
  const a = await fetch(s2, {
    method: "PATCH",
    headers: v(i, true),
    body: JSON.stringify(o)
  });
  if (!a.ok) {
    const u = await a.text();
    throw new Error(u || `HTTP ${a.status}`);
  }
  try {
    return await a.json();
  } catch {
    return { status: "updated" };
  }
}
function Kt(e, t3) {
  if (!t3)
    return null;
  const n = String((e == null ? void 0 : e.topic) ?? "").trim(), r = String((e == null ? void 0 : e.subscriberName) ?? "").trim(), i = String((e == null ? void 0 : e.userName) ?? "").trim(), s2 = Z(t3);
  if (!s2 || !ot(n, r, t3))
    return null;
  const o = Array.isArray(t3.topics) ? t3.topics.map((h) => String(h).trim()).filter(Boolean) : [], c = it(t3.participants), a = [], u = /* @__PURE__ */ new Set();
  for (const h of [n, s2, ...o])
    !h || u.has(h) || (u.add(h), a.push(h));
  const l = st(t3), d = Jt(n, t3), b = Zt(n, t3) ? "leading" : "following", f2 = a.map((h) => {
    const g = !!n && (h === n || h.toLowerCase() === n.toLowerCase()), m = h === l || h.toLowerCase() === l.toLowerCase(), y = m && b === "following";
    let T2 = "";
    return g ? T2 = b === "leading" ? "(You) \xB7 leading" : "(You)" : y ? T2 = "Following" : b === "leading" && (T2 = "Following you"), {
      placeId: h,
      label: g && i ? i : h,
      isSelf: g,
      isLeading: m,
      isFollowing: y,
      statusLabel: T2
    };
  });
  return {
    title: String(t3.title ?? "").trim(),
    places: f2,
    selfPlaceId: n,
    leadingPlaceId: l,
    selfRole: b,
    isConferenceOwner: d,
    hostTopic: s2,
    sceneLeaderTopic: l,
    attendeeTopics: o,
    participants: c
  };
}
async function ws(e, t3, n, r, i) {
  const s2 = await at(e, i), o = ct(t3, n, s2);
  return Kt({ topic: t3, subscriberName: n, userName: r }, o);
}
function ut(e, t3) {
  if (t3 === "file:")
    return true;
  const n = String(e || "").toLowerCase();
  return !!(n === "localhost" || n === "127.0.0.1" || n === "[::1]" || /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(n) || /^192\.168\.\d{1,3}\.\d{1,3}$/.test(n) || /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(n));
}
function Qt(e = typeof window < "u" ? window.location : null) {
  return e ? !ut(e.hostname, e.protocol) : false;
}
function en(e) {
  try {
    const t3 = new URL(e);
    return !ut(t3.hostname, t3.protocol);
  } catch {
    return false;
  }
}
function Is(e, t3, n = Qt()) {
  const r = t3.find((s2) => {
    var c;
    const o = (c = e[s2]) == null ? void 0 : c.hubEndpoint;
    return o && en(o) === n;
  });
  if (r)
    return r;
  const i = n ? "cloud" : "local";
  return e[i] ? i : t3[0];
}
function Es() {
  return typeof document > "u" ? Promise.resolve() : tn().then(nn);
}
function tn() {
  return document.prerendering ? new Promise((e) => {
    const t3 = () => {
      document.prerendering || (document.removeEventListener("prerenderingchange", t3), e());
    };
    document.addEventListener("prerenderingchange", t3);
  }) : Promise.resolve();
}
function nn() {
  return document.visibilityState === "visible" ? Promise.resolve() : new Promise((e) => {
    const t3 = () => {
      document.visibilityState === "visible" && (document.removeEventListener("visibilitychange", t3), e());
    };
    document.addEventListener("visibilitychange", t3);
  });
}
function rn(e) {
  return String(e || "").trim().toUpperCase();
}
var sn = Object.freeze({
  ira: (e) => e === "SLICERLIVE-IRA" || e.startsWith("SLICERLIVE-IRA"),
  ohif: (e) => e === "OHIF" || e.startsWith("OHIF"),
  volview: (e) => e === "VOLVIEW" || e.startsWith("VOLVIEW"),
  slicer: (e) => e === "3DSLICER-ID" || e === "SLICER-HUB" || e.startsWith("3DSLICER") || e.startsWith("SLICER-HUB"),
  /** slicer-mirror Four-Up LiveScene stream client (not desktop Image Display). */
  slicerMirror: (e) => e === "SLICER-MIRROR" || e.startsWith("SLICER-MIRROR"),
  mhub: (e) => e === "MHUB" || e.startsWith("MHUB") || e === "MHUB_AI" || e.startsWith("MHUB_AI") || e === "MHUBAI" || e.startsWith("MHUBAI"),
  eucaim: (e) => e === "EUCAIM" || e.startsWith("EUCAIM") || e === "NNUNET_EUCAIM" || e.startsWith("NNUNET_EUCAIM") || e === "NNUNET-EUCAIM" || e.startsWith("NNUNET-EUCAIM"),
  vox2seglam: (e) => e === "VOX2SEGLAM" || e.startsWith("VOX2SEGLAM") || e === "VOX2_SEG_LAM" || e.startsWith("VOX2_SEG_LAM") || e === "VOX2-SEG-LAM" || e.startsWith("VOX2-SEG-LAM"),
  lung: (e) => e === "LUNGSCREENING" || e.startsWith("LUNGSCREENING"),
  totalseg: (e) => e === "TOTALSEG" || e.startsWith("TOTALSEG") || e === "TOTAL_SEGMENTATOR" || e.startsWith("TOTAL_SEGMENTATOR") || e === "TOTAL-SEGMENTATOR" || e.startsWith("TOTAL-SEGMENTATOR"),
  neuro: (e) => e === "NEURO_SEG" || e.startsWith("NEURO_SEG") || e === "NEUROSEG" || e.startsWith("NEUROSEG"),
  dental: (e) => e === "DENTAL_SEG" || e.startsWith("DENTAL_SEG") || e === "DENTALSEG" || e.startsWith("DENTALSEG") || e === "DENTALSEGMENTATOR" || e.startsWith("DENTALSEGMENTATOR"),
  txrv: (e) => e === "TORCHXRAYVISION" || e.startsWith("TORCHXRAYVISION") || e === "TXRV" || e.startsWith("TXRV") || e === "TORCH_XRAY_VISION" || e.startsWith("TORCH_XRAY_VISION") || e === "TORCH-XRAY-VISION" || e.startsWith("TORCH-XRAY-VISION"),
  flexray: (e) => e === "FLEXRAY" || e.startsWith("FLEXRAY") || e === "FLEX_RAY" || e.startsWith("FLEX_RAY"),
  reporting: (e) => e === "RPT" || e.startsWith("RPT-") || e === "CAST-RPT" || e.startsWith("CAST-RPT"),
  classroom: (e) => e === "CLASSROOM" || e.startsWith("CLASSROOM-") || e === "CAST-CLASSROOM" || e.startsWith("CAST-CLASSROOM")
});
function As(e, t3) {
  const n = sn[t3];
  return n ? n(rn(e)) : false;
}
var K = "http://fhircast.hl7.org/StructureDefinition/fhircast-imaging-study-open";
var Q = "urn:dicom:uid";
var lt = "urn:cast:nifti-url";
var ft = "urn:cast:nifti-filename";
var be = "urn:cast:volview-sample-id";
var $ = "urn:cast:worklist-sample-id";
var me = "urn:cast:ohif-mode";
var x = "urn:cast:open-mode";
var W = "dicomweb";
var ge = "dicom-url";
var O = "files";
var ye = "idc";
var pe = "local-dicom";
var Se = "idc";
var _e = "idc-source-bucket";
var dt = "urn:cast:dicomweb-root";
function _(e) {
  return typeof e != "string" ? "" : e.trim().replace(/^urn:oid:/i, "");
}
function We(e) {
  return typeof e == "string" ? e.trim().toLowerCase() : "";
}
function D(e, t3) {
  if (!Array.isArray(e))
    return null;
  const n = String(t3 || "").trim().toLowerCase(), r = e.find(
    (i) => i && typeof i == "object" && typeof i.key == "string" && i.key.trim().toLowerCase() === n
  );
  return !(r != null && r.resource) || typeof r.resource != "object" ? null : r.resource;
}
function C(e, t3) {
  const n = D(e, "study");
  if (!n)
    return "";
  const r = Array.isArray(n.identifier) ? n.identifier : [], i = We(t3), s2 = r.find(
    (o) => We(o == null ? void 0 : o.system) === i
  );
  return typeof (s2 == null ? void 0 : s2.value) == "string" ? s2.value.trim() : "";
}
function E(e) {
  const t3 = D(e, "study");
  return t3 ? _(t3.uid) || _(C(e, Q)) : "";
}
function I(e) {
  const t3 = D(e, "series");
  if (t3)
    return _(t3.uid);
  const n = D(e, "study"), i = (Array.isArray(n == null ? void 0 : n.series) ? n.series : [])[0];
  return !i || typeof i != "object" ? "" : _(i.uid);
}
function G(e) {
  return C(e, be) || C(e, $);
}
function on(e) {
  return typeof e.url == "string" ? e.url.trim() : typeof e.uri == "string" ? e.uri.trim() : "";
}
function cn(e) {
  return typeof e.fileName == "string" ? e.fileName.trim() : typeof e.filename == "string" ? e.filename.trim() : "";
}
var an = /* @__PURE__ */ new Set(["http:", "https:", "s3:", "gs:"]);
function ee(e) {
  if (!e || typeof e != "object")
    return null;
  const t3 = on(e);
  if (!t3)
    return null;
  try {
    const o = new URL(t3);
    if (!an.has(o.protocol))
      return null;
  } catch {
    return null;
  }
  const n = cn(e), r = typeof e.mimeType == "string" ? e.mimeType.trim() : "", i = typeof e.role == "string" ? e.role.trim() : "", s2 = typeof e.label == "string" ? e.label.trim() : "";
  return {
    url: t3,
    fileName: n,
    mimeType: r,
    role: i,
    label: s2
  };
}
function mt({
  id: e,
  files: t3,
  patientReference: n,
  openMode: r,
  includeLegacyNiftiIdentifiers: i = false
}) {
  const s2 = String(e || "").trim() || "study", o = (Array.isArray(t3) ? t3 : []).map((l) => ee(l)).filter((l) => l !== null), c = [
    { system: x, value: r },
    {
      system: $,
      value: s2
    },
    {
      system: be,
      value: s2
    }
  ];
  if (i && o.length === 1) {
    const [l] = o;
    c.push({
      system: lt,
      value: l.url
    }), l.fileName && c.push({
      system: ft,
      value: l.fileName
    });
  }
  const a = {
    resourceType: "ImagingStudy",
    id: s2,
    meta: {
      profile: [K]
    },
    identifier: c,
    status: "available"
  };
  n && (a.subject = { reference: String(n).trim() });
  const u = [
    {
      key: "study",
      resource: a
    }
  ];
  return o.length > 0 && u.push({
    key: "files",
    resource: {
      files: o.map((l) => ({
        url: l.url,
        fileName: l.fileName || void 0,
        mimeType: l.mimeType || void 0,
        role: l.role || void 0,
        label: l.label || void 0
      }))
    }
  }), u;
}
function ln({
  id: e,
  files: t3,
  patientReference: n,
  includeLegacyNiftiIdentifiers: r = true
}) {
  return mt({
    id: e,
    files: t3,
    patientReference: n,
    openMode: O,
    includeLegacyNiftiIdentifiers: r
  });
}
function Ns({
  id: e,
  files: t3,
  patientReference: n
}) {
  return mt({
    id: e,
    files: t3,
    patientReference: n,
    openMode: ge,
    includeLegacyNiftiIdentifiers: false
  });
}
function Ts({
  id: e,
  studyInstanceUID: t3,
  seriesInstanceUID: n,
  dicomwebRoot: r,
  patientReference: i,
  ohifMode: s2,
  files: o,
  sourceBucket: c
}) {
  const a = String(e || "").trim() || "study", u = _(t3), l = _(n), d = String(r || "").trim().replace(/\/$/, ""), b = [
    { system: x, value: W },
    { system: Q, value: u },
    {
      system: $,
      value: a
    }
  ];
  d && b.push({ system: dt, value: d });
  const f2 = String(s2 || "").trim();
  f2 && b.push({
    system: me,
    value: f2
  });
  const h = (Array.isArray(o) ? o : []).map((y) => ee(y)).filter((y) => y !== null);
  if (h.length > 0) {
    const y = String(c || "aws").trim().toLowerCase() === "gcs" ? "gcs" : "aws";
    b.push({
      system: _e,
      value: y
    }), l && b.push({ system: Se, value: l });
  }
  const g = {
    resourceType: "ImagingStudy",
    id: a,
    uid: u,
    meta: {
      profile: [K]
    },
    identifier: b,
    status: "available"
  };
  i && (g.subject = { reference: String(i).trim() });
  const m = [
    {
      key: "study",
      resource: g
    }
  ];
  return l && m.push({
    key: "series",
    resource: {
      resourceType: "ImagingStudy",
      uid: l
    }
  }), h.length > 0 && m.push({
    key: "files",
    resource: {
      files: h.map((y) => ({
        url: y.url,
        fileName: y.fileName || void 0,
        mimeType: y.mimeType || void 0,
        role: y.role || void 0,
        label: y.label || void 0
      }))
    }
  }), m;
}
function Us({
  id: e,
  studyInstanceUID: t3,
  seriesInstanceUID: n,
  patientReference: r
}) {
  const i = String(e || "").trim() || "study", s2 = _(t3), o = _(n), a = {
    resourceType: "ImagingStudy",
    id: i,
    uid: s2,
    meta: {
      profile: [K]
    },
    identifier: [
      { system: x, value: pe },
      { system: Q, value: s2 },
      {
        system: $,
        value: i
      }
    ],
    status: "available"
  };
  r && (a.subject = { reference: String(r).trim() });
  const u = [
    {
      key: "study",
      resource: a
    }
  ];
  return o && u.push({
    key: "series",
    resource: {
      resourceType: "ImagingStudy",
      uid: o
    }
  }), u;
}
function Ls({
  id: e,
  studyInstanceUID: t3,
  seriesInstanceUID: n,
  sourceBucket: r,
  files: i,
  patientReference: s2,
  ohifMode: o
}) {
  const c = String(e || "").trim() || "study", a = _(t3), u = _(n), l = String(r || "aws").trim().toLowerCase() === "gcs" ? "gcs" : "aws", d = (Array.isArray(i) ? i : []).map((m) => ee(m)).filter((m) => m !== null), b = [
    { system: x, value: ye },
    { system: Q, value: a },
    {
      system: $,
      value: c
    },
    {
      system: be,
      value: c
    },
    { system: _e, value: l }
  ];
  u && b.push({ system: Se, value: u });
  const f2 = String(o || "").trim();
  f2 && b.push({
    system: me,
    value: f2
  });
  const h = {
    resourceType: "ImagingStudy",
    id: c,
    uid: a,
    meta: {
      profile: [K]
    },
    identifier: b,
    status: "available"
  };
  s2 && (h.subject = { reference: String(s2).trim() });
  const g = [
    {
      key: "study",
      resource: h
    }
  ];
  return u && g.push({
    key: "series",
    resource: {
      resourceType: "ImagingStudy",
      uid: u
    }
  }), d.length > 0 && g.push({
    key: "files",
    resource: {
      files: d.map((m) => ({
        url: m.url,
        fileName: m.fileName || void 0,
        mimeType: m.mimeType || void 0,
        role: m.role || void 0,
        label: m.label || void 0
      }))
    }
  }), g;
}
var vs = "Study already open - skipped reload";
function Rs(e, t3) {
  if (!(e != null && e.length) || !(t3 != null && t3.length)) return false;
  const n = G(e), r = G(t3);
  if (n && r && n === r) return true;
  const i = E(e), s2 = E(t3);
  if (!i || !s2 || i !== s2) return false;
  const o = I(e) || "", c = I(t3) || "";
  return !o || !c ? true : o === c;
}
var fn = "https://js2.jetstream-cloud.org:8001/swift/v1/idc-index/";
var dn = "https://cdn.jsdelivr.net/npm/hyparquet@1.28.2/+esm";
var hn = [
  "StudyInstanceUID",
  "SeriesInstanceUID",
  "crdc_series_uuid",
  "aws_bucket",
  "Modality",
  "instanceCount",
  "SeriesDescription",
  "PatientID",
  "collection_id",
  "license_short_name",
  "source_DOI"
];
var bn = /* @__PURE__ */ new Set(["CT", "MR", "PT", "PET", "NM"]);
var R = null;
function mn(e) {
  const t3 = String(e || fn).replace(/\/?$/, "/");
  return {
    base: t3,
    groupsUrl: new URL("idc-rad-groups.json", t3).href,
    parquetUrl: new URL("idc-rad-slim.parquet", t3).href
  };
}
async function gn(e, t3) {
  if (R)
    return R;
  t3 == null || t3("fetching the IDC index directory\u2026");
  let n;
  try {
    const r = globalThis.caches ? await globalThis.caches.open("idc-rad") : null;
    r && (n = await r.match(e)), n || (n = await fetch(e), n.ok && r && await r.put(e, n.clone()));
  } catch {
    n = await fetch(e);
  }
  if (!n || !n.ok)
    throw new Error(
      `index directory not reachable at ${e} (HTTP ${(n == null ? void 0 : n.status) ?? "?"})`
    );
  return R = await n.json(), R;
}
async function yn(e, t3 = {}) {
  const { parquetUrl: n, groupsUrl: r } = mn(t3.indexBase), i = t3.onStatus, s2 = await gn(r, i), o = s2.rowGroupSize, c = [];
  for (let a = 0; a < s2.groups.length; a++) {
    const u = s2.groups[a];
    e >= u.min && e <= u.max && c.push([a * o, Math.min((a + 1) * o, s2.total)]);
  }
  if (!c.length)
    throw new Error(
      `StudyInstanceUID not found in the slim IDC index (${s2.version}): ${e}`
    );
  i == null || i(
    `range-reading the IDC index (${c.length} group${c.length > 1 ? "s" : ""})\u2026`
  );
  try {
    const a = await import(
      /* @vite-ignore */
      dn
    ), u = await a.asyncBufferFromUrl({ url: n }), l = await a.parquetMetadataAsync(u), b = (await Promise.all(
      c.map(
        ([f2, h]) => a.parquetReadObjects({
          file: u,
          metadata: l,
          columns: hn,
          rowStart: f2,
          rowEnd: h
        })
      )
    )).flat().filter((f2) => f2.StudyInstanceUID === e);
    if (!b.length)
      throw new Error(`StudyInstanceUID not found in the IDC index: ${e}`);
    return b;
  } catch (a) {
    const u = a instanceof Error ? a.message : String(a);
    throw u.includes("not found") ? a : new Error(
      `couldn't range-read the slim IDC index at ${n} (${u})`
    );
  }
}
async function pn({
  studyInstanceUID: e,
  seriesInstanceUID: t3,
  indexBase: n,
  onStatus: r,
  useMemo: i = true
}) {
  var T2, Re;
  const s2 = String(e || "").trim();
  if (!s2)
    throw new Error("studyInstanceUID is required");
  const o = String(t3 || "").trim(), c = o ? [o] : [], a = `idc-rad:${s2}:${c.join(",")}`;
  if (i)
    try {
      const p = (T2 = globalThis.localStorage) == null ? void 0 : T2.getItem(a);
      if (p)
        return JSON.parse(p);
    } catch {
    }
  const u = await yn(s2, { indexBase: n, onStatus: r }), l = new Set(c), d = u.filter(
    (p) => bn.has(String(p.Modality).toUpperCase())
  ), b = u.filter(
    (p) => String(p.Modality).toUpperCase() === "SEG"
  );
  let f2 = d.find((p) => l.has(String(p.SeriesInstanceUID))) || d.slice().sort((p, Et) => Number(Et.instanceCount) - Number(p.instanceCount))[0];
  if (!f2 && o && (f2 = u.find((p) => String(p.SeriesInstanceUID) === o)), !f2)
    throw new Error("no CT/MR/PET/NM image series found in this study");
  const h = b.find((p) => l.has(String(p.SeriesInstanceUID))) || b[0], g = String(f2.Modality).toUpperCase(), m = g === "PET" ? "PT" : g, y = {
    crdcSeriesUuid: String(f2.crdc_series_uuid),
    awsBucket: String(f2.aws_bucket || "idc-open-data"),
    studyInstanceUID: s2,
    seriesInstanceUID: String(f2.SeriesInstanceUID || ""),
    modality: m,
    seriesDescription: String(f2.SeriesDescription || m),
    patientId: String(f2.PatientID || ""),
    collectionId: String(f2.collection_id || ""),
    license: `${f2.license_short_name || "IDC"} \xB7 ${f2.collection_id || ""}${f2.source_DOI ? ` \xB7 doi:${f2.source_DOI}` : ""}`,
    segCrdcSeriesUuid: h ? String(h.crdc_series_uuid) : void 0,
    segAwsBucket: h ? String(h.aws_bucket) : void 0
  };
  if (i)
    try {
      (Re = globalThis.localStorage) == null || Re.setItem(a, JSON.stringify(y));
    } catch {
    }
  return y;
}
var Cn = [
  "TOTALSEG",
  "TOTAL_SEGMENTATOR",
  "TOTAL-SEGMENTATOR"
];
var wn = [
  "LUNGSCREENING",
  "LUNG_SCREENING"
];
var In = [
  "NEURO_SEG",
  "NEUROSEG",
  "NEURO-SEG"
];
var En = [
  "DENTAL_SEG",
  "DENTALSEG",
  "DENTAL-SEG",
  "DENTALSEGMENTATOR"
];
var An = [
  "TORCHXRAYVISION",
  "TXRV",
  "TORCH_XRAY_VISION",
  "TORCH-XRAY-VISION"
];
var Nn = ["FLEXRAY", "FLEX_RAY", "FLEX-RAY"];
var Tn = ["MHUB", "MHUB_AI", "MHUBAI"];
var Un = ["EUCAIM", "NNUNET_EUCAIM", "NNUNET-EUCAIM"];
var Ln = [
  "VOX2SEGLAM",
  "VOX2_SEG_LAM",
  "VOX2-SEG-LAM"
];
function Xe(e) {
  return String(e || "").trim().toUpperCase().replace(/-/g, "_");
}
function w(e, t3) {
  const n = Xe(e);
  if (!n)
    return false;
  const r = n.replace(/_/g, "");
  return t3.some((i) => {
    const s2 = Xe(i);
    return s2 === n || s2.replace(/_/g, "") === r;
  });
}
function we(e) {
  return w(e, Cn);
}
function Ie(e) {
  return w(e, wn);
}
function Ee(e) {
  return w(e, In);
}
function Ae(e) {
  return w(e, En);
}
function Ne(e) {
  return w(e, An);
}
function gt(e) {
  return w(e, Nn);
}
function Te(e) {
  return w(e, Tn);
}
function Ue(e) {
  return w(e, Un);
}
function Le(e) {
  return w(e, Ln);
}
function yt(e, t3) {
  if (!Array.isArray(e))
    return;
  const n = String(t3).trim().toLowerCase(), r = e.find((s2) => !s2 || typeof s2 != "object" ? false : String(s2.key ?? "").trim().toLowerCase() === n);
  if (!r)
    return;
  const i = r.value;
  return typeof i == "string" ? i.trim() : void 0;
}
function pt(e) {
  if (!e || typeof e != "object" || e.source !== "status")
    return false;
  const t3 = yt(e.items, "availability");
  return t3 ? t3.toLowerCase() === "online" : Array.isArray(e.items) && e.items.length > 0;
}
function ke(e) {
  const t3 = String((e == null ? void 0 : e.productName) ?? "").trim();
  if (t3)
    return t3;
  const n = e == null ? void 0 : e.data;
  if (n && typeof n == "object") {
    const r = String(n.product ?? "").trim();
    if (r)
      return r;
  }
  return "";
}
var kn = "mhub";
var vn = "MHUB";
var Rn = "MHub models";
var On = "Boston, USA";
var Pn = "Medical Imaging Model Hub \u2014 peer-reviewed deep learning models via standardized Docker I/O.";
var Dn = "https://github.com/MHubAI/";
var Mn = "https://mhub.ai";
var Hn = "Apache-2.0";
var $n = "https://www.apache.org/licenses/LICENSE-2.0";
var xn = "Models may use different licenses; check each model";
var Fn = "dicom-send";
var Bn = true;
var jn = "https://github.com/MHubAI.png";
var Wn = {
  id: kn,
  product: vn,
  title: Rn,
  location: On,
  summary: Pn,
  githubUrl: Dn,
  websiteUrl: Mn,
  license: Hn,
  licenseUrl: $n,
  licenseRestriction: xn,
  hubEvent: Fn,
  enabled: Bn,
  iconUrl: jn
};
var Vn = "eucaim";
var Gn = "EUCAIM";
var zn = "EUCAIM nnU-Net";
var qn = "Heidelberg, Germany";
var Xn = "MIC-DKFZ EUCAIM nnU-Net Docker tasks \u2014 DICOM series in, DICOM SEG out.";
var Yn = "https://github.com/MIC-DKFZ/nnunet-eucaim-docker";
var Jn = "https://cancerimage.eu/";
var Zn = "Apache-2.0";
var Kn = "https://www.apache.org/licenses/LICENSE-2.0";
var Qn = "dicom-send";
var er = true;
var tr = "https://github.com/MIC-DKFZ.png";
var nr = {
  id: Vn,
  product: Gn,
  title: zn,
  location: qn,
  summary: Xn,
  githubUrl: Yn,
  websiteUrl: Jn,
  license: Zn,
  licenseUrl: Kn,
  hubEvent: Qn,
  enabled: er,
  iconUrl: tr
};
var rr = "vox2seglam";
var ir = "VOX2SEGLAM";
var sr = "Vox2SegLAM";
var or = "Montreal, Canada";
var cr = "Joint subcortical segmentation and anatomical landmark detection on T1-weighted brain MRI (Harvard\u2013Oxford Atlas 2.0 protocol). DICOM in \u2192 DICOM SEG/SR out; NIfTI in \u2192 NIfTI out.";
var ar = "https://github.com/Neuro-iX/Vox2SegLAM";
var ur = "https://github.com/Neuro-iX/Vox2SegLAM";
var lr = "MIT";
var fr = "https://opensource.org/licenses/MIT";
var dr = "dicom-send";
var hr = true;
var br = {
  id: rr,
  product: ir,
  title: sr,
  location: or,
  summary: cr,
  githubUrl: ar,
  websiteUrl: ur,
  license: lr,
  licenseUrl: fr,
  hubEvent: dr,
  enabled: hr
};
var mr = "totalseg";
var gr = "TOTALSEG";
var yr = "Total Segmentator";
var pr = "Basel, Switzerland";
var Sr = "Whole-body CT/MR multi-organ segmentation.";
var _r = "https://github.com/wasserth/TotalSegmentator";
var Cr = "https://totalsegmentator.com/";
var wr = "https://www.buymeacoffee.com/totalsegmentator";
var Ir = "Apache-2.0";
var Er = "https://www.apache.org/licenses/LICENSE-2.0";
var Ar = "dicom-send";
var Nr = true;
var Tr = "https://pubs.rsna.org/doi/10.1148/ryai.230024";
var Ur = {
  id: mr,
  product: gr,
  title: yr,
  location: pr,
  summary: Sr,
  githubUrl: _r,
  websiteUrl: Cr,
  buyMeACoffeeUrl: wr,
  license: Ir,
  licenseUrl: Er,
  hubEvent: Ar,
  enabled: Nr,
  citeUrl: Tr
};
var Lr = "dental";
var kr = "DENTAL_SEG";
var vr = "Dental Segmentator";
var Rr = "Paris, France";
var Or = "Fully automatic CT/CBCT dental segmentation (maxilla, mandible, upper/lower teeth, mandibular canal).";
var Pr = "https://github.com/gaudot/SlicerDentalSegmentator";
var Dr = "https://www.kitware.com/dental-segmentator/";
var Mr = "Apache-2.0";
var Hr = "https://www.apache.org/licenses/LICENSE-2.0";
var $r = "dicom-send";
var xr = true;
var Fr = {
  id: Lr,
  product: kr,
  title: vr,
  location: Rr,
  summary: Or,
  githubUrl: Pr,
  websiteUrl: Dr,
  license: Mr,
  licenseUrl: Hr,
  hubEvent: $r,
  enabled: xr
};
var Br = "txrv";
var jr = "TORCHXRAYVISION";
var Wr = "TorchXRayVision";
var Vr = "Montreal, Canada";
var Gr = "Chest X-ray pathology classification (18 findings) and lung/heart anatomy segmentation.";
var zr = "https://github.com/mlmed/torchxrayvision";
var qr = "https://mlmed.org/torchxrayvision/";
var Xr = "Cohen et al., TorchXRayVision: A library of chest X-ray datasets and models, MIDL 2022";
var Yr = "https://arxiv.org/abs/2111.00595";
var Jr = "Apache-2.0";
var Zr = "https://www.apache.org/licenses/LICENSE-2.0";
var Kr = "dicom-send";
var Qr = true;
var ei = {
  id: Br,
  product: jr,
  title: Wr,
  location: Vr,
  summary: Gr,
  githubUrl: zr,
  websiteUrl: qr,
  cite: Xr,
  citeUrl: Yr,
  license: Jr,
  licenseUrl: Zr,
  hubEvent: Kr,
  enabled: Qr
};
var ti = "flexray";
var ni = "FLEXRAY";
var ri = "FleXray";
var ii = "local - in browser";
var si = "Foundation model for universal clinical X-ray anatomy segmentation (60 structures) across body regions, views, and acquisition settings. Designed for on-device / local inference.";
var oi = "https://flexray.csail.mit.edu/";
var ci = "https://github.com/VictorButoi/FleXray";
var ai = "CC-BY-NC-4.0";
var ui = "https://creativecommons.org/licenses/by-nc/4.0/";
var li = "Not for commercial use";
var fi = "Victor Ion Butoi, Vivek Gopalakrishnan, John V. Guttag, Adrian V. Dalca, and Neel Dey (2026). FleXray: Universal Clinical X-ray Segmentation. arXiv:2609.26756";
var di = "https://arxiv.org/abs/2609.26756";
var hi = "dicom-send";
var bi = true;
var mi = true;
var gi = {
  id: ti,
  product: ni,
  title: ri,
  location: ii,
  summary: si,
  websiteUrl: oi,
  githubUrl: ci,
  license: ai,
  licenseUrl: ui,
  licenseRestriction: li,
  cite: fi,
  citeUrl: di,
  hubEvent: hi,
  enabled: bi,
  localCapable: mi
};
var yi = "data:image/svg+xml,%3csvg%20width='35'%20height='50'%20viewBox='0%200%2035%2050'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M30.7512%2011.6307L30.7171%2011.6106L30.6382%2011.5865C30.6699%2011.6134%2030.7097%2011.6289%2030.7512%2011.6307Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M31.2481%2015.2031L31.21%2015.2138L31.2481%2015.2031Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M30.7659%2011.6253C30.761%2011.6247%2030.7563%2011.6236%2030.7517%2011.6219C30.7514%2011.6251%2030.7514%2011.6283%2030.7517%2011.6314C30.7569%2011.6307%2030.7618%2011.6286%2030.7659%2011.6253Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M30.7515%2011.6314H30.7572V11.6278L30.7515%2011.6314Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M31.2178%2015.1962L31.2753%2015.1634L31.2967%2015.1514L31.3161%2015.1307C31.2796%2015.1464%2031.2463%2015.1686%2031.2178%2015.1962Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M30.8507%2011.7088L30.7945%2011.6553L30.7563%2011.6345C30.7768%2011.6707%2030.8107%2011.6973%2030.8507%2011.7088Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M16.715%2046.3714C16.6701%2046.3908%2016.6307%2046.4212%2016.6006%2046.4597L16.636%2046.4369C16.6601%2046.4149%2016.6942%2046.3888%2016.715%2046.3714Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M24.9235%2044.7473C24.9235%2044.6965%2024.8987%2044.7059%2024.9048%2044.8864C24.9048%2044.8717%2024.9108%2044.857%2024.9134%2044.843C24.9168%2044.8109%2024.9195%2044.7794%2024.9235%2044.7473Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M24.0719%2046.3714C24.027%2046.3908%2023.9877%2046.4212%2023.9575%2046.4597L23.993%2046.4369C24.017%2046.4149%2024.0512%2046.3888%2024.0719%2046.3714Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M10.9344%2046.7574C10.9003%2046.7277%2010.8586%2046.7082%2010.814%2046.7012C10.8501%2046.7186%2010.8862%2046.736%2010.9103%2046.7493L10.9344%2046.7574Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M9.63391%2045.5042C9.62859%2045.4515%209.61242%2045.4005%209.58643%2045.3544C9.60484%2045.4024%209.62025%2045.4516%209.63258%2045.5015L9.63391%2045.5042Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M18.3715%2023.0976C16.5857%2023.8665%2014.5591%2024.7382%2011.9326%2024.7382C10.8339%2024.736%209.74049%2024.5844%208.68213%2024.2875L10.4987%2043.0444C10.563%2043.8284%2010.9181%2044.5594%2011.4935%2045.0923C12.0689%2045.6251%2012.8225%2045.9208%2013.6047%2045.9207C13.6047%2045.9207%2016.1804%2046.0552%2017.0398%2046.0552C17.9648%2046.0552%2020.7385%2045.9207%2020.7385%2045.9207C21.5205%2045.9207%2022.274%2045.6249%2022.8493%2045.092C23.4245%2044.5592%2023.7795%2043.8283%2023.8438%2043.0444L25.7895%2022.3173C24.92%2022.0187%2024.0425%2021.8203%2023.0533%2021.8203C21.3424%2021.8196%2019.964%2022.4122%2018.3715%2023.0976Z'%20fill='%23FFFFFF'/%3e%3cpath%20d='M3.05859%2015.095L3.08936%2015.1238L3.10943%2015.1358C3.09397%2015.1205%203.07693%2015.1068%203.05859%2015.095Z'%20fill='%23FFDD00'/%3e%3cpath%20d='M34.1896%2013.3639L33.916%2011.9762C33.6706%2010.7312%2033.1134%209.55468%2031.8426%209.10468C31.4353%208.96073%2030.9732%208.89885%2030.6608%208.60086C30.3485%208.30288%2030.2562%207.84009%2030.1839%207.41094C30.0502%206.62326%2029.9244%205.83492%2029.7873%205.04859C29.6689%204.37257%2029.5753%203.61315%2029.267%202.99296C28.8657%202.16022%2028.033%201.67322%2027.205%201.35102C26.7807%201.19173%2026.3477%201.05698%2025.9081%200.947426C23.8394%200.398542%2021.6644%200.196746%2019.5362%200.0817228C16.9817%20-0.0600379%2014.4204%20-0.0173274%2011.872%200.209526C9.97525%200.383071%207.97745%200.592939%206.17495%201.25281C5.51616%201.49429%204.8373%201.7842%204.33634%202.29609C3.72169%202.92502%203.52104%203.89768%203.96982%204.68199C4.28886%205.23895%204.82927%205.63245%205.40246%205.89276C6.14906%206.22818%206.92877%206.48341%207.72865%206.65421C9.95585%207.14928%2012.2626%207.34368%2014.538%207.42641C17.0599%207.52878%2019.5859%207.44582%2022.0958%207.1782C22.7165%207.10959%2023.336%207.0273%2023.9545%206.93134C24.6828%206.81901%2025.1503%205.86115%2024.9356%205.19388C24.6788%204.39611%2023.9886%204.08669%2023.208%204.2071C23.093%204.22526%2022.9786%204.24208%2022.8636%204.25889L22.7807%204.271C22.5163%204.30463%2022.2518%204.33602%2021.9874%204.36517C21.4412%204.42437%2020.8937%204.4728%2020.3448%204.51046C19.1155%204.59656%2017.8828%204.63625%2016.6508%204.63827C15.4403%204.63827%2014.229%204.60396%2013.0211%204.52392C12.47%204.48759%2011.9202%204.4414%2011.3718%204.38535C11.1223%204.35912%2010.8735%204.33154%2010.6247%204.3006L10.3879%204.27033L10.3364%204.26293L10.091%204.22728C9.58933%204.15127%209.08771%204.06382%208.59144%203.95822C8.54136%203.94704%208.49657%203.91902%208.46446%203.87879C8.43236%203.83855%208.41486%203.7885%208.41486%203.73691C8.41486%203.68533%208.43236%203.63528%208.46446%203.59504C8.49657%203.55481%208.54136%203.52679%208.59144%203.51561H8.6008C9.03086%203.42346%209.46426%203.34476%209.899%203.27615C10.0439%203.25328%2010.1893%203.23086%2010.3351%203.20888H10.3391C10.6113%203.19072%2010.8849%203.14162%2011.1557%203.10933C13.5125%202.86279%2015.8832%202.77874%2018.2513%202.85776C19.4011%202.89139%2020.5501%202.95933%2021.6945%203.07637C21.9406%203.10193%2022.1854%203.12884%2022.4302%203.15911C22.5238%203.17054%2022.6181%203.18399%2022.7124%203.19543L22.9024%203.22301C23.4562%203.30597%2024.0071%203.40664%2024.5551%203.52503C25.367%203.70261%2026.4097%203.76046%2026.7709%204.65508C26.8859%204.93894%2026.9381%205.25442%2027.0016%205.5524L27.0826%205.93245C27.0847%205.93927%2027.0863%205.94624%2027.0873%205.9533C27.2785%206.85017%2027.4701%207.74704%2027.6618%208.64391C27.6758%208.71017%2027.6762%208.77862%2027.6628%208.84501C27.6493%208.9114%2027.6225%208.97429%2027.5838%209.02977C27.5451%209.08525%2027.4955%209.13212%2027.4381%209.16746C27.3806%209.2028%2027.3165%209.22585%2027.2498%209.23517H27.2444L27.1274%209.25132L27.0117%209.26679C26.6452%209.31477%2026.2782%209.35961%2025.9108%209.40132C25.1871%209.48428%2024.4623%209.55603%2023.7364%209.61657C22.294%209.7372%2020.8486%209.81635%2019.4004%209.85401C18.6625%209.87374%2017.9247%209.88294%2017.1872%209.88159C14.2517%209.87926%2011.3188%209.70768%208.40283%209.36769C8.08714%209.33002%207.77145%209.28966%207.45577%209.24863C7.70056%209.28024%207.27786%209.22441%207.19225%209.2123C6.9916%209.18405%206.79095%209.15468%206.5903%209.12419C5.91679%209.02262%205.24729%208.8975%204.57511%208.78786C3.76249%208.65333%202.98531%208.72059%202.25026%209.12419C1.6469%209.45624%201.15857%209.96544%200.850401%2010.5838C0.533376%2011.243%200.439071%2011.9608%200.297279%2012.6691C0.155487%2013.3774%20-0.0652275%2014.1395%200.0183763%2014.8666C0.198292%2016.4359%201.28915%2017.7113%202.85823%2017.9965C4.33434%2018.2655%205.81847%2018.4835%207.30662%2018.6691C13.1524%2019.3892%2019.0582%2019.4753%2024.9223%2018.9261C25.3998%2018.8812%2025.8767%2018.8324%2026.3529%2018.7794C26.5016%2018.763%2026.6521%2018.7802%2026.7934%2018.8299C26.9347%2018.8795%2027.0631%2018.9603%2027.1693%2019.0663C27.2755%2019.1724%2027.3567%2019.3009%2027.4071%2019.4426C27.4575%2019.5843%2027.4757%2019.7356%2027.4605%2019.8853L27.312%2021.3369C27.0128%2024.2701%2026.7136%2027.2031%2026.4144%2030.1358C26.1023%2033.2157%2025.7882%2036.2953%2025.472%2039.3747C25.3829%2040.242%2025.2937%2041.109%2025.2045%2041.9758C25.1189%2042.8294%2025.1069%2043.7099%2024.9457%2044.5534C24.6915%2045.8799%2023.7986%2046.6945%2022.4957%2046.9925C21.3021%2047.2657%2020.0827%2047.4091%2018.8586%2047.4203C17.5016%2047.4277%2016.1452%2047.3672%2014.7881%2047.3746C13.3395%2047.3826%2011.5651%2047.2481%2010.4468%2046.1638C9.46426%2045.2113%209.32849%2043.72%209.19472%2042.4306C9.01637%2040.7234%208.83957%2039.0164%208.66434%2037.3097L7.68116%2027.8192L7.0451%2021.6786C7.0344%2021.577%207.0237%2021.4768%207.01367%2021.3745C6.93742%2020.642%206.42176%2019.925%205.60913%2019.962C4.91354%2019.9929%204.12299%2020.5875%204.20458%2021.3745L4.67611%2025.927L5.65126%2035.3442C5.92905%2038.0191%206.20617%2040.6944%206.48262%2043.3703C6.53613%2043.8828%206.58628%2044.3967%206.64247%2044.9093C6.94812%2047.7102%209.075%2049.2196%2011.7089%2049.6448C13.2472%2049.8936%2014.8229%2049.9448%2016.384%2049.9703C18.3851%2050.0026%2020.4063%2050.08%2022.3747%2049.7154C25.2915%2049.1773%2027.4799%2047.2185%2027.7922%2044.1801C27.8814%2043.303%2027.9706%2042.4256%2028.0597%2041.548C28.3563%2038.6458%2028.6523%2035.7433%2028.9479%2032.8406L29.9151%2023.3562L30.3585%2019.0095C30.3806%2018.794%2030.4711%2018.5913%2030.6166%2018.4315C30.7621%2018.2717%2030.9549%2018.1633%2031.1665%2018.1223C32.0005%2017.9588%2032.7977%2017.6796%2033.391%2017.0413C34.3354%2016.0249%2034.5233%2014.6998%2034.1896%2013.3639ZM2.81542%2014.3016C2.82813%2014.2955%202.80472%2014.4052%202.79469%2014.4563C2.79268%2014.3789%202.7967%2014.3103%202.81542%2014.3016ZM2.89635%2014.9312C2.90304%2014.9265%202.9231%2014.9534%202.94384%2014.9857C2.9124%2014.9561%202.89234%2014.9339%202.89568%2014.9312H2.89635ZM2.97594%2015.0368C3.0047%2015.0859%203.02009%2015.1168%202.97594%2015.0368V15.0368ZM3.13579%2015.1673H3.1398C3.1398%2015.172%203.14716%2015.1767%203.14984%2015.1814C3.1454%2015.1762%203.14048%2015.1715%203.13513%2015.1673H3.13579ZM31.1277%2014.9722C30.828%2015.2588%2030.3766%2015.392%2029.9305%2015.4586C24.9276%2016.2052%2019.8519%2016.5832%2014.7942%2016.4164C11.1745%2016.292%207.59287%2015.8877%204.00928%2015.3785C3.65815%2015.3287%203.27758%2015.2642%203.03614%2015.0038C2.58133%2014.5128%202.80472%2013.524%202.9231%2012.9307C3.03145%2012.3872%203.23879%2011.6628%203.88154%2011.5854C4.88478%2011.467%206.04989%2011.8928%207.04243%2012.0442C8.2374%2012.2276%209.43684%2012.3744%2010.6407%2012.4848C15.7787%2012.9556%2021.0029%2012.8823%2026.1181%2012.1935C27.0505%2012.0675%2027.9795%2011.9211%2028.9051%2011.7543C29.7298%2011.6056%2030.6441%2011.3264%2031.1424%2012.1854C31.4841%2012.7706%2031.5296%2013.5536%2031.4768%2014.2148C31.4605%2014.5029%2031.3354%2014.7739%2031.127%2014.9722H31.1277Z'%20fill='%23FFDD00'/%3e%3c/svg%3e";
function pi(e) {
  const t3 = String(e.summary || e.capabilities || "").trim(), n = e.hubEvent === "nifti-send" ? "nifti-send" : "dicom-send", r = {
    id: String(e.id || "").trim(),
    product: String(e.product || "").trim(),
    title: String(e.title || "").trim(),
    location: String(e.location || "").trim(),
    summary: t3,
    capabilities: t3,
    hubEvent: n
  }, i = String(e.githubUrl || "").trim();
  i && (r.githubUrl = i);
  const s2 = String(e.websiteUrl || "").trim();
  s2 && (r.websiteUrl = s2);
  const o = String(e.buyMeACoffeeUrl || "").trim();
  o && (r.buyMeACoffeeUrl = o);
  const c = String(e.iconUrl || "").trim();
  c && (r.iconUrl = c);
  const a = String(e.cite || "").trim();
  a && (r.cite = a);
  const u = String(e.citeUrl || "").trim();
  u && (r.citeUrl = u);
  const l = String(e.license || "").trim();
  l && (r.license = l);
  const d = String(e.licenseUrl || "").trim();
  d && (r.licenseUrl = d);
  const b = String(e.licenseRestriction || "").trim();
  return b && (r.licenseRestriction = b), e.localCapable === true && (r.localCapable = true), r;
}
function Si(e) {
  return (e == null ? void 0 : e.enabled) !== false;
}
var A = Object.freeze(
  [
    br,
    Wn,
    Ur,
    Fr,
    ei,
    gi,
    nr
  ].filter(Si).map(pi)
);
var zs = Object.freeze(
  A.filter((e) => e.localCapable === true)
);
function S(e) {
  return String(e ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Xs(e) {
  if (!e || typeof e != "object") return "";
  const t3 = S(e.title), n = S(e.summary || e.capabilities), r = String(e.iconUrl || "").trim(), i = ['<div class="hub-inference-info-card">'];
  r ? i.push(
    `<div class="hub-inference-info-heading"><img class="hub-inference-info-icon" src="${S(r)}" alt="" width="28" height="28" decoding="async" /><div class="hub-inference-info-title">${t3}</div></div>`
  ) : i.push(`<div class="hub-inference-info-title">${t3}</div>`), n && i.push(`<p class="hub-inference-info-summary">${n}</p>`);
  const s2 = String(e.cite || "").trim(), o = String(e.citeUrl || "").trim();
  if (s2) {
    const f2 = S(s2);
    o ? i.push(
      `<p class="hub-inference-info-citation"><span class="hub-inference-info-citation-label">Citation:</span> <a class="hub-inference-info-citation-link" href="${S(o)}" target="_blank" rel="noopener noreferrer">${f2}</a></p>`
    ) : i.push(
      `<p class="hub-inference-info-citation"><span class="hub-inference-info-citation-label">Citation:</span> ${f2}</p>`
    );
  }
  const c = String(e.license || "").trim(), a = String(e.licenseUrl || "").trim(), u = String(e.licenseRestriction || "").trim();
  if (c || u) {
    const f2 = ['<p class="hub-inference-info-license">'];
    if (c) {
      const h = S(c), g = a ? `<a class="hub-inference-info-license-link" href="${S(a)}" target="_blank" rel="noopener noreferrer">${h}</a>` : h;
      f2.push(
        `<span class="hub-inference-info-license-label">License:</span> ${g}`
      );
    }
    c && u && f2.push(" "), u && f2.push(
      `<span class="hub-inference-info-restriction">${S(u)}</span>`
    ), f2.push("</p>"), i.push(f2.join(""));
  }
  i.push('<div class="hub-inference-info-links">');
  const l = String(e.githubUrl || "").trim();
  l && i.push(
    `<a class="hub-inference-info-link hub-inference-info-github" href="${S(l)}" target="_blank" rel="noopener noreferrer"><svg class="hub-inference-info-github-icon" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path fill="currentColor" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27s1.36.09 2 .27c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>GitHub</a>`
  ), a && i.push(
    `<a class="hub-inference-info-link" href="${S(a)}" target="_blank" rel="noopener noreferrer">License</a>`
  );
  const d = String(e.websiteUrl || "").trim();
  d && i.push(
    `<a class="hub-inference-info-link" href="${S(d)}" target="_blank" rel="noopener noreferrer">Website</a>`
  ), o && i.push(
    `<a class="hub-inference-info-link" href="${S(o)}" target="_blank" rel="noopener noreferrer" title="${S(s2 || "Citation")}">Cite</a>`
  );
  const b = String(e.buyMeACoffeeUrl || "").trim();
  return b && i.push(
    `<a class="hub-inference-info-link hub-inference-info-coffee" href="${S(b)}" target="_blank" rel="noopener noreferrer" title="Buy Me a Coffee"><img class="hub-inference-info-coffee-icon" src="${yi}" alt="" width="12" height="16" decoding="async" />Buy me a coffee</a>`
  ), i.push("</div></div>"), i.join("");
}
function Ys(e, t3) {
  if (!e || typeof e != "object")
    return "";
  const n = [
    String(e.title || "").trim(),
    String(e.summary || e.capabilities || "").trim(),
    `Location: ${String(e.location || "").trim()}`
  ].filter((c) => c && !c.endsWith(": "));
  t3 && n.push(`Status: ${t3}`);
  const r = String(e.cite || "").trim();
  r && n.push(`Citation: ${r}`);
  const i = String(e.license || "").trim();
  i && n.push(`License: ${i}`);
  const s2 = String(e.licenseRestriction || "").trim();
  s2 && n.push(s2);
  const o = String(e.githubUrl || "").trim();
  return o && n.push(o), n.join(`
`);
}
function _i(e) {
  const t3 = String(e || "").trim().toUpperCase().replace(/-/g, "_");
  if (!t3)
    return null;
  const n = t3.replace(/_/g, "");
  return A.find((r) => {
    const i = String(r.product || "").trim().toUpperCase().replace(/-/g, "_");
    return i === t3 || i.replace(/_/g, "") === n;
  }) || null;
}
function te(e) {
  const t3 = e == null ? void 0 : e["hub.event"];
  return typeof t3 == "string" ? t3.trim().toLowerCase() : "";
}
function eo(e) {
  if (!Array.isArray(e))
    return [];
  try {
    return structuredClone(e);
  } catch {
    try {
      return JSON.parse(JSON.stringify(e));
    } catch {
      return [...e];
    }
  }
}
function to(e) {
  const t3 = e == null ? void 0 : e.event;
  return t3 && typeof t3 == "object" && t3.context != null ? t3.context : [];
}
function no(e) {
  return String(
    (e == null ? void 0 : e["subscriber.name"]) || (e == null ? void 0 : e.subscriber) || ""
  ).trim() || null;
}
function ro(e) {
  return String((e == null ? void 0 : e["subscriber.product.name"]) || "").trim();
}
function io(e) {
  const t3 = String((e == null ? void 0 : e["subscriber.actor"]) || "").trim();
  if (t3)
    return t3;
  const n = e == null ? void 0 : e["subscriber.actors"];
  if (Array.isArray(n))
    for (const r of n) {
      const i = String(r || "").trim();
      if (i)
        return i;
    }
  return "";
}
function wt(e, t3, n) {
  if (!e || typeof e != "object")
    return { online: false, items: [], raw: n, ...t3 ? { productName: t3 } : {} };
  const r = (
    /** @type {{ items?: unknown }} */
    e
  ), i = Array.isArray(r.items) ? r.items : [], s2 = yt(i, "job");
  return {
    online: pt(e),
    items: i,
    ...s2 ? { job: s2 } : {},
    raw: n,
    ...t3 ? { productName: t3 } : {}
  };
}
async function It(e, t3) {
  const n = String((t3 == null ? void 0 : t3.subscriberName) || "").trim();
  if (!(e != null && e.request))
    return { ok: false, status: 0, data: { error: "No Hub client" } };
  if (!n)
    return { ok: false, status: 0, data: { error: "No subscriber name" } };
  const r = String((t3 == null ? void 0 : t3.topic) || "").trim(), i = String((t3 == null ? void 0 : t3.subscriberProductName) || "").trim(), s2 = String((t3 == null ? void 0 : t3.subscriberActor) || "").trim(), o = String((t3 == null ? void 0 : t3.targetActor) || "*").trim() || "*", c = String((t3 == null ? void 0 : t3.targetProductName) || "").trim();
  return e.request({
    "subscriber.name": n,
    ...i ? { "subscriber.product.name": i } : {},
    ...s2 ? { "subscriber.actor": s2 } : {},
    "target.actor": o,
    ...c ? { "target.product.name": c } : {},
    event: {
      "hub.event": k("STATUS"),
      ...r ? { "hub.topic": r } : {},
      context: { dataType: "STATUS" }
    }
  });
}
async function go(e, t3) {
  const n = String((t3 == null ? void 0 : t3.subscriberName) || "").trim();
  if (!(e != null && e.request))
    return { ok: false, status: 0, data: { error: "No Hub client" } };
  if (!n)
    return { ok: false, status: 0, data: { error: "No subscriber name" } };
  const r = String((t3 == null ? void 0 : t3.topic) || "").trim(), i = String((t3 == null ? void 0 : t3.subscriberProductName) || "").trim(), s2 = String((t3 == null ? void 0 : t3.subscriberActor) || "").trim(), o = String((t3 == null ? void 0 : t3.targetActor) || "ID").trim() || "ID", c = String((t3 == null ? void 0 : t3.targetProductName) || "").trim();
  return e.request({
    "subscriber.name": n,
    ...i ? { "subscriber.product.name": i } : {},
    ...s2 ? { "subscriber.actor": s2 } : {},
    "target.actor": o,
    ...c ? { "target.product.name": c } : {},
    event: {
      "hub.event": k("LIVESCENE"),
      ...r ? { "hub.topic": r } : {},
      context: { dataType: "LIVESCENE" }
    }
  });
}
async function po(e, t3) {
  const n = String((t3 == null ? void 0 : t3.subscriberName) || "").trim();
  if (!(e != null && e.request))
    return { ok: false, status: 0, data: { error: "No Hub client" } };
  if (!n)
    return { ok: false, status: 0, data: { error: "No subscriber name" } };
  const r = String((t3 == null ? void 0 : t3.topic) || "").trim(), i = String((t3 == null ? void 0 : t3.subscriberProductName) || "").trim(), s2 = String((t3 == null ? void 0 : t3.subscriberActor) || "").trim(), o = String((t3 == null ? void 0 : t3.targetActor) || "ID").trim() || "ID", c = String((t3 == null ? void 0 : t3.targetProductName) || "").trim(), a = Number(t3 == null ? void 0 : t3.timeoutSeconds), u = Number.isFinite(a) && a > 0 ? a : 5;
  return e.request({
    "subscriber.name": n,
    ...i ? { "subscriber.product.name": i } : {},
    ...s2 ? { "subscriber.actor": s2 } : {},
    "target.actor": o,
    ...c ? { "target.product.name": c } : {},
    event: {
      "hub.event": k("SLICERWORKLIST"),
      ...r ? { "hub.topic": r } : {},
      context: {
        dataType: "SLICERWORKLIST",
        timeoutSeconds: u
      }
    }
  });
}
async function So(e, t3) {
  const n = String((t3 == null ? void 0 : t3.subscriberName) || "").trim(), r = String((t3 == null ? void 0 : t3.studyInstanceUID) || "").trim();
  if (!(e != null && e.request))
    return { ok: false, status: 0, data: { error: "No Hub client" } };
  if (!n)
    return { ok: false, status: 0, data: { error: "No subscriber name" } };
  if (!r)
    return { ok: false, status: 0, data: { error: "No studyInstanceUID" } };
  const i = String((t3 == null ? void 0 : t3.topic) || "").trim(), s2 = String((t3 == null ? void 0 : t3.subscriberProductName) || "").trim(), o = String((t3 == null ? void 0 : t3.subscriberActor) || "").trim(), c = String((t3 == null ? void 0 : t3.targetActor) || "ID").trim() || "ID", a = String((t3 == null ? void 0 : t3.targetProductName) || "").trim(), u = Number(t3 == null ? void 0 : t3.timeoutSeconds), l = Number.isFinite(u) && u > 0 ? u : 5;
  return e.request({
    "subscriber.name": n,
    ...s2 ? { "subscriber.product.name": s2 } : {},
    ...o ? { "subscriber.actor": o } : {},
    "target.actor": c,
    ...a ? { "target.product.name": a } : {},
    event: {
      "hub.event": k("SLICERSTUDYINFO"),
      ...i ? { "hub.topic": i } : {},
      context: {
        dataType: "SLICERSTUDYINFO",
        studyInstanceUID: r,
        timeoutSeconds: l
      }
    }
  });
}
function Pi(e, t3) {
  if (!e) return false;
  const n = _i(e);
  return n && n.id === t3.id ? true : t3.id === "mhub" ? Te(e) : t3.id === "eucaim" ? Ue(e) : t3.id === "vox2seglam" ? Le(e) : t3.id === "totalseg" ? we(e) : t3.id === "lung" ? Ie(e) : t3.id === "neuro" ? Ee(e) : t3.id === "dental" ? Ae(e) : t3.id === "txrv" ? Ne(e) : t3.id === "flexray" ? gt(e) : false;
}
function Di(e) {
  if (!e || typeof e != "object")
    return A.map((r) => ({
      server: r,
      probe: { online: false, items: [], error: "Empty STATUS result" }
    }));
  const t3 = (
    /** @type {{ ok?: boolean, status?: number, data?: unknown }} */
    e
  );
  if (t3.ok === false) {
    const r = `HTTP ${t3.status ?? "?"}`;
    return A.map((i) => ({
      server: i,
      probe: { online: false, items: [], error: r, raw: t3.data }
    }));
  }
  const { responses: n } = de(t3.data);
  return A.map((r) => {
    for (const i of n) {
      const s2 = ke(i);
      if (!Pi(s2, r)) continue;
      const o = i.data;
      return {
        server: r,
        probe: wt(
          o,
          s2 || r.product,
          t3.data
        )
      };
    }
    return {
      server: r,
      probe: { online: false, items: [], raw: t3.data }
    };
  });
}

// ../conference-ui/dist/conference-ui.js
var Ee2 = Object.freeze({
  // Dialog shell
  dialogTitle: "Conferencing",
  close: "Close",
  closeAria: "Close",
  // Session (user / topic)
  sessionSection: "User / topic",
  sessionInfo: "Session info",
  participantsAria: "Participants",
  userLabel: "User:",
  changeUserName: "Change user name",
  changeUserNameTitle: "Change user name",
  userNamePlaceholder: "Enter user name",
  openAnotherUser: "Open another user",
  openAnotherUserTitle: "Open another user session to test conferencing",
  openAnotherUserPrompt: "User name for new session",
  userNameSavedNote: "Switched user.",
  userNameSwitchingNote: "Switching user\u2026",
  userNameAlreadyExists: "A user with this name already exists.",
  done: "OK",
  // Create
  createSection: "Create a conference",
  conferenceTitle: "Conference title",
  selectConferenceTitle: "Select a conference title",
  otherTitle: "Other\u2026",
  customTitle: "Custom title",
  customTitlePlaceholder: "Enter conference title",
  users: "Users",
  loadingUsers: "Loading users\u2026",
  noUsers: "No users available",
  createConference: "Create conference",
  creating: "Creating\u2026",
  // Join
  joinSection: "Join a conference",
  activeConferences: "Active conferences",
  noConferences: "No conferences available",
  selectConference: "Select a conference",
  untitled: "Untitled",
  joinConference: "Join conference",
  joining: "Joining\u2026",
  // Manage
  manageSection: "Manage conference",
  titleLabel: "Title:",
  na: "N/A",
  participants: "Participants",
  noPlaces: "No places",
  leaveConference: "Leave conference",
  endConference: "End conference",
  ending: "Ending\u2026",
  leaving: "Leaving\u2026",
  conferenceEnded: "Conference ended.",
  leftConference: "Left conference.",
  // Errors / status
  connectHubFirst: "Connect to the Slicer hub first.",
  topicRequiredHost: "Hub topic is required to host a conference.",
  topicRequiredJoin: "Hub topic is required to join a conference.",
  titleRequired: "Conference title is required.",
  selectAttendee: "Select at least one attendee topic.",
  selectConferenceToJoin: "Select a conference to join.",
  failedCreate: "Failed to create conference.",
  failedJoin: "Failed to join conference.",
  failedUpdate: "Failed to update conference.",
  // Invite
  inviteTitle: "Conference invitation",
  joinAndFollow: "Join and follow",
  joinNoFollow: "Join but do not follow",
  doNotJoin: "Do not join",
  hostFallback: "host",
  /** {{title}} — join and follow {{host}}? */
  inviteLeadWithTitle: "{{title}} \u2014 join and follow {{host}}?",
  /** Join conference and follow {{host}}? */
  inviteLeadNoTitle: "Join conference and follow {{host}}?",
  /** Join and follow {{host}} */
  joinAndFollowHost: "Join and follow {{host}}",
  // Takeover
  takeoverTitle: "Take over?",
  takeoverBody: "The host and all participants will be notified that you are taking over. You will lead scene updates for this conference.",
  cancel: "Cancel",
  takeOver: "Take over",
  // Header
  conferencing: "Conferencing",
  subscribeHubFirst: "Subscribe to the hub first",
  stopFollowing: "Stop following",
  resumeFollowing: "Resume following"
});
function ae(e, n = {}) {
  return String(e || "").replace(
    /\{\{(\w+)\}\}/g,
    (o, l) => n[l] != null ? String(n[l]) : ""
  );
}
function Q2(e) {
  return !e || typeof e != "object" ? { ...Ee2 } : { ...Ee2, ...e };
}
function Te2(e, n, o = "hub-dialog-anchored") {
  e instanceof HTMLElement && e.classList.remove(o), n instanceof HTMLElement && (n.style.top = "", n.style.left = "", n.style.right = "", n.style.bottom = "", n.style.maxWidth = "", n.style.position = "", n.style.margin = "");
}
function Ze(e) {
  const n = e == null ? void 0 : e.overlay, o = e == null ? void 0 : e.dialog, l = e == null ? void 0 : e.anchor, t3 = String((e == null ? void 0 : e.anchoredClass) || "hub-dialog-anchored").trim(), u = Number.isFinite(e == null ? void 0 : e.gap) ? Number(e.gap) : 6, c = Number.isFinite(e == null ? void 0 : e.pad) ? Number(e.pad) : 8, a = (e == null ? void 0 : e.align) === "end";
  if (!(n instanceof HTMLElement) || !(o instanceof HTMLElement))
    return;
  if (!(l instanceof HTMLElement)) {
    Te2(n, o, t3);
    return;
  }
  const g = l.getBoundingClientRect();
  n.classList.add(t3), o.style.position = "absolute", o.style.margin = "0";
  const y = Math.max(
    280,
    Math.min(o.offsetWidth || 480, window.innerWidth - c * 2)
  );
  let d = a ? g.right - y : g.left, i = g.bottom + u;
  const b = window.innerWidth - y - c;
  d > b && (d = Math.max(c, b)), d < c && (d = c);
  const p = o.offsetHeight || 280;
  i + p > window.innerHeight - c && (i = Math.max(c, g.top - p - u)), o.style.left = `${Math.round(d)}px`, o.style.top = `${Math.round(i)}px`, o.style.maxWidth = `${Math.round(y)}px`;
}
function s(e, n) {
  return `${e}-${n}`;
}
function Z2(e) {
  return String(e ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Ke2(e, n) {
  const o = String(e || "").trim();
  if (!o) return false;
  const l = Z(n);
  return l && (l === o || l.toLowerCase() === o.toLowerCase()) ? true : (Array.isArray(n == null ? void 0 : n.topics) ? n.topics : []).some((u) => {
    const c = String(u || "").trim();
    return c === o || c.toLowerCase() === o.toLowerCase();
  });
}
function ut2(e) {
  const n = typeof (e == null ? void 0 : e.getSession) == "function" ? e.getSession : () => ({}), o = typeof (e == null ? void 0 : e.onConferenceChange) == "function" ? e.onConferenceChange : null, l = typeof (e == null ? void 0 : e.onFollowChange) == "function" ? e.onFollowChange : null, t3 = String((e == null ? void 0 : e.classPrefix) || "hub-conference").trim(), u = (e == null ? void 0 : e.anchorAlign) === "end" ? "end" : "start", c = (e == null ? void 0 : e.root) || (typeof document < "u" ? document.body : null);
  if (!c)
    throw new Error("createHubConferenceDialog requires a DOM root");
  let a = Q2(e == null ? void 0 : e.strings), g = null, y = false, d = null;
  const i = document.createElement("div");
  i.className = s(t3, "overlay"), i.hidden = true, i.innerHTML = `
    <div class="${s(t3, "dialog")}" role="dialog" aria-modal="true" aria-labelledby="${s(t3, "title")}" tabindex="-1">
      <div class="${s(t3, "header")}">
        <h2 id="${s(t3, "title")}" class="${s(t3, "title")}" data-hub-conference-dialog-title></h2>
        <button type="button" class="${s(t3, "close")}" data-hub-conference-close aria-label="">\xD7</button>
      </div>
      <div class="${s(t3, "body")}">
        <p class="${s(t3, "status")}" data-hub-conference-status role="alert" hidden></p>
        <div data-hub-conference-create>
          <div class="${s(t3, "section")}" data-hub-conference-create-form>
            <div class="${s(t3, "section-title")}" data-hub-conference-create-section></div>
            <div class="${s(t3, "field")}">
              <label class="${s(t3, "label")}" for="${s(t3, "title-select")}" data-hub-conference-title-label></label>
              <select id="${s(t3, "title-select")}" class="${s(t3, "select")}" data-hub-conference-title-select>
              </select>
            </div>
            <div class="${s(t3, "field")}" data-hub-conference-custom-group hidden>
              <label class="${s(t3, "label")}" for="${s(t3, "custom-title")}" data-hub-conference-custom-label></label>
              <input id="${s(t3, "custom-title")}" class="${s(t3, "input")}" type="text" data-hub-conference-custom-title />
            </div>
            <div class="${s(t3, "field")}">
              <span class="${s(t3, "label")}" data-hub-conference-users-label></span>
              <div class="${s(t3, "topics")}" data-hub-conference-topics>
                <p class="${s(t3, "muted")}" data-hub-conference-loading-users></p>
              </div>
              <p class="${s(t3, "muted")}" data-hub-conference-user-note hidden></p>
            </div>
            <button type="button" class="${s(t3, "primary")}" data-hub-conference-create-btn></button>
          </div>
          <div class="${s(t3, "section")}" data-hub-conference-join-section>
            <div class="${s(t3, "section-title")}" data-hub-conference-join-section-title></div>
            <div class="${s(t3, "field")}">
              <label class="${s(t3, "label")}" for="${s(t3, "join-select")}" data-hub-conference-active-label></label>
              <select id="${s(t3, "join-select")}" class="${s(t3, "select")}" data-hub-conference-join-select>
              </select>
            </div>
            <button type="button" class="${s(t3, "primary")}" data-hub-conference-join-btn disabled></button>
          </div>
        </div>
        <div data-hub-conference-manage hidden>
          <div class="${s(t3, "info")}" data-hub-conference-info></div>
        </div>
        <button
          type="button"
          id="openConferenceTestWorklistBtn"
          class="${s(t3, "secondary")} ${s(t3, "open-another-user")}"
          data-hub-conference-open-another-user
        ></button>
      </div>
    </div>
    <div
      class="${s(t3, "change-user-overlay")}"
      data-hub-conference-change-user-overlay
      hidden
    >
      <div
        class="${s(t3, "change-user-dialog")}"
        role="dialog"
        aria-modal="true"
        aria-labelledby="${s(t3, "change-user-title")}"
        tabindex="-1"
      >
        <div class="${s(t3, "change-user-header")}">
          <h3
            id="${s(t3, "change-user-title")}"
            class="${s(t3, "change-user-title")}"
            data-hub-conference-change-user-title
          ></h3>
          <button
            type="button"
            class="${s(t3, "close")}"
            data-hub-conference-change-user-close
            aria-label=""
          >\xD7</button>
        </div>
        <div class="${s(t3, "field")}">
          <label
            class="${s(t3, "label")}"
            for="sessionUserNameInput"
            data-hub-conference-user-label
          ></label>
          <input
            type="text"
            id="sessionUserNameInput"
            class="${s(t3, "input")} ${s(t3, "user-input")}"
            autocomplete="username"
            data-hub-conference-user-input
          />
        </div>
        <div class="${s(t3, "change-user-actions")}">
          <button
            type="button"
            class="${s(t3, "primary")}"
            data-hub-conference-change-user-done
          ></button>
        </div>
      </div>
    </div>
  `, c.appendChild(i);
  const b = i.querySelector(`.${s(t3, "dialog")}`), p = i.querySelector("[data-hub-conference-status]"), C2 = i.querySelector(
    "[data-hub-conference-open-another-user]"
  ), E3 = i.querySelector(
    "[data-hub-conference-change-user-overlay]"
  ), v2 = i.querySelector(
    "[data-hub-conference-change-user-done]"
  ), w2 = i.querySelector(
    "[data-hub-conference-change-user-close]"
  ), N = i.querySelector("#sessionUserNameInput"), $2 = i.querySelector("[data-hub-conference-user-note]"), D3 = typeof (e == null ? void 0 : e.onUserNameChange) == "function" ? e.onUserNameChange : null, I3 = i.querySelector("[data-hub-conference-create]"), S2 = i.querySelector(
    "[data-hub-conference-create-form]"
  ), U2 = i.querySelector("[data-hub-conference-manage]"), H3 = i.querySelector("[data-hub-conference-join-section]"), A2 = i.querySelector("[data-hub-conference-title-select]"), re2 = i.querySelector("[data-hub-conference-custom-group]"), W3 = i.querySelector("[data-hub-conference-custom-title]"), q2 = i.querySelector("[data-hub-conference-topics]"), T2 = i.querySelector("[data-hub-conference-join-select]"), le3 = i.querySelector("[data-hub-conference-info]"), F3 = i.querySelector("[data-hub-conference-create-btn]"), k3 = i.querySelector("[data-hub-conference-join-btn]"), ee2 = i.querySelector("[data-hub-conference-close]");
  function ue3(r) {
    !I3 || !S2 || !H3 || (r ? I3.insertBefore(H3, S2) : I3.insertBefore(S2, H3));
  }
  function Ae2() {
    if (!(A2 instanceof HTMLSelectElement)) return;
    const r = String(A2.value || "");
    A2.replaceChildren();
    const f2 = document.createElement("option");
    f2.value = "", f2.textContent = a.selectConferenceTitle, A2.appendChild(f2);
    for (const m of ms) {
      const L2 = document.createElement("option");
      L2.value = m, L2.textContent = m, m === "Anatomy class" && (L2.selected = true), A2.appendChild(L2);
    }
    const h = document.createElement("option");
    h.value = "other", h.textContent = a.otherTitle, A2.appendChild(h), r && [...A2.options].some((m) => m.value === r) && (A2.value = r);
  }
  function de5() {
    const r = (f2, h) => {
      const m = i.querySelector(f2);
      m && (m.textContent = h);
    };
    r("[data-hub-conference-dialog-title]", a.dialogTitle), r("[data-hub-conference-create-section]", a.createSection), r("[data-hub-conference-title-label]", a.conferenceTitle), r("[data-hub-conference-custom-label]", a.customTitle), r("[data-hub-conference-users-label]", a.users), r("[data-hub-conference-loading-users]", a.loadingUsers), r("[data-hub-conference-join-section-title]", a.joinSection), r("[data-hub-conference-active-label]", a.activeConferences), F3 && (F3.textContent = a.createConference), k3 && (k3.textContent = a.joinConference), i.querySelectorAll("[data-hub-conference-user-label]").forEach((f2) => {
      f2 instanceof HTMLElement && (f2.textContent = a.userLabel);
    }), r("[data-hub-conference-change-user-title]", a.changeUserNameTitle), C2 instanceof HTMLElement && (C2.textContent = a.openAnotherUser, C2.title = a.openAnotherUserTitle), v2 instanceof HTMLElement && (v2.textContent = a.done), $2 instanceof HTMLElement && ($2.textContent = a.userNameSavedNote), N instanceof HTMLInputElement && (N.placeholder = a.userNamePlaceholder), W3 instanceof HTMLInputElement && (W3.placeholder = a.customTitlePlaceholder), ee2 instanceof HTMLElement && ee2.setAttribute("aria-label", a.closeAria), w2 instanceof HTMLElement && w2.setAttribute("aria-label", a.closeAria), Ae2(), oe3();
  }
  function ke2() {
  }
  function fe2() {
    return i.querySelector("[data-hub-conference-user-name-btn]");
  }
  function oe3() {
    const r = fe2();
    if (!(r instanceof HTMLElement)) return;
    const f2 = String(_3().userName || "").trim() || "\u2014";
    r.textContent = f2, r.title = a.changeUserNameTitle, r.setAttribute("aria-label", a.changeUserName);
  }
  function Me2() {
    const r = document.createElement("button");
    r.type = "button", r.className = `${s(t3, "secondary")} ${s(t3, "user-name-btn")}`, r.dataset.hubConferenceUserNameBtn = "";
    const f2 = String(_3().userName || "").trim() || "\u2014";
    return r.textContent = f2, r.title = a.changeUserNameTitle, r.setAttribute("aria-label", a.changeUserName), r;
  }
  function he2(r = "") {
    const f2 = document.createElement("div");
    f2.className = `${s(t3, "topic-row")} ${s(t3, "topic-row-self")}`;
    const h = String(_3().topic || "").trim(), m = document.createElement("input");
    m.type = "checkbox", m.dataset.hubConferenceTopic = "1", m.value = h, m.checked = true, f2.appendChild(m), f2.appendChild(Me2());
    const L2 = ge2(r);
    if (L2) {
      const x2 = document.createElement("span");
      x2.className = s(t3, "topic-timezone"), x2.textContent = L2, f2.appendChild(x2);
    }
    return f2;
  }
  function X2(r, { error: f2 = false } = {}) {
    if (!($2 instanceof HTMLElement)) return;
    const h = String(r || "").trim();
    if (!h) {
      $2.hidden = true, $2.textContent = "";
      return;
    }
    $2.hidden = false, $2.textContent = h, $2.classList.toggle(s(t3, "status-error"), f2);
  }
  async function me3(r, f2 = {}) {
    const h = String(r || "").trim();
    if (!h) return false;
    const m = _3(), L2 = String(m.topic || "").trim(), x2 = String(m.userName || "").trim();
    return f2.excludeSelf !== false && (h === L2 || h === x2) || !m.hubEndpoint ? false : (await gs(
      m.hubEndpoint,
      m.accessToken
    )).some((R2) => String((R2 == null ? void 0 : R2.topic) || "").trim() === h);
  }
  async function Ue2() {
    const r = a.openAnotherUserPrompt || "User name for new session", f2 = window.prompt(r, "STUDENT-1");
    if (f2 === null) return;
    const h = String(f2).trim();
    if (!h) return;
    if (await me3(h, { excludeSelf: false })) {
      X2(a.userNameAlreadyExists, { error: true });
      return;
    }
    const m = new URL(window.location.href);
    m.searchParams.set("userName", h), m.searchParams.set("topic", h), m.searchParams.delete("freshUser"), window.open(m.href, "_blank", "noopener,noreferrer"), J3(), V2();
  }
  function qe() {
    E3 instanceof HTMLElement && (N instanceof HTMLInputElement && (N.value = String(_3().userName || "").trim()), X2("", {}), E3.hidden = false, N instanceof HTMLInputElement && (N.focus(), N.select()));
  }
  function J3() {
    E3 instanceof HTMLElement && (E3.hidden = true);
  }
  async function be2() {
    if (!(N instanceof HTMLInputElement)) return;
    const r = N.value.trim();
    if (!r) return;
    const f2 = _3(), h = String(f2.userName || "").trim();
    if (r === h) {
      J3();
      return;
    }
    if (await me3(r, { excludeSelf: true })) {
      X2(a.userNameAlreadyExists, { error: true });
      return;
    }
    v2 instanceof HTMLButtonElement && (v2.disabled = true), X2(a.userNameSwitchingNote || "Switching user\u2026");
    try {
      D3 && await D3(r);
      const m = fe2();
      m instanceof HTMLElement && (m.textContent = r || "\u2014"), X2(a.userNameSavedNote), J3(), te2();
    } catch (m) {
      const L2 = m instanceof Error && m.message ? m.message : a.userNameAlreadyExists;
      X2(L2, { error: true });
    } finally {
      v2 instanceof HTMLButtonElement && (v2.disabled = false);
    }
  }
  de5();
  function j2(r, f2) {
    if (!p)
      return;
    const h = String(f2 || "").trim();
    if (p.classList.remove(
      s(t3, "status-success"),
      s(t3, "status-error")
    ), !h) {
      p.hidden = true, p.textContent = "";
      return;
    }
    p.hidden = false, p.textContent = h, r === "success" ? p.classList.add(s(t3, "status-success")) : r === "error" && p.classList.add(s(t3, "status-error"));
  }
  function pe2(r) {
    g = r, o && o(r);
  }
  function _3() {
    const r = n() || {};
    return {
      hubEndpoint: String(r.hubEndpoint ?? "").trim(),
      topic: String(r.topic ?? "").trim(),
      subscriberName: String(r.subscriberName ?? "").trim(),
      userName: String(r.userName ?? "").trim(),
      connected: !!r.connected,
      accessToken: String(r.accessToken ?? "").trim()
    };
  }
  function je2() {
    const r = String((A2 == null ? void 0 : A2.value) || "").trim();
    return r === "other" ? String((W3 == null ? void 0 : W3.value) || "").trim() : r;
  }
  function Pe2() {
    return q2 ? Array.from(
      q2.querySelectorAll(
        'input[type="checkbox"][data-hub-conference-topic]:checked'
      )
    ).map((r) => String(r.value || "").trim()).filter(Boolean) : [];
  }
  function ge2(r) {
    var h;
    const f2 = String(r || "").trim();
    if (!f2) return "";
    try {
      const L2 = (h = new Intl.DateTimeFormat("en", {
        timeZone: f2,
        timeZoneName: "shortOffset"
      }).formatToParts(/* @__PURE__ */ new Date()).find((x2) => x2.type === "timeZoneName")) == null ? void 0 : h.value;
      return L2 ? `${f2} (${L2})` : f2;
    } catch {
      return f2;
    }
  }
  function ye2(r) {
    if (!q2)
      return;
    q2.replaceChildren();
    const f2 = String(_3().topic || "").trim();
    let h = false, m = 0;
    const L2 = Array.isArray(r) ? r : [];
    for (const x2 of L2) {
      const B2 = typeof x2 == "string" ? String(x2).trim() : String((x2 == null ? void 0 : x2.topic) ?? "").trim();
      if (!B2) continue;
      const R2 = typeof x2 == "string" ? "" : String((x2 == null ? void 0 : x2.timezone) ?? "").trim();
      if (f2 && B2 === f2) {
        q2.appendChild(he2(R2)), h = true, m += 1;
        continue;
      }
      const O2 = document.createElement("label");
      O2.className = s(t3, "topic-row");
      const G3 = document.createElement("input");
      G3.type = "checkbox", G3.dataset.hubConferenceTopic = "1", G3.value = B2, G3.checked = true;
      const Y3 = document.createElement("span");
      Y3.className = s(t3, "topic-label"), Y3.textContent = B2, O2.appendChild(G3), O2.appendChild(Y3);
      const ve = ge2(R2);
      if (ve) {
        const se2 = document.createElement("span");
        se2.className = s(t3, "topic-timezone"), se2.textContent = ve, O2.appendChild(se2);
      }
      q2.appendChild(O2), m += 1;
    }
    if (f2 && !h && (q2.insertBefore(
      he2(""),
      q2.firstChild
    ), m += 1), !m) {
      const x2 = document.createElement("p");
      x2.className = s(t3, "muted"), x2.textContent = a.noUsers, q2.appendChild(x2);
    }
    oe3();
  }
  function Se2(r, f2) {
    if (!T2 || !k3) return;
    const h = (Array.isArray(r) ? r : []).filter(
      (B2) => B2 && typeof B2 == "object" && !Ke2(
        f2,
        /** @type {Record<string, unknown>} */
        B2
      )
    ), m = String(T2.value || "");
    if (T2.replaceChildren(), !h.length) {
      T2.replaceChildren(), T2.disabled = true, k3.disabled = true, H3 instanceof HTMLElement && (H3.hidden = true), ue3(false);
      return;
    }
    H3 instanceof HTMLElement && (H3.hidden = false);
    const L2 = document.createElement("option");
    L2.value = "", L2.textContent = a.selectConference, T2.appendChild(L2);
    const x2 = [];
    for (const B2 of h) {
      const R2 = (
        /** @type {Record<string, unknown>} */
        B2
      ), O2 = Z(R2);
      if (!O2) continue;
      x2.push(O2);
      const G3 = String(R2.title || "").trim() || a.untitled, Y3 = document.createElement("option");
      Y3.value = O2, Y3.textContent = `${G3} \u2014 ${O2}`, T2.appendChild(Y3);
    }
    T2.disabled = false, m && x2.includes(m) ? T2.value = m : x2.length && (T2.value = x2[0]), k3.disabled = !String(T2.value || "").trim(), ue3(true);
  }
  function ce3(r) {
    if (I3 && (I3.hidden = !!r), U2 && (U2.hidden = !r), r && le3) {
      const f2 = r.places.length ? `<div class="${s(t3, "places")}">${r.places.map((h) => {
        const m = [s(t3, "place")];
        h.isSelf && m.push(s(t3, "place-self")), h.isLeading && m.push(s(t3, "place-leading")), h.isFollowing && m.push(s(t3, "place-following"));
        const L2 = h.statusLabel ? `<span class="${s(t3, "place-status")}">${Z2(
          h.statusLabel
        )}</span>` : "";
        return `<span class="${m.join(
          " "
        )}" title="${Z2(h.placeId)}"><span class="${s(
          t3,
          "place-name"
        )}">${Z2(h.label)}</span>${L2}</span>`;
      }).join("")}</div>` : `<div class="${s(t3, "muted")}">${Z2(a.noPlaces)}</div>`;
      le3.innerHTML = `<div><strong>${Z2(a.titleLabel)}</strong> ${Z2(
        r.title || a.na
      )}</div><div class="${s(t3, "places-label")}">${Z2(
        a.participants
      )}</div>${f2}`;
    }
  }
  async function te2() {
    const r = _3();
    if (!r.hubEndpoint || !r.connected)
      return ye2([]), Se2([], r.topic), ce3(null), pe2(null), null;
    const [f2, h] = await Promise.all([
      gs(r.hubEndpoint, r.accessToken),
      at(r.hubEndpoint, r.accessToken)
    ]), m = ct(
      r.topic,
      r.subscriberName,
      h
    ), L2 = Kt(r, m);
    return m || (ye2(f2), Se2(h, r.topic)), ce3(L2), pe2(L2), L2;
  }
  async function Ie2() {
    if (y)
      return;
    const r = _3(), f2 = je2(), h = Pe2();
    if (!r.connected) {
      j2("error", a.connectHubFirst);
      return;
    }
    if (!r.topic) {
      j2("error", a.topicRequiredHost);
      return;
    }
    if (!f2) {
      j2("error", a.titleRequired);
      return;
    }
    if (!h.length) {
      j2("error", a.selectAttendee);
      return;
    }
    y = true, F3 && (F3.disabled = true, F3.textContent = a.creating), j2("", "");
    try {
      await ys(
        r.hubEndpoint,
        r.topic,
        f2,
        h,
        r.userName,
        r.accessToken
      ), await te2(), V2();
    } catch (m) {
      j2(
        "error",
        m instanceof Error ? m.message : a.failedCreate
      );
    } finally {
      y = false, F3 && (F3.disabled = false, F3.textContent = a.createConference);
    }
  }
  async function Fe2() {
    if (y) return;
    const r = _3(), f2 = String((T2 == null ? void 0 : T2.value) || "").trim();
    if (!r.connected) {
      j2("error", a.connectHubFirst);
      return;
    }
    if (!r.topic) {
      j2("error", a.topicRequiredJoin);
      return;
    }
    if (!f2) {
      j2("error", a.selectConferenceToJoin);
      return;
    }
    y = true, k3 && (k3.disabled = true, k3.textContent = a.joining), j2("", "");
    try {
      await ps(
        r.hubEndpoint,
        f2,
        r.topic,
        r.userName,
        r.accessToken
      ), l == null || l(true), await te2(), V2();
    } catch (h) {
      j2(
        "error",
        h instanceof Error ? h.message : a.failedJoin
      );
    } finally {
      y = false, k3 && (k3.textContent = a.joinConference, k3.disabled = !String((T2 == null ? void 0 : T2.value) || "").trim());
    }
  }
  function Be2() {
    Te2(
      i,
      b instanceof HTMLElement ? b : null,
      s(t3, "overlay-anchored")
    );
  }
  function ie(r) {
    Ze({
      overlay: i,
      dialog: b instanceof HTMLElement ? b : null,
      anchor: r,
      anchoredClass: s(t3, "overlay-anchored"),
      align: u
    });
  }
  function _e3(r) {
    j2("", ""), A2 && (A2.value = "Anatomy class"), W3 && (W3.value = ""), re2 && (re2.hidden = true), J3(), $2 instanceof HTMLElement && ($2.hidden = true), oe3(), d = r instanceof HTMLElement ? r : null, i.hidden = false, ie(d), b instanceof HTMLElement && b.focus({ preventScroll: true }), te2().then(() => ie(d)).catch(() => {
    });
  }
  function V2() {
    J3(), i.hidden = true, j2("", ""), Be2(), d = null;
  }
  function Oe2() {
    V2(), i.remove();
  }
  function De2(r) {
    a = Q2(r), de5(), g && ce3(g);
  }
  return A2 == null || A2.addEventListener("change", () => {
    re2 && (re2.hidden = String(A2.value || "") !== "other");
  }), T2 == null || T2.addEventListener("change", () => {
    k3 && (k3.disabled = !String(T2.value || "").trim() || y);
  }), F3 == null || F3.addEventListener("click", () => {
    Ie2().catch(() => {
    });
  }), k3 == null || k3.addEventListener("click", () => {
    Fe2().catch(() => {
    });
  }), ee2 == null || ee2.addEventListener("click", (r) => {
    r.stopPropagation(), V2();
  }), q2 == null || q2.addEventListener("click", (r) => {
    const f2 = r.target;
    if (!(f2 instanceof Element)) return;
    const h = f2.closest("[data-hub-conference-user-name-btn]");
    !(h instanceof HTMLElement) || !q2.contains(h) || (r.stopPropagation(), qe());
  }), v2 == null || v2.addEventListener("click", (r) => {
    r.stopPropagation(), be2();
  }), w2 == null || w2.addEventListener("click", (r) => {
    r.stopPropagation(), J3();
  }), C2 == null || C2.addEventListener("click", (r) => {
    r.stopPropagation(), Ue2();
  }), N == null || N.addEventListener("keydown", (r) => {
    r.key === "Enter" ? (r.preventDefault(), be2()) : r.key === "Escape" && (r.preventDefault(), J3());
  }), E3 == null || E3.addEventListener("click", (r) => {
    r.target === E3 && J3();
  }), i.addEventListener("click", (r) => {
    r.target === i && V2();
  }), window.addEventListener("resize", () => {
    i.hidden || ie(d);
  }), {
    open: _e3,
    close: V2,
    destroy: Oe2,
    refresh: te2,
    setStrings: De2,
    syncSessionControl: ke2,
    getSessionControl: () => ({
      button: null,
      label: null
    }),
    getView: () => g,
    get element() {
      return i;
    }
  };
}
var Le2 = "ID";
function dt2(e = {}) {
  const n = Array.isArray(e.selfActors) ? e.selfActors.map((u) => String(u || "").trim()).filter(Boolean) : [], o = Array.isArray(e.connectedActors) ? e.connectedActors.map((u) => String(u || "").trim()).filter(Boolean) : [];
  return n.some(
    (u) => u === Le2 || u.toUpperCase() === "ID"
  ) ? true : !o.some(
    (u) => u === Le2 || u.toUpperCase() === "ID"
  );
}
function Xe2(e) {
  const n = e && typeof e == "object" ? (
    /** @type {{ event?: Record<string, unknown> }} */
    e.event
  ) : null;
  if (!n || typeof n != "object")
    return null;
  const o = String(n["hub.event"] || "").trim().toLowerCase();
  if (o !== "conference-start" && o !== "conference-end" && o !== "conference-lead")
    return null;
  const l = n.context && typeof n.context == "object" ? (
    /** @type {Record<string, unknown>} */
    n.context
  ) : {}, t3 = String(
    l.hostTopic || n["hub.topic"] || ""
  ).trim(), u = String(l.title || "").trim(), c = String(l.hostUserName || "").trim(), a = String(l.sceneLeaderTopic || "").trim(), g = String(
    l.leaderUserName || l.leaderLabel || ""
  ).trim(), y = g || a || c || t3 || "host", d = String(l.joinedTopic || "").trim();
  return {
    hubEvent: o,
    title: u,
    hostTopic: t3,
    hostUserName: c,
    hostLabel: c || t3 || "host",
    sceneLeaderTopic: a,
    leaderUserName: g,
    leaderLabel: y,
    joinedTopic: d
  };
}
function M2(e, n) {
  return `${e}-${n}`;
}
function Qe2(e = {}) {
  const n = typeof e.onDecision == "function" ? e.onDecision : null, o = String(
    e.classPrefix || "hub-conference-invite"
  ).trim(), l = e.root || (typeof document < "u" ? document.body : null);
  if (!l)
    throw new Error("createHubConferenceInviteDialog requires a DOM root");
  let t3 = Q2(e.strings), u = null, c = false;
  const a = document.createElement("div");
  a.className = M2(o, "overlay"), a.hidden = true, a.innerHTML = `
    <div class="${M2(o, "dialog")}" role="dialog" aria-modal="true" aria-labelledby="${M2(o, "title")}" tabindex="-1">
      <div class="${M2(o, "header")}">
        <h2 id="${M2(o, "title")}" class="${M2(o, "title")}" data-hub-invite-title></h2>
        <button type="button" class="${M2(o, "close")}" data-hub-invite-close aria-label="">\xD7</button>
      </div>
      <div class="${M2(o, "body")}">
        <p class="${M2(o, "lead")}" data-hub-invite-lead></p>
        <p class="${M2(o, "status")}" data-hub-invite-status role="alert" hidden></p>
        <div class="${M2(o, "actions")}">
          <button type="button" class="${M2(o, "primary")}" data-hub-invite-follow></button>
          <button type="button" class="${M2(o, "secondary")}" data-hub-invite-join></button>
          <button type="button" class="${M2(o, "secondary")}" data-hub-invite-decline></button>
        </div>
      </div>
    </div>
  `, l.appendChild(a);
  const g = a.querySelector(`.${M2(o, "dialog")}`), y = a.querySelector("[data-hub-invite-title]"), d = a.querySelector("[data-hub-invite-lead]"), i = a.querySelector("[data-hub-invite-status]"), b = a.querySelector("[data-hub-invite-follow]"), p = a.querySelector("[data-hub-invite-join]"), C2 = a.querySelector("[data-hub-invite-decline]"), E3 = a.querySelector("[data-hub-invite-close]");
  function v2() {
    y && (y.textContent = t3.inviteTitle), p && (p.textContent = t3.joinNoFollow), C2 && (C2.textContent = t3.doNotJoin), E3 instanceof HTMLElement && E3.setAttribute("aria-label", t3.closeAria), b && u ? b.textContent = ae(
      t3.joinAndFollowHost,
      { host: u.hostLabel || t3.hostFallback }
    ) : b && (b.textContent = t3.joinAndFollow);
  }
  v2();
  function w2(S2, U2) {
    if (!(i instanceof HTMLElement)) return;
    const H3 = String(U2 || "").trim();
    i.hidden = !H3, i.textContent = H3, i.classList.toggle(M2(o, "status-error"), S2 === "error");
  }
  function N(S2) {
    c = S2;
    for (const U2 of [b, p, C2])
      U2 instanceof HTMLButtonElement && (U2.disabled = S2);
  }
  function $2() {
    a.hidden = true, u = null, w2("", ""), N(false);
  }
  function D3(S2) {
    const U2 = String(
      (S2 == null ? void 0 : S2.hostLabel) || (S2 == null ? void 0 : S2.hostUserName) || (S2 == null ? void 0 : S2.hostTopic) || t3.hostFallback
    ).trim() || t3.hostFallback, H3 = String((S2 == null ? void 0 : S2.title) || "").trim();
    u = {
      hubEvent: "conference-start",
      title: H3,
      hostTopic: String((S2 == null ? void 0 : S2.hostTopic) || "").trim(),
      hostUserName: String((S2 == null ? void 0 : S2.hostUserName) || "").trim(),
      hostLabel: U2
    }, d instanceof HTMLElement && (d.textContent = H3 ? ae(t3.inviteLeadWithTitle, {
      title: H3,
      host: U2
    }) : ae(t3.inviteLeadNoTitle, {
      host: U2
    })), b instanceof HTMLElement && (b.textContent = ae(
      t3.joinAndFollowHost,
      { host: U2 }
    )), w2("", ""), a.hidden = false, g instanceof HTMLElement && g.focus({ preventScroll: true });
  }
  async function I3(S2) {
    if (c || !u) return;
    const U2 = u;
    N(true);
    try {
      n && await n(S2, U2), $2();
    } catch (H3) {
      w2(
        "error",
        H3 instanceof Error ? H3.message : t3.failedUpdate
      ), N(false);
    }
  }
  return b == null || b.addEventListener("click", () => {
    I3("join-follow");
  }), p == null || p.addEventListener("click", () => {
    I3("join");
  }), C2 == null || C2.addEventListener("click", () => {
    I3("decline");
  }), a.querySelectorAll("[data-hub-invite-close]").forEach((S2) => {
    S2.addEventListener("click", () => $2());
  }), a.addEventListener("click", (S2) => {
    S2.target === a && $2();
  }), {
    open: D3,
    close: $2,
    /**
     * @param {Partial<import('./conferenceStrings.js').CastConferenceStrings> | null | undefined} next
     */
    setStrings(S2) {
      t3 = Q2(S2), v2(), u && !a.hidden && D3(u);
    },
    destroy() {
      $2(), a.remove();
    },
    isOpen() {
      return !a.hidden;
    },
    getInvite() {
      return u;
    },
    element: a
  };
}
function ft2(e) {
  const n = typeof (e == null ? void 0 : e.getSession) == "function" ? e.getSession : () => ({}), o = typeof (e == null ? void 0 : e.shouldShow) == "function" ? e.shouldShow : () => true, l = typeof (e == null ? void 0 : e.onConferenceChange) == "function" ? e.onConferenceChange : null, t3 = typeof (e == null ? void 0 : e.onFollowChange) == "function" ? e.onFollowChange : null, u = typeof (e == null ? void 0 : e.onLeadChange) == "function" ? e.onLeadChange : null, c = (e == null ? void 0 : e.dialog) || Qe2({
    root: e == null ? void 0 : e.root,
    classPrefix: e == null ? void 0 : e.classPrefix,
    strings: e == null ? void 0 : e.strings,
    onDecision: async (d, i) => {
      await g(d, i);
    }
  });
  async function a() {
    const d = n(), i = await ws(
      d.hubEndpoint || "",
      d.topic || "",
      d.subscriberName || "",
      d.userName || "",
      d.accessToken || ""
    );
    return l == null || l(i), i;
  }
  async function g(d, i) {
    const b = n(), p = String((i == null ? void 0 : i.hostTopic) || "").trim();
    if (!p)
      throw new Error("Missing conference host topic.");
    if (d === "decline") {
      const v2 = String(b.topic || "").trim();
      if (v2)
        try {
          await Ss(
            b.hubEndpoint || "",
            p,
            v2,
            b.accessToken || ""
          );
        } catch {
        }
      t3 == null || t3(false), l == null || l(null);
      return;
    }
    const C2 = String(b.topic || "").trim();
    if (!C2)
      throw new Error("Hub topic is required to join a conference.");
    await ps(
      b.hubEndpoint || "",
      p,
      C2,
      b.userName || b.subscriberName || "",
      b.accessToken || ""
    );
    const E3 = d === "join-follow";
    t3 == null || t3(E3, E3 ? i : void 0), await a();
  }
  function y(d) {
    const i = Xe2(d);
    if (!i) return false;
    const b = n(), p = String(b.topic || "").trim();
    if (i.hubEvent === "conference-lead") {
      const E3 = String(i.sceneLeaderTopic || "").trim(), v2 = !!p && !!E3 && (p === E3 || p.toLowerCase() === E3.toLowerCase());
      return t3 == null || t3(!v2, i), a().then(() => {
        u == null || u(i);
      }), true;
    }
    if (i.hubEvent === "conference-end") {
      const E3 = (
        /** @type {{ context?: Record<string, unknown> }} */
        d.event || {}
      ), v2 = E3.context && typeof E3.context == "object" ? E3.context : {}, w2 = String(v2.leaveTopic || "").trim();
      return !w2 || w2 === p ? (c.close(), t3 == null || t3(false), l == null || l(null)) : a(), true;
    }
    if (p && i.hostTopic && (p === i.hostTopic || p.toLowerCase() === i.hostTopic.toLowerCase()))
      return t3 == null || t3(false), a(), true;
    const C2 = String(i.joinedTopic || "").trim();
    return p && C2 && (p === C2 || p.toLowerCase() === C2.toLowerCase()) ? (t3 == null || t3(true, i), a(), true) : o() ? (c.open(i), a(), true) : (a(), true);
  }
  return {
    handleHubMessage: y,
    open: (d) => c.open(d),
    close: () => c.close(),
    destroy: () => c.destroy(),
    refresh: a,
    /**
     * @param {Partial<import('./conferenceStrings.js').CastConferenceStrings> | null | undefined} next
     */
    setStrings(d) {
      var i;
      (i = c.setStrings) == null || i.call(c, d);
    },
    dialog: c
  };
}
function P(e, n) {
  return `${e}-${n}`;
}
function $e2(e) {
  var l;
  if (!((l = e == null ? void 0 : e.places) != null && l.length)) return null;
  const n = e.places.find((t3) => t3 && t3.isLeading);
  if (n) return n;
  const o = String(e.leadingPlaceId || "").trim();
  return o && e.places.find(
    (t3) => t3 && (t3.placeId === o || t3.placeId.toLowerCase() === o.toLowerCase())
  ) || null;
}
function et2(e, n = true) {
  return e != null && e.isFollowing ? n ? "Following" : "Skipping" : String((e == null ? void 0 : e.statusLabel) || "").trim();
}
function Ne2(e, n, o = "short", l = true, t3 = "") {
  if ((n === "leading" || n === "following" ? n : e != null && e.isLeading ? "leading" : "following") === "leading")
    return o === "full" ? "You \xB7 leading" : "Leading";
  const c = String(t3 || "").trim();
  if (!l)
    return c ? `Skipping ${c}` : o === "full" ? "You \xB7 skipping" : "Skipping";
  if (c) return `Following ${c}`;
  if (o === "full") {
    const a = String((e == null ? void 0 : e.statusLabel) || "").trim();
    return a || "You";
  }
  return "Following";
}
function tt2(e, n, o = true) {
  if (!e) return "";
  if (e.isSelf) {
    const l = $e2(n);
    return Ne2(
      e,
      n == null ? void 0 : n.selfRole,
      "short",
      o,
      l && !l.isSelf ? l.label : ""
    );
  }
  return et2(e, o);
}
function nt2(e, n) {
  e.classList.remove(n, `${n}-leading`);
  const o = e.querySelector("[data-hub-conference-role]");
  o instanceof HTMLElement && (o.hidden = true, o.textContent = "");
}
function He2(e, n, o, l, t3) {
  const u = (n.places || []).filter((c) => c && (t3 || !c.isSelf));
  for (const c of u) {
    const a = document.createElement("div");
    a.className = P(o, "chip"), a.setAttribute("role", "listitem"), c.isSelf && a.classList.add(P(o, "chip-self")), c.isLeading && a.classList.add(P(o, "chip-leading")), c.isFollowing && (a.classList.add(P(o, "chip-following")), l || a.classList.add(P(o, "chip-skipping")));
    const g = tt2(
      c,
      n,
      l
    ), y = document.createElement("span");
    y.className = P(o, "chip-name"), y.textContent = c.label;
    const d = [c.label, g, c.placeId].map((i) => String(i || "").trim()).filter(Boolean).join(" \u2014 ");
    if (y.title = d, a.title = d, a.append(y), g) {
      const i = document.createElement("span");
      i.className = P(o, "chip-status"), i.textContent = g, a.append(i);
    }
    e.append(a);
  }
}
function ht(e) {
  var v2;
  const n = (e == null ? void 0 : e.view) ?? null, o = e == null ? void 0 : e.statusControl, l = (e == null ? void 0 : e.chipsHost) instanceof HTMLElement ? e.chipsHost : null, t3 = String((e == null ? void 0 : e.classPrefix) || "hub-conference").trim() || "hub-conference", u = String((e == null ? void 0 : e.statusClassPrefix) || P(t3, "user")).trim() || P(t3, "user"), c = (e == null ? void 0 : e.selfStatusMode) === "full" ? "full" : "short", a = (e == null ? void 0 : e.followHost) !== false, g = P(t3, "chip-status");
  if (!(o instanceof HTMLElement))
    return;
  if (!!!((v2 = n == null ? void 0 : n.places) != null && v2.length)) {
    nt2(o, u), l && (l.replaceChildren(), l.hidden = true), z();
    return;
  }
  const d = n.places.find((w2) => w2 && w2.isSelf) || null, i = $e2(n), b = n.selfRole === "leading" || !!(d != null && d.isLeading), p = i && !i.isSelf ? String(i.label || "").trim() : "";
  o.classList.add(u), o.classList.toggle(`${u}-leading`, b);
  let C2 = o.querySelector("[data-hub-conference-role]");
  if (C2 instanceof HTMLElement || (C2 = document.createElement("span"), C2.dataset.hubConferenceRole = "1", o.append(C2)), C2.className = g, C2.hidden = false, C2.textContent = Ne2(
    d,
    n.selfRole,
    c,
    a,
    p
  ), !l)
    return;
  if (l.replaceChildren(), !n.places.filter((w2) => w2 && !w2.isSelf).length) {
    l.hidden = true;
    return;
  }
  l.hidden = false, He2(l, n, t3, a, false);
}
var K2 = null;
function z() {
  K2 && (K2.cleanup(), K2 = null);
}
function rt2(e = {}) {
  var b;
  const n = Q2(e.strings), o = e.view ?? null, l = !!e.followHost, t3 = !!e.connected, u = !!((b = o == null ? void 0 : o.places) != null && b.length), c = (o == null ? void 0 : o.selfRole) === "leading", g = !!(o != null && o.isConferenceOwner) ? n.endConference : n.leaveConference, y = u && !c && l, d = u && !c && !l, i = t3 ? n.conferencing : n.subscribeHubFirst;
  return {
    active: u,
    start: {
      // Keep Conferencing available while active so User/topic + Manage stay reachable.
      hidden: false,
      disabled: !t3,
      label: n.conferencing,
      title: i,
      ariaLabel: n.conferencing
    },
    leave: {
      hidden: !u,
      disabled: !t3 || !u,
      label: g,
      title: g,
      ariaLabel: g
    },
    stopFollowing: {
      hidden: !y,
      label: n.stopFollowing,
      title: n.stopFollowing,
      ariaLabel: n.stopFollowing
    },
    resumeFollowing: {
      hidden: !d,
      label: n.resumeFollowing,
      title: n.resumeFollowing,
      ariaLabel: n.resumeFollowing
    },
    takeOver: {
      hidden: !d,
      disabled: !t3 || !d,
      label: n.takeOver,
      title: n.takeOver,
      ariaLabel: n.takeOver
    }
  };
}
function ne2(e, n) {
  e instanceof HTMLElement && (typeof n.hidden == "boolean" && (e.hidden = n.hidden), typeof n.disabled == "boolean" && "disabled" in e && (e.disabled = n.disabled, n.disabled || e.removeAttribute("disabled")), typeof n.label == "string" && !e.querySelector("svg") && (e.textContent = n.label), typeof n.title == "string" && (e.title = n.title), typeof n.ariaLabel == "string" && e.setAttribute("aria-label", n.ariaLabel));
}
function pt2(e = {}) {
  const n = rt2({
    view: e.view,
    followHost: e.followHost,
    connected: e.connected,
    strings: e.strings
  });
  return ne2(e.startBtn, n.start), ne2(e.endBtn, n.leave), ne2(e.stopFollowBtn, n.stopFollowing), ne2(e.resumeFollowBtn, n.resumeFollowing), ne2(e.takeOverBtn, n.takeOver), n;
}
function gt2(e = {}) {
  return new Promise((n) => {
    if (typeof document > "u") {
      n(false);
      return;
    }
    const o = Q2(e.strings), l = String(
      e.classPrefix || "hub-conference-takeover"
    ).trim(), t3 = e.root || document.body, u = document.createElement("div");
    u.className = `${l}-overlay`, u.setAttribute("role", "presentation"), u.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:10040",
      "display:flex",
      "align-items:center",
      "justify-content:center",
      "background:rgba(0,0,0,.45)",
      "padding:16px"
    ].join(";");
    const c = document.createElement("div");
    c.className = `${l}-dialog`, c.setAttribute("role", "dialog"), c.setAttribute("aria-modal", "true"), c.setAttribute("aria-labelledby", `${l}-title`), c.tabIndex = -1, c.style.cssText = [
      "width:min(420px,100%)",
      "background:#121820",
      "color:#e8eef8",
      "border:1px solid #33507e",
      "border-radius:10px",
      "box-shadow:0 16px 40px rgba(0,0,0,.4)",
      "padding:18px 18px 14px",
      "font:14px/1.45 -apple-system,system-ui,sans-serif"
    ].join(";"), c.innerHTML = `
      <h2 id="${l}-title" style="margin:0 0 10px;font:700 16px/1.3 -apple-system,system-ui,sans-serif;"></h2>
      <p data-hub-takeover-body style="margin:0 0 16px;opacity:.92;"></p>
      <div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;">
        <button type="button" data-hub-takeover-cancel style="padding:7px 12px;border-radius:6px;border:1px solid #4a628a;background:#1a2332;color:#e8eef8;cursor:pointer;font:600 13px -apple-system,system-ui,sans-serif;"></button>
        <button type="button" data-hub-takeover-confirm style="padding:7px 12px;border-radius:6px;border:1px solid #2b6cb0;background:#2b6cb0;color:#fff;cursor:pointer;font:600 13px -apple-system,system-ui,sans-serif;"></button>
      </div>
    `;
    const a = c.querySelector(`#${l}-title`), g = c.querySelector("[data-hub-takeover-body]"), y = c.querySelector("[data-hub-takeover-cancel]"), d = c.querySelector("[data-hub-takeover-confirm]");
    a && (a.textContent = o.takeoverTitle), g && (g.textContent = o.takeoverBody), y && (y.textContent = o.cancel), d && (d.textContent = o.takeOver), u.appendChild(c), t3.appendChild(u);
    let i = false;
    const b = (p) => {
      i || (i = true, u.remove(), n(!!p));
    };
    u.addEventListener("click", (p) => {
      p.target === u && b(false);
    }), y == null || y.addEventListener("click", () => b(false)), d == null || d.addEventListener("click", () => b(true)), c.addEventListener("keydown", (p) => {
      p.key === "Escape" && (p.preventDefault(), b(false));
    }), c.focus({ preventScroll: true });
  });
}
function yt2(e, n = {}) {
  var g;
  const o = String(e || "").trim();
  if (!o || typeof document > "u")
    return;
  const l = Math.max(1e3, Number(n.ms) || 4e3), t3 = String(n.classPrefix || "hub-info-toast").trim(), u = n.root || (typeof document < "u" ? document.body : null);
  if (!u)
    return;
  const c = (g = u.querySelector) == null ? void 0 : g.call(u, `.${t3}`);
  c && c.remove();
  const a = document.createElement("div");
  a.className = t3, a.setAttribute("role", "status"), a.textContent = o, a.style.cssText = [
    "position:fixed",
    "left:50%",
    "bottom:28px",
    "transform:translateX(-50%)",
    "z-index:10050",
    "max-width:min(420px,calc(100vw - 32px))",
    "padding:10px 16px",
    "border-radius:8px",
    "background:#1a2332",
    "color:#e8eef8",
    "font:600 13px/1.35 -apple-system,system-ui,sans-serif",
    "box-shadow:0 8px 28px rgba(0,0,0,.35)",
    "pointer-events:none"
  ].join(";"), u.appendChild(a), window.setTimeout(() => {
    a.remove();
  }, l);
}
var at2 = "hub-radio-icon";
var ot2 = `<svg class="${at2}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"/></svg>`;
var st2 = "hub-conference-icon";
var St = `<svg class="${st2}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`;
function Ct(e, n = {}) {
  return n == null || n.conferenceActive, e === "connected" ? {
    tone: "connected",
    showSlash: false,
    pulse: false,
    conferencePulse: false
  } : e === "connecting" || e === "token-ready" ? {
    tone: "connecting",
    showSlash: false,
    pulse: true,
    conferencePulse: false
  } : e === "error" || e === "disconnected" ? {
    tone: "error",
    showSlash: true,
    pulse: false,
    conferencePulse: false
  } : {
    tone: "idle",
    showSlash: true,
    pulse: false,
    conferencePulse: false
  };
}

// ../../node_modules/i18next/dist/esm/i18next.js
var isString = (obj) => typeof obj === "string";
var defer = () => {
  let res;
  let rej;
  const promise = new Promise((resolve, reject) => {
    res = resolve;
    rej = reject;
  });
  promise.resolve = res;
  promise.reject = rej;
  return promise;
};
var makeString = (object) => {
  if (object == null) return "";
  return String(object);
};
var copy = (a, s2, t3) => {
  a.forEach((m) => {
    if (s2[m]) t3[m] = s2[m];
  });
};
var lastOfPathSeparatorRegExp = /###/g;
var cleanKey = (key) => key && key.includes("###") ? key.replace(lastOfPathSeparatorRegExp, ".") : key;
var canNotTraverseDeeper = (object) => !object || isString(object);
var getLastOfPath = (object, path, Empty) => {
  const stack = !isString(path) ? path : path.split(".");
  let stackIndex = 0;
  while (stackIndex < stack.length - 1) {
    if (canNotTraverseDeeper(object)) return {};
    const key = cleanKey(stack[stackIndex]);
    if (!object[key] && Empty) object[key] = new Empty();
    if (Object.prototype.hasOwnProperty.call(object, key)) {
      object = object[key];
    } else {
      object = {};
    }
    ++stackIndex;
  }
  if (canNotTraverseDeeper(object)) return {};
  return {
    obj: object,
    k: cleanKey(stack[stackIndex])
  };
};
var setPath = (object, path, newValue) => {
  const {
    obj,
    k: k3
  } = getLastOfPath(object, path, Object);
  if (obj !== void 0 || path.length === 1) {
    obj[k3] = newValue;
    return;
  }
  let e = path[path.length - 1];
  let p = path.slice(0, path.length - 1);
  let last = getLastOfPath(object, p, Object);
  while (last.obj === void 0 && p.length) {
    e = `${p[p.length - 1]}.${e}`;
    p = p.slice(0, p.length - 1);
    last = getLastOfPath(object, p, Object);
    if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== "undefined") {
      last.obj = void 0;
    }
  }
  last.obj[`${last.k}.${e}`] = newValue;
};
var pushPath = (object, path, newValue, concat) => {
  const {
    obj,
    k: k3
  } = getLastOfPath(object, path, Object);
  obj[k3] = obj[k3] || [];
  obj[k3].push(newValue);
};
var getPath = (object, path) => {
  const {
    obj,
    k: k3
  } = getLastOfPath(object, path);
  if (!obj) return void 0;
  if (!Object.prototype.hasOwnProperty.call(obj, k3)) return void 0;
  return obj[k3];
};
var getPathWithDefaults = (data, defaultData, key) => {
  const value = getPath(data, key);
  if (value !== void 0) {
    return value;
  }
  return getPath(defaultData, key);
};
var deepExtend = (target, source, overwrite) => {
  for (const prop in source) {
    if (prop !== "__proto__" && prop !== "constructor") {
      if (Object.prototype.hasOwnProperty.call(target, prop)) {
        if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
          if (overwrite) target[prop] = source[prop];
        } else {
          deepExtend(target[prop], source[prop], overwrite);
        }
      } else {
        target[prop] = source[prop];
      }
    }
  }
  return target;
};
var regexEscape = (str) => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
var _entityMap = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
  "/": "&#x2F;"
};
var escape = (data) => {
  if (isString(data)) {
    return data.replace(/[&<>"'\/]/g, (s2) => _entityMap[s2]);
  }
  return data;
};
var RegExpCache = class {
  constructor(capacity) {
    this.capacity = capacity;
    this.regExpMap = /* @__PURE__ */ new Map();
    this.regExpQueue = [];
  }
  getRegExp(pattern) {
    const regExpFromCache = this.regExpMap.get(pattern);
    if (regExpFromCache !== void 0) {
      return regExpFromCache;
    }
    const regExpNew = new RegExp(pattern);
    if (this.regExpQueue.length === this.capacity) {
      this.regExpMap.delete(this.regExpQueue.shift());
    }
    this.regExpMap.set(pattern, regExpNew);
    this.regExpQueue.push(pattern);
    return regExpNew;
  }
};
var chars = [" ", ",", "?", "!", ";"];
var looksLikeObjectPathRegExpCache = new RegExpCache(20);
var looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
  nsSeparator = nsSeparator || "";
  keySeparator = keySeparator || "";
  const possibleChars = chars.filter((c) => !nsSeparator.includes(c) && !keySeparator.includes(c));
  if (possibleChars.length === 0) return true;
  const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map((c) => c === "?" ? "\\?" : c).join("|")})`);
  let matched = !r.test(key);
  if (!matched) {
    const ki = key.indexOf(keySeparator);
    if (ki > 0 && !r.test(key.substring(0, ki))) {
      matched = true;
    }
  }
  return matched;
};
var deepFind = (obj, path, keySeparator = ".") => {
  if (!obj) return void 0;
  if (obj[path]) {
    if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
    return obj[path];
  }
  const tokens = path.split(keySeparator);
  let current = obj;
  for (let i = 0; i < tokens.length; ) {
    if (!current || typeof current !== "object") {
      return void 0;
    }
    let next;
    let nextPath = "";
    for (let j2 = i; j2 < tokens.length; ++j2) {
      if (j2 !== i) {
        nextPath += keySeparator;
      }
      nextPath += tokens[j2];
      next = current[nextPath];
      if (next !== void 0) {
        if (["string", "number", "boolean"].includes(typeof next) && j2 < tokens.length - 1) {
          continue;
        }
        i += j2 - i + 1;
        break;
      }
    }
    current = next;
  }
  return current;
};
var getCleanedCode = (code) => code?.replace(/_/g, "-");
var consoleLogger = {
  type: "logger",
  log(args) {
    this.output("log", args);
  },
  warn(args) {
    this.output("warn", args);
  },
  error(args) {
    this.output("error", args);
  },
  output(type, args) {
    console?.[type]?.apply?.(console, args);
  }
};
var Logger = class _Logger {
  constructor(concreteLogger, options = {}) {
    this.init(concreteLogger, options);
  }
  init(concreteLogger, options = {}) {
    this.prefix = options.prefix || "i18next:";
    this.logger = concreteLogger || consoleLogger;
    this.options = options;
    this.debug = options.debug;
  }
  log(...args) {
    return this.forward(args, "log", "", true);
  }
  warn(...args) {
    return this.forward(args, "warn", "", true);
  }
  error(...args) {
    return this.forward(args, "error", "");
  }
  deprecate(...args) {
    return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
  }
  forward(args, lvl, prefix, debugOnly) {
    if (debugOnly && !this.debug) return null;
    args = args.map((a) => isString(a) ? a.replace(/[\r\n\x00-\x1F\x7F]/g, " ") : a);
    if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
    return this.logger[lvl](args);
  }
  create(moduleName) {
    return new _Logger(this.logger, {
      ...{
        prefix: `${this.prefix}:${moduleName}:`
      },
      ...this.options
    });
  }
  clone(options) {
    options = options || this.options;
    options.prefix = options.prefix || this.prefix;
    return new _Logger(this.logger, options);
  }
};
var baseLogger = new Logger();
var EventEmitter = class {
  constructor() {
    this.observers = {};
  }
  on(events, listener) {
    events.split(" ").forEach((event) => {
      if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
      const numListeners = this.observers[event].get(listener) || 0;
      this.observers[event].set(listener, numListeners + 1);
    });
    return this;
  }
  off(event, listener) {
    if (!this.observers[event]) return;
    if (!listener) {
      delete this.observers[event];
      return;
    }
    this.observers[event].delete(listener);
  }
  once(event, listener) {
    const wrapper = (...args) => {
      listener(...args);
      this.off(event, wrapper);
    };
    this.on(event, wrapper);
    return this;
  }
  emit(event, ...args) {
    if (this.observers[event]) {
      const cloned = Array.from(this.observers[event].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer(...args);
        }
      });
    }
    if (this.observers["*"]) {
      const cloned = Array.from(this.observers["*"].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer(event, ...args);
        }
      });
    }
  }
};
var ResourceStore = class extends EventEmitter {
  constructor(data, options = {
    ns: ["translation"],
    defaultNS: "translation"
  }) {
    super();
    this.data = data || {};
    this.options = options;
    if (this.options.keySeparator === void 0) {
      this.options.keySeparator = ".";
    }
    if (this.options.ignoreJSONStructure === void 0) {
      this.options.ignoreJSONStructure = true;
    }
  }
  addNamespaces(ns) {
    if (!this.options.ns.includes(ns)) {
      this.options.ns.push(ns);
    }
  }
  removeNamespaces(ns) {
    const index = this.options.ns.indexOf(ns);
    if (index > -1) {
      this.options.ns.splice(index, 1);
    }
  }
  getResource(lng, ns, key, options = {}) {
    const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
    const ignoreJSONStructure = options.ignoreJSONStructure !== void 0 ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
    let path;
    if (lng.includes(".")) {
      path = lng.split(".");
    } else {
      path = [lng, ns];
      if (key) {
        if (Array.isArray(key)) {
          path.push(...key);
        } else if (isString(key) && keySeparator) {
          path.push(...key.split(keySeparator));
        } else {
          path.push(key);
        }
      }
    }
    const result = getPath(this.data, path);
    if (!result && !ns && !key && lng.includes(".")) {
      lng = path[0];
      ns = path[1];
      key = path.slice(2).join(".");
    }
    if (result || !ignoreJSONStructure || !isString(key)) return result;
    return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
  }
  addResource(lng, ns, key, value, options = {
    silent: false
  }) {
    const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
    let path = [lng, ns];
    if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.includes(".")) {
      path = lng.split(".");
      value = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    setPath(this.data, path, value);
    if (!options.silent) this.emit("added", lng, ns, key, value);
  }
  addResources(lng, ns, resources, options = {
    silent: false
  }) {
    for (const m in resources) {
      if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], {
        silent: true
      });
    }
    if (!options.silent) this.emit("added", lng, ns, resources);
  }
  addResourceBundle(lng, ns, resources, deep, overwrite, options = {
    silent: false,
    skipCopy: false
  }) {
    let path = [lng, ns];
    if (lng.includes(".")) {
      path = lng.split(".");
      deep = resources;
      resources = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    let pack = getPath(this.data, path) || {};
    if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
    if (deep) {
      deepExtend(pack, resources, overwrite);
    } else {
      pack = {
        ...pack,
        ...resources
      };
    }
    setPath(this.data, path, pack);
    if (!options.silent) this.emit("added", lng, ns, resources);
  }
  removeResourceBundle(lng, ns) {
    if (this.hasResourceBundle(lng, ns)) {
      delete this.data[lng][ns];
    }
    this.removeNamespaces(ns);
    this.emit("removed", lng, ns);
  }
  hasResourceBundle(lng, ns) {
    return this.getResource(lng, ns) !== void 0;
  }
  getResourceBundle(lng, ns) {
    if (!ns) ns = this.options.defaultNS;
    return this.getResource(lng, ns);
  }
  getDataByLanguage(lng) {
    return this.data[lng];
  }
  hasLanguageSomeTranslations(lng) {
    const data = this.getDataByLanguage(lng);
    const n = data && Object.keys(data) || [];
    return !!n.find((v2) => data[v2] && Object.keys(data[v2]).length > 0);
  }
  toJSON() {
    return this.data;
  }
};
var postProcessor = {
  processors: {},
  addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle(processors, value, key, options, translator) {
    processors.forEach((processor) => {
      value = this.processors[processor]?.process(value, key, options, translator) ?? value;
    });
    return value;
  }
};
var PATH_KEY = Symbol("i18next/PATH_KEY");
function createProxy() {
  const state = [];
  const handler = /* @__PURE__ */ Object.create(null);
  let proxy;
  handler.get = (target, key) => {
    proxy?.revoke?.();
    if (key === PATH_KEY) return state;
    state.push(key);
    proxy = Proxy.revocable(target, handler);
    return proxy.proxy;
  };
  return Proxy.revocable(/* @__PURE__ */ Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
  const {
    [PATH_KEY]: path
  } = selector(createProxy());
  const keySeparator = opts?.keySeparator ?? ".";
  const nsSeparator = opts?.nsSeparator ?? ":";
  const strict = opts?.enableSelector === "strict";
  if (path.length > 1 && nsSeparator) {
    const ns = opts?.ns;
    const nsList = strict ? Array.isArray(ns) ? ns : ns ? [ns] : null : Array.isArray(ns) ? ns : null;
    if (nsList) {
      const candidates = strict ? nsList : nsList.length > 1 ? nsList.slice(1) : [];
      if (candidates.includes(path[0])) {
        return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
      }
    }
  }
  return path.join(keySeparator);
}
var shouldHandleAsObject = (res) => !isString(res) && typeof res !== "boolean" && typeof res !== "number";
var Translator = class _Translator extends EventEmitter {
  constructor(services, options = {}) {
    super();
    copy(["resourceStore", "languageUtils", "pluralResolver", "interpolator", "backendConnector", "i18nFormat", "utils"], services, this);
    this.options = options;
    if (this.options.keySeparator === void 0) {
      this.options.keySeparator = ".";
    }
    this.logger = baseLogger.create("translator");
    this.checkedLoadedFor = {};
  }
  changeLanguage(lng) {
    if (lng) this.language = lng;
  }
  exists(key, o = {
    interpolation: {}
  }) {
    const opt = {
      ...o
    };
    if (key == null) return false;
    const resolved = this.resolve(key, opt);
    if (resolved?.res === void 0) return false;
    const isObject = shouldHandleAsObject(resolved.res);
    if (opt.returnObjects === false && isObject) {
      return false;
    }
    return true;
  }
  extractFromKey(key, opt) {
    let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === void 0) nsSeparator = ":";
    const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
    let namespaces = opt.ns || this.options.defaultNS || [];
    const wouldCheckForNsInKey = nsSeparator && key.includes(nsSeparator);
    const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
    if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
      const m = key.match(this.interpolator.nestingRegexp);
      if (m && m.length > 0) {
        return {
          key,
          namespaces: isString(namespaces) ? [namespaces] : namespaces
        };
      }
      const parts = key.split(nsSeparator);
      if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.includes(parts[0])) namespaces = parts.shift();
      key = parts.join(keySeparator);
    }
    return {
      key,
      namespaces: isString(namespaces) ? [namespaces] : namespaces
    };
  }
  translate(keys, o, lastKey) {
    let opt = typeof o === "object" ? {
      ...o
    } : o;
    if (typeof opt !== "object" && this.options.overloadTranslationOptionHandler) {
      opt = this.options.overloadTranslationOptionHandler(arguments);
    }
    if (typeof opt === "object") opt = {
      ...opt
    };
    if (!opt) opt = {};
    if (keys == null) return "";
    if (typeof keys === "function") keys = keysFromSelector(keys, {
      ...this.options,
      ...opt
    });
    if (!Array.isArray(keys)) keys = [String(keys)];
    keys = keys.map((k3) => typeof k3 === "function" ? keysFromSelector(k3, {
      ...this.options,
      ...opt
    }) : String(k3));
    const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
    const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
    const {
      key,
      namespaces
    } = this.extractFromKey(keys[keys.length - 1], opt);
    const namespace = namespaces[namespaces.length - 1];
    let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === void 0) nsSeparator = ":";
    const lng = opt.lng || this.language;
    const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
    if (lng?.toLowerCase() === "cimode") {
      if (appendNamespaceToCIMode) {
        if (returnDetails) {
          return {
            res: `${namespace}${nsSeparator}${key}`,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt)
          };
        }
        return `${namespace}${nsSeparator}${key}`;
      }
      if (returnDetails) {
        return {
          res: key,
          usedKey: key,
          exactUsedKey: key,
          usedLng: lng,
          usedNS: namespace,
          usedParams: this.getUsedParamsDetails(opt)
        };
      }
      return key;
    }
    const resolved = this.resolve(keys, opt);
    let res = resolved?.res;
    const resUsedKey = resolved?.usedKey || key;
    const resExactUsedKey = resolved?.exactUsedKey || key;
    const noObject = ["[object Number]", "[object Function]", "[object RegExp]"];
    const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
    const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
    const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
    const hasDefaultValue = _Translator.hasDefaultValue(opt);
    const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : "";
    const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, {
      ordinal: false
    }) : "";
    const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
    const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
    let resForObjHndl = res;
    if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
      resForObjHndl = defaultValue;
    }
    const handleAsObject = shouldHandleAsObject(resForObjHndl);
    const resType = Object.prototype.toString.apply(resForObjHndl);
    if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && !noObject.includes(resType) && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
      if (!opt.returnObjects && !this.options.returnObjects) {
        if (!this.options.returnedObjectHandler) {
          this.logger.warn("accessing an object - but returnObjects options is not enabled!");
        }
        const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
          ...opt,
          ns: namespaces
        }) : `key '${key} (${this.language})' returned an object instead of string.`;
        if (returnDetails) {
          resolved.res = r;
          resolved.usedParams = this.getUsedParamsDetails(opt);
          return resolved;
        }
        return r;
      }
      if (keySeparator) {
        const resTypeIsArray = Array.isArray(resForObjHndl);
        const copy2 = resTypeIsArray ? [] : {};
        const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
        for (const m in resForObjHndl) {
          if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
            const deepKey = `${newKeyToUse}${keySeparator}${m}`;
            if (hasDefaultValue && !res) {
              copy2[m] = this.translate(deepKey, {
                ...opt,
                defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            } else {
              copy2[m] = this.translate(deepKey, {
                ...opt,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            }
            if (copy2[m] === deepKey) copy2[m] = resForObjHndl[m];
          }
        }
        res = copy2;
      }
    } else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
      res = res.join(joinArrays);
      if (res) res = this.extendTranslation(res, keys, opt, lastKey);
    } else {
      let usedDefault = false;
      let usedKey = false;
      if (!this.isValidLookup(res) && hasDefaultValue) {
        usedDefault = true;
        res = defaultValue;
      }
      if (!this.isValidLookup(res)) {
        usedKey = true;
        res = key;
      }
      const missingKeyNoValueFallbackToKey = opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
      const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? void 0 : res;
      const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
      if (usedKey || usedDefault || updateMissing) {
        this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace, needsPluralHandling && !updateMissing ? `${key}${this.pluralResolver.getSuffix(lng, opt.count, opt)}` : key, updateMissing ? defaultValue : res);
        if (keySeparator) {
          const fk = this.resolve(key, {
            ...opt,
            keySeparator: false
          });
          if (fk && fk.res) this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
        }
        let lngs = [];
        const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
        if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) {
          for (let i = 0; i < fallbackLngs.length; i++) {
            lngs.push(fallbackLngs[i]);
          }
        } else if (this.options.saveMissingTo === "all") {
          lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
        } else {
          lngs.push(opt.lng || this.language);
        }
        const send = (l, k3, specificDefaultValue) => {
          const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
          if (this.options.missingKeyHandler) {
            this.options.missingKeyHandler(l, namespace, k3, defaultForMissing, updateMissing, opt);
          } else if (this.backendConnector?.saveMissing) {
            this.backendConnector.saveMissing(l, namespace, k3, defaultForMissing, updateMissing, opt);
          }
          this.emit("missingKey", l, namespace, k3, res);
        };
        if (this.options.saveMissing) {
          if (this.options.saveMissingPlurals && needsPluralHandling) {
            lngs.forEach((language) => {
              const suffixes = this.pluralResolver.getSuffixes(language, opt);
              if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && !suffixes.includes(`${this.options.pluralSeparator}zero`)) {
                suffixes.push(`${this.options.pluralSeparator}zero`);
              }
              suffixes.forEach((suffix) => {
                send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
              });
            });
          } else {
            send(lngs, key, defaultValue);
          }
        }
      }
      res = this.extendTranslation(res, keys, opt, resolved, lastKey);
      if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
        res = `${namespace}${nsSeparator}${key}`;
      }
      if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
        res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : void 0, opt);
      }
    }
    if (returnDetails) {
      resolved.res = res;
      resolved.usedParams = this.getUsedParamsDetails(opt);
      return resolved;
    }
    return res;
  }
  extendTranslation(res, key, opt, resolved, lastKey) {
    if (this.i18nFormat?.parse) {
      res = this.i18nFormat.parse(res, {
        ...this.options.interpolation.defaultVariables,
        ...opt
      }, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, {
        resolved
      });
    } else if (!opt.skipInterpolation) {
      if (opt.interpolation) this.interpolator.init({
        ...opt,
        ...{
          interpolation: {
            ...this.options.interpolation,
            ...opt.interpolation
          }
        }
      });
      const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== void 0 ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
      let nestBef;
      if (skipOnVariables) {
        const nb = res.match(this.interpolator.nestingRegexp);
        nestBef = nb && nb.length;
      }
      let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
      if (this.options.interpolation.defaultVariables) data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
      res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
      if (skipOnVariables) {
        const na = res.match(this.interpolator.nestingRegexp);
        const nestAft = na && na.length;
        if (nestBef < nestAft) opt.nest = false;
      }
      if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
      if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
        if (lastKey?.[0] === args[0] && !opt.context) {
          this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
          return null;
        }
        return this.translate(...args, key);
      }, opt);
      if (opt.interpolation) this.interpolator.reset();
    }
    const postProcess = opt.postProcess || this.options.postProcess;
    const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
    if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
      res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
        i18nResolved: {
          ...resolved,
          usedParams: this.getUsedParamsDetails(opt)
        },
        ...opt
      } : opt, this);
    }
    return res;
  }
  resolve(keys, opt = {}) {
    let found;
    let usedKey;
    let exactUsedKey;
    let usedLng;
    let usedNS;
    if (isString(keys)) keys = [keys];
    if (Array.isArray(keys)) keys = keys.map((k3) => typeof k3 === "function" ? keysFromSelector(k3, {
      ...this.options,
      ...opt
    }) : k3);
    keys.forEach((k3) => {
      if (this.isValidLookup(found)) return;
      const extracted = this.extractFromKey(k3, opt);
      const key = extracted.key;
      usedKey = key;
      let namespaces = extracted.namespaces;
      if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
      const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const needsContextHandling = opt.context !== void 0 && (isString(opt.context) || typeof opt.context === "number") && opt.context !== "";
      const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
      namespaces.forEach((ns) => {
        if (this.isValidLookup(found)) return;
        usedNS = ns;
        if (!this.checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
          this.checkedLoadedFor[`${codes[0]}-${ns}`] = true;
          this.logger.warn(`key "${usedKey}" for languages "${codes.join(", ")}" won't get resolved as namespace "${usedNS}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
        }
        codes.forEach((code) => {
          if (this.isValidLookup(found)) return;
          usedLng = code;
          const finalKeys = [key];
          if (this.i18nFormat?.addLookupKeys) {
            this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
          } else {
            let pluralSuffix;
            if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
            const zeroSuffix = `${this.options.pluralSeparator}zero`;
            const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
            if (needsPluralHandling) {
              if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) {
                finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
              }
              finalKeys.push(key + pluralSuffix);
              if (needsZeroSuffixLookup) {
                finalKeys.push(key + zeroSuffix);
              }
            }
            if (needsContextHandling) {
              const contextKey = `${key}${this.options.contextSeparator || "_"}${opt.context}`;
              finalKeys.push(contextKey);
              if (needsPluralHandling) {
                if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) {
                  finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                finalKeys.push(contextKey + pluralSuffix);
                if (needsZeroSuffixLookup) {
                  finalKeys.push(contextKey + zeroSuffix);
                }
              }
            }
          }
          let possibleKey;
          while (possibleKey = finalKeys.pop()) {
            if (!this.isValidLookup(found)) {
              exactUsedKey = possibleKey;
              found = this.getResource(code, ns, possibleKey, opt);
            }
          }
        });
      });
    });
    return {
      res: found,
      usedKey,
      exactUsedKey,
      usedLng,
      usedNS
    };
  }
  isValidLookup(res) {
    return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
  }
  getResource(code, ns, key, options = {}) {
    if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
    return this.resourceStore.getResource(code, ns, key, options);
  }
  getUsedParamsDetails(options = {}) {
    const optionsKeys = ["defaultValue", "ordinal", "context", "replace", "lng", "lngs", "fallbackLng", "ns", "keySeparator", "nsSeparator", "returnObjects", "returnDetails", "joinArrays", "postProcess", "interpolation"];
    const useOptionsReplaceForData = options.replace && !isString(options.replace);
    let data = useOptionsReplaceForData ? options.replace : options;
    if (useOptionsReplaceForData && typeof options.count !== "undefined") {
      data = {
        ...data,
        count: options.count
      };
    }
    if (this.options.interpolation.defaultVariables) {
      data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
    }
    if (!useOptionsReplaceForData) {
      data = {
        ...data
      };
      for (const key of optionsKeys) {
        delete data[key];
      }
    }
    return data;
  }
  static hasDefaultValue(options) {
    const prefix = "defaultValue";
    for (const option in options) {
      if (Object.prototype.hasOwnProperty.call(options, option) && option.startsWith(prefix) && void 0 !== options[option]) {
        return true;
      }
    }
    return false;
  }
};
var LanguageUtil = class {
  constructor(options) {
    this.options = options;
    this.supportedLngs = this.options.supportedLngs || false;
    this.logger = baseLogger.create("languageUtils");
    this.resolveHierarchyCache = {};
  }
  clearCache() {
    this.resolveHierarchyCache = {};
  }
  getScriptPartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || !code.includes("-")) return null;
    const p = code.split("-");
    if (p.length === 2) return null;
    p.pop();
    if (p[p.length - 1].toLowerCase() === "x") return null;
    return this.formatLanguageCode(p.join("-"));
  }
  getLanguagePartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || !code.includes("-")) return code;
    const p = code.split("-");
    return this.formatLanguageCode(p[0]);
  }
  formatLanguageCode(code) {
    if (isString(code) && code.includes("-")) {
      let formattedCode;
      try {
        formattedCode = Intl.getCanonicalLocales(code)[0];
      } catch (e) {
      }
      if (formattedCode && this.options.lowerCaseLng) {
        formattedCode = formattedCode.toLowerCase();
      }
      if (formattedCode) return formattedCode;
      if (this.options.lowerCaseLng) {
        return code.toLowerCase();
      }
      return code;
    }
    return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
  }
  isSupportedCode(code) {
    if (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) {
      code = this.getLanguagePartFromCode(code);
    }
    return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.includes(code);
  }
  getBestMatchFromCodes(codes) {
    if (!codes) return null;
    let found;
    codes.forEach((code) => {
      if (found) return;
      const cleanedLng = this.formatLanguageCode(code);
      if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
    });
    if (!found && this.options.supportedLngs) {
      codes.forEach((code) => {
        if (found) return;
        const lngScOnly = this.getScriptPartFromCode(code);
        if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
        const lngOnly = this.getLanguagePartFromCode(code);
        if (this.isSupportedCode(lngOnly)) return found = lngOnly;
        found = this.options.supportedLngs.find((supportedLng) => {
          if (supportedLng === lngOnly) return true;
          if (!supportedLng.includes("-") && !lngOnly.includes("-")) return false;
          if (supportedLng.includes("-") && !lngOnly.includes("-") && supportedLng.slice(0, supportedLng.indexOf("-")) === lngOnly) return true;
          if (supportedLng.startsWith(lngOnly) && lngOnly.length > 1) return true;
          return false;
        });
      });
    }
    if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
    return found;
  }
  getFallbackCodes(fallbacks, code) {
    if (!fallbacks) return [];
    if (typeof fallbacks === "function") fallbacks = fallbacks(code);
    if (isString(fallbacks)) fallbacks = [fallbacks];
    if (Array.isArray(fallbacks)) return fallbacks;
    if (!code) return fallbacks.default || [];
    let found = fallbacks[code];
    if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
    if (!found) found = fallbacks[this.formatLanguageCode(code)];
    if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
    if (!found) found = fallbacks.default;
    return found || [];
  }
  toResolveHierarchy(code, fallbackCode) {
    const fallbackLng = this.options.fallbackLng;
    const fallbackLngKey = Array.isArray(fallbackLng) ? fallbackLng.join("|") : fallbackLng;
    if (fallbackLngKey !== this._cachedFallbackLng) {
      this.resolveHierarchyCache = {};
      this._cachedFallbackLng = fallbackLngKey;
    }
    const hasCacheableFallback = fallbackCode === void 0 || fallbackCode === false || isString(fallbackCode);
    const usesUncacheableOptionsFallback = fallbackCode === void 0 && typeof this.options.fallbackLng === "function";
    const cacheable = isString(code) && hasCacheableFallback && !usesUncacheableOptionsFallback;
    let cacheKey = null;
    if (cacheable) {
      let fallbackCacheKey;
      if (fallbackCode === void 0) fallbackCacheKey = "undefined";
      else if (fallbackCode === false) fallbackCacheKey = "boolean:false";
      else fallbackCacheKey = `string:${fallbackCode}`;
      cacheKey = `${code.length}:${code}|${fallbackCacheKey}`;
    }
    if (cacheKey !== null) {
      const cached2 = this.resolveHierarchyCache[cacheKey];
      if (cached2 !== void 0) return cached2.slice();
    }
    const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
    const codes = [];
    const addCode = (c) => {
      if (!c) return;
      if (this.isSupportedCode(c)) {
        codes.push(c);
      } else {
        this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
      }
    };
    if (isString(code) && (code.includes("-") || code.includes("_"))) {
      if (this.options.load !== "languageOnly") addCode(this.formatLanguageCode(code));
      if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly") addCode(this.getScriptPartFromCode(code));
      if (this.options.load !== "currentOnly") addCode(this.getLanguagePartFromCode(code));
    } else if (isString(code)) {
      addCode(this.formatLanguageCode(code));
    }
    fallbackCodes.forEach((fc) => {
      if (!codes.includes(fc)) addCode(this.formatLanguageCode(fc));
    });
    if (cacheKey !== null) {
      this.resolveHierarchyCache[cacheKey] = codes;
      return codes.slice();
    }
    return codes;
  }
};
var suffixesOrder = {
  zero: 0,
  one: 1,
  two: 2,
  few: 3,
  many: 4,
  other: 5
};
var dummyRule = {
  select: (count) => count === 1 ? "one" : "other",
  resolvedOptions: () => ({
    pluralCategories: ["one", "other"]
  })
};
var PluralResolver = class {
  constructor(languageUtils, options = {}) {
    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create("pluralResolver");
    this.pluralRulesCache = {};
  }
  clearCache() {
    this.pluralRulesCache = {};
  }
  getRule(code, options = {}) {
    const cleanedCode = getCleanedCode(code === "dev" ? "en" : code);
    const type = options.ordinal ? "ordinal" : "cardinal";
    const cacheKey = JSON.stringify({
      cleanedCode,
      type
    });
    if (cacheKey in this.pluralRulesCache) {
      return this.pluralRulesCache[cacheKey];
    }
    let rule;
    try {
      rule = new Intl.PluralRules(cleanedCode, {
        type
      });
    } catch (err) {
      if (typeof Intl === "undefined") {
        this.logger.error("No Intl support, please use an Intl polyfill!");
        return dummyRule;
      }
      if (!code.match(/-|_/)) return dummyRule;
      const lngPart = this.languageUtils.getLanguagePartFromCode(code);
      rule = this.getRule(lngPart, options);
    }
    this.pluralRulesCache[cacheKey] = rule;
    return rule;
  }
  needsPlural(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule("dev", options);
    return rule?.resolvedOptions().pluralCategories.length > 1;
  }
  getPluralFormsOfKey(code, key, options = {}) {
    return this.getSuffixes(code, options).map((suffix) => `${key}${suffix}`);
  }
  getSuffixes(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule("dev", options);
    if (!rule) return [];
    return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map((pluralCategory) => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${pluralCategory}`);
  }
  getSuffix(code, count, options = {}) {
    const rule = this.getRule(code, options);
    if (rule) {
      return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${rule.select(count)}`;
    }
    this.logger.warn(`no plural rule found for: ${code}`);
    return this.getSuffix("dev", count, options);
  }
};
var deepFindWithDefaults = (data, defaultData, key, keySeparator = ".", ignoreJSONStructure = true) => {
  let path = getPathWithDefaults(data, defaultData, key);
  if (!path && ignoreJSONStructure && isString(key)) {
    path = deepFind(data, key, keySeparator);
    if (path === void 0) path = deepFind(defaultData, key, keySeparator);
  }
  return path;
};
var regexSafe = (val) => val.replace(/\$/g, "$$$$");
var Interpolator = class {
  constructor(options = {}) {
    this.logger = baseLogger.create("interpolator");
    this.options = options;
    this.format = options?.interpolation?.format || ((value) => value);
    this.init(options);
  }
  init(options = {}) {
    if (!options.interpolation) options.interpolation = {
      escapeValue: true
    };
    const {
      escape: escape$1,
      escapeValue,
      useRawValueToEscape,
      prefix,
      prefixEscaped,
      suffix,
      suffixEscaped,
      formatSeparator,
      unescapeSuffix,
      unescapePrefix,
      nestingPrefix,
      nestingPrefixEscaped,
      nestingSuffix,
      nestingSuffixEscaped,
      nestingOptionsSeparator,
      maxReplaces,
      alwaysFormat
    } = options.interpolation;
    this.escape = escape$1 !== void 0 ? escape$1 : escape;
    this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
    this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
    this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || "{{";
    this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || "}}";
    this.formatSeparator = formatSeparator || ",";
    this.unescapePrefix = unescapeSuffix ? "" : unescapePrefix ? regexEscape(unescapePrefix) : "-";
    this.unescapeSuffix = this.unescapePrefix ? "" : unescapeSuffix ? regexEscape(unescapeSuffix) : "";
    this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape("$t(");
    this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(")");
    this.nestingOptionsSeparator = nestingOptionsSeparator || ",";
    this.maxReplaces = maxReplaces || 1e3;
    this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
    this.resetRegExp();
  }
  reset() {
    if (this.options) this.init(this.options);
  }
  resetRegExp() {
    const getOrResetRegExp = (existingRegExp, pattern) => {
      if (existingRegExp?.source === pattern) {
        existingRegExp.lastIndex = 0;
        return existingRegExp;
      }
      return new RegExp(pattern, "g");
    };
    this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
    this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
    this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
  }
  interpolate(str, data, lng, options) {
    let match;
    let value;
    let replaces;
    const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
    const handleFormat = (key) => {
      if (!key.includes(this.formatSeparator)) {
        const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
        return this.alwaysFormat ? this.format(path, void 0, lng, {
          ...options,
          ...data,
          interpolationkey: key
        }) : path;
      }
      const p = key.split(this.formatSeparator);
      const k3 = p.shift().trim();
      const f2 = p.join(this.formatSeparator).trim();
      return this.format(deepFindWithDefaults(data, defaultData, k3, this.options.keySeparator, this.options.ignoreJSONStructure), f2, lng, {
        ...options,
        ...data,
        interpolationkey: k3
      });
    };
    this.resetRegExp();
    if (!this.escapeValue && typeof str === "string" && /\$t\([^)]*\{[^}]*\{\{/.test(str)) {
      this.logger.warn("nesting options string contains interpolated variables with escapeValue: false \u2014 if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.");
    }
    const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
    const skipOnVariables = options?.interpolation?.skipOnVariables !== void 0 ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
    const todos = [{
      regex: this.regexpUnescape,
      safeValue: (val) => val
    }, {
      regex: this.regexp,
      safeValue: (val) => this.escapeValue ? this.escape(val) : val
    }];
    todos.forEach((todo) => {
      replaces = 0;
      while (match = todo.regex.exec(str)) {
        const matchedVar = match[1].trim();
        value = handleFormat(matchedVar);
        if (value === void 0) {
          if (typeof missingInterpolationHandler === "function") {
            const temp = missingInterpolationHandler(str, match, options);
            value = isString(temp) ? temp : "";
          } else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) {
            value = "";
          } else if (skipOnVariables) {
            value = match[0];
            continue;
          } else {
            this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
            value = "";
          }
        } else if (!isString(value) && !this.useRawValueToEscape) {
          value = makeString(value);
        }
        const safeValue = todo.safeValue(value);
        str = str.replace(match[0], regexSafe(safeValue));
        if (skipOnVariables) {
          todo.regex.lastIndex += safeValue.length;
          todo.regex.lastIndex -= match[0].length;
        } else {
          todo.regex.lastIndex = 0;
        }
        replaces++;
        if (replaces >= this.maxReplaces) {
          break;
        }
      }
    });
    return str;
  }
  nest(str, fc, options = {}) {
    let match;
    let value;
    let clonedOptions;
    const handleHasOptions = (key, inheritedOptions) => {
      const sep = this.nestingOptionsSeparator;
      if (!key.includes(sep)) return key;
      const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
      let optionsString = `{${c[1]}`;
      key = c[0];
      optionsString = this.interpolate(optionsString, clonedOptions);
      const matchedSingleQuotes = optionsString.match(/'/g);
      const matchedDoubleQuotes = optionsString.match(/"/g);
      if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) {
        optionsString = optionsString.replace(/'/g, '"');
      }
      try {
        clonedOptions = JSON.parse(optionsString);
        if (inheritedOptions) clonedOptions = {
          ...inheritedOptions,
          ...clonedOptions
        };
      } catch (e) {
        this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
        return `${key}${sep}${optionsString}`;
      }
      if (clonedOptions.defaultValue && clonedOptions.defaultValue.includes(this.prefix)) delete clonedOptions.defaultValue;
      return key;
    };
    while (match = this.nestingRegexp.exec(str)) {
      let formatters = [];
      clonedOptions = {
        ...options
      };
      clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
      clonedOptions.applyPostProcessor = false;
      delete clonedOptions.defaultValue;
      const keyEndIndex = /{.*}/s.test(match[1]) ? match[1].lastIndexOf("}") + 1 : match[1].indexOf(this.formatSeparator);
      if (keyEndIndex !== -1) {
        formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map((elem) => elem.trim()).filter(Boolean);
        match[1] = match[1].slice(0, keyEndIndex);
      }
      value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
      if (value && match[0] === str && !isString(value)) return value;
      if (!isString(value)) value = makeString(value);
      if (!value) {
        this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
        value = "";
      }
      if (formatters.length) {
        value = formatters.reduce((v2, f2) => this.format(v2, f2, options.lng, {
          ...options,
          interpolationkey: match[1].trim()
        }), value.trim());
      }
      str = str.replace(match[0], regexSafe(makeString(value)));
      this.regexp.lastIndex = 0;
    }
    return str;
  }
};
var parseFormatStr = (formatStr) => {
  let formatName = formatStr.toLowerCase().trim();
  const formatOptions = {};
  if (formatStr.includes("(")) {
    const p = formatStr.split("(");
    formatName = p[0].toLowerCase().trim();
    const optStr = p[1].slice(0, -1);
    if (formatName === "currency" && !optStr.includes(":")) {
      if (!formatOptions.currency) formatOptions.currency = optStr.trim();
    } else if (formatName === "relativetime" && !optStr.includes(":")) {
      if (!formatOptions.range) formatOptions.range = optStr.trim();
    } else {
      const opts = optStr.split(";");
      opts.forEach((opt) => {
        if (opt) {
          const [key, ...rest] = opt.split(":");
          const val = rest.join(":").trim().replace(/^'+|'+$/g, "");
          const trimmedKey = key.trim();
          if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
          if (val === "false") formatOptions[trimmedKey] = false;
          if (val === "true") formatOptions[trimmedKey] = true;
          if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
        }
      });
    }
  }
  return {
    formatName,
    formatOptions
  };
};
var createCachedFormatter = (fn2) => {
  const cache = {};
  return (v2, l, o) => {
    let optForCache = o;
    if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
      optForCache = {
        ...optForCache,
        [o.interpolationkey]: void 0
      };
    }
    const key = l + JSON.stringify(optForCache);
    let frm = cache[key];
    if (!frm) {
      frm = fn2(getCleanedCode(l), o);
      cache[key] = frm;
    }
    return frm(v2);
  };
};
var createNonCachedFormatter = (fn2) => (v2, l, o) => fn2(getCleanedCode(l), o)(v2);
var Formatter = class {
  constructor(options = {}) {
    this.logger = baseLogger.create("formatter");
    this.options = options;
    this.init(options);
  }
  init(services, options = {
    interpolation: {}
  }) {
    this.formatSeparator = options.interpolation.formatSeparator || ",";
    const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
    this.formats = {
      number: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt
        });
        return (val) => formatter.format(val);
      }),
      currency: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt,
          style: "currency"
        });
        return (val) => formatter.format(val);
      }),
      datetime: cf((lng, opt) => {
        const formatter = new Intl.DateTimeFormat(lng, {
          ...opt
        });
        return (val) => formatter.format(val);
      }),
      relativetime: cf((lng, opt) => {
        const formatter = new Intl.RelativeTimeFormat(lng, {
          ...opt
        });
        return (val) => formatter.format(val, opt.range || "day");
      }),
      list: cf((lng, opt) => {
        const formatter = new Intl.ListFormat(lng, {
          ...opt
        });
        return (val) => formatter.format(val);
      })
    };
  }
  add(name, fc) {
    this.formats[name.toLowerCase().trim()] = fc;
  }
  addCached(name, fc) {
    this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
  }
  format(value, format, lng, options = {}) {
    if (!format) return value;
    if (value == null) return value;
    const rawFormats = format.split(this.formatSeparator);
    const formats = [];
    for (let i = 0; i < rawFormats.length; i++) {
      let f2 = rawFormats[i];
      while (f2.indexOf("(") > -1 && !f2.includes(")") && i + 1 < rawFormats.length) {
        f2 = `${f2}${this.formatSeparator}${rawFormats[++i]}`;
      }
      formats.push(f2);
    }
    const result = formats.reduce((mem, f2) => {
      const {
        formatName,
        formatOptions
      } = parseFormatStr(f2);
      if (this.formats[formatName]) {
        let formatted = mem;
        try {
          const valOptions = options?.formatParams?.[options.interpolationkey] || {};
          const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
          formatted = this.formats[formatName](mem, l, {
            ...formatOptions,
            ...options,
            ...valOptions
          });
        } catch (error) {
          this.logger.warn(error);
        }
        return formatted;
      } else {
        this.logger.warn(`there was no format function for ${formatName}`);
      }
      return mem;
    }, value);
    return result;
  }
};
var removePending = (q2, name) => {
  if (q2.pending[name] !== void 0) {
    delete q2.pending[name];
    q2.pendingCount--;
  }
};
var Connector = class extends EventEmitter {
  constructor(backend, store, services, options = {}) {
    super();
    this.backend = backend;
    this.store = store;
    this.services = services;
    this.languageUtils = services.languageUtils;
    this.options = options;
    this.logger = baseLogger.create("backendConnector");
    this.waitingReads = [];
    this.maxParallelReads = options.maxParallelReads || 10;
    this.readingCalls = 0;
    this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
    this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
    this.state = {};
    this.queue = [];
    this.backend?.init?.(services, options.backend, options);
  }
  queueLoad(languages, namespaces, options, callback) {
    const toLoad = {};
    const pending = {};
    const toLoadLanguages = {};
    const toLoadNamespaces = {};
    languages.forEach((lng) => {
      let hasAllNamespaces = true;
      namespaces.forEach((ns) => {
        const name = `${lng}|${ns}`;
        if (!options.reload && this.store.hasResourceBundle(lng, ns)) {
          this.state[name] = 2;
        } else if (this.state[name] < 0) ;
        else if (this.state[name] === 1) {
          if (pending[name] === void 0) pending[name] = true;
        } else {
          this.state[name] = 1;
          hasAllNamespaces = false;
          if (pending[name] === void 0) pending[name] = true;
          if (toLoad[name] === void 0) toLoad[name] = true;
          if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
        }
      });
      if (!hasAllNamespaces) toLoadLanguages[lng] = true;
    });
    if (Object.keys(toLoad).length || Object.keys(pending).length) {
      this.queue.push({
        pending,
        pendingCount: Object.keys(pending).length,
        loaded: {},
        errors: [],
        callback
      });
    }
    return {
      toLoad: Object.keys(toLoad),
      pending: Object.keys(pending),
      toLoadLanguages: Object.keys(toLoadLanguages),
      toLoadNamespaces: Object.keys(toLoadNamespaces)
    };
  }
  loaded(name, err, data) {
    const s2 = name.split("|");
    const lng = s2[0];
    const ns = s2[1];
    if (err) this.emit("failedLoading", lng, ns, err);
    if (!err && data) {
      this.store.addResourceBundle(lng, ns, data, void 0, void 0, {
        skipCopy: true
      });
    }
    this.state[name] = err ? -1 : 2;
    if (err && data) this.state[name] = 0;
    const loaded = {};
    this.queue.forEach((q2) => {
      pushPath(q2.loaded, [lng], ns);
      removePending(q2, name);
      if (err) q2.errors.push(err);
      if (q2.pendingCount === 0 && !q2.done) {
        Object.keys(q2.loaded).forEach((l) => {
          if (!loaded[l]) loaded[l] = {};
          const loadedKeys = q2.loaded[l];
          if (loadedKeys.length) {
            loadedKeys.forEach((n) => {
              if (loaded[l][n] === void 0) loaded[l][n] = true;
            });
          }
        });
        q2.done = true;
        if (q2.errors.length) {
          q2.callback(q2.errors);
        } else {
          q2.callback();
        }
      }
    });
    this.emit("loaded", loaded);
    this.queue = this.queue.filter((q2) => !q2.done);
  }
  read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
    if (!lng.length) return callback(null, {});
    if (this.readingCalls >= this.maxParallelReads) {
      this.waitingReads.push({
        lng,
        ns,
        fcName,
        tried,
        wait,
        callback
      });
      return;
    }
    this.readingCalls++;
    const resolver = (err, data) => {
      this.readingCalls--;
      if (this.waitingReads.length > 0) {
        const next = this.waitingReads.shift();
        this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
      }
      if (err && data && tried < this.maxRetries) {
        setTimeout(() => {
          this.read(lng, ns, fcName, tried + 1, wait * 2, callback);
        }, wait);
        return;
      }
      callback(err, data);
    };
    const fc = this.backend[fcName].bind(this.backend);
    if (fc.length === 2) {
      try {
        const r = fc(lng, ns);
        if (r && typeof r.then === "function") {
          r.then((data) => resolver(null, data)).catch(resolver);
        } else {
          resolver(null, r);
        }
      } catch (err) {
        resolver(err);
      }
      return;
    }
    return fc(lng, ns, resolver);
  }
  prepareLoading(languages, namespaces, options = {}, callback) {
    if (!this.backend) {
      this.logger.warn("No backend was added via i18next.use. Will not load resources.");
      return callback && callback();
    }
    if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
    if (isString(namespaces)) namespaces = [namespaces];
    const toLoad = this.queueLoad(languages, namespaces, options, callback);
    if (!toLoad.toLoad.length) {
      if (!toLoad.pending.length) callback();
      return null;
    }
    toLoad.toLoad.forEach((name) => {
      this.loadOne(name);
    });
  }
  load(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {}, callback);
  }
  reload(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {
      reload: true
    }, callback);
  }
  loadOne(name, prefix = "") {
    const s2 = name.split("|");
    const lng = s2[0];
    const ns = s2[1];
    this.read(lng, ns, "read", void 0, void 0, (err, data) => {
      if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
      if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
      this.loaded(name, err, data);
    });
  }
  saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {
  }) {
    if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
      this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
      return;
    }
    if (key === void 0 || key === null || key === "") return;
    if (this.backend?.create) {
      const opts = {
        ...options,
        isUpdate
      };
      const fc = this.backend.create.bind(this.backend);
      if (fc.length < 6) {
        try {
          let r;
          if (fc.length === 5) {
            r = fc(languages, namespace, key, fallbackValue, opts);
          } else {
            r = fc(languages, namespace, key, fallbackValue);
          }
          if (r && typeof r.then === "function") {
            r.then((data) => clb(null, data)).catch(clb);
          } else {
            clb(null, r);
          }
        } catch (err) {
          clb(err);
        }
      } else {
        fc(languages, namespace, key, fallbackValue, clb, opts);
      }
    }
    if (!languages || !languages[0]) return;
    this.store.addResource(languages[0], namespace, key, fallbackValue);
  }
};
var get = () => ({
  debug: false,
  initAsync: true,
  ns: ["translation"],
  defaultNS: ["translation"],
  fallbackLng: ["dev"],
  fallbackNS: false,
  supportedLngs: false,
  nonExplicitSupportedLngs: false,
  load: "all",
  preload: false,
  keySeparator: ".",
  nsSeparator: ":",
  pluralSeparator: "_",
  contextSeparator: "_",
  enableSelector: false,
  partialBundledLanguages: false,
  saveMissing: false,
  updateMissing: false,
  saveMissingTo: "fallback",
  saveMissingPlurals: true,
  missingKeyHandler: false,
  missingInterpolationHandler: false,
  postProcess: false,
  postProcessPassResolved: false,
  returnNull: false,
  returnEmptyString: true,
  returnObjects: false,
  joinArrays: false,
  returnedObjectHandler: false,
  parseMissingKeyHandler: false,
  appendNamespaceToMissingKey: false,
  appendNamespaceToCIMode: false,
  overloadTranslationOptionHandler: (args) => {
    let ret = {};
    if (typeof args[1] === "object") ret = args[1];
    if (isString(args[1])) ret.defaultValue = args[1];
    if (isString(args[2])) ret.tDescription = args[2];
    if (typeof args[2] === "object" || typeof args[3] === "object") {
      const options = args[3] || args[2];
      Object.keys(options).forEach((key) => {
        ret[key] = options[key];
      });
    }
    return ret;
  },
  interpolation: {
    escapeValue: true,
    prefix: "{{",
    suffix: "}}",
    formatSeparator: ",",
    unescapePrefix: "-",
    nestingPrefix: "$t(",
    nestingSuffix: ")",
    nestingOptionsSeparator: ",",
    maxReplaces: 1e3,
    skipOnVariables: true
  },
  cacheInBuiltFormats: true
});
var transformOptions = (options) => {
  if (isString(options.ns)) options.ns = [options.ns];
  if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
  if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
  if (options.supportedLngs && !options.supportedLngs.includes("cimode")) {
    options.supportedLngs = options.supportedLngs.concat(["cimode"]);
  }
  return options;
};
var noop = () => {
};
var bindMemberFunctions = (inst) => {
  const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
  mems.forEach((mem) => {
    if (typeof inst[mem] === "function") {
      inst[mem] = inst[mem].bind(inst);
    }
  });
};
var I18n = class _I18n extends EventEmitter {
  constructor(options = {}, callback) {
    super();
    this.options = transformOptions(options);
    this.services = {};
    this.logger = baseLogger;
    this.modules = {
      external: []
    };
    bindMemberFunctions(this);
    if (callback && !this.isInitialized && !options.isClone) {
      if (!this.options.initAsync) {
        this.init(options, callback);
        return this;
      }
      setTimeout(() => {
        this.init(options, callback);
      }, 0);
    }
  }
  init(options = {}, callback) {
    this.isInitializing = true;
    if (typeof options === "function") {
      callback = options;
      options = {};
    }
    if (options.defaultNS == null && options.ns) {
      if (isString(options.ns)) {
        options.defaultNS = options.ns;
      } else if (!options.ns.includes("translation")) {
        options.defaultNS = options.ns[0];
      }
    }
    const defOpts = get();
    this.options = {
      ...defOpts,
      ...this.options,
      ...transformOptions(options)
    };
    this.options.interpolation = {
      ...defOpts.interpolation,
      ...this.options.interpolation
    };
    if (options.keySeparator !== void 0) {
      this.options.userDefinedKeySeparator = options.keySeparator;
    }
    if (options.nsSeparator !== void 0) {
      this.options.userDefinedNsSeparator = options.nsSeparator;
    }
    if (typeof this.options.overloadTranslationOptionHandler !== "function") {
      this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
    }
    const createClassOnDemand = (ClassOrObject) => {
      if (!ClassOrObject) return null;
      if (typeof ClassOrObject === "function") return new ClassOrObject();
      return ClassOrObject;
    };
    if (!this.options.isClone) {
      if (this.modules.logger) {
        baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
      } else {
        baseLogger.init(null, this.options);
      }
      let formatter;
      if (this.modules.formatter) {
        formatter = this.modules.formatter;
      } else {
        formatter = Formatter;
      }
      const lu = new LanguageUtil(this.options);
      this.store = new ResourceStore(this.options.resources, this.options);
      const s2 = this.services;
      s2.logger = baseLogger;
      s2.resourceStore = this.store;
      s2.languageUtils = lu;
      s2.pluralResolver = new PluralResolver(lu, {
        prepend: this.options.pluralSeparator
      });
      if (formatter) {
        s2.formatter = createClassOnDemand(formatter);
        if (s2.formatter.init) s2.formatter.init(s2, this.options);
        this.options.interpolation.format = s2.formatter.format.bind(s2.formatter);
      }
      s2.interpolator = new Interpolator(this.options);
      s2.utils = {
        hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
      };
      s2.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s2.resourceStore, s2, this.options);
      s2.backendConnector.on("*", (event, ...args) => {
        this.emit(event, ...args);
      });
      if (this.modules.languageDetector) {
        s2.languageDetector = createClassOnDemand(this.modules.languageDetector);
        if (s2.languageDetector.init) s2.languageDetector.init(s2, this.options.detection, this.options);
      }
      if (this.modules.i18nFormat) {
        s2.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
        if (s2.i18nFormat.init) s2.i18nFormat.init(this);
      }
      this.translator = new Translator(this.services, this.options);
      this.translator.on("*", (event, ...args) => {
        this.emit(event, ...args);
      });
      this.modules.external.forEach((m) => {
        if (m.init) m.init(this);
      });
    }
    this.format = this.options.interpolation.format;
    if (!callback) callback = noop;
    if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
      const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
      if (codes.length > 0 && codes[0] !== "dev") this.options.lng = codes[0];
    }
    if (!this.services.languageDetector && !this.options.lng) {
      this.logger.warn("init: no languageDetector is used and no lng is defined");
    }
    const storeApi = ["getResource", "hasResourceBundle", "getResourceBundle", "getDataByLanguage"];
    storeApi.forEach((fcName) => {
      this[fcName] = (...args) => this.store[fcName](...args);
    });
    const storeApiChained = ["addResource", "addResources", "addResourceBundle", "removeResourceBundle"];
    storeApiChained.forEach((fcName) => {
      this[fcName] = (...args) => {
        this.store[fcName](...args);
        return this;
      };
    });
    const deferred = defer();
    const load = () => {
      const finish = (err, t3) => {
        this.isInitializing = false;
        if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn("init: i18next is already initialized. You should call init just once!");
        this.isInitialized = true;
        if (!this.options.isClone) this.logger.log("initialized", this.options);
        this.emit("initialized", this.options);
        deferred.resolve(t3);
        callback(err, t3);
      };
      if ((this.languages || this.isLanguageChangingTo) && !this.isInitialized) return finish(null, this.t.bind(this));
      this.changeLanguage(this.options.lng, finish);
    };
    if (this.options.resources || !this.options.initAsync) {
      load();
    } else {
      setTimeout(load, 0);
    }
    return deferred;
  }
  loadResources(language, callback = noop) {
    let usedCallback = callback;
    const usedLng = isString(language) ? language : this.language;
    if (typeof language === "function") usedCallback = language;
    if (!this.options.resources || this.options.partialBundledLanguages) {
      if (usedLng?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
      const toLoad = [];
      const append = (lng) => {
        if (!lng) return;
        if (lng === "cimode") return;
        const lngs = this.services.languageUtils.toResolveHierarchy(lng);
        lngs.forEach((l) => {
          if (l === "cimode") return;
          if (!toLoad.includes(l)) toLoad.push(l);
        });
      };
      if (!usedLng) {
        const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        fallbacks.forEach((l) => append(l));
      } else {
        append(usedLng);
      }
      this.options.preload?.forEach?.((l) => append(l));
      this.services.backendConnector.load(toLoad, this.options.ns, (e) => {
        if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
        usedCallback(e);
      });
    } else {
      usedCallback(null);
    }
  }
  reloadResources(lngs, ns, callback) {
    const deferred = defer();
    if (typeof lngs === "function") {
      callback = lngs;
      lngs = void 0;
    }
    if (typeof ns === "function") {
      callback = ns;
      ns = void 0;
    }
    if (!lngs) lngs = this.languages;
    if (!ns) ns = this.options.ns;
    if (!callback) callback = noop;
    this.services.backendConnector.reload(lngs, ns, (err) => {
      deferred.resolve();
      callback(err);
    });
    return deferred;
  }
  use(module) {
    if (!module) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
    if (!module.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
    if (module.type === "backend") {
      this.modules.backend = module;
    }
    if (module.type === "logger" || module.log && module.warn && module.error) {
      this.modules.logger = module;
    }
    if (module.type === "languageDetector") {
      this.modules.languageDetector = module;
    }
    if (module.type === "i18nFormat") {
      this.modules.i18nFormat = module;
    }
    if (module.type === "postProcessor") {
      postProcessor.addPostProcessor(module);
    }
    if (module.type === "formatter") {
      this.modules.formatter = module;
    }
    if (module.type === "3rdParty") {
      this.modules.external.push(module);
    }
    return this;
  }
  setResolvedLanguage(l) {
    if (!l || !this.languages) return;
    if (["cimode", "dev"].includes(l)) return;
    for (let li2 = 0; li2 < this.languages.length; li2++) {
      const lngInLngs = this.languages[li2];
      if (["cimode", "dev"].includes(lngInLngs)) continue;
      if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
        this.resolvedLanguage = lngInLngs;
        break;
      }
    }
    if (!this.resolvedLanguage && !this.languages.includes(l) && this.store.hasLanguageSomeTranslations(l)) {
      this.resolvedLanguage = l;
      this.languages.unshift(l);
    }
  }
  changeLanguage(lng, callback) {
    this.isLanguageChangingTo = lng;
    const deferred = defer();
    this.emit("languageChanging", lng);
    const setLngProps = (l) => {
      this.language = l;
      this.languages = this.services.languageUtils.toResolveHierarchy(l);
      this.resolvedLanguage = void 0;
      this.setResolvedLanguage(l);
    };
    const done = (err, l) => {
      if (l) {
        if (this.isLanguageChangingTo === lng) {
          setLngProps(l);
          this.translator.changeLanguage(l);
          this.isLanguageChangingTo = void 0;
          this.emit("languageChanged", l);
          this.logger.log("languageChanged", l);
        }
      } else {
        this.isLanguageChangingTo = void 0;
      }
      deferred.resolve((...args) => this.t(...args));
      if (callback) callback(err, (...args) => this.t(...args));
    };
    const setLng = (lngs) => {
      if (!lng && !lngs && this.services.languageDetector) lngs = [];
      const fl = isString(lngs) ? lngs : lngs && lngs[0];
      const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
      if (l) {
        if (!this.language) {
          setLngProps(l);
        }
        if (!this.translator.language) this.translator.changeLanguage(l);
        this.services.languageDetector?.cacheUserLanguage?.(l);
      }
      this.loadResources(l, (err) => {
        done(err, l);
      });
    };
    if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
      setLng(this.services.languageDetector.detect());
    } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
      if (this.services.languageDetector.detect.length === 0) {
        this.services.languageDetector.detect().then(setLng);
      } else {
        this.services.languageDetector.detect(setLng);
      }
    } else {
      setLng(lng);
    }
    return deferred;
  }
  getFixedT(lng, ns, keyPrefix, fixedOpts) {
    const scopeNs = fixedOpts?.scopeNs;
    const fixedT = (key, opts, ...rest) => {
      let o;
      if (typeof opts !== "object") {
        o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
      } else {
        o = {
          ...opts
        };
      }
      o.lng = o.lng || fixedT.lng;
      o.lngs = o.lngs || fixedT.lngs;
      const explicitCallNs = o.ns !== void 0 && o.ns !== null;
      o.ns = o.ns || fixedT.ns;
      if (o.keyPrefix !== "") o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
      const selectorOpts = {
        ...this.options,
        ...o
      };
      if (Array.isArray(scopeNs) && !explicitCallNs) selectorOpts.ns = scopeNs;
      if (typeof o.keyPrefix === "function") o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
      const keySeparator = this.options.keySeparator || ".";
      let resultKey;
      if (o.keyPrefix && Array.isArray(key)) {
        resultKey = key.map((k3) => {
          if (typeof k3 === "function") k3 = keysFromSelector(k3, selectorOpts);
          return `${o.keyPrefix}${keySeparator}${k3}`;
        });
      } else {
        if (typeof key === "function") key = keysFromSelector(key, selectorOpts);
        resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
      }
      return this.t(resultKey, o);
    };
    if (isString(lng)) {
      fixedT.lng = lng;
    } else {
      fixedT.lngs = lng;
    }
    fixedT.ns = ns;
    fixedT.keyPrefix = keyPrefix;
    return fixedT;
  }
  t(...args) {
    return this.translator?.translate(...args);
  }
  exists(...args) {
    return this.translator?.exists(...args);
  }
  setDefaultNamespace(ns) {
    this.options.defaultNS = ns;
  }
  hasLoadedNamespace(ns, options = {}) {
    if (!this.isInitialized) {
      this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages);
      return false;
    }
    if (!this.languages || !this.languages.length) {
      this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages);
      return false;
    }
    const lng = options.lng || this.resolvedLanguage || this.languages[0];
    const fallbackLng = this.options ? this.options.fallbackLng : false;
    const lastLng = this.languages[this.languages.length - 1];
    if (lng.toLowerCase() === "cimode") return true;
    const loadNotPending = (l, n) => {
      const loadState = this.services.backendConnector.state[`${l}|${n}`];
      return loadState === -1 || loadState === 0 || loadState === 2;
    };
    if (options.precheck) {
      const preResult = options.precheck(this, loadNotPending);
      if (preResult !== void 0) return preResult;
    }
    if (this.hasResourceBundle(lng, ns)) return true;
    if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
    if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
    return false;
  }
  loadNamespaces(ns, callback) {
    const deferred = defer();
    if (!this.options.ns) {
      if (callback) callback();
      return Promise.resolve();
    }
    if (isString(ns)) ns = [ns];
    ns.forEach((n) => {
      if (!this.options.ns.includes(n)) this.options.ns.push(n);
    });
    this.loadResources((err) => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  loadLanguages(lngs, callback) {
    const deferred = defer();
    if (isString(lngs)) lngs = [lngs];
    const preloaded = this.options.preload || [];
    const newLngs = lngs.filter((lng) => !preloaded.includes(lng) && this.services.languageUtils.isSupportedCode(lng));
    if (!newLngs.length) {
      if (callback) callback();
      return Promise.resolve();
    }
    this.options.preload = preloaded.concat(newLngs);
    this.loadResources((err) => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  dir(lng) {
    if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
    if (!lng) return "rtl";
    try {
      const l = new Intl.Locale(lng);
      if (l && l.getTextInfo) {
        const ti2 = l.getTextInfo();
        if (ti2 && ti2.direction) return ti2.direction;
      }
    } catch (e) {
    }
    const rtlLngs = ["ar", "shu", "sqr", "ssh", "xaa", "yhd", "yud", "aao", "abh", "abv", "acm", "acq", "acw", "acx", "acy", "adf", "ads", "aeb", "aec", "afb", "ajp", "apc", "apd", "arb", "arq", "ars", "ary", "arz", "auz", "avl", "ayh", "ayl", "ayn", "ayp", "bbz", "pga", "he", "iw", "ps", "pbt", "pbu", "pst", "prp", "prd", "ug", "ur", "ydd", "yds", "yih", "ji", "yi", "hbo", "men", "xmn", "fa", "jpr", "peo", "pes", "prs", "dv", "sam", "ckb"];
    const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
    if (lng.toLowerCase().indexOf("-latn") > 1) return "ltr";
    return rtlLngs.includes(languageUtils.getLanguagePartFromCode(lng)) || lng.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
  }
  static createInstance(options = {}, callback) {
    const instance2 = new _I18n(options, callback);
    instance2.createInstance = _I18n.createInstance;
    return instance2;
  }
  cloneInstance(options = {}, callback = noop) {
    const forkResourceStore = options.forkResourceStore;
    if (forkResourceStore) delete options.forkResourceStore;
    const mergedOptions = {
      ...this.options,
      ...options,
      ...{
        isClone: true
      }
    };
    const clone = new _I18n(mergedOptions);
    if (options.debug !== void 0 || options.prefix !== void 0) {
      clone.logger = clone.logger.clone(options);
    }
    const membersToCopy = ["store", "services", "language"];
    membersToCopy.forEach((m) => {
      clone[m] = this[m];
    });
    clone.services = {
      ...this.services
    };
    clone.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    if (forkResourceStore) {
      const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
        prev[l] = {
          ...this.store.data[l]
        };
        prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
          acc[n] = {
            ...prev[l][n]
          };
          return acc;
        }, prev[l]);
        return prev;
      }, {});
      clone.store = new ResourceStore(clonedData, mergedOptions);
      clone.services.resourceStore = clone.store;
    }
    if (options.interpolation) {
      const defOpts = get();
      const mergedInterpolation = {
        ...defOpts.interpolation,
        ...this.options.interpolation,
        ...options.interpolation
      };
      const mergedForInterpolator = {
        ...mergedOptions,
        interpolation: mergedInterpolation
      };
      clone.services.interpolator = new Interpolator(mergedForInterpolator);
    }
    clone.translator = new Translator(clone.services, mergedOptions);
    clone.translator.on("*", (event, ...args) => {
      clone.emit(event, ...args);
    });
    clone.init(mergedOptions, callback);
    clone.translator.options = mergedOptions;
    clone.translator.backendConnector.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    return clone;
  }
  toJSON() {
    return {
      options: this.options,
      store: this.store,
      language: this.language,
      languages: this.languages,
      resolvedLanguage: this.resolvedLanguage
    };
  }
};
var instance = I18n.createInstance();
var createInstance = instance.createInstance;
var dir = instance.dir;
var init = instance.init;
var loadResources = instance.loadResources;
var reloadResources = instance.reloadResources;
var use = instance.use;
var changeLanguage = instance.changeLanguage;
var getFixedT = instance.getFixedT;
var t = instance.t;
var exists = instance.exists;
var setDefaultNamespace = instance.setDefaultNamespace;
var hasLoadedNamespace = instance.hasLoadedNamespace;
var loadNamespaces = instance.loadNamespaces;
var loadLanguages = instance.loadLanguages;

// ../i18n/storage.ts
var LOCALE_STORAGE_KEY = "pw46.locale";
var LEGACY_LOCALE_KEY = "wl-locale";
var LOCALE_COOKIE = "pw46.locale";
function isAppLocale(value) {
  return value === "en" || value === "ar" || value === "fr" || value === "es" || value === "ca" || value === "de" || value === "it" || value === "pt" || value === "ko" || value === "pl" || value === "uk" || value === "cs" || value === "nl" || value === "el" || value === "lv" || value === "hu" || value === "lt" || value === "ro" || value === "no";
}
function appLocaleToOhifLng(locale) {
  if (locale === "en") return "en-US";
  if (locale === "pt") return "pt-BR";
  return locale;
}
function readCookie(name) {
  if (typeof document === "undefined") return null;
  const prefix = `${encodeURIComponent(name)}=`;
  for (const part of document.cookie.split(";")) {
    const s2 = part.trim();
    if (s2.startsWith(prefix)) {
      try {
        return decodeURIComponent(s2.slice(prefix.length));
      } catch {
        return s2.slice(prefix.length);
      }
    }
  }
  return null;
}
function writeCookie(name, value) {
  if (typeof document === "undefined") return;
  document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(
    value
  )}; path=/; max-age=31536000; SameSite=Lax`;
}
function fromNavigator() {
  const nav = (typeof navigator !== "undefined" ? navigator.language || "" : "").toLowerCase();
  if (nav.startsWith("ca")) return "ca";
  if (nav.startsWith("ar")) return "ar";
  if (nav.startsWith("es")) return "es";
  if (nav.startsWith("fr")) return "fr";
  if (nav.startsWith("de")) return "de";
  if (nav.startsWith("it")) return "it";
  if (nav.startsWith("pt")) return "pt";
  if (nav.startsWith("ko")) return "ko";
  if (nav.startsWith("pl")) return "pl";
  if (nav.startsWith("uk")) return "uk";
  if (nav.startsWith("cs")) return "cs";
  if (nav.startsWith("nl")) return "nl";
  if (nav.startsWith("el")) return "el";
  if (nav.startsWith("lv")) return "lv";
  if (nav.startsWith("hu")) return "hu";
  if (nav.startsWith("lt")) return "lt";
  if (nav.startsWith("ro")) return "ro";
  if (nav.startsWith("no") || nav.startsWith("nb") || nav.startsWith("nn"))
    return "no";
  return "en";
}
function resolveStoredLocale() {
  const cookie = readCookie(LOCALE_COOKIE)?.trim().toLowerCase();
  if (isAppLocale(cookie)) {
    try {
      localStorage.setItem(LOCALE_STORAGE_KEY, cookie);
      localStorage.removeItem(LEGACY_LOCALE_KEY);
    } catch {
    }
    return cookie;
  }
  try {
    const stored = localStorage.getItem(LOCALE_STORAGE_KEY)?.trim().toLowerCase();
    if (isAppLocale(stored)) {
      try {
        writeCookie(LOCALE_COOKIE, stored);
      } catch {
      }
      return stored;
    }
  } catch {
  }
  try {
    const legacy = localStorage.getItem(LEGACY_LOCALE_KEY)?.trim().toLowerCase();
    if (isAppLocale(legacy)) {
      persistLocale(legacy);
      return legacy;
    }
  } catch {
  }
  return fromNavigator();
}
function persistLocale(code) {
  try {
    localStorage.setItem(LOCALE_STORAGE_KEY, code);
    localStorage.removeItem(LEGACY_LOCALE_KEY);
  } catch {
  }
  try {
    writeCookie(LOCALE_COOKIE, code);
  } catch {
  }
  applyDocumentLocale(code);
}
function applyDocumentLocale(code) {
  if (typeof document === "undefined") return;
  document.documentElement.lang = code;
  document.documentElement.dir = code === "ar" ? "rtl" : "ltr";
}

// ../i18n/language-picker.ts
var APP_LOCALES = [
  { code: "en", nativeLabel: "English" },
  { code: "fr", nativeLabel: "Fran\xE7ais" },
  { code: "de", nativeLabel: "Deutsch" },
  { code: "es", nativeLabel: "Espa\xF1ol" },
  { code: "ca", nativeLabel: "Catal\xE0" },
  { code: "it", nativeLabel: "Italiano" },
  { code: "pt", nativeLabel: "Portugu\xEAs" },
  { code: "ko", nativeLabel: "\uD55C\uAD6D\uC5B4" },
  { code: "pl", nativeLabel: "Polski" },
  { code: "uk", nativeLabel: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430" },
  { code: "cs", nativeLabel: "\u010Ce\u0161tina" },
  { code: "nl", nativeLabel: "Nederlands" },
  { code: "el", nativeLabel: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC" },
  { code: "lv", nativeLabel: "Latvie\u0161u" },
  { code: "ar", nativeLabel: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" },
  { code: "hu", nativeLabel: "Magyar" },
  { code: "lt", nativeLabel: "Lietuvi\u0173" },
  { code: "ro", nativeLabel: "Rom\xE2n\u0103" },
  { code: "no", nativeLabel: "Norsk" }
];
function wireLanguagePicker(opts) {
  const btnId = opts.btnId ?? "langPickerBtn";
  const menuId = opts.menuId ?? "langPickerMenu";
  const btn = document.getElementById(btnId);
  const menu = document.getElementById(menuId);
  if (!(btn instanceof HTMLButtonElement) || !(menu instanceof HTMLElement)) {
    return;
  }
  const renderMenu = () => {
    const current = opts.getLocale();
    menu.replaceChildren();
    for (const { code, nativeLabel } of APP_LOCALES) {
      const li2 = document.createElement("li");
      li2.setAttribute("role", "option");
      li2.dataset.locale = code;
      li2.textContent = nativeLabel;
      li2.classList.toggle("is-active", code === current);
      li2.setAttribute("aria-selected", code === current ? "true" : "false");
      menu.appendChild(li2);
    }
  };
  const closeMenu = () => {
    menu.hidden = true;
    btn.setAttribute("aria-expanded", "false");
  };
  const openMenu = () => {
    renderMenu();
    menu.hidden = false;
    btn.setAttribute("aria-expanded", "true");
  };
  btn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (menu.hidden) openMenu();
    else closeMenu();
  });
  menu.addEventListener("click", (ev) => {
    const li2 = ev.target?.closest("li[data-locale]");
    if (!(li2 instanceof HTMLElement)) return;
    const code = li2.dataset.locale;
    if (!code) return;
    void Promise.resolve(opts.setLocale(code)).then(() => {
      closeMenu();
    });
  });
  document.addEventListener("click", (ev) => {
    if (menu.hidden) return;
    const target = ev.target;
    if (btn.contains(target) || menu.contains(target)) return;
    closeMenu();
  });
  renderMenu();
}

// ../i18n/conference.ts
var en2 = {
  dialogTitle: "Conferencing",
  close: "Close",
  closeAria: "Close",
  createSection: "Create a conference",
  conferenceTitle: "Conference title",
  selectConferenceTitle: "Select a conference title",
  otherTitle: "Other\u2026",
  customTitle: "Custom title",
  customTitlePlaceholder: "Enter conference title",
  users: "Users",
  loadingUsers: "Loading users\u2026",
  noUsers: "No users available",
  createConference: "Create conference",
  creating: "Creating\u2026",
  joinSection: "Join a conference",
  activeConferences: "Active conferences",
  noConferences: "No conferences available",
  selectConference: "Select a conference",
  untitled: "Untitled",
  joinConference: "Join conference",
  joining: "Joining\u2026",
  manageSection: "Manage conference",
  titleLabel: "Title:",
  na: "N/A",
  participants: "Participants",
  noPlaces: "No places",
  leaveConference: "Leave conference",
  endConference: "End conference",
  ending: "Ending\u2026",
  leaving: "Leaving\u2026",
  conferenceEnded: "Conference ended.",
  leftConference: "Left conference.",
  connectHubFirst: "Connect to the Slicer hub first.",
  topicRequiredHost: "Hub topic is required to host a conference.",
  topicRequiredJoin: "Hub topic is required to join a conference.",
  titleRequired: "Conference title is required.",
  selectAttendee: "Select at least one attendee topic.",
  selectConferenceToJoin: "Select a conference to join.",
  failedCreate: "Failed to create conference.",
  failedJoin: "Failed to join conference.",
  failedUpdate: "Failed to update conference.",
  inviteTitle: "Conference invitation",
  joinAndFollow: "Join and follow",
  joinNoFollow: "Join but do not follow",
  doNotJoin: "Do not join",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 join and follow {{host}}?",
  inviteLeadNoTitle: "Join conference and follow {{host}}?",
  joinAndFollowHost: "Join and follow {{host}}",
  takeoverTitle: "Take over?",
  takeoverBody: "The host and all participants will be notified that you are taking over. You will lead scene updates for this conference.",
  cancel: "Cancel",
  takeOver: "Take over",
  conferencing: "Conferencing",
  subscribeHubFirst: "Subscribe to the hub first",
  stopFollowing: "Stop following",
  resumeFollowing: "Resume following"
};
var de2 = {
  dialogTitle: "Konferenz",
  close: "Schlie\xDFen",
  closeAria: "Schlie\xDFen",
  createSection: "Konferenz erstellen",
  conferenceTitle: "Konferenztitel",
  selectConferenceTitle: "Titel ausw\xE4hlen",
  otherTitle: "Andere\u2026",
  customTitle: "Benutzerdefinierter Titel",
  customTitlePlaceholder: "Konferenztitel eingeben",
  users: "Benutzer",
  loadingUsers: "Benutzer werden geladen\u2026",
  noUsers: "Keine Benutzer verf\xFCgbar",
  createConference: "Konferenz erstellen",
  creating: "Wird erstellt\u2026",
  joinSection: "An einer Konferenz teilnehmen",
  activeConferences: "Aktive Konferenzen",
  noConferences: "Keine Konferenzen verf\xFCgbar",
  selectConference: "Konferenz ausw\xE4hlen",
  untitled: "Ohne Titel",
  joinConference: "Konferenz beitreten",
  joining: "Beitritt\u2026",
  manageSection: "Konferenz verwalten",
  titleLabel: "Titel:",
  na: "k. A.",
  participants: "Teilnehmer",
  noPlaces: "Keine Orte",
  leaveConference: "Konferenz verlassen",
  endConference: "Konferenz beenden",
  ending: "Wird beendet\u2026",
  leaving: "Verlassen\u2026",
  conferenceEnded: "Konferenz beendet.",
  leftConference: "Konferenz verlassen.",
  connectHubFirst: "Stellen Sie zuerst eine Verbindung zum Hub-Hub her.",
  topicRequiredHost: "Ein Hub-Topic ist erforderlich, um eine Konferenz zu hosten.",
  topicRequiredJoin: "Ein Hub-Topic ist erforderlich, um einer Konferenz beizutreten.",
  titleRequired: "Konferenztitel ist erforderlich.",
  selectAttendee: "W\xE4hlen Sie mindestens einen Teilnehmer aus.",
  selectConferenceToJoin: "W\xE4hlen Sie eine Konferenz zum Beitreten aus.",
  failedCreate: "Konferenz konnte nicht erstellt werden.",
  failedJoin: "Beitritt zur Konferenz fehlgeschlagen.",
  failedUpdate: "Aktualisierung der Konferenz fehlgeschlagen.",
  inviteTitle: "Konferenzeinladung",
  joinAndFollow: "Beitreten und folgen",
  joinNoFollow: "Beitreten, aber nicht folgen",
  doNotJoin: "Nicht beitreten",
  hostFallback: "Host",
  inviteLeadWithTitle: "{{title}} \u2014 beitreten und {{host}} folgen?",
  inviteLeadNoTitle: "Konferenz beitreten und {{host}} folgen?",
  joinAndFollowHost: "Beitreten und {{host}} folgen",
  takeoverTitle: "\xDCbernehmen?",
  takeoverBody: "Der Host und alle Teilnehmer werden benachrichtigt, dass Sie die F\xFChrung \xFCbernehmen. Sie leiten dann die Szenenaktualisierungen f\xFCr diese Konferenz.",
  cancel: "Abbrechen",
  takeOver: "\xDCbernehmen",
  conferencing: "Konferenz",
  subscribeHubFirst: "Zuerst am Hub anmelden",
  stopFollowing: "Folgen beenden",
  resumeFollowing: "Folgen fortsetzen"
};
var fr2 = {
  dialogTitle: "Conf\xE9rence",
  close: "Fermer",
  closeAria: "Fermer",
  createSection: "Cr\xE9er une conf\xE9rence",
  conferenceTitle: "Titre de la conf\xE9rence",
  selectConferenceTitle: "S\xE9lectionner un titre",
  otherTitle: "Autre\u2026",
  customTitle: "Titre personnalis\xE9",
  customTitlePlaceholder: "Saisir le titre de la conf\xE9rence",
  users: "Utilisateurs",
  loadingUsers: "Chargement des utilisateurs\u2026",
  noUsers: "Aucun utilisateur disponible",
  createConference: "Cr\xE9er la conf\xE9rence",
  creating: "Cr\xE9ation\u2026",
  joinSection: "Rejoindre une conf\xE9rence",
  activeConferences: "Conf\xE9rences actives",
  noConferences: "Aucune conf\xE9rence disponible",
  selectConference: "S\xE9lectionner une conf\xE9rence",
  untitled: "Sans titre",
  joinConference: "Rejoindre la conf\xE9rence",
  joining: "Connexion\u2026",
  manageSection: "G\xE9rer la conf\xE9rence",
  titleLabel: "Titre :",
  na: "N/D",
  participants: "Participants",
  noPlaces: "Aucun lieu",
  leaveConference: "Quitter la conf\xE9rence",
  endConference: "Terminer la conf\xE9rence",
  ending: "Fin\u2026",
  leaving: "D\xE9part\u2026",
  conferenceEnded: "Conf\xE9rence termin\xE9e.",
  leftConference: "Vous avez quitt\xE9 la conf\xE9rence.",
  connectHubFirst: "Connectez-vous d\u2019abord au hub Hub.",
  topicRequiredHost: "Un topic Hub est requis pour animer une conf\xE9rence.",
  topicRequiredJoin: "Un topic Hub est requis pour rejoindre une conf\xE9rence.",
  titleRequired: "Le titre de la conf\xE9rence est requis.",
  selectAttendee: "S\xE9lectionnez au moins un participant.",
  selectConferenceToJoin: "S\xE9lectionnez une conf\xE9rence \xE0 rejoindre.",
  failedCreate: "\xC9chec de la cr\xE9ation de la conf\xE9rence.",
  failedJoin: "\xC9chec de la connexion \xE0 la conf\xE9rence.",
  failedUpdate: "\xC9chec de la mise \xE0 jour de la conf\xE9rence.",
  inviteTitle: "Invitation \xE0 la conf\xE9rence",
  joinAndFollow: "Rejoindre et suivre",
  joinNoFollow: "Rejoindre sans suivre",
  doNotJoin: "Ne pas rejoindre",
  hostFallback: "h\xF4te",
  inviteLeadWithTitle: "{{title}} \u2014 rejoindre et suivre {{host}} ?",
  inviteLeadNoTitle: "Rejoindre la conf\xE9rence et suivre {{host}} ?",
  joinAndFollowHost: "Rejoindre et suivre {{host}}",
  takeoverTitle: "Prendre la main ?",
  takeoverBody: "L\u2019h\xF4te et tous les participants seront inform\xE9s que vous prenez la main. Vous dirigerez les mises \xE0 jour de sc\xE8ne pour cette conf\xE9rence.",
  cancel: "Annuler",
  takeOver: "Prendre la main",
  conferencing: "Conf\xE9rence",
  subscribeHubFirst: "Abonnez-vous d\u2019abord au hub",
  stopFollowing: "Arr\xEAter de suivre",
  resumeFollowing: "Reprendre le suivi"
};
var es = {
  dialogTitle: "Conferencia",
  close: "Cerrar",
  closeAria: "Cerrar",
  createSection: "Crear una conferencia",
  conferenceTitle: "T\xEDtulo de la conferencia",
  selectConferenceTitle: "Seleccionar un t\xEDtulo",
  otherTitle: "Otro\u2026",
  customTitle: "T\xEDtulo personalizado",
  customTitlePlaceholder: "Introducir el t\xEDtulo de la conferencia",
  users: "Usuarios",
  loadingUsers: "Cargando usuarios\u2026",
  noUsers: "No hay usuarios disponibles",
  createConference: "Crear conferencia",
  creating: "Creando\u2026",
  joinSection: "Unirse a una conferencia",
  activeConferences: "Conferencias activas",
  noConferences: "No hay conferencias disponibles",
  selectConference: "Seleccionar una conferencia",
  untitled: "Sin t\xEDtulo",
  joinConference: "Unirse a la conferencia",
  joining: "Uni\xE9ndose\u2026",
  manageSection: "Gestionar conferencia",
  titleLabel: "T\xEDtulo:",
  na: "N/D",
  participants: "Participantes",
  noPlaces: "Sin lugares",
  leaveConference: "Abandonar la conferencia",
  endConference: "Terminar la conferencia",
  ending: "Terminando\u2026",
  leaving: "Saliendo\u2026",
  conferenceEnded: "Conferencia terminada.",
  leftConference: "Has abandonado la conferencia.",
  connectHubFirst: "Con\xE9ctate primero al hub Hub.",
  topicRequiredHost: "Se requiere un topic Hub para organizar una conferencia.",
  topicRequiredJoin: "Se requiere un topic Hub para unirse a una conferencia.",
  titleRequired: "El t\xEDtulo de la conferencia es obligatorio.",
  selectAttendee: "Selecciona al menos un participante.",
  selectConferenceToJoin: "Selecciona una conferencia a la que unirte.",
  failedCreate: "Error al crear la conferencia.",
  failedJoin: "Error al unirse a la conferencia.",
  failedUpdate: "Error al actualizar la conferencia.",
  inviteTitle: "Invitaci\xF3n a la conferencia",
  joinAndFollow: "Unirse y seguir",
  joinNoFollow: "Unirse sin seguir",
  doNotJoin: "No unirse",
  hostFallback: "anfitri\xF3n",
  inviteLeadWithTitle: "{{title}} \u2014 \xBFunirse y seguir a {{host}}?",
  inviteLeadNoTitle: "\xBFUnirse a la conferencia y seguir a {{host}}?",
  joinAndFollowHost: "Unirse y seguir a {{host}}",
  takeoverTitle: "\xBFTomar el control?",
  takeoverBody: "Se notificar\xE1 al anfitri\xF3n y a todos los participantes de que tomas el control. Dirigir\xE1s las actualizaciones de escena de esta conferencia.",
  cancel: "Cancelar",
  takeOver: "Tomar el control",
  conferencing: "Conferencia",
  subscribeHubFirst: "Suscr\xEDbete primero al hub",
  stopFollowing: "Dejar de seguir",
  resumeFollowing: "Reanudar el seguimiento"
};
var ca = {
  dialogTitle: "Confer\xE8ncia",
  close: "Tancar",
  closeAria: "Tancar",
  createSection: "Crear una confer\xE8ncia",
  conferenceTitle: "T\xEDtol de la confer\xE8ncia",
  selectConferenceTitle: "Seleccionar un t\xEDtol",
  otherTitle: "Altre\u2026",
  customTitle: "T\xEDtol personalitzat",
  customTitlePlaceholder: "Introdu\xEFu el t\xEDtol de la confer\xE8ncia",
  users: "Usuaris",
  loadingUsers: "S\u2019estan carregant els usuaris\u2026",
  noUsers: "No hi ha usuaris disponibles",
  createConference: "Crear la confer\xE8ncia",
  creating: "S\u2019est\xE0 creant\u2026",
  joinSection: "Unir-se a una confer\xE8ncia",
  activeConferences: "Confer\xE8ncies actives",
  noConferences: "No hi ha confer\xE8ncies disponibles",
  selectConference: "Seleccionar una confer\xE8ncia",
  untitled: "Sense t\xEDtol",
  joinConference: "Unir-se a la confer\xE8ncia",
  joining: "S\u2019est\xE0 unint\u2026",
  manageSection: "Gestionar la confer\xE8ncia",
  titleLabel: "T\xEDtol:",
  na: "N/D",
  participants: "Participants",
  noPlaces: "Sense llocs",
  leaveConference: "Sortir de la confer\xE8ncia",
  endConference: "Acabar la confer\xE8ncia",
  ending: "S\u2019est\xE0 acabant\u2026",
  leaving: "S\u2019est\xE0 sortint\u2026",
  conferenceEnded: "Confer\xE8ncia acabada.",
  leftConference: "Heu sortit de la confer\xE8ncia.",
  connectHubFirst: "Connecteu-vos primer al hub Hub.",
  topicRequiredHost: "Cal un topic Hub per organitzar una confer\xE8ncia.",
  topicRequiredJoin: "Cal un topic Hub per unir-se a una confer\xE8ncia.",
  titleRequired: "El t\xEDtol de la confer\xE8ncia \xE9s obligatori.",
  selectAttendee: "Seleccioneu almenys un participant.",
  selectConferenceToJoin: "Seleccioneu una confer\xE8ncia a la qual unir-vos.",
  failedCreate: "No s\u2019ha pogut crear la confer\xE8ncia.",
  failedJoin: "No s\u2019ha pogut unir a la confer\xE8ncia.",
  failedUpdate: "No s\u2019ha pogut actualitzar la confer\xE8ncia.",
  inviteTitle: "Invitaci\xF3 a la confer\xE8ncia",
  joinAndFollow: "Unir-se i seguir",
  joinNoFollow: "Unir-se sense seguir",
  doNotJoin: "No unir-se",
  hostFallback: "amfitri\xF3",
  inviteLeadWithTitle: "{{title}} \u2014 unir-se i seguir {{host}}?",
  inviteLeadNoTitle: "Unir-se a la confer\xE8ncia i seguir {{host}}?",
  joinAndFollowHost: "Unir-se i seguir {{host}}",
  takeoverTitle: "Prendre el control?",
  takeoverBody: "Se notificar\xE0 a l\u2019amfitri\xF3 i a tots els participants que preneu el control. Direccioneu les actualitzacions d\u2019escena d\u2019aquesta confer\xE8ncia.",
  cancel: "Cancel\xB7lar",
  takeOver: "Prendre el control",
  conferencing: "Confer\xE8ncia",
  subscribeHubFirst: "Subscriviu-vos primer al hub",
  stopFollowing: "Deixar de seguir",
  resumeFollowing: "Reprendre el seguiment"
};
var it2 = {
  dialogTitle: "Conferenza",
  close: "Chiudi",
  closeAria: "Chiudi",
  createSection: "Crea una conferenza",
  conferenceTitle: "Titolo della conferenza",
  selectConferenceTitle: "Seleziona un titolo",
  otherTitle: "Altro\u2026",
  customTitle: "Titolo personalizzato",
  customTitlePlaceholder: "Inserisci il titolo della conferenza",
  users: "Utenti",
  loadingUsers: "Caricamento utenti\u2026",
  noUsers: "Nessun utente disponibile",
  createConference: "Crea conferenza",
  creating: "Creazione\u2026",
  joinSection: "Partecipa a una conferenza",
  activeConferences: "Conferenze attive",
  noConferences: "Nessuna conferenza disponibile",
  selectConference: "Seleziona una conferenza",
  untitled: "Senza titolo",
  joinConference: "Partecipa alla conferenza",
  joining: "Accesso\u2026",
  manageSection: "Gestisci conferenza",
  titleLabel: "Titolo:",
  na: "N/D",
  participants: "Partecipanti",
  noPlaces: "Nessun luogo",
  leaveConference: "Lascia la conferenza",
  endConference: "Termina la conferenza",
  ending: "Chiusura\u2026",
  leaving: "Uscita\u2026",
  conferenceEnded: "Conferenza terminata.",
  leftConference: "Hai lasciato la conferenza.",
  connectHubFirst: "Connettiti prima all\u2019hub Hub.",
  topicRequiredHost: "\xC8 richiesto un topic Hub per ospitare una conferenza.",
  topicRequiredJoin: "\xC8 richiesto un topic Hub per partecipare a una conferenza.",
  titleRequired: "Il titolo della conferenza \xE8 obbligatorio.",
  selectAttendee: "Seleziona almeno un partecipante.",
  selectConferenceToJoin: "Seleziona una conferenza a cui partecipare.",
  failedCreate: "Creazione della conferenza non riuscita.",
  failedJoin: "Partecipazione alla conferenza non riuscita.",
  failedUpdate: "Aggiornamento della conferenza non riuscito.",
  inviteTitle: "Invito alla conferenza",
  joinAndFollow: "Partecipa e segui",
  joinNoFollow: "Partecipa senza seguire",
  doNotJoin: "Non partecipare",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 partecipare e seguire {{host}}?",
  inviteLeadNoTitle: "Partecipare alla conferenza e seguire {{host}}?",
  joinAndFollowHost: "Partecipa e segui {{host}}",
  takeoverTitle: "Prendere il controllo?",
  takeoverBody: "L\u2019host e tutti i partecipanti saranno avvisati che stai prendendo il controllo. Dirigerai gli aggiornamenti di scena di questa conferenza.",
  cancel: "Annulla",
  takeOver: "Prendi il controllo",
  conferencing: "Conferenza",
  subscribeHubFirst: "Iscriviti prima all\u2019hub",
  stopFollowing: "Smetti di seguire",
  resumeFollowing: "Riprendi a seguire"
};
var pt3 = {
  dialogTitle: "Confer\xEAncia",
  close: "Fechar",
  closeAria: "Fechar",
  createSection: "Criar uma confer\xEAncia",
  conferenceTitle: "T\xEDtulo da confer\xEAncia",
  selectConferenceTitle: "Selecionar um t\xEDtulo",
  otherTitle: "Outro\u2026",
  customTitle: "T\xEDtulo personalizado",
  customTitlePlaceholder: "Introduza o t\xEDtulo da confer\xEAncia",
  users: "Utilizadores",
  loadingUsers: "A carregar utilizadores\u2026",
  noUsers: "Nenhum utilizador dispon\xEDvel",
  createConference: "Criar confer\xEAncia",
  creating: "A criar\u2026",
  joinSection: "Participar numa confer\xEAncia",
  activeConferences: "Confer\xEAncias ativas",
  noConferences: "Nenhuma confer\xEAncia dispon\xEDvel",
  selectConference: "Selecionar uma confer\xEAncia",
  untitled: "Sem t\xEDtulo",
  joinConference: "Participar na confer\xEAncia",
  joining: "A participar\u2026",
  manageSection: "Gerir confer\xEAncia",
  titleLabel: "T\xEDtulo:",
  na: "N/D",
  participants: "Participantes",
  noPlaces: "Sem locais",
  leaveConference: "Sair da confer\xEAncia",
  endConference: "Terminar a confer\xEAncia",
  ending: "A terminar\u2026",
  leaving: "A sair\u2026",
  conferenceEnded: "Confer\xEAncia terminada.",
  leftConference: "Saiu da confer\xEAncia.",
  connectHubFirst: "Ligue-se primeiro ao hub Hub.",
  topicRequiredHost: "\xC9 necess\xE1rio um topic Hub para organizar uma confer\xEAncia.",
  topicRequiredJoin: "\xC9 necess\xE1rio um topic Hub para participar numa confer\xEAncia.",
  titleRequired: "O t\xEDtulo da confer\xEAncia \xE9 obrigat\xF3rio.",
  selectAttendee: "Selecione pelo menos um participante.",
  selectConferenceToJoin: "Selecione uma confer\xEAncia a que participar.",
  failedCreate: "Falha ao criar a confer\xEAncia.",
  failedJoin: "Falha ao participar na confer\xEAncia.",
  failedUpdate: "Falha ao atualizar a confer\xEAncia.",
  inviteTitle: "Convite para a confer\xEAncia",
  joinAndFollow: "Participar e seguir",
  joinNoFollow: "Participar sem seguir",
  doNotJoin: "N\xE3o participar",
  hostFallback: "anfitri\xE3o",
  inviteLeadWithTitle: "{{title}} \u2014 participar e seguir {{host}}?",
  inviteLeadNoTitle: "Participar na confer\xEAncia e seguir {{host}}?",
  joinAndFollowHost: "Participar e seguir {{host}}",
  takeoverTitle: "Assumir o controlo?",
  takeoverBody: "O anfitri\xE3o e todos os participantes ser\xE3o notificados de que est\xE1 a assumir o controlo. Passar\xE1 a liderar as atualiza\xE7\xF5es de cena desta confer\xEAncia.",
  cancel: "Cancelar",
  takeOver: "Assumir o controlo",
  conferencing: "Confer\xEAncia",
  subscribeHubFirst: "Subscreva primeiro o hub",
  stopFollowing: "Parar de seguir",
  resumeFollowing: "Retomar o seguimento"
};
var ko = {
  dialogTitle: "\uD654\uC0C1\uD68C\uC758",
  close: "\uB2EB\uAE30",
  closeAria: "\uB2EB\uAE30",
  createSection: "\uD68C\uC758 \uB9CC\uB4E4\uAE30",
  conferenceTitle: "\uD68C\uC758 \uC81C\uBAA9",
  selectConferenceTitle: "\uC81C\uBAA9 \uC120\uD0DD",
  otherTitle: "\uAE30\uD0C0\u2026",
  customTitle: "\uC0AC\uC6A9\uC790 \uC9C0\uC815 \uC81C\uBAA9",
  customTitlePlaceholder: "\uD68C\uC758 \uC81C\uBAA9 \uC785\uB825",
  users: "\uC0AC\uC6A9\uC790",
  loadingUsers: "\uC0AC\uC6A9\uC790 \uBD88\uB7EC\uC624\uB294 \uC911\u2026",
  noUsers: "\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uC0AC\uC6A9\uC790 \uC5C6\uC74C",
  createConference: "\uD68C\uC758 \uB9CC\uB4E4\uAE30",
  creating: "\uB9CC\uB4DC\uB294 \uC911\u2026",
  joinSection: "\uD68C\uC758 \uCC38\uAC00",
  activeConferences: "\uC9C4\uD589 \uC911\uC778 \uD68C\uC758",
  noConferences: "\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uD68C\uC758 \uC5C6\uC74C",
  selectConference: "\uD68C\uC758 \uC120\uD0DD",
  untitled: "\uC81C\uBAA9 \uC5C6\uC74C",
  joinConference: "\uD68C\uC758 \uCC38\uAC00",
  joining: "\uCC38\uAC00 \uC911\u2026",
  manageSection: "\uD68C\uC758 \uAD00\uB9AC",
  titleLabel: "\uC81C\uBAA9:",
  na: "\uD574\uB2F9 \uC5C6\uC74C",
  participants: "\uCC38\uAC00\uC790",
  noPlaces: "\uC7A5\uC18C \uC5C6\uC74C",
  leaveConference: "\uD68C\uC758 \uB098\uAC00\uAE30",
  endConference: "\uD68C\uC758 \uC885\uB8CC",
  ending: "\uC885\uB8CC \uC911\u2026",
  leaving: "\uB098\uAC00\uB294 \uC911\u2026",
  conferenceEnded: "\uD68C\uC758\uAC00 \uC885\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  leftConference: "\uD68C\uC758\uC5D0\uC11C \uB098\uAC14\uC2B5\uB2C8\uB2E4.",
  connectHubFirst: "\uBA3C\uC800 Hub \uD5C8\uBE0C\uC5D0 \uC5F0\uACB0\uD558\uC138\uC694.",
  topicRequiredHost: "\uD68C\uC758\uB97C \uC8FC\uCD5C\uD558\uB824\uBA74 Hub \uD1A0\uD53D\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  topicRequiredJoin: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uB824\uBA74 Hub \uD1A0\uD53D\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  titleRequired: "\uD68C\uC758 \uC81C\uBAA9\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  selectAttendee: "\uCC38\uAC00\uC790\uB97C \uD55C \uBA85 \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694.",
  selectConferenceToJoin: "\uCC38\uAC00\uD560 \uD68C\uC758\uB97C \uC120\uD0DD\uD558\uC138\uC694.",
  failedCreate: "\uD68C\uC758\uB97C \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  failedJoin: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  failedUpdate: "\uD68C\uC758\uB97C \uC5C5\uB370\uC774\uD2B8\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
  inviteTitle: "\uD68C\uC758 \uCD08\uB300",
  joinAndFollow: "\uCC38\uAC00\uD558\uACE0 \uB530\uB77C\uAC00\uAE30",
  joinNoFollow: "\uCC38\uAC00\uD558\uB418 \uB530\uB77C\uAC00\uC9C0 \uC54A\uAE30",
  doNotJoin: "\uCC38\uAC00\uD558\uC9C0 \uC54A\uAE30",
  hostFallback: "\uD638\uC2A4\uD2B8",
  inviteLeadWithTitle: "{{title}} \u2014 \uCC38\uAC00\uD558\uACE0 {{host}}\uB97C \uB530\uB77C\uAC08\uAE4C\uC694?",
  inviteLeadNoTitle: "\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uACE0 {{host}}\uB97C \uB530\uB77C\uAC08\uAE4C\uC694?",
  joinAndFollowHost: "{{host}}\uB97C \uB530\uB77C\uAC00\uBA70 \uCC38\uAC00",
  takeoverTitle: "\uC8FC\uB3C4\uAD8C\uC744 \uAC00\uC838\uC62C\uAE4C\uC694?",
  takeoverBody: "\uD638\uC2A4\uD2B8\uC640 \uBAA8\uB4E0 \uCC38\uAC00\uC790\uC5D0\uAC8C \uC8FC\uB3C4\uAD8C\uC744 \uAC00\uC838\uAC04\uB2E4\uB294 \uC54C\uB9BC\uC774 \uAC11\uB2C8\uB2E4. \uC774 \uD68C\uC758\uC758 \uC7A5\uBA74 \uC5C5\uB370\uC774\uD2B8\uB97C \uC774\uB04C\uAC8C \uB429\uB2C8\uB2E4.",
  cancel: "\uCDE8\uC18C",
  takeOver: "\uC8FC\uB3C4\uAD8C \uAC00\uC838\uC624\uAE30",
  conferencing: "\uD654\uC0C1\uD68C\uC758",
  subscribeHubFirst: "\uBA3C\uC800 \uD5C8\uBE0C\uC5D0 \uAD6C\uB3C5\uD558\uC138\uC694",
  stopFollowing: "\uB530\uB77C\uAC00\uAE30 \uC911\uC9C0",
  resumeFollowing: "\uB530\uB77C\uAC00\uAE30 \uC7AC\uAC1C"
};
var pl = {
  dialogTitle: "Konferencja",
  close: "Zamknij",
  closeAria: "Zamknij",
  createSection: "Utw\xF3rz konferencj\u0119",
  conferenceTitle: "Tytu\u0142 konferencji",
  selectConferenceTitle: "Wybierz tytu\u0142",
  otherTitle: "Inny\u2026",
  customTitle: "Tytu\u0142 niestandardowy",
  customTitlePlaceholder: "Wpisz tytu\u0142 konferencji",
  users: "U\u017Cytkownicy",
  loadingUsers: "\u0141adowanie u\u017Cytkownik\xF3w\u2026",
  noUsers: "Brak dost\u0119pnych u\u017Cytkownik\xF3w",
  createConference: "Utw\xF3rz konferencj\u0119",
  creating: "Tworzenie\u2026",
  joinSection: "Do\u0142\u0105cz do konferencji",
  activeConferences: "Aktywne konferencje",
  noConferences: "Brak dost\u0119pnych konferencji",
  selectConference: "Wybierz konferencj\u0119",
  untitled: "Bez tytu\u0142u",
  joinConference: "Do\u0142\u0105cz do konferencji",
  joining: "Do\u0142\u0105czanie\u2026",
  manageSection: "Zarz\u0105dzaj konferencj\u0105",
  titleLabel: "Tytu\u0142:",
  na: "nd.",
  participants: "Uczestnicy",
  noPlaces: "Brak miejsc",
  leaveConference: "Opu\u015B\u0107 konferencj\u0119",
  endConference: "Zako\u0144cz konferencj\u0119",
  ending: "Ko\u0144czenie\u2026",
  leaving: "Opuszczanie\u2026",
  conferenceEnded: "Konferencja zako\u0144czona.",
  leftConference: "Opuszczono konferencj\u0119.",
  connectHubFirst: "Najpierw po\u0142\u0105cz si\u0119 z hubem Hub.",
  topicRequiredHost: "Do prowadzenia konferencji wymagany jest topic Hub.",
  topicRequiredJoin: "Do do\u0142\u0105czenia do konferencji wymagany jest topic Hub.",
  titleRequired: "Tytu\u0142 konferencji jest wymagany.",
  selectAttendee: "Wybierz co najmniej jednego uczestnika.",
  selectConferenceToJoin: "Wybierz konferencj\u0119, do kt\xF3rej chcesz do\u0142\u0105czy\u0107.",
  failedCreate: "Nie uda\u0142o si\u0119 utworzy\u0107 konferencji.",
  failedJoin: "Nie uda\u0142o si\u0119 do\u0142\u0105czy\u0107 do konferencji.",
  failedUpdate: "Nie uda\u0142o si\u0119 zaktualizowa\u0107 konferencji.",
  inviteTitle: "Zaproszenie na konferencj\u0119",
  joinAndFollow: "Do\u0142\u0105cz i \u015Bled\u017A",
  joinNoFollow: "Do\u0142\u0105cz, ale nie \u015Bled\u017A",
  doNotJoin: "Nie do\u0142\u0105czaj",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 do\u0142\u0105czy\u0107 i \u015Bledzi\u0107 {{host}}?",
  inviteLeadNoTitle: "Do\u0142\u0105czy\u0107 do konferencji i \u015Bledzi\u0107 {{host}}?",
  joinAndFollowHost: "Do\u0142\u0105cz i \u015Bled\u017A {{host}}",
  takeoverTitle: "Przej\u0105\u0107 prowadzenie?",
  takeoverBody: "Host i wszyscy uczestnicy zostan\u0105 powiadomieni, \u017Ce przejmujesz prowadzenie. B\u0119dziesz kierowa\u0107 aktualizacjami sceny tej konferencji.",
  cancel: "Anuluj",
  takeOver: "Przejmij",
  conferencing: "Konferencja",
  subscribeHubFirst: "Najpierw zasubskrybuj hub",
  stopFollowing: "Przesta\u0144 \u015Bledzi\u0107",
  resumeFollowing: "Wzn\xF3w \u015Bledzenie"
};
var uk = {
  dialogTitle: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F",
  close: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
  closeAria: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
  createSection: "\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  conferenceTitle: "\u041D\u0430\u0437\u0432\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  selectConferenceTitle: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043D\u0430\u0437\u0432\u0443",
  otherTitle: "\u0406\u043D\u0448\u0435\u2026",
  customTitle: "\u0412\u043B\u0430\u0441\u043D\u0430 \u043D\u0430\u0437\u0432\u0430",
  customTitlePlaceholder: "\u0412\u0432\u0435\u0434\u0456\u0442\u044C \u043D\u0430\u0437\u0432\u0443 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  users: "\u041A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456",
  loadingUsers: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0435\u043D\u043D\u044F \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456\u0432\u2026",
  noUsers: "\u041D\u0435\u043C\u0430\u0454 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0438\u0445 \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0456\u0432",
  createConference: "\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  creating: "\u0421\u0442\u0432\u043E\u0440\u0435\u043D\u043D\u044F\u2026",
  joinSection: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  activeConferences: "\u0410\u043A\u0442\u0438\u0432\u043D\u0456 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  noConferences: "\u041D\u0435\u043C\u0430\u0454 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0438\u0445 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0439",
  selectConference: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  untitled: "\u0411\u0435\u0437 \u043D\u0430\u0437\u0432\u0438",
  joinConference: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  joining: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u043D\u043D\u044F\u2026",
  manageSection: "\u041A\u0435\u0440\u0443\u0432\u0430\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0454\u044E",
  titleLabel: "\u041D\u0430\u0437\u0432\u0430:",
  na: "\u043D/\u0434",
  participants: "\u0423\u0447\u0430\u0441\u043D\u0438\u043A\u0438",
  noPlaces: "\u041D\u0435\u043C\u0430\u0454 \u043C\u0456\u0441\u0446\u044C",
  leaveConference: "\u0412\u0438\u0439\u0442\u0438 \u0437 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457",
  endConference: "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  ending: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u044F\u2026",
  leaving: "\u0412\u0438\u0445\u0456\u0434\u2026",
  conferenceEnded: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E.",
  leftConference: "\u0412\u0438 \u0432\u0438\u0439\u0448\u043B\u0438 \u0437 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  connectHubFirst: "\u0421\u043F\u043E\u0447\u0430\u0442\u043A\u0443 \u043F\u0456\u0434\u043A\u043B\u044E\u0447\u0456\u0442\u044C\u0441\u044F \u0434\u043E Hub-\u0445\u0430\u0431\u0443.",
  topicRequiredHost: "\u0414\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u043D\u044F \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457 \u043F\u043E\u0442\u0440\u0456\u0431\u0435\u043D Hub topic.",
  topicRequiredJoin: "\u0429\u043E\u0431 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457, \u043F\u043E\u0442\u0440\u0456\u0431\u0435\u043D Hub topic.",
  titleRequired: "\u041F\u043E\u0442\u0440\u0456\u0431\u043D\u0430 \u043D\u0430\u0437\u0432\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  selectAttendee: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043F\u0440\u0438\u043D\u0430\u0439\u043C\u043D\u0456 \u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0430\u0441\u043D\u0438\u043A\u0430.",
  selectConferenceToJoin: "\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E, \u0434\u043E \u044F\u043A\u043E\u0457 \u0445\u043E\u0447\u0435\u0442\u0435 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F.",
  failedCreate: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u0441\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.",
  failedJoin: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  failedUpdate: "\u041D\u0435 \u0432\u0434\u0430\u043B\u043E\u0441\u044F \u043E\u043D\u043E\u0432\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.",
  inviteTitle: "\u0417\u0430\u043F\u0440\u043E\u0448\u0435\u043D\u043D\u044F \u043D\u0430 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E",
  joinAndFollow: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438",
  joinNoFollow: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F, \u0430\u043B\u0435 \u043D\u0435 \u0441\u0442\u0435\u0436\u0438\u0442\u0438",
  doNotJoin: "\u041D\u0435 \u043F\u0440\u0438\u0454\u0434\u043D\u0443\u0432\u0430\u0442\u0438\u0441\u044F",
  hostFallback: "\u0432\u0435\u0434\u0443\u0447\u0438\u0439",
  inviteLeadWithTitle: "{{title}} \u2014 \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}?",
  inviteLeadNoTitle: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457 \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}?",
  joinAndFollowHost: "\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438 \u0437\u0430 {{host}}",
  takeoverTitle: "\u041F\u0435\u0440\u0435\u0445\u043E\u043F\u0438\u0442\u0438 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F?",
  takeoverBody: "\u0412\u0435\u0434\u0443\u0447\u043E\u0433\u043E \u0442\u0430 \u0432\u0441\u0456\u0445 \u0443\u0447\u0430\u0441\u043D\u0438\u043A\u0456\u0432 \u0431\u0443\u0434\u0435 \u043F\u043E\u0432\u0456\u0434\u043E\u043C\u043B\u0435\u043D\u043E, \u0449\u043E \u0432\u0438 \u043F\u0435\u0440\u0435\u0445\u043E\u043F\u043B\u044E\u0454\u0442\u0435 \u043A\u0435\u0440\u0443\u0432\u0430\u043D\u043D\u044F. \u0412\u0438 \u043A\u0435\u0440\u0443\u0432\u0430\u0442\u0438\u043C\u0435\u0442\u0435 \u043E\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F\u043C\u0438 \u0441\u0446\u0435\u043D\u0438 \u0446\u0456\u0454\u0457 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
  cancel: "\u0421\u043A\u0430\u0441\u0443\u0432\u0430\u0442\u0438",
  takeOver: "\u041F\u0435\u0440\u0435\u0445\u043E\u043F\u0438\u0442\u0438",
  conferencing: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F",
  subscribeHubFirst: "\u0421\u043F\u043E\u0447\u0430\u0442\u043A\u0443 \u043F\u0456\u0434\u043F\u0438\u0448\u0456\u0442\u044C\u0441\u044F \u043D\u0430 \u0445\u0430\u0431",
  stopFollowing: "\u041F\u0440\u0438\u043F\u0438\u043D\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F",
  resumeFollowing: "\u0412\u0456\u0434\u043D\u043E\u0432\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F"
};
var cs2 = {
  dialogTitle: "Konference",
  close: "Zav\u0159\xEDt",
  closeAria: "Zav\u0159\xEDt",
  createSection: "Vytvo\u0159it konferenci",
  conferenceTitle: "N\xE1zev konference",
  selectConferenceTitle: "Vyberte n\xE1zev",
  otherTitle: "Jin\xFD\u2026",
  customTitle: "Vlastn\xED n\xE1zev",
  customTitlePlaceholder: "Zadejte n\xE1zev konference",
  users: "U\u017Eivatel\xE9",
  loadingUsers: "Na\u010D\xEDt\xE1n\xED u\u017Eivatel\u016F\u2026",
  noUsers: "\u017D\xE1dn\xED dostupn\xED u\u017Eivatel\xE9",
  createConference: "Vytvo\u0159it konferenci",
  creating: "Vytv\xE1\u0159en\xED\u2026",
  joinSection: "P\u0159ipojit se ke konferenci",
  activeConferences: "Aktivn\xED konference",
  noConferences: "\u017D\xE1dn\xE9 dostupn\xE9 konference",
  selectConference: "Vyberte konferenci",
  untitled: "Bez n\xE1zvu",
  joinConference: "P\u0159ipojit se ke konferenci",
  joining: "P\u0159ipojov\xE1n\xED\u2026",
  manageSection: "Spravovat konferenci",
  titleLabel: "N\xE1zev:",
  na: "n/a",
  participants: "\xDA\u010Dastn\xEDci",
  noPlaces: "\u017D\xE1dn\xE1 m\xEDsta",
  leaveConference: "Opustit konferenci",
  endConference: "Ukon\u010Dit konferenci",
  ending: "Ukon\u010Dov\xE1n\xED\u2026",
  leaving: "Opou\u0161t\u011Bn\xED\u2026",
  conferenceEnded: "Konference ukon\u010Dena.",
  leftConference: "Opustili jste konferenci.",
  connectHubFirst: "Nejprve se p\u0159ipojte k Hub hubu.",
  topicRequiredHost: "Pro po\u0159\xE1d\xE1n\xED konference je vy\u017Eadov\xE1n Hub topic.",
  topicRequiredJoin: "Pro p\u0159ipojen\xED ke konferenci je vy\u017Eadov\xE1n Hub topic.",
  titleRequired: "N\xE1zev konference je povinn\xFD.",
  selectAttendee: "Vyberte alespo\u0148 jednoho \xFA\u010Dastn\xEDka.",
  selectConferenceToJoin: "Vyberte konferenci, ke kter\xE9 se chcete p\u0159ipojit.",
  failedCreate: "Vytvo\u0159en\xED konference se nezda\u0159ilo.",
  failedJoin: "P\u0159ipojen\xED ke konferenci se nezda\u0159ilo.",
  failedUpdate: "Aktualizace konference se nezda\u0159ila.",
  inviteTitle: "Pozv\xE1nka na konferenci",
  joinAndFollow: "P\u0159ipojit se a sledovat",
  joinNoFollow: "P\u0159ipojit se, ale nesledovat",
  doNotJoin: "Nep\u0159ipojovat se",
  hostFallback: "hostitel",
  inviteLeadWithTitle: "{{title}} \u2014 p\u0159ipojit se a sledovat {{host}}?",
  inviteLeadNoTitle: "P\u0159ipojit se ke konferenci a sledovat {{host}}?",
  joinAndFollowHost: "P\u0159ipojit se a sledovat {{host}}",
  takeoverTitle: "P\u0159evz\xEDt veden\xED?",
  takeoverBody: "Hostitel a v\u0161ichni \xFA\u010Dastn\xEDci budou upozorn\u011Bni, \u017Ee p\u0159eb\xEDr\xE1te veden\xED. Budete \u0159\xEDdit aktualizace sc\xE9ny t\xE9to konference.",
  cancel: "Zru\u0161it",
  takeOver: "P\u0159evz\xEDt",
  conferencing: "Konference",
  subscribeHubFirst: "Nejprve se p\u0159ihlaste k hubu",
  stopFollowing: "P\u0159estat sledovat",
  resumeFollowing: "Obnovit sledov\xE1n\xED"
};
var nl = {
  dialogTitle: "Conferentie",
  close: "Sluiten",
  closeAria: "Sluiten",
  createSection: "Een conferentie maken",
  conferenceTitle: "Conferentietitel",
  selectConferenceTitle: "Selecteer een titel",
  otherTitle: "Anders\u2026",
  customTitle: "Aangepaste titel",
  customTitlePlaceholder: "Voer de conferentietitel in",
  users: "Gebruikers",
  loadingUsers: "Gebruikers laden\u2026",
  noUsers: "Geen gebruikers beschikbaar",
  createConference: "Conferentie maken",
  creating: "Bezig met maken\u2026",
  joinSection: "Deelnemen aan een conferentie",
  activeConferences: "Actieve conferenties",
  noConferences: "Geen conferenties beschikbaar",
  selectConference: "Selecteer een conferentie",
  untitled: "Zonder titel",
  joinConference: "Deelnemen aan conferentie",
  joining: "Bezig met deelnemen\u2026",
  manageSection: "Conferentie beheren",
  titleLabel: "Titel:",
  na: "n.v.t.",
  participants: "Deelnemers",
  noPlaces: "Geen plaatsen",
  leaveConference: "Conferentie verlaten",
  endConference: "Conferentie be\xEBindigen",
  ending: "Be\xEBindigen\u2026",
  leaving: "Verlaten\u2026",
  conferenceEnded: "Conferentie be\xEBindigd.",
  leftConference: "U hebt de conferentie verlaten.",
  connectHubFirst: "Maak eerst verbinding met de Hub-hub.",
  topicRequiredHost: "Een Hub-topic is vereist om een conferentie te hosten.",
  topicRequiredJoin: "Een Hub-topic is vereist om aan een conferentie deel te nemen.",
  titleRequired: "Conferentietitel is verplicht.",
  selectAttendee: "Selecteer minstens \xE9\xE9n deelnemer.",
  selectConferenceToJoin: "Selecteer een conferentie om deel te nemen.",
  failedCreate: "Conferentie maken mislukt.",
  failedJoin: "Deelnemen aan conferentie mislukt.",
  failedUpdate: "Conferentie bijwerken mislukt.",
  inviteTitle: "Conferentie-uitnodiging",
  joinAndFollow: "Deelnemen en volgen",
  joinNoFollow: "Deelnemen maar niet volgen",
  doNotJoin: "Niet deelnemen",
  hostFallback: "host",
  inviteLeadWithTitle: "{{title}} \u2014 deelnemen en {{host}} volgen?",
  inviteLeadNoTitle: "Deelnemen aan de conferentie en {{host}} volgen?",
  joinAndFollowHost: "Deelnemen en {{host}} volgen",
  takeoverTitle: "Overname?",
  takeoverBody: "De host en alle deelnemers worden ge\xEFnformeerd dat u de leiding overneemt. U leidt dan de sc\xE8ne-updates voor deze conferentie.",
  cancel: "Annuleren",
  takeOver: "Overnemen",
  conferencing: "Conferentie",
  subscribeHubFirst: "Abonneer u eerst op de hub",
  stopFollowing: "Stoppen met volgen",
  resumeFollowing: "Volgen hervatten"
};
var el = {
  dialogTitle: "\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  close: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
  closeAria: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
  createSection: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  conferenceTitle: "\u03A4\u03AF\u03C4\u03BB\u03BF\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  selectConferenceTitle: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03C4\u03AF\u03C4\u03BB\u03BF",
  otherTitle: "\u0386\u03BB\u03BB\u03BF\u2026",
  customTitle: "\u03A0\u03C1\u03BF\u03C3\u03B1\u03C1\u03BC\u03BF\u03C3\u03BC\u03AD\u03BD\u03BF\u03C2 \u03C4\u03AF\u03C4\u03BB\u03BF\u03C2",
  customTitlePlaceholder: "\u0395\u03B9\u03C3\u03B1\u03B3\u03AC\u03B3\u03B5\u03C4\u03B5 \u03C4\u03BF\u03BD \u03C4\u03AF\u03C4\u03BB\u03BF \u03C4\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  users: "\u03A7\u03C1\u03AE\u03C3\u03C4\u03B5\u03C2",
  loadingUsers: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03C7\u03C1\u03B7\u03C3\u03C4\u03CE\u03BD\u2026",
  noUsers: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B4\u03B9\u03B1\u03B8\u03AD\u03C3\u03B9\u03BC\u03BF\u03B9 \u03C7\u03C1\u03AE\u03C3\u03C4\u03B5\u03C2",
  createConference: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  creating: "\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1\u2026",
  joinSection: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  activeConferences: "\u0395\u03BD\u03B5\u03C1\u03B3\u03AD\u03C2 \u03B4\u03B9\u03B1\u03C3\u03BA\u03AD\u03C8\u03B5\u03B9\u03C2",
  noConferences: "\u0394\u03B5\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03BD \u03B4\u03B9\u03B1\u03B8\u03AD\u03C3\u03B9\u03BC\u03B5\u03C2 \u03B4\u03B9\u03B1\u03C3\u03BA\u03AD\u03C8\u03B5\u03B9\u03C2",
  selectConference: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  untitled: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03C4\u03AF\u03C4\u03BB\u03BF",
  joinConference: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  joining: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE\u2026",
  manageSection: "\u0394\u03B9\u03B1\u03C7\u03B5\u03AF\u03C1\u03B9\u03C3\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  titleLabel: "\u03A4\u03AF\u03C4\u03BB\u03BF\u03C2:",
  na: "\u0394/\u03A5",
  participants: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B5\u03C2",
  noPlaces: "\u03A7\u03C9\u03C1\u03AF\u03C2 \u03B8\u03AD\u03C3\u03B5\u03B9\u03C2",
  leaveConference: "\u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7 \u03B1\u03C0\u03CC \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  endConference: "\u03A4\u03B5\u03C1\u03BC\u03B1\u03C4\u03B9\u03C3\u03BC\u03CC\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2",
  ending: "\u03A4\u03B5\u03C1\u03BC\u03B1\u03C4\u03B9\u03C3\u03BC\u03CC\u03C2\u2026",
  leaving: "\u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7\u2026",
  conferenceEnded: "\u0397 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03C4\u03B5\u03C1\u03BC\u03B1\u03C4\u03AF\u03C3\u03C4\u03B7\u03BA\u03B5.",
  leftConference: "\u0391\u03C0\u03BF\u03C7\u03C9\u03C1\u03AE\u03C3\u03B1\u03C4\u03B5 \u03B1\u03C0\u03CC \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  connectHubFirst: "\u03A3\u03C5\u03BD\u03B4\u03B5\u03B8\u03B5\u03AF\u03C4\u03B5 \u03C0\u03C1\u03CE\u03C4\u03B1 \u03C3\u03C4\u03BF Slicer hub.",
  topicRequiredHost: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 Hub topic \u03B3\u03B9\u03B1 \u03C6\u03B9\u03BB\u03BF\u03BE\u03B5\u03BD\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  topicRequiredJoin: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 Hub topic \u03B3\u03B9\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  titleRequired: "\u0391\u03C0\u03B1\u03B9\u03C4\u03B5\u03AF\u03C4\u03B1\u03B9 \u03C4\u03AF\u03C4\u03BB\u03BF\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  selectAttendee: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03C4\u03BF\u03C5\u03BB\u03AC\u03C7\u03B9\u03C3\u03C4\u03BF\u03BD \u03AD\u03BD\u03B1\u03BD \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B1.",
  selectConferenceToJoin: "\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03B3\u03B9\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE.",
  failedCreate: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03B4\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  failedJoin: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE\u03C2 \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
  failedUpdate: "\u0391\u03C0\u03BF\u03C4\u03C5\u03C7\u03AF\u03B1 \u03B5\u03BD\u03B7\u03BC\u03AD\u03C1\u03C9\u03C3\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  inviteTitle: "\u03A0\u03C1\u03CC\u03C3\u03BA\u03BB\u03B7\u03C3\u03B7 \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  joinAndFollow: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7",
  joinNoFollow: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C7\u03C9\u03C1\u03AF\u03C2 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7",
  doNotJoin: "\u038C\u03C7\u03B9 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE",
  hostFallback: "\u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7\u03C2",
  inviteLeadWithTitle: "{{title}} \u2014 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}};",
  inviteLeadNoTitle: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}};",
  joinAndFollowHost: "\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03C4\u03BF\u03C5 {{host}}",
  takeoverTitle: "\u0391\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7 \u03B5\u03BB\u03AD\u03B3\u03C7\u03BF\u03C5;",
  takeoverBody: "\u039F \u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7\u03C2 \u03BA\u03B1\u03B9 \u03CC\u03BB\u03BF\u03B9 \u03BF\u03B9 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B5\u03C2 \u03B8\u03B1 \u03B5\u03B9\u03B4\u03BF\u03C0\u03BF\u03B9\u03B7\u03B8\u03BF\u03CD\u03BD \u03CC\u03C4\u03B9 \u03B1\u03BD\u03B1\u03BB\u03B1\u03BC\u03B2\u03AC\u03BD\u03B5\u03C4\u03B5 \u03C4\u03BF\u03BD \u03AD\u03BB\u03B5\u03B3\u03C7\u03BF. \u0398\u03B1 \u03BF\u03B4\u03B7\u03B3\u03B5\u03AF\u03C4\u03B5 \u03C4\u03B9\u03C2 \u03B5\u03BD\u03B7\u03BC\u03B5\u03C1\u03CE\u03C3\u03B5\u03B9\u03C2 \u03C3\u03BA\u03B7\u03BD\u03AE\u03C2 \u03B1\u03C5\u03C4\u03AE\u03C2 \u03C4\u03B7\u03C2 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2.",
  cancel: "\u0391\u03BA\u03CD\u03C1\u03C9\u03C3\u03B7",
  takeOver: "\u0391\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7",
  conferencing: "\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
  subscribeHubFirst: "\u0395\u03B3\u03B3\u03C1\u03B1\u03C6\u03B5\u03AF\u03C4\u03B5 \u03C0\u03C1\u03CE\u03C4\u03B1 \u03C3\u03C4\u03BF hub",
  stopFollowing: "\u0394\u03B9\u03B1\u03BA\u03BF\u03C0\u03AE \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7\u03C2",
  resumeFollowing: "\u0395\u03C0\u03B1\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7\u03C2"
};
var lv = {
  dialogTitle: "Konference",
  close: "Aizv\u0113rt",
  closeAria: "Aizv\u0113rt",
  createSection: "Izveidot konferenci",
  conferenceTitle: "Konferences nosaukums",
  selectConferenceTitle: "Atlas\u012Bt nosaukumu",
  otherTitle: "Cits\u2026",
  customTitle: "Piel\u0101gots nosaukums",
  customTitlePlaceholder: "Ievadiet konferences nosaukumu",
  users: "Lietot\u0101ji",
  loadingUsers: "Iel\u0101d\u0113 lietot\u0101jus\u2026",
  noUsers: "Nav pieejamu lietot\u0101ju",
  createConference: "Izveidot konferenci",
  creating: "Izveido\u2026",
  joinSection: "Pievienoties konferencei",
  activeConferences: "Akt\u012Bv\u0101s konferences",
  noConferences: "Nav pieejamu konferen\u010Du",
  selectConference: "Atlas\u012Bt konferenci",
  untitled: "Bez nosaukuma",
  joinConference: "Pievienoties konferencei",
  joining: "Pievienojas\u2026",
  manageSection: "P\u0101rvald\u012Bt konferenci",
  titleLabel: "Nosaukums:",
  na: "n/a",
  participants: "Dal\u012Bbnieki",
  noPlaces: "Nav vietu",
  leaveConference: "Atst\u0101t konferenci",
  endConference: "Beigt konferenci",
  ending: "Beidz\u2026",
  leaving: "Atst\u0101j\u2026",
  conferenceEnded: "Konference beigusies.",
  leftConference: "J\u016Bs atst\u0101j\u0101t konferenci.",
  connectHubFirst: "Vispirms piesl\u0113dzieties Slicer hub.",
  topicRequiredHost: "Lai r\u012Bkotu konferenci, nepiecie\u0161ams Hub topic.",
  topicRequiredJoin: "Lai pievienotos konferencei, nepiecie\u0161ams Hub topic.",
  titleRequired: "Nepiecie\u0161ams konferences nosaukums.",
  selectAttendee: "Atlasiet vismaz vienu dal\u012Bbnieku.",
  selectConferenceToJoin: "Atlasiet konferenci, kurai pievienoties.",
  failedCreate: "Neizdev\u0101s izveidot konferenci.",
  failedJoin: "Neizdev\u0101s pievienoties konferencei.",
  failedUpdate: "Neizdev\u0101s atjaunin\u0101t konferenci.",
  inviteTitle: "Uzaicin\u0101jums uz konferenci",
  joinAndFollow: "Pievienoties un sekot",
  joinNoFollow: "Pievienoties, bet nesekot",
  doNotJoin: "Nepievienoties",
  hostFallback: "vad\u012Bt\u0101js",
  inviteLeadWithTitle: "{{title}} \u2014 pievienoties un sekot {{host}}?",
  inviteLeadNoTitle: "Pievienoties konferencei un sekot {{host}}?",
  joinAndFollowHost: "Pievienoties un sekot {{host}}",
  takeoverTitle: "P\u0101r\u0146emt vad\u012Bbu?",
  takeoverBody: "Vad\u012Bt\u0101js un visi dal\u012Bbnieki tiks inform\u0113ti, ka j\u016Bs p\u0101r\u0146emat vad\u012Bbu. J\u016Bs vad\u012Bsiet \u0161\u012Bs konferences ainas atjaunin\u0101jumus.",
  cancel: "Atcelt",
  takeOver: "P\u0101r\u0146emt",
  conferencing: "Konference",
  subscribeHubFirst: "Vispirms abon\u0113jiet hub",
  stopFollowing: "P\u0101rtraukt seko\u0161anu",
  resumeFollowing: "Ats\u0101kt seko\u0161anu"
};
var hu = {
  dialogTitle: "Konferencia",
  close: "Bez\xE1r\xE1s",
  closeAria: "Bez\xE1r\xE1s",
  createSection: "Konferencia l\xE9trehoz\xE1sa",
  conferenceTitle: "Konferencia c\xEDme",
  selectConferenceTitle: "C\xEDm kiv\xE1laszt\xE1sa",
  otherTitle: "Egy\xE9b\u2026",
  customTitle: "Egy\xE9ni c\xEDm",
  customTitlePlaceholder: "Adja meg a konferencia c\xEDm\xE9t",
  users: "Felhaszn\xE1l\xF3k",
  loadingUsers: "Felhaszn\xE1l\xF3k bet\xF6lt\xE9se\u2026",
  noUsers: "Nincs el\xE9rhet\u0151 felhaszn\xE1l\xF3",
  createConference: "Konferencia l\xE9trehoz\xE1sa",
  creating: "L\xE9trehoz\xE1s\u2026",
  joinSection: "Csatlakoz\xE1s konferenci\xE1hoz",
  activeConferences: "Akt\xEDv konferenci\xE1k",
  noConferences: "Nincs el\xE9rhet\u0151 konferencia",
  selectConference: "Konferencia kiv\xE1laszt\xE1sa",
  untitled: "N\xE9vtelen",
  joinConference: "Csatlakoz\xE1s a konferenci\xE1hoz",
  joining: "Csatlakoz\xE1s\u2026",
  manageSection: "Konferencia kezel\xE9se",
  titleLabel: "C\xEDm:",
  na: "n/a",
  participants: "R\xE9sztvev\u0151k",
  noPlaces: "Nincs hely",
  leaveConference: "Kil\xE9p\xE9s a konferenci\xE1b\xF3l",
  endConference: "Konferencia befejez\xE9se",
  ending: "Befejez\xE9s\u2026",
  leaving: "Kil\xE9p\xE9s\u2026",
  conferenceEnded: "A konferencia v\xE9get \xE9rt.",
  leftConference: "Kil\xE9pett a konferenci\xE1b\xF3l.",
  connectHubFirst: "El\u0151sz\xF6r csatlakozzon a Hub hubhoz.",
  topicRequiredHost: "Konferencia ind\xEDt\xE1s\xE1hoz Hub topic sz\xFCks\xE9ges.",
  topicRequiredJoin: "Konferenci\xE1hoz csatlakoz\xE1shoz Hub topic sz\xFCks\xE9ges.",
  titleRequired: "A konferencia c\xEDme k\xF6telez\u0151.",
  selectAttendee: "V\xE1lasszon legal\xE1bb egy r\xE9sztvev\u0151t.",
  selectConferenceToJoin: "V\xE1lasszon konferenci\xE1t a csatlakoz\xE1shoz.",
  failedCreate: "Nem siker\xFClt l\xE9trehozni a konferenci\xE1t.",
  failedJoin: "Nem siker\xFClt csatlakozni a konferenci\xE1hoz.",
  failedUpdate: "Nem siker\xFClt friss\xEDteni a konferenci\xE1t.",
  inviteTitle: "Konferenciamegh\xEDv\xF3",
  joinAndFollow: "Csatlakoz\xE1s \xE9s k\xF6vet\xE9s",
  joinNoFollow: "Csatlakoz\xE1s k\xF6vet\xE9s n\xE9lk\xFCl",
  doNotJoin: "Nem csatlakozom",
  hostFallback: "h\xE1zigazda",
  inviteLeadWithTitle: "{{title}} \u2014 csatlakoz\xE1s \xE9s {{host}} k\xF6vet\xE9se?",
  inviteLeadNoTitle: "Csatlakoz\xE1s a konferenci\xE1hoz \xE9s {{host}} k\xF6vet\xE9se?",
  joinAndFollowHost: "Csatlakoz\xE1s \xE9s {{host}} k\xF6vet\xE9se",
  takeoverTitle: "\xC1tv\xE9tel?",
  takeoverBody: "A h\xE1zigazda \xE9s minden r\xE9sztvev\u0151 \xE9rtes\xEDt\xE9st kap, hogy \xD6n \xE1tveszi a vezet\xE9st. \xD6n ir\xE1ny\xEDtja majd a konferencia jelenetfriss\xEDt\xE9seit.",
  cancel: "M\xE9gse",
  takeOver: "\xC1tv\xE9tel",
  conferencing: "Konferencia",
  subscribeHubFirst: "El\u0151sz\xF6r iratkozzon fel a hubra",
  stopFollowing: "K\xF6vet\xE9s le\xE1ll\xEDt\xE1sa",
  resumeFollowing: "K\xF6vet\xE9s folytat\xE1sa"
};
var lt2 = {
  dialogTitle: "Konferencija",
  close: "U\u017Edaryti",
  closeAria: "U\u017Edaryti",
  createSection: "Sukurti konferencij\u0105",
  conferenceTitle: "Konferencijos pavadinimas",
  selectConferenceTitle: "Pasirinkite pavadinim\u0105",
  otherTitle: "Kita\u2026",
  customTitle: "Pasirinktinis pavadinimas",
  customTitlePlaceholder: "\u012Eveskite konferencijos pavadinim\u0105",
  users: "Naudotojai",
  loadingUsers: "\u012Ekeliami naudotojai\u2026",
  noUsers: "N\u0117ra galim\u0173 naudotoj\u0173",
  createConference: "Sukurti konferencij\u0105",
  creating: "Kuriama\u2026",
  joinSection: "Prisijungti prie konferencijos",
  activeConferences: "Aktyvios konferencijos",
  noConferences: "N\u0117ra galim\u0173 konferencij\u0173",
  selectConference: "Pasirinkite konferencij\u0105",
  untitled: "Be pavadinimo",
  joinConference: "Prisijungti prie konferencijos",
  joining: "Jungiamasi\u2026",
  manageSection: "Tvarkyti konferencij\u0105",
  titleLabel: "Pavadinimas:",
  na: "n/d",
  participants: "Dalyviai",
  noPlaces: "N\u0117ra viet\u0173",
  leaveConference: "I\u0161eiti i\u0161 konferencijos",
  endConference: "Baigti konferencij\u0105",
  ending: "Baigiama\u2026",
  leaving: "I\u0161einama\u2026",
  conferenceEnded: "Konferencija baigta.",
  leftConference: "I\u0161\u0117jote i\u0161 konferencijos.",
  connectHubFirst: "Pirmiausia prisijunkite prie Slicer hub.",
  topicRequiredHost: "Konferencijai vesti reikalingas Hub topic.",
  topicRequiredJoin: "Norint prisijungti prie konferencijos, reikalingas Hub topic.",
  titleRequired: "Reikalingas konferencijos pavadinimas.",
  selectAttendee: "Pasirinkite bent vien\u0105 dalyv\u012F.",
  selectConferenceToJoin: "Pasirinkite konferencij\u0105, prie kurios jungtis.",
  failedCreate: "Nepavyko sukurti konferencijos.",
  failedJoin: "Nepavyko prisijungti prie konferencijos.",
  failedUpdate: "Nepavyko atnaujinti konferencijos.",
  inviteTitle: "Kvietimas \u012F konferencij\u0105",
  joinAndFollow: "Prisijungti ir sekti",
  joinNoFollow: "Prisijungti, bet nesekti",
  doNotJoin: "Neprisijungti",
  hostFallback: "ved\u0117jas",
  inviteLeadWithTitle: "{{title}} \u2014 prisijungti ir sekti {{host}}?",
  inviteLeadNoTitle: "Prisijungti prie konferencijos ir sekti {{host}}?",
  joinAndFollowHost: "Prisijungti ir sekti {{host}}",
  takeoverTitle: "Perimti valdym\u0105?",
  takeoverBody: "Ved\u0117jas ir visi dalyviai bus informuoti, kad perimate valdym\u0105. V\u0117site \u0161ios konferencijos scenos atnaujinimus.",
  cancel: "At\u0161aukti",
  takeOver: "Perimti",
  conferencing: "Konferencija",
  subscribeHubFirst: "Pirmiausia u\u017Esiprenumeruokite hub",
  stopFollowing: "Nustoti sekti",
  resumeFollowing: "T\u0119sti sekim\u0105"
};
var ro2 = {
  dialogTitle: "Conferin\u021B\u0103",
  close: "\xCEnchide",
  closeAria: "\xCEnchide",
  createSection: "Creeaz\u0103 o conferin\u021B\u0103",
  conferenceTitle: "Titlul conferin\u021Bei",
  selectConferenceTitle: "Selecteaz\u0103 un titlu",
  otherTitle: "Altul\u2026",
  customTitle: "Titlu personalizat",
  customTitlePlaceholder: "Introduce\u021Bi titlul conferin\u021Bei",
  users: "Utilizatori",
  loadingUsers: "Se \xEEncarc\u0103 utilizatorii\u2026",
  noUsers: "Nu exist\u0103 utilizatori disponibili",
  createConference: "Creeaz\u0103 conferin\u021Ba",
  creating: "Se creeaz\u0103\u2026",
  joinSection: "Particip\u0103 la o conferin\u021B\u0103",
  activeConferences: "Conferin\u021Be active",
  noConferences: "Nu exist\u0103 conferin\u021Be disponibile",
  selectConference: "Selecteaz\u0103 o conferin\u021B\u0103",
  untitled: "F\u0103r\u0103 titlu",
  joinConference: "Particip\u0103 la conferin\u021B\u0103",
  joining: "Se particip\u0103\u2026",
  manageSection: "Gestioneaz\u0103 conferin\u021Ba",
  titleLabel: "Titlu:",
  na: "N/A",
  participants: "Participan\u021Bi",
  noPlaces: "F\u0103r\u0103 locuri",
  leaveConference: "P\u0103r\u0103se\u0219te conferin\u021Ba",
  endConference: "\xCEncheie conferin\u021Ba",
  ending: "Se \xEEncheie\u2026",
  leaving: "Se p\u0103r\u0103se\u0219te\u2026",
  conferenceEnded: "Conferin\u021Ba s-a \xEEncheiat.",
  leftConference: "A\u021Bi p\u0103r\u0103sit conferin\u021Ba.",
  connectHubFirst: "Conecta\u021Bi-v\u0103 mai \xEEnt\xE2i la hub-ul Hub.",
  topicRequiredHost: "Este necesar un topic Hub pentru a g\u0103zdui o conferin\u021B\u0103.",
  topicRequiredJoin: "Este necesar un topic Hub pentru a participa la o conferin\u021B\u0103.",
  titleRequired: "Titlul conferin\u021Bei este obligatoriu.",
  selectAttendee: "Selecta\u021Bi cel pu\u021Bin un participant.",
  selectConferenceToJoin: "Selecta\u021Bi o conferin\u021B\u0103 la care s\u0103 participa\u021Bi.",
  failedCreate: "Crearea conferin\u021Bei a e\u0219uat.",
  failedJoin: "Participarea la conferin\u021B\u0103 a e\u0219uat.",
  failedUpdate: "Actualizarea conferin\u021Bei a e\u0219uat.",
  inviteTitle: "Invita\u021Bie la conferin\u021B\u0103",
  joinAndFollow: "Particip\u0103 \u0219i urmeaz\u0103",
  joinNoFollow: "Particip\u0103, dar nu urma",
  doNotJoin: "Nu participa",
  hostFallback: "gazd\u0103",
  inviteLeadWithTitle: "{{title}} \u2014 participa\u021Bi \u0219i urma\u021Bi pe {{host}}?",
  inviteLeadNoTitle: "Participa\u021Bi la conferin\u021B\u0103 \u0219i urma\u021Bi pe {{host}}?",
  joinAndFollowHost: "Particip\u0103 \u0219i urmeaz\u0103 pe {{host}}",
  takeoverTitle: "Preia controlul?",
  takeoverBody: "Gazda \u0219i to\u021Bi participan\u021Bii vor fi anun\u021Ba\u021Bi c\u0103 prelua\u021Bi controlul. Ve\u021Bi conduce actualiz\u0103rile de scen\u0103 ale acestei conferin\u021Be.",
  cancel: "Anuleaz\u0103",
  takeOver: "Preia",
  conferencing: "Conferin\u021B\u0103",
  subscribeHubFirst: "Abona\u021Bi-v\u0103 mai \xEEnt\xE2i la hub",
  stopFollowing: "Opre\u0219te urm\u0103rirea",
  resumeFollowing: "Reia urm\u0103rirea"
};
var no2 = {
  dialogTitle: "Konferanse",
  close: "Lukk",
  closeAria: "Lukk",
  createSection: "Opprett en konferanse",
  conferenceTitle: "Konferansetittel",
  selectConferenceTitle: "Velg en tittel",
  otherTitle: "Annet\u2026",
  customTitle: "Egendefinert tittel",
  customTitlePlaceholder: "Skriv inn konferansetittel",
  users: "Brukere",
  loadingUsers: "Laster brukere\u2026",
  noUsers: "Ingen brukere tilgjengelig",
  createConference: "Opprett konferanse",
  creating: "Oppretter\u2026",
  joinSection: "Bli med i en konferanse",
  activeConferences: "Aktive konferanser",
  noConferences: "Ingen konferanser tilgjengelig",
  selectConference: "Velg en konferanse",
  untitled: "Uten tittel",
  joinConference: "Bli med i konferansen",
  joining: "Blir med\u2026",
  manageSection: "Administrer konferanse",
  titleLabel: "Tittel:",
  na: "i/t",
  participants: "Deltakere",
  noPlaces: "Ingen steder",
  leaveConference: "Forlat konferansen",
  endConference: "Avslutt konferansen",
  ending: "Avslutter\u2026",
  leaving: "Forlater\u2026",
  conferenceEnded: "Konferansen er avsluttet.",
  leftConference: "Du forlot konferansen.",
  connectHubFirst: "Koble til Hub-huben f\xF8rst.",
  topicRequiredHost: "Hub-topic kreves for \xE5 v\xE6re vert for en konferanse.",
  topicRequiredJoin: "Hub-topic kreves for \xE5 bli med i en konferanse.",
  titleRequired: "Konferansetittel er p\xE5krevd.",
  selectAttendee: "Velg minst \xE9n deltaker.",
  selectConferenceToJoin: "Velg en konferanse \xE5 bli med i.",
  failedCreate: "Kunne ikke opprette konferansen.",
  failedJoin: "Kunne ikke bli med i konferansen.",
  failedUpdate: "Kunne ikke oppdatere konferansen.",
  inviteTitle: "Konferanseinvitasjon",
  joinAndFollow: "Bli med og f\xF8lg",
  joinNoFollow: "Bli med, men ikke f\xF8lg",
  doNotJoin: "Ikke bli med",
  hostFallback: "vert",
  inviteLeadWithTitle: "{{title}} \u2014 bli med og f\xF8lge {{host}}?",
  inviteLeadNoTitle: "Bli med i konferansen og f\xF8lge {{host}}?",
  joinAndFollowHost: "Bli med og f\xF8lg {{host}}",
  takeoverTitle: "Ta over?",
  takeoverBody: "Verten og alle deltakere blir varslet om at du tar over. Du vil lede sceneoppdateringene for denne konferansen.",
  cancel: "Avbryt",
  takeOver: "Ta over",
  conferencing: "Konferanse",
  subscribeHubFirst: "Abonner p\xE5 huben f\xF8rst",
  stopFollowing: "Stopp \xE5 f\xF8lge",
  resumeFollowing: "Fortsett \xE5 f\xF8lge"
};
var ar2 = {
  dialogTitle: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  close: "\u0625\u063A\u0644\u0627\u0642",
  closeAria: "\u0625\u063A\u0644\u0627\u0642",
  createSection: "\u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631",
  conferenceTitle: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  selectConferenceTitle: "\u0627\u062E\u062A\u0631 \u0639\u0646\u0648\u0627\u0646 \u0645\u0624\u062A\u0645\u0631",
  otherTitle: "\u0623\u062E\u0631\u0649\u2026",
  customTitle: "\u0639\u0646\u0648\u0627\u0646 \u0645\u062E\u0635\u0635",
  customTitlePlaceholder: "\u0623\u062F\u062E\u0644 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  users: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646",
  loadingUsers: "\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646\u2026",
  noUsers: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646",
  createConference: "\u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631",
  creating: "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0646\u0634\u0627\u0621\u2026",
  joinSection: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631",
  activeConferences: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A \u0627\u0644\u0646\u0634\u0637\u0629",
  noConferences: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  selectConference: "\u0627\u062E\u062A\u0631 \u0645\u0624\u062A\u0645\u0631\u0627\u064B",
  untitled: "\u0628\u062F\u0648\u0646 \u0639\u0646\u0648\u0627\u0646",
  joinConference: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  joining: "\u062C\u0627\u0631\u064D \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645\u2026",
  manageSection: "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  titleLabel: "\u0627\u0644\u0639\u0646\u0648\u0627\u0646:",
  na: "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D",
  participants: "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0648\u0646",
  noPlaces: "\u0644\u0627 \u0623\u0645\u0627\u0643\u0646",
  leaveConference: "\u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  endConference: "\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u0645\u0624\u062A\u0645\u0631",
  ending: "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0646\u0647\u0627\u0621\u2026",
  leaving: "\u062C\u0627\u0631\u064D \u0627\u0644\u0645\u063A\u0627\u062F\u0631\u0629\u2026",
  conferenceEnded: "\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  leftConference: "\u063A\u0627\u062F\u0631\u062A \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  connectHubFirst: "\u0627\u062A\u0635\u0644 \u0628\u0645\u0631\u0643\u0632 Hub \u0623\u0648\u0644\u0627\u064B.",
  topicRequiredHost: "\u0645\u0648\u0636\u0648\u0639 Hub \u0645\u0637\u0644\u0648\u0628 \u0644\u0627\u0633\u062A\u0636\u0627\u0641\u0629 \u0645\u0624\u062A\u0645\u0631.",
  topicRequiredJoin: "\u0645\u0648\u0636\u0648\u0639 Hub \u0645\u0637\u0644\u0648\u0628 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631.",
  titleRequired: "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0645\u0637\u0644\u0648\u0628.",
  selectAttendee: "\u062D\u062F\u062F \u0645\u0648\u0636\u0648\u0639 \u0645\u0634\u0627\u0631\u0643 \u0648\u0627\u062D\u062F \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  selectConferenceToJoin: "\u0627\u062E\u062A\u0631 \u0645\u0624\u062A\u0645\u0631\u0627\u064B \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u064A\u0647.",
  failedCreate: "\u0641\u0634\u0644 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  failedJoin: "\u0641\u0634\u0644 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  failedUpdate: "\u0641\u0634\u0644 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  inviteTitle: "\u062F\u0639\u0648\u0629 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631",
  joinAndFollow: "\u0627\u0646\u0636\u0645 \u0648\u0627\u062A\u0628\u0639",
  joinNoFollow: "\u0627\u0646\u0636\u0645 \u062F\u0648\u0646 \u0645\u062A\u0627\u0628\u0639\u0629",
  doNotJoin: "\u0639\u062F\u0645 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  hostFallback: "\u0627\u0644\u0645\u0636\u064A\u0641",
  inviteLeadWithTitle: "{{title}} \u2014 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 {{host}}\u061F",
  inviteLeadNoTitle: "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 {{host}}\u061F",
  joinAndFollowHost: "\u0627\u0646\u0636\u0645 \u0648\u0627\u062A\u0628\u0639 {{host}}",
  takeoverTitle: "\u062A\u0648\u0644\u064A \u0627\u0644\u0642\u064A\u0627\u062F\u0629\u061F",
  takeoverBody: "\u0633\u064A\u062A\u0645 \u0625\u062E\u0637\u0627\u0631 \u0627\u0644\u0645\u0636\u064A\u0641 \u0648\u062C\u0645\u064A\u0639 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646 \u0628\u0623\u0646\u0643 \u062A\u062A\u0648\u0644\u0649 \u0627\u0644\u0642\u064A\u0627\u062F\u0629. \u0633\u062A\u0642\u0648\u062F \u062A\u062D\u062F\u064A\u062B\u0627\u062A \u0627\u0644\u0645\u0634\u0647\u062F \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.",
  cancel: "\u0625\u0644\u063A\u0627\u0621",
  takeOver: "\u062A\u0648\u0644\u064A \u0627\u0644\u0642\u064A\u0627\u062F\u0629",
  conferencing: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  subscribeHubFirst: "\u0627\u0634\u062A\u0631\u0643 \u0641\u064A \u0627\u0644\u0645\u0631\u0643\u0632 \u0623\u0648\u0644\u0627\u064B",
  stopFollowing: "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629",
  resumeFollowing: "\u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629"
};
var CONFERENCE_BY_LOCALE = {
  en: en2,
  ar: ar2,
  fr: fr2,
  es,
  ca,
  de: de2,
  it: it2,
  pt: pt3,
  ko,
  pl,
  uk,
  cs: cs2,
  nl,
  el,
  lv,
  hu,
  lt: lt2,
  ro: ro2,
  no: no2
};
function conferenceStringsFor(locale) {
  const code = locale || resolveStoredLocale();
  return { ...CONFERENCE_BY_LOCALE[code] };
}

// locales/en.ts
var en3 = {
  chrome: {
    conferencing: "Conferencing",
    open: "Open",
    close: "Close",
    searchPortal: "Search portal",
    searchPortalTitle: "Open the IDC search portal",
    worklist: "Worklist:",
    exploreIdc: "Explore the NCI Imaging Data Commons:",
    viewers: "Image Displays:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Classrooms:",
    anatomicalPlanes: "Classroom",
    currentContext: "Current context:",
    none: "none",
    colStudy: "Study",
    colModalities: "Modalities",
    colFormat: "Format",
    colSize: "Size",
    language: "Language",
    openStudy: "Open study",
    closeStudy: "Close the open study",
    closeContext: "Close current context",
    cannotOpen: "Cannot open",
    saveWorklist: "Save",
    loadWorklist: "Load",
    saveWorklistTitle: "Save My Worklist as JSON",
    loadWorklistTitle: "Load My Worklist from JSON"
  },
  conference: CONFERENCE_BY_LOCALE.en,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "About this application",
    aboutLinkLabel: "About",
    aboutLinkSuffix: "\u2014 licenses, acknowledgements, and trademarks.",
    quickStartTitle: "Quick Start:",
    quickStartBody: "Click one of the {{open}} buttons on the right to open a CR and use the magic wand icon {{magicWand}} to run FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "How to connect Worklist to 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Install the Slicer WebSub Interface Extension</li>
        <li>In <strong>3D Slicer</strong>, open the <strong>Hub Interface</strong> module, then the <strong>Image Display Client</strong> section.</li>
        <li>Choose hub <strong>SLICER-HUB-CLOUD</strong> (same cloud hub as this worklist). Use <strong>SLICER-HUB</strong> only when you are running a local hub on port 2018.</li>
        <li>If not using OIDC, set <strong>User</strong> to the same user as your cloud worklist (top left), then click <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic set, Connect, status Connected" width="585" height="127" />
        </li>
        <li>When connected, the worklist <strong>SlicerDesktop</strong> viewer button lights up and the worklist switches to a dedicated <strong>Slicer DICOM</strong> table (filled via <code>slicerworklist-request</code>). Click a row to load series details (<code>slicerstudyinfo-request</code>). Open a study from the list \u2014 it loads in desktop Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist with viewers (SlicerDesktop selected), Evidence Creators, and study list" width="870" height="498" />
        </li>
        <li>For browser conferencing / live view, use <strong>SlicerLive</strong> and <strong>Conferencing</strong> when others follow your node changes and camera/presentation changes.</li>
      </ol>
    `,
    howto1Title: "How to join a conference.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Open the worklist and click <strong>Conferencing</strong> on the top right.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive header with Conferencing highlighted" width="477" height="117" />
        </li>
        <li>If a conference is in progress on your hub instance, it will be shown in a dropdown.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Join a conference: active conferences dropdown and Join conference button" width="322" height="175" />
        </li>
        <li>If the conference has not started, wait for the invitation to join:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Conference invitation: Join and follow, Join but do not follow, or Do not join" width="190" height="141" />
        </li>
        <li>If you chose follow, you track the host\u2019s study and presentation. Leave anytime with <strong>Leave conference</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Header with Leave conference, your place, and a following participant" width="397" height="80" />
        </li>
        <li>If you stop following, you can then resume following or take over the conference.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Header with Resume following and Take over after stopping follow" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "How to create a conference.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Open the worklist and click <strong>Conferencing</strong> on the top right.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive header with Conferencing highlighted" width="477" height="117" />
        </li>
        <li>As the host, click <strong>Conferencing</strong> (worklist header or the SlicerLive bar). Pick a conference title and create it \u2014 you become the <strong>leading</strong> place.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Create conference: title field and Create conference button" width="167" height="192" />
        </li>
        <li>While leading, changes you make in SlicerLive (layout, window/level, segment visibility, camera, MPR slice scroll/pan/zoom, vanishing marker ink, and similar scene updates) fan out to followers on the conference.</li>
        <li>You can <strong>End conference</strong> for everyone. While leading, use the <strong>B</strong> hotkey to toggle vanishing marker ink on/off.</li>
        <li>You can test conferencing on a single desktop by using the <strong>Open another user</strong> button. See the following video for a demo: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "How to search the IDC and add to a personal list.",
    howto4Title: "How to load a local study to a viewer.",
    howto5Title: "How to use remote AI",
    howto6Title: "How to export a segment to an STL file for 3D printing.",
    howto7Title: "How to use Reporting / DICOM SR."
  }
};

// locales/ar.ts
var ar3 = {
  chrome: {
    conferencing: "\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
    open: "\u0641\u062A\u062D",
    close: "\u0625\u063A\u0644\u0627\u0642",
    searchPortal: "\u0628\u0648\u0627\u0628\u0629 \u0627\u0644\u0628\u062D\u062B",
    searchPortalTitle: "\u0641\u062A\u062D \u0628\u0648\u0627\u0628\u0629 \u0628\u062D\u062B IDC",
    worklist: "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644:",
    exploreIdc: "\u0627\u0633\u062A\u0643\u0634\u0641 NCI Imaging Data Commons:",
    viewers: "\u0627\u0644\u0639\u0627\u0631\u0636\u0627\u062A:",
    reportingClients: "\u0645\u0646\u0634\u0626\u0648 \u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "\u0627\u0644\u0645\u0642\u0631\u0631:",
    anatomicalPlanes: "Classroom",
    currentContext: "\u0627\u0644\u0633\u064A\u0627\u0642 \u0627\u0644\u062D\u0627\u0644\u064A:",
    none: "\u0644\u0627 \u0634\u064A\u0621",
    colStudy: "\u062F\u0631\u0627\u0633\u0629",
    colModalities: "\u0627\u0644\u0637\u0631\u0627\u0626\u0642",
    colFormat: "\u0627\u0644\u062A\u0646\u0633\u064A\u0642",
    colSize: "\u0627\u0644\u062D\u062C\u0645",
    language: "\u0627\u0644\u0644\u063A\u0629",
    openStudy: "\u0641\u062A\u062D \u0627\u0644\u062F\u0631\u0627\u0633\u0629",
    closeStudy: "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u062F\u0631\u0627\u0633\u0629 \u0627\u0644\u0645\u0641\u062A\u0648\u062D\u0629",
    closeContext: "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0633\u064A\u0627\u0642 \u0627\u0644\u062D\u0627\u0644\u064A",
    cannotOpen: "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0641\u062A\u062D",
    saveWorklist: "\u062D\u0641\u0638",
    loadWorklist: "\u062A\u062D\u0645\u064A\u0644",
    saveWorklistTitle: "\u062D\u0641\u0638 \u0642\u0627\u0626\u0645\u0629 \u0639\u0645\u0644\u064A \u0643\u0640 JSON",
    loadWorklistTitle: "\u062A\u062D\u0645\u064A\u0644 \u0642\u0627\u0626\u0645\u0629 \u0639\u0645\u0644\u064A \u0645\u0646 JSON"
  },
  conference: CONFERENCE_BY_LOCALE.ar,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\u062D\u0648\u0644 \u0647\u0630\u0627 \u0627\u0644\u062A\u0637\u0628\u064A\u0642",
    aboutLinkLabel: "\u062D\u0648\u0644",
    aboutLinkSuffix: "\u2014 \u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635 \u0648\u0627\u0644\u0625\u0642\u0631\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629.",
    quickStartTitle: "\u0628\u062F\u0627\u064A\u0629 \u0633\u0631\u064A\u0639\u0629:",
    quickStartBody: "\u0627\u0646\u0642\u0631 \u0623\u062D\u062F \u0623\u0632\u0631\u0627\u0631 {{open}} \u0639\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646 \u0644\u0641\u062A\u062D CR \u0648\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0623\u064A\u0642\u0648\u0646\u0629 \u0627\u0644\u0639\u0635\u0627 \u0627\u0644\u0633\u062D\u0631\u064A\u0629 {{magicWand}} \u0644\u062A\u0634\u063A\u064A\u0644 FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "\u0643\u064A\u0641\u064A\u0629 \u0631\u0628\u0637 Worklist \u0628\u0640 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>\u062B\u0628\u0651\u062A \u0627\u0645\u062A\u062F\u0627\u062F Slicer WebSub Interface</li>
        <li>\u0641\u064A <strong>3D Slicer</strong>\u060C \u0627\u0641\u062A\u062D \u0648\u062D\u062F\u0629 <strong>Hub Interface</strong> \u062B\u0645 \u0642\u0633\u0645 <strong>Image Display Client</strong>.</li>
        <li>\u0627\u062E\u062A\u0631 \u0627\u0644\u0645\u0631\u0643\u0632 <strong>SLICER-HUB-CLOUD</strong> (\u0646\u0641\u0633 \u0645\u0631\u0643\u0632 \u0627\u0644\u0633\u062D\u0627\u0628\u0629 \u0644\u0647\u0630\u0647 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644). \u0627\u0633\u062A\u062E\u062F\u0645 <strong>SLICER-HUB</strong> \u0641\u0642\u0637 \u0639\u0646\u062F \u062A\u0634\u063A\u064A\u0644 \u0645\u0631\u0643\u0632 \u0645\u062D\u0644\u064A \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u0641\u0630 2018.</li>
        <li>\u0628\u062F\u0648\u0646 OIDC\u060C \u0639\u064A\u0651\u0646 <strong>User</strong> \u0625\u0644\u0649 \u0646\u0641\u0633 \u0645\u0633\u062A\u062E\u062F\u0645 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 (\u0623\u0639\u0644\u0649 \u0627\u0644\u064A\u0633\u0627\u0631)\u060C \u062B\u0645 \u0627\u0646\u0642\u0631 <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: \u0645\u0631\u0643\u0632 SLICER-HUB-CLOUD\u060C \u0645\u0648\u0636\u0648\u0639 \u0645\u0639\u064A\u0651\u0646\u060C Connect\u060C \u062D\u0627\u0644\u0629 Connected" width="585" height="127" />
        </li>
        <li>\u0639\u0646\u062F \u0627\u0644\u0627\u062A\u0635\u0627\u0644\u060C \u064A\u0636\u064A\u0621 \u0632\u0631 \u0627\u0644\u0639\u0627\u0631\u0636 <strong>SlicerDesktop</strong>\u060C \u0648\u064A\u062A\u063A\u064A\u0651\u0631 \u0645\u062D\u062F\u062F \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0625\u0644\u0649 \xAB3D Slicer\xBB \u0648\u062A\u0639\u0631\u0636 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0645\u062D\u062A\u0648\u0649 \u0642\u0627\u0639\u062F\u0629 DICOM \u0641\u064A Slicer. \u0627\u0641\u062A\u062D \u062F\u0631\u0627\u0633\u0629 \u0645\u0646 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u2014 \u062A\u064F\u062D\u0645\u0651\u064E\u0644 \u0641\u064A Slicer \u0644\u0633\u0637\u062D \u0627\u0644\u0645\u0643\u062A\u0628.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist \u0645\u0639 \u0627\u0644\u0639\u0627\u0631\u0636\u0627\u062A (SlicerDesktop \u0645\u062D\u062F\u0651\u062F) \u0648\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0639\u0646 \u0628\u064F\u0639\u062F \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062F\u0631\u0627\u0633\u0627\u062A" width="870" height="498" />
        </li>
        <li>\u0644\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A / \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0641\u064A \u0627\u0644\u0645\u062A\u0635\u0641\u062D\u060C \u0627\u0633\u062A\u062E\u062F\u0645 <strong>SlicerLive</strong> \u0648<strong>\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A</strong> \u0639\u0646\u062F\u0645\u0627 \u064A\u062A\u0627\u0628\u0639 \u0627\u0644\u0622\u062E\u0631\u0648\u0646 \u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0627\u0644\u0639\u0642\u062F\u0629 \u0648\u0627\u0644\u0643\u0627\u0645\u064A\u0631\u0627/\u0627\u0644\u0639\u0631\u0636.</li>
      </ol>
    `,
    howto1Title: "\u0643\u064A\u0641\u064A\u0629 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\u0627\u0641\u062A\u062D \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644 \u0648\u0627\u0646\u0642\u0631 <strong>\u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A</strong> \u0623\u0639\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u0634\u0631\u064A\u0637 SlicerLive \u0645\u0639 \u062A\u0645\u064A\u064A\u0632 \u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A" width="477" height="117" />
        </li>
        <li>\u0625\u0630\u0627 \u0643\u0627\u0646 \u0645\u0624\u062A\u0645\u0631 \u062C\u0627\u0631\u064A\u0627\u064B \u0639\u0644\u0649 \u0645\u062B\u064A\u0644 \u0627\u0644\u0645\u0631\u0643\u0632 \u0644\u062F\u064A\u0643\u060C \u064A\u0638\u0647\u0631 \u0641\u064A \u0642\u0627\u0626\u0645\u0629 \u0645\u0646\u0633\u062F\u0644\u0629.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0645\u0624\u062A\u0645\u0631: \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A \u0627\u0644\u0646\u0634\u0637\u0629 \u0648\u0632\u0631 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645" width="322" height="175" />
        </li>
        <li>\u0625\u0630\u0627 \u0644\u0645 \u064A\u0628\u062F\u0623 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0628\u0639\u062F\u060C \u0627\u0646\u062A\u0638\u0631 \u0627\u0644\u062F\u0639\u0648\u0629 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="\u062F\u0639\u0648\u0629 \u0645\u0624\u062A\u0645\u0631: \u0627\u0646\u0636\u0645 \u0648\u0627\u062A\u0628\u0639\u060C \u0627\u0646\u0636\u0645 \u062F\u0648\u0646 \u0645\u062A\u0627\u0628\u0639\u0629\u060C \u0623\u0648 \u0639\u062F\u0645 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645" width="190" height="141" />
        </li>
        <li>\u0625\u0630\u0627 \u0627\u062E\u062A\u0631\u062A \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629\u060C \u062A\u062A\u0627\u0628\u0639 \u062F\u0631\u0627\u0633\u0629 \u0627\u0644\u0645\u0636\u064A\u0641 \u0648\u0639\u0631\u0636\u0647. \u063A\u0627\u062F\u0631 \u0641\u064A \u0623\u064A \u0648\u0642\u062A \u0639\u0628\u0631 <strong>\u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="\u0627\u0644\u0634\u0631\u064A\u0637 \u0645\u0639 \u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0648\u0645\u0643\u0627\u0646\u0643 \u0648\u0645\u0634\u0627\u0631\u0643 \u064A\u062A\u0627\u0628\u0639" width="397" height="80" />
        </li>
        <li>\u0625\u0630\u0627 \u0623\u0648\u0642\u0641\u062A \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629\u060C \u064A\u0645\u0643\u0646\u0643 \u0628\u0639\u062F\u0647\u0627 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0623\u0648 \u062A\u0648\u0644\u064A \u0642\u064A\u0627\u062F\u0629 \u0627\u0644\u0645\u0624\u062A\u0645\u0631.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="\u0627\u0644\u0634\u0631\u064A\u0637 \u0645\u0639 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0648\u062A\u0648\u0644\u064A \u0627\u0644\u0642\u064A\u0627\u062F\u0629 \u0628\u0639\u062F \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "\u0643\u064A\u0641\u064A\u0629 \u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\u0627\u0641\u062A\u062D \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644 \u0648\u0627\u0646\u0642\u0631 <strong>\u0627\u0644\u0645\u0624\u062A\u0645\u0631</strong> \u0641\u064A \u0623\u0639\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u0631\u0623\u0633 SlicerLive \u0645\u0639 \u062A\u0645\u064A\u064A\u0632 \u0627\u0644\u0645\u0624\u062A\u0645\u0631" width="477" height="117" />
        </li>
        <li>\u0643\u0645\u0636\u064A\u0641\u060C \u0627\u0646\u0642\u0631 <strong>\u0627\u0644\u0645\u0624\u062A\u0645\u0631</strong> (\u0631\u0623\u0633 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0639\u0645\u0644 \u0623\u0648 \u0634\u0631\u064A\u0637 SlicerLive). \u0627\u062E\u062A\u0631 \u0639\u0646\u0648\u0627\u0646\u0627\u064B \u0648\u0623\u0646\u0634\u0626\u0647 \u2014 \u062A\u0635\u0628\u062D \u0627\u0644\u0645\u0643\u0627\u0646 <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="\u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631: \u062D\u0642\u0644 \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0648\u0632\u0631 \u0625\u0646\u0634\u0627\u0621 \u0645\u0624\u062A\u0645\u0631" width="167" height="192" />
        </li>
        <li>\u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0642\u064A\u0627\u062F\u0629\u060C \u062A\u064F\u0628\u062B \u062A\u063A\u064A\u064A\u0631\u0627\u062A SlicerLive (\u0627\u0644\u062A\u062E\u0637\u064A\u0637\u060C \u0627\u0644\u0646\u0627\u0641\u0630\u0629/\u0627\u0644\u0645\u0633\u062A\u0648\u0649\u060C \u0631\u0624\u064A\u0629 \u0627\u0644\u0634\u0631\u0627\u0626\u062D\u060C \u0627\u0644\u0643\u0627\u0645\u064A\u0631\u0627\u060C \u062A\u0645\u0631\u064A\u0631/\u062A\u062D\u0631\u064A\u0643/\u062A\u0643\u0628\u064A\u0631 MPR\u060C \u0627\u0644\u062D\u0628\u0631 \u0627\u0644\u0645\u062A\u0644\u0627\u0634\u064A \u0648\u062A\u062D\u062F\u064A\u062B\u0627\u062A \u0627\u0644\u0645\u0634\u0647\u062F \u0627\u0644\u0645\u0634\u0627\u0628\u0647\u0629) \u0625\u0644\u0649 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u064A\u0646.</li>
        <li>\u064A\u0645\u0643\u0646\u0643 <strong>\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u0645\u0624\u062A\u0645\u0631</strong> \u0644\u0644\u062C\u0645\u064A\u0639. \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0642\u064A\u0627\u062F\u0629 \u0627\u0633\u062A\u062E\u062F\u0645 \u0645\u0641\u062A\u0627\u062D <strong>B</strong> \u0644\u062A\u0628\u062F\u064A\u0644 \u0627\u0644\u062D\u0628\u0631 \u0627\u0644\u0645\u062A\u0644\u0627\u0634\u064A.</li>
        <li>\u064A\u0645\u0643\u0646\u0643 \u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u0645\u0624\u062A\u0645\u0631 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632 \u0648\u0627\u062D\u062F \u0639\u0628\u0631 \u0632\u0631 <strong>Open another user</strong>. \u0634\u0627\u0647\u062F \u0641\u064A\u062F\u064A\u0648 \u0627\u0644\u0639\u0631\u0636: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "\u0643\u064A\u0641\u064A\u0629 \u0627\u0644\u0628\u062D\u062B \u0641\u064A IDC \u0648\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0634\u062E\u0635\u064A\u0629.",
    howto4Title: "\u0643\u064A\u0641\u064A\u0629 \u062A\u062D\u0645\u064A\u0644 \u062F\u0631\u0627\u0633\u0629 \u0645\u062D\u0644\u064A\u0629 \u0625\u0644\u0649 \u0639\u0627\u0631\u0636.",
    howto5Title: "\u0643\u064A\u0641\u064A\u0629 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0639\u0646 \u0628\u064F\u0639\u062F",
    howto6Title: "\u0643\u064A\u0641\u064A\u0629 \u062A\u0635\u062F\u064A\u0631 \u0645\u0642\u0637\u0639 \u0625\u0644\u0649 \u0645\u0644\u0641 STL \u0644\u0644\u0637\u0628\u0627\u0639\u0629 \u062B\u0644\u0627\u062B\u064A\u0629 \u0627\u0644\u0623\u0628\u0639\u0627\u062F.",
    howto7Title: "\u0643\u064A\u0641\u064A\u0629 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631 / DICOM SR."
  }
};

// locales/fr.ts
var fr3 = {
  chrome: {
    conferencing: "Conf\xE9rence",
    open: "Ouvrir",
    close: "Fermer",
    searchPortal: "Portail de recherche",
    searchPortalTitle: "Ouvrir le portail de recherche IDC",
    worklist: "Liste de travail:",
    exploreIdc: "Explorer le NCI Imaging Data Commons :",
    viewers: "Visionneuses :",
    reportingClients: "Cr\xE9ateurs de rapports :",
    localAi: "Cr\xE9ateurs d\u2019\xE9vidence :",
    remoteAi: "Cr\xE9ateurs d\u2019\xE9vidence :",
    classroom: "Salle de classe :",
    anatomicalPlanes: "Salle de classe",
    currentContext: "Contexte actuel :",
    none: "aucun",
    colStudy: "\xC9tude",
    colModalities: "Modalit\xE9s",
    colFormat: "Format",
    colSize: "Taille",
    language: "Langue",
    openStudy: "Ouvrir l\u2019\xE9tude",
    closeStudy: "Fermer l\u2019\xE9tude ouverte",
    closeContext: "Fermer le contexte actuel",
    cannotOpen: "Impossible d\u2019ouvrir",
    saveWorklist: "Enregistrer",
    loadWorklist: "Charger",
    saveWorklistTitle: "Enregistrer ma liste de travail en JSON",
    loadWorklistTitle: "Charger ma liste de travail depuis un JSON"
  },
  conference: CONFERENCE_BY_LOCALE.fr,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\xC0 propos de cette application",
    aboutLinkLabel: "\xC0 propos",
    aboutLinkSuffix: "\u2014 licences, remerciements et marques.",
    quickStartTitle: "D\xE9marrage rapide :",
    quickStartBody: "Cliquez sur l\u2019un des boutons {{open}} \xE0 droite pour ouvrir un CR et utiliser l\u2019ic\xF4ne baguette magique {{magicWand}} pour lancer FleXray.",
    introHtml: `
        <p>
          L\u2019
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) fait partie du Cancer Research Data Commons du NCI. Il h\xE9berge dans
          le cloud de vastes collections d\u2019imagerie oncologique en acc\xE8s libre, afin
          que chercheurs, cliniciens et enseignants puissent explorer de vraies
          \xE9tudes de qualit\xE9 clinique sans d\xE9ployer leur propre archive.
        </p>
        <p>
          L\u2019IDC s\u2019investit dans l\u2019\xE9ducation et les outils ouverts pour que
          \xE9tudiants et enseignants puissent apprendre l\u2019imagerie m\xE9dicale avec des
          donn\xE9es authentiques, des flux reproductibles et des visionneuses libres
          \u2014 pas seulement des pipelines de recherche.
        </p>
        <p>
          Cette application <strong>Classroom</strong> est un client p\xE9dagogique
          h\xE9berg\xE9 par le Hub. Elle s\u2019appuie sur l\u2019IDC (et d\u2019autres archives
          ouvertes) avec des affichages d\u2019images en direct pour glossaires,
          examens d\u2019exemple et conf\xE9rences collaboratives. Les le\xE7ons sont
          organis\xE9es en <strong>cours</strong> que les enseignants peuvent
          \xE9tendre dans le paquet Classroom.
        </p>
        <p>
          L\u2019affichage s\u2019appuie sur des plateformes open source qui partagent
          l\u2019engagement de l\u2019IDC pour une imagerie m\xE9dicale accessible&nbsp;:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 visionneuse web d\u2019images m\xE9dicales fond\xE9e sur des normes ouvertes
            (dont DICOMweb). Tr\xE8s utilis\xE9e en recherche et en enseignement, elle
            est con\xE7ue pour que modes et extensions \xE9voluent avec les flux
            p\xE9dagogiques et cliniques.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 visionneuse interop\xE9rable de microscopie sur lames issue de
            l\u2019Imaging Data Commons (National Cancer Institute), pour
            l\u2019enseignement et la recherche en imagerie sur lames enti\xE8res.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 plateforme de bureau pour la visualisation, l\u2019analyse et la
            recherche.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            s\u2019ex\xE9cute comme extension Slicer afin que Classroom, la conf\xE9rence et
            l\u2019affichage d\u2019images partagent une m\xEAme pile de messagerie ouverte,
            avec les m\xEAmes donn\xE9es et outils.
          </li>
        </ul>
        <p>
          Pour une anatomie libre et ouverte, consultez le
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          du Brigham and Women\u2019s Hospital. Il diffuse des atlas anatomiques de
          haute qualit\xE9 et des logiciels open source dans le monde entier, afin
          de d\xE9mocratiser le savoir m\xE9dical pour \xE9tudiants, cliniciens,
          chercheurs et grand public, o\xF9 qu\u2019ils vivent et dans de nombreuses
          langues. Les atlas s\u2019explorent dans le navigateur Open Anatomy
          Browser&nbsp;; le groupe a aussi cr\xE9\xE9
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          utilis\xE9 pour produire ces atlas.
        </p>
        <p>
          L\u2019
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">atlas p\xE9dagogique BoneHub</a>
          de l\u2019Universit\xE9 de Twente propose des mod\xE8les 3D interactifs du
          squelette complet de l\u2019homme et de la femme Visible Human pour
          l\u2019enseignement, la visualisation et l\u2019impression 3D. Des maillages
          STL et des fichiers CAO IGES/STEP libres (CC BY 4.0) sont disponibles
          dans le jeu de donn\xE9es
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          sur Hugging Face.
        </p>
    `,
    howto0Title: "Comment connecter Worklist \xE0 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Installez l\u2019extension Slicer WebSub Interface</li>
        <li>Dans <strong>3D Slicer</strong>, ouvrez le module <strong>Hub Interface</strong>, puis la section <strong>Image Display Client</strong>.</li>
        <li>Choisissez le hub <strong>SLICER-HUB-CLOUD</strong> (le m\xEAme hub cloud que cette liste de travail). Utilisez <strong>SLICER-HUB</strong> uniquement si vous ex\xE9cutez un hub local sur le port 2018.</li>
        <li>Sans OIDC, d\xE9finissez <strong>User</strong> sur le m\xEAme utilisateur que votre liste de travail cloud (en haut \xE0 gauche), puis cliquez sur <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client : hub SLICER-HUB-CLOUD, topic d\xE9fini, Connect, statut Connected" width="585" height="127" />
        </li>
        <li>Une fois connect\xE9, le bouton visionneuse <strong>SlicerDesktop</strong> s\u2019allume, le s\xE9lecteur de liste passe \xE0 \xAB 3D Slicer \xBB et la liste affiche le contenu de la base DICOM de Slicer. Ouvrez une \xE9tude \u2014 elle se charge dans Slicer bureau.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist avec visionneuses (SlicerDesktop s\xE9lectionn\xE9), IA distante et liste d\u2019\xE9tudes" width="870" height="498" />
        </li>
        <li>Pour la conf\xE9rence / vue live dans le navigateur, utilisez <strong>SlicerLive</strong> et <strong>Conf\xE9rence</strong> lorsque d\u2019autres suivent vos changements de n\u0153uds et de cam\xE9ra/pr\xE9sentation.</li>
      </ol>
    `,
    howto1Title: "Comment rejoindre une conf\xE9rence.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Ouvrez la worklist et cliquez sur <strong>Conf\xE9rence</strong> en haut \xE0 droite.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="En-t\xEAte SlicerLive avec Conf\xE9rence mise en \xE9vidence" width="477" height="117" />
        </li>
        <li>Si une conf\xE9rence est en cours sur votre instance de hub, elle appara\xEEt dans une liste d\xE9roulante.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Rejoindre une conf\xE9rence : liste des conf\xE9rences actives et bouton Rejoindre" width="322" height="175" />
        </li>
        <li>Si la conf\xE9rence n\u2019a pas encore commenc\xE9, attendez l\u2019invitation \xE0 rejoindre :</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Invitation : Rejoindre et suivre, Rejoindre sans suivre, ou Ne pas rejoindre" width="190" height="141" />
        </li>
        <li>Si vous avez choisi de suivre, vous suivez l\u2019\xE9tude et la pr\xE9sentation de l\u2019h\xF4te. Quittez \xE0 tout moment avec <strong>Quitter la conf\xE9rence</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="En-t\xEAte avec Quitter la conf\xE9rence, votre lieu et un participant qui suit" width="397" height="80" />
        </li>
        <li>Si vous arr\xEAtez de suivre, vous pouvez ensuite reprendre le suivi ou prendre le contr\xF4le de la conf\xE9rence.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="En-t\xEAte avec Reprendre le suivi et Prendre le contr\xF4le apr\xE8s l\u2019arr\xEAt du suivi" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Comment cr\xE9er une conf\xE9rence.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Ouvrez la worklist et cliquez sur <strong>Conf\xE9rence</strong> en haut \xE0 droite.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="En-t\xEAte SlicerLive avec Conf\xE9rence mise en \xE9vidence" width="477" height="117" />
        </li>
        <li>En tant qu\u2019h\xF4te, cliquez sur <strong>Conf\xE9rence</strong> (en-t\xEAte de la liste ou barre SlicerLive). Choisissez un titre et cr\xE9ez \u2014 vous devenez le lieu <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Cr\xE9er une conf\xE9rence : titre et bouton Cr\xE9er une conf\xE9rence" width="167" height="192" />
        </li>
        <li>En leading, vos changements dans SlicerLive (mise en page, fen\xEAtre/niveau, visibilit\xE9 des segments, cam\xE9ra, d\xE9filement/panoramique/zoom MPR, encre \xE9ph\xE9m\xE8re et mises \xE0 jour de sc\xE8ne similaires) sont diffus\xE9s aux suiveurs de la conf\xE9rence.</li>
        <li>Vous pouvez <strong>Terminer la conf\xE9rence</strong> pour tout le monde. En leading, utilisez la touche <strong>B</strong> pour activer/d\xE9sactiver l\u2019encre \xE9ph\xE9m\xE8re.</li>
        <li>Vous pouvez tester la conf\xE9rence sur un seul ordinateur avec le bouton <strong>Open another user</strong>. Voir la vid\xE9o de d\xE9monstration : <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Comment rechercher dans IDC et ajouter \xE0 une liste personnelle.",
    howto4Title: "Comment charger une \xE9tude locale dans une visionneuse.",
    howto5Title: "Comment utiliser l\u2019IA distante",
    howto6Title: "Comment exporter un segment en STL pour l\u2019impression 3D.",
    howto7Title: "Comment utiliser le Reporting / DICOM SR."
  }
};

// locales/es.ts
var es2 = {
  chrome: {
    conferencing: "Conferencia",
    open: "Abrir",
    close: "Cerrar",
    searchPortal: "Portal de b\xFAsqueda",
    searchPortalTitle: "Abrir el portal de b\xFAsqueda IDC",
    worklist: "Lista de trabajo:",
    exploreIdc: "Explorar el NCI Imaging Data Commons:",
    viewers: "Visores:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Curso:",
    anatomicalPlanes: "Classroom",
    currentContext: "Contexto actual:",
    none: "ninguno",
    colStudy: "Estudio",
    colModalities: "Modalidades",
    colFormat: "Formato",
    colSize: "Tama\xF1o",
    language: "Idioma",
    openStudy: "Abrir estudio",
    closeStudy: "Cerrar el estudio abierto",
    closeContext: "Cerrar el contexto actual",
    cannotOpen: "No se puede abrir",
    saveWorklist: "Guardar",
    loadWorklist: "Cargar",
    saveWorklistTitle: "Guardar mi lista de trabajo como JSON",
    loadWorklistTitle: "Cargar mi lista de trabajo desde JSON"
  },
  conference: CONFERENCE_BY_LOCALE.es,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Acerca de esta aplicaci\xF3n",
    aboutLinkLabel: "Acerca de",
    aboutLinkSuffix: "\u2014 licencias, agradecimientos y marcas.",
    quickStartTitle: "Inicio r\xE1pido:",
    quickStartBody: "Haz clic en uno de los botones {{open}} a la derecha para abrir un CR y usar el icono de varita m\xE1gica {{magicWand}} para ejecutar FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "C\xF3mo conectar Worklist a 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Instala la extensi\xF3n Slicer WebSub Interface</li>
        <li>En <strong>3D Slicer</strong>, abre el m\xF3dulo <strong>Hub Interface</strong> y la secci\xF3n <strong>Image Display Client</strong>.</li>
        <li>Elige el hub <strong>SLICER-HUB-CLOUD</strong> (el mismo hub en la nube que esta lista). Usa <strong>SLICER-HUB</strong> solo si ejecutas un hub local en el puerto 2018.</li>
        <li>Sin OIDC, pon <strong>User</strong> igual que el usuario de tu lista en la nube (arriba a la izquierda) y pulsa <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Al conectar, el bot\xF3n <strong>SlicerDesktop</strong> se activa, el selector pasa a \xAB3D Slicer\xBB y la lista muestra la base DICOM de Slicer. Abre un estudio \u2014 se carga en Slicer de escritorio.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist con visores, IA remota y lista de estudios" width="870" height="498" />
        </li>
        <li>Para conferencia / vista en vivo en el navegador, usa <strong>SlicerLive</strong> y <strong>Conferencia</strong> cuando otros sigan tus cambios de nodos y c\xE1mara/presentaci\xF3n.</li>
      </ol>
    `,
    howto1Title: "C\xF3mo unirse a una conferencia.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Abre la worklist y pulsa <strong>Conferencia</strong> arriba a la derecha.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cabecera SlicerLive con Conferencia resaltada" width="477" height="117" />
        </li>
        <li>Si hay una conferencia en curso en tu instancia del hub, aparecer\xE1 en un desplegable.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Unirse a una conferencia: desplegable de conferencias activas y bot\xF3n Unirse" width="322" height="175" />
        </li>
        <li>Si la conferencia a\xFAn no ha empezado, espera la invitaci\xF3n para unirte:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Invitaci\xF3n a la conferencia" width="190" height="141" />
        </li>
        <li>Si elegiste seguir, sigues el estudio y la presentaci\xF3n del anfitri\xF3n. Sal en cualquier momento con <strong>Salir de la conferencia</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Cabecera con Salir de la conferencia, tu lugar y un participante que sigue" width="397" height="80" />
        </li>
        <li>Si dejas de seguir, puedes reanudar el seguimiento o tomar el control de la conferencia.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Cabecera con Reanudar seguimiento y Tomar el control tras dejar de seguir" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "C\xF3mo crear una conferencia.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Abre la worklist y pulsa <strong>Conferencia</strong> arriba a la derecha.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cabecera SlicerLive con Conferencia resaltada" width="477" height="117" />
        </li>
        <li>Como anfitri\xF3n, pulsa <strong>Conferencia</strong> (cabecera o barra de SlicerLive). Elige un t\xEDtulo y cr\xE9ala \u2014 te conviertes en el lugar <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Crear conferencia: campo de t\xEDtulo y bot\xF3n Crear conferencia" width="167" height="192" />
        </li>
        <li>Mientras lideras, los cambios en SlicerLive (dise\xF1o, ventana/nivel, visibilidad de segmentos, c\xE1mara, desplazamiento/pan/zoom MPR, tinta ef\xEDmera y actualizaciones de escena similares) se propagan a quienes siguen.</li>
        <li>Puedes <strong>Finalizar la conferencia</strong> para todos. Mientras lideras, usa la tecla <strong>B</strong> para activar/desactivar la tinta ef\xEDmera.</li>
        <li>Puedes probar la conferencia en un solo escritorio con el bot\xF3n <strong>Open another user</strong>. Vea el siguiente v\xEDdeo de demostraci\xF3n: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "C\xF3mo buscar en IDC y a\xF1adir a una lista personal.",
    howto4Title: "C\xF3mo cargar un estudio local en un visor.",
    howto5Title: "C\xF3mo usar la IA remota",
    howto6Title: "C\xF3mo exportar un segmento a STL para impresi\xF3n 3D.",
    howto7Title: "C\xF3mo usar Reporting / DICOM SR."
  }
};

// locales/ca.ts
var ca2 = {
  chrome: {
    conferencing: "Confer\xE8ncia",
    open: "Obrir",
    close: "Tancar",
    searchPortal: "Portal de cerca",
    searchPortalTitle: "Obrir el portal de cerca IDC",
    worklist: "Llista de treball:",
    exploreIdc: "Explorar el NCI Imaging Data Commons:",
    viewers: "Visualitzadors:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Curs:",
    anatomicalPlanes: "Classroom",
    currentContext: "Context actual:",
    none: "cap",
    colStudy: "Estudi",
    colModalities: "Modalitats",
    colFormat: "Format",
    colSize: "Mida",
    language: "Idioma",
    openStudy: "Obrir l\u2019estudi",
    closeStudy: "Tancar l\u2019estudi obert",
    closeContext: "Tancar el context actual",
    cannotOpen: "No es pot obrir",
    saveWorklist: "Desa",
    loadWorklist: "Carrega",
    saveWorklistTitle: "Desa la meva llista de treball com a JSON",
    loadWorklistTitle: "Carrega la meva llista de treball des de JSON"
  },
  conference: CONFERENCE_BY_LOCALE.ca,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Quant a aquesta aplicaci\xF3",
    aboutLinkLabel: "Quant a",
    aboutLinkSuffix: "\u2014 llic\xE8ncies, agra\xEFments i marques.",
    quickStartTitle: "Inici r\xE0pid:",
    quickStartBody: "Feu clic en un dels botons {{open}} a la dreta per obrir un CR i usar la icona de vareta m\xE0gica {{magicWand}} per executar FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Com connectar Worklist a 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Instal\xB7leu l\u2019extensi\xF3 Slicer WebSub Interface</li>
        <li>A <strong>3D Slicer</strong>, obriu el m\xF2dul <strong>Hub Interface</strong> i la secci\xF3 <strong>Image Display Client</strong>.</li>
        <li>Trieu el hub <strong>SLICER-HUB-CLOUD</strong> (el mateix hub al n\xFAvol que aquesta llista). Useu <strong>SLICER-HUB</strong> nom\xE9s si executeu un hub local al port 2018.</li>
        <li>Sense OIDC, poseu <strong>User</strong> igual que l\u2019usuari de la llista al n\xFAvol (a dalt a l\u2019esquerra) i feu clic a <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD" width="585" height="127" />
        </li>
        <li>Un cop connectat, el bot\xF3 <strong>SlicerDesktop</strong> s\u2019activa, el selector passa a \xAB3D Slicer\xBB i la llista mostra la base DICOM de Slicer. Obriu un estudi \u2014 es carrega a Slicer d\u2019escriptori.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist amb visualitzadors i llista d\u2019estudis" width="870" height="498" />
        </li>
        <li>Per a confer\xE8ncia / vista en viu al navegador, useu <strong>SlicerLive</strong> i <strong>Confer\xE8ncia</strong> quan altres segueixin els canvis de nodes i c\xE0mera/presentaci\xF3.</li>
      </ol>
    `,
    howto1Title: "Com unir-se a una confer\xE8ncia.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Obriu la worklist i feu clic a <strong>Confer\xE8ncia</strong> a dalt a la dreta.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cap\xE7alera SlicerLive amb Confer\xE8ncia destacada" width="477" height="117" />
        </li>
        <li>Si hi ha una confer\xE8ncia en curs a la vostra inst\xE0ncia del hub, es mostrar\xE0 en un desplegable.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Unir-se a una confer\xE8ncia: desplegable de confer\xE8ncies actives i bot\xF3 Unir-se" width="322" height="175" />
        </li>
        <li>Si la confer\xE8ncia encara no ha comen\xE7at, espereu la invitaci\xF3 per unir-vos:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Invitaci\xF3 a la confer\xE8ncia" width="190" height="141" />
        </li>
        <li>Si heu triat seguir, seguiu l\u2019estudi i la presentaci\xF3 de l\u2019amfitri\xF3. Sortiu en qualsevol moment amb <strong>Sortir de la confer\xE8ncia</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Cap\xE7alera amb Sortir de la confer\xE8ncia, el vostre lloc i un participant que segueix" width="397" height="80" />
        </li>
        <li>Si deixeu de seguir, despr\xE9s podeu reprendre el seguiment o prendre el control de la confer\xE8ncia.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Cap\xE7alera amb Reprendre el seguiment i Prendre el control despr\xE9s d\u2019aturar el seguiment" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Com crear una confer\xE8ncia.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Obriu la worklist i feu clic a <strong>Confer\xE8ncia</strong> a dalt a la dreta.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cap\xE7alera SlicerLive amb Confer\xE8ncia destacada" width="477" height="117" />
        </li>
        <li>Com a amfitri\xF3, feu clic a <strong>Confer\xE8ncia</strong> (cap\xE7alera o barra de SlicerLive). Trieu un t\xEDtol i creeu-la \u2014 esdevindreu el lloc <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Crear confer\xE8ncia: camp de t\xEDtol i bot\xF3 Crear confer\xE8ncia" width="167" height="192" />
        </li>
        <li>Mentre lidereu, els canvis a SlicerLive (disposici\xF3, finestra/nivell, visibilitat de segments, c\xE0mera, despla\xE7ament/pan/zoom MPR, tinta ef\xEDmera i actualitzacions d\u2019escena similars) es propaguen als seguidors.</li>
        <li>Podeu <strong>Finalitzar la confer\xE8ncia</strong> per a tothom. Mentre lidereu, useu la tecla <strong>B</strong> per activar/desactivar la tinta ef\xEDmera.</li>
        <li>Podeu provar la confer\xE8ncia en un sol escriptori amb el bot\xF3 <strong>Open another user</strong>. Vegeu el v\xEDdeo de demostraci\xF3: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Com cercar a IDC i afegir a una llista personal.",
    howto4Title: "Com carregar un estudi local a un visualitzador.",
    howto5Title: "Com utilitzar la IA remota",
    howto6Title: "Com exportar un segment a STL per a impressi\xF3 3D.",
    howto7Title: "Com utilitzar Reporting / DICOM SR."
  }
};

// locales/de.ts
var de3 = {
  chrome: {
    conferencing: "Konferenz",
    open: "\xD6ffnen",
    close: "Schlie\xDFen",
    searchPortal: "Suchportal",
    searchPortalTitle: "IDC-Suchportal \xF6ffnen",
    worklist: "Worklist:",
    exploreIdc: "NCI Imaging Data Commons erkunden:",
    viewers: "Viewer:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurs:",
    anatomicalPlanes: "Classroom",
    currentContext: "Aktueller Kontext:",
    none: "keiner",
    colStudy: "Studie",
    colModalities: "Modalit\xE4ten",
    colFormat: "Format",
    colSize: "Gr\xF6\xDFe",
    language: "Sprache",
    openStudy: "Studie \xF6ffnen",
    closeStudy: "Offene Studie schlie\xDFen",
    closeContext: "Aktuellen Kontext schlie\xDFen",
    cannotOpen: "Kann nicht ge\xF6ffnet werden",
    saveWorklist: "Speichern",
    loadWorklist: "Laden",
    saveWorklistTitle: "Meine Worklist als JSON speichern",
    loadWorklistTitle: "Meine Worklist aus JSON laden"
  },
  conference: CONFERENCE_BY_LOCALE.de,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\xDCber diese Anwendung",
    aboutLinkLabel: "Info",
    aboutLinkSuffix: "\u2014 Lizenzen, Danksagungen und Marken.",
    quickStartTitle: "Schnellstart:",
    quickStartBody: "Klicken Sie rechts auf einen der {{open}} Buttons, um ein CR zu \xF6ffnen und das Zauberstab-Symbol {{magicWand}} zu verwenden, um FleXray auszuf\xFChren.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "So verbinden Sie Worklist mit 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Installieren Sie die Slicer WebSub Interface Extension</li>
        <li>\xD6ffnen Sie in <strong>3D Slicer</strong> das Modul <strong>Hub Interface</strong> und den Abschnitt <strong>Image Display Client</strong>.</li>
        <li>W\xE4hlen Sie den Hub <strong>SLICER-HUB-CLOUD</strong> (derselbe Cloud-Hub wie diese Worklist). Nutzen Sie <strong>SLICER-HUB</strong> nur, wenn Sie einen lokalen Hub auf Port 2018 betreiben.</li>
        <li>Ohne OIDC setzen Sie <strong>User</strong> auf denselben Benutzer wie Ihre Cloud-Worklist (oben links) und klicken auf <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: Hub SLICER-HUB-CLOUD, Topic gesetzt, Connect, Status Connected" width="585" height="127" />
        </li>
        <li>Nach der Verbindung leuchtet der Viewer-Button <strong>SlicerDesktop</strong>, die Worklist-Auswahl wechselt zu \u201E3D Slicer\u201C und zeigt den Inhalt der Slicer-DICOM-Datenbank. \xD6ffnen Sie eine Studie \u2014 sie wird in Desktop-Slicer geladen.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist mit Viewern (SlicerDesktop ausgew\xE4hlt), Remote-KI und Studienliste" width="870" height="498" />
        </li>
        <li>F\xFCr Browser-Konferenz / Live-Ansicht nutzen Sie <strong>SlicerLive</strong> und <strong>Konferenz</strong>, wenn andere Ihre Knoten- und Kamera-/Pr\xE4sentations\xE4nderungen folgen.</li>
      </ol>
    `,
    howto1Title: "So treten Sie einer Konferenz bei.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\xD6ffnen Sie die Worklist und klicken Sie oben rechts auf <strong>Konferenz</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-Kopfzeile mit hervorgehobener Konferenz" width="477" height="117" />
        </li>
        <li>Wenn auf Ihrer Hub-Instanz bereits eine Konferenz l\xE4uft, erscheint sie in einem Dropdown.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Konferenz beitreten: Dropdown Aktive Konferenzen und Schaltfl\xE4che Konferenz beitreten" width="322" height="175" />
        </li>
        <li>Wenn die Konferenz noch nicht gestartet ist, warten Sie auf die Einladung zum Beitreten:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Konferenzeinladung: Beitreten und folgen, Beitreten ohne Folgen oder Nicht beitreten" width="190" height="141" />
        </li>
        <li>Wenn Sie Folgen gew\xE4hlt haben, folgen Sie Studie und Pr\xE4sentation des Hosts. Verlassen Sie jederzeit mit <strong>Konferenz verlassen</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Kopfzeile mit Konferenz verlassen, Ihrem Ort und einem folgenden Teilnehmer" width="397" height="80" />
        </li>
        <li>Wenn Sie das Folgen beenden, k\xF6nnen Sie anschlie\xDFend das Folgen wieder aufnehmen oder die Konferenz \xFCbernehmen.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Kopfzeile mit Folgen fortsetzen und \xDCbernehmen nach Beenden des Folgens" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "So erstellen Sie eine Konferenz.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\xD6ffnen Sie die Worklist und klicken Sie oben rechts auf <strong>Konferenz</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-Kopfzeile mit hervorgehobener Konferenz" width="477" height="117" />
        </li>
        <li>Als Host klicken Sie auf <strong>Konferenz</strong> (Worklist-Kopfzeile oder SlicerLive-Leiste). W\xE4hlen Sie einen Titel und erstellen Sie die Konferenz \u2014 Sie werden der <strong>f\xFChrende</strong> Ort.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Konferenz erstellen: Titelfeld und Schaltfl\xE4che Konferenz erstellen" width="167" height="192" />
        </li>
        <li>W\xE4hrend Sie f\xFChren, werden \xC4nderungen in SlicerLive (Layout, Fenster/Level, Segment-Sichtbarkeit, Kamera, MPR-Scrollen/Schwenken/Zoomen, tempor\xE4re Markierungen und \xE4hnliche Szenenaktualisierungen) an die Follower der Konferenz gesendet.</li>
        <li>Sie k\xF6nnen die <strong>Konferenz beenden</strong> f\xFCr alle. W\xE4hrend Sie f\xFChren, schalten Sie mit der Taste <strong>B</strong> die tempor\xE4re Markierungsfarbe ein/aus.</li>
        <li>Sie k\xF6nnen Conferencing auf einem einzelnen Desktop mit der Schaltfl\xE4che <strong>Open another user</strong> testen. Siehe das folgende Demovideo: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "So durchsuchen Sie IDC und f\xFCgen Eintr\xE4ge zu einer pers\xF6nlichen Liste hinzu.",
    howto4Title: "So laden Sie eine lokale Studie in einen Viewer.",
    howto5Title: "So nutzen Sie Remote-KI",
    howto6Title: "So exportieren Sie ein Segment als STL f\xFCr den 3D-Druck.",
    howto7Title: "So nutzen Sie Reporting / DICOM SR."
  }
};

// locales/it.ts
var it3 = {
  chrome: {
    conferencing: "Conferenza",
    open: "Apri",
    close: "Chiudi",
    searchPortal: "Portale di ricerca",
    searchPortalTitle: "Apri il portale di ricerca IDC",
    worklist: "Worklist:",
    exploreIdc: "Esplora l\u2019NCI Imaging Data Commons:",
    viewers: "Viewer:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Corso:",
    anatomicalPlanes: "Classroom",
    currentContext: "Contesto attuale:",
    none: "nessuno",
    colStudy: "Studio",
    colModalities: "Modalit\xE0",
    colFormat: "Formato",
    colSize: "Dimensione",
    language: "Lingua",
    openStudy: "Apri studio",
    closeStudy: "Chiudi lo studio aperto",
    closeContext: "Chiudi il contesto attuale",
    cannotOpen: "Impossibile aprire",
    saveWorklist: "Salva",
    loadWorklist: "Carica",
    saveWorklistTitle: "Salva la mia worklist come JSON",
    loadWorklistTitle: "Carica la mia worklist da JSON"
  },
  conference: CONFERENCE_BY_LOCALE.it,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Informazioni su questa applicazione",
    aboutLinkLabel: "Informazioni",
    aboutLinkSuffix: "\u2014 licenze, riconoscimenti e marchi.",
    quickStartTitle: "Avvio rapido:",
    quickStartBody: "Fai clic su uno dei pulsanti {{open}} a destra per aprire un CR e usare l\u2019icona bacchetta magica {{magicWand}} per eseguire FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Come collegare Worklist a 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Installa l\u2019estensione Slicer WebSub Interface</li>
        <li>In <strong>3D Slicer</strong>, apri il modulo <strong>Hub Interface</strong> e la sezione <strong>Image Display Client</strong>.</li>
        <li>Scegli l\u2019hub <strong>SLICER-HUB-CLOUD</strong> (lo stesso hub cloud di questa worklist). Usa <strong>SLICER-HUB</strong> solo se esegui un hub locale sulla porta 2018.</li>
        <li>Senza OIDC, imposta <strong>User</strong> sullo stesso utente della worklist cloud (in alto a sinistra), poi fai clic su <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Una volta connesso, il pulsante viewer <strong>SlicerDesktop</strong> si attiva, il selettore passa a \xAB3D Slicer\xBB e la lista mostra il contenuto del database DICOM di Slicer. Apri uno studio \u2014 viene caricato in Slicer desktop.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist con viewer (SlicerDesktop selezionato), IA remota e elenco studi" width="870" height="498" />
        </li>
        <li>Per la conferenza / vista live nel browser, usa <strong>SlicerLive</strong> e <strong>Conferenza</strong> quando altri seguono le modifiche ai nodi e alla telecamera/presentazione.</li>
      </ol>
    `,
    howto1Title: "Come unirsi a una conferenza.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Apri la worklist e fai clic su <strong>Conferenza</strong> in alto a destra.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Intestazione SlicerLive con Conferenza evidenziata" width="477" height="117" />
        </li>
        <li>Se \xE8 in corso una conferenza sulla tua istanza hub, viene mostrata in un menu a discesa.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Partecipa a una conferenza: menu conferenze attive e pulsante Partecipa" width="322" height="175" />
        </li>
        <li>Se la conferenza non \xE8 ancora iniziata, attendi l\u2019invito a partecipare:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Invito: Partecipa e segui, Partecipa senza seguire, o Non partecipare" width="190" height="141" />
        </li>
        <li>Se hai scelto di seguire, segui lo studio e la presentazione dell\u2019host. Esci in qualsiasi momento con <strong>Lascia conferenza</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Intestazione con Lascia conferenza, il tuo luogo e un partecipante che segue" width="397" height="80" />
        </li>
        <li>Se interrompi il follow, puoi poi riprendere a seguire o prendere il controllo della conferenza.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Intestazione con Riprendi a seguire e Prendi il controllo dopo aver interrotto il follow" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Come creare una conferenza.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Apri la worklist e fai clic su <strong>Conferenza</strong> in alto a destra.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Intestazione SlicerLive con Conferenza evidenziata" width="477" height="117" />
        </li>
        <li>Come host, fai clic su <strong>Conferenza</strong> (intestazione worklist o barra SlicerLive). Scegli un titolo e creala \u2014 diventi il luogo <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Crea conferenza: campo titolo e pulsante Crea conferenza" width="167" height="192" />
        </li>
        <li>Mentre sei leading, le modifiche in SlicerLive (layout, finestra/livello, visibilit\xE0 segmenti, fotocamera, scroll/pan/zoom MPR, inchiostro effimero e aggiornamenti di scena simili) vengono propagate ai follower.</li>
        <li>Puoi <strong>Termina conferenza</strong> per tutti. Mentre sei leading, usa il tasto <strong>B</strong> per attivare/disattivare l\u2019inchiostro effimero.</li>
        <li>Puoi testare la conferenza su un solo desktop con il pulsante <strong>Open another user</strong>. Guarda il seguente video dimostrativo: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Come cercare in IDC e aggiungere a un elenco personale.",
    howto4Title: "Come caricare uno studio locale in un viewer.",
    howto5Title: "Come usare l\u2019IA remota",
    howto6Title: "Come esportare un segmento in STL per la stampa 3D.",
    howto7Title: "Come usare Reporting / DICOM SR."
  }
};

// locales/pt.ts
var pt4 = {
  chrome: {
    conferencing: "Confer\xEAncia",
    open: "Abrir",
    close: "Fechar",
    searchPortal: "Portal de pesquisa",
    searchPortalTitle: "Abrir o portal de pesquisa IDC",
    worklist: "Worklist:",
    exploreIdc: "Explorar o NCI Imaging Data Commons:",
    viewers: "Visualizadores:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Curso:",
    anatomicalPlanes: "Classroom",
    currentContext: "Contexto atual:",
    none: "nenhum",
    colStudy: "Estudo",
    colModalities: "Modalidades",
    colFormat: "Formato",
    colSize: "Tamanho",
    language: "Idioma",
    openStudy: "Abrir estudo",
    closeStudy: "Fechar o estudo aberto",
    closeContext: "Fechar o contexto atual",
    cannotOpen: "N\xE3o \xE9 poss\xEDvel abrir",
    saveWorklist: "Guardar",
    loadWorklist: "Carregar",
    saveWorklistTitle: "Guardar a minha worklist como JSON",
    loadWorklistTitle: "Carregar a minha worklist a partir de JSON"
  },
  conference: CONFERENCE_BY_LOCALE.pt,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Acerca desta aplica\xE7\xE3o",
    aboutLinkLabel: "Acerca",
    aboutLinkSuffix: "\u2014 licen\xE7as, agradecimentos e marcas.",
    quickStartTitle: "In\xEDcio r\xE1pido:",
    quickStartBody: "Clique num dos bot\xF5es {{open}} \xE0 direita para abrir um CR e usar o \xEDcone de varinha m\xE1gica {{magicWand}} para executar o FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Como ligar o Worklist ao 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Instale a extens\xE3o Slicer WebSub Interface</li>
        <li>No <strong>3D Slicer</strong>, abra o m\xF3dulo <strong>Hub Interface</strong> e a sec\xE7\xE3o <strong>Image Display Client</strong>.</li>
        <li>Escolha o hub <strong>SLICER-HUB-CLOUD</strong> (o mesmo hub na nuvem que esta worklist). Use <strong>SLICER-HUB</strong> apenas se executar um hub local na porta 2018.</li>
        <li>Sem OIDC, defina <strong>User</strong> igual ao utilizador da sua worklist na nuvem (canto superior esquerdo) e clique em <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Ao ligar, o bot\xE3o <strong>SlicerDesktop</strong> ativa-se, o seletor passa a \xAB3D Slicer\xBB e a lista mostra a base DICOM do Slicer. Abra um estudo \u2014 carrega no Slicer de ambiente de trabalho.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist com visualizadores (SlicerDesktop selecionado), IA remota e lista de estudos" width="870" height="498" />
        </li>
        <li>Para confer\xEAncia / vista live no browser, use <strong>SlicerLive</strong> e <strong>Confer\xEAncia</strong> quando outros seguem as suas altera\xE7\xF5es de n\xF3s e c\xE2mara/apresenta\xE7\xE3o.</li>
      </ol>
    `,
    howto1Title: "Como juntar-se a uma confer\xEAncia.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Abra a worklist e clique em <strong>Confer\xEAncia</strong> no canto superior direito.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cabe\xE7alho SlicerLive com Confer\xEAncia destacada" width="477" height="117" />
        </li>
        <li>Se houver uma confer\xEAncia em curso na sua inst\xE2ncia do hub, ser\xE1 mostrada num menu pendente.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Participar numa confer\xEAncia: menu de confer\xEAncias ativas e bot\xE3o Participar" width="322" height="175" />
        </li>
        <li>Se a confer\xEAncia ainda n\xE3o come\xE7ou, aguarde o convite para participar:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Convite: Participar e seguir, Participar sem seguir, ou N\xE3o participar" width="190" height="141" />
        </li>
        <li>Se escolheu seguir, acompanha o estudo e a apresenta\xE7\xE3o do anfitri\xE3o. Saia a qualquer momento com <strong>Sair da confer\xEAncia</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Cabe\xE7alho com Sair da confer\xEAncia, o seu local e um participante a seguir" width="397" height="80" />
        </li>
        <li>Se deixar de seguir, pode depois retomar a seguir ou assumir a confer\xEAncia.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Cabe\xE7alho com Retomar a seguir e Assumir ap\xF3s parar de seguir" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Como criar uma confer\xEAncia.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Abra a worklist e clique em <strong>Confer\xEAncia</strong> no canto superior direito.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Cabe\xE7alho SlicerLive com Confer\xEAncia destacada" width="477" height="117" />
        </li>
        <li>Como anfitri\xE3o, clique em <strong>Confer\xEAncia</strong> (cabe\xE7alho ou barra SlicerLive). Escolha um t\xEDtulo e crie \u2014 torna-se o lugar <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Criar confer\xEAncia: campo de t\xEDtulo e bot\xE3o Criar confer\xEAncia" width="167" height="192" />
        </li>
        <li>Enquanto lidera, as altera\xE7\xF5es no SlicerLive (layout, janela/n\xEDvel, visibilidade de segmentos, c\xE2mara, scroll/pan/zoom MPR, tinta ef\xE9mera e atualiza\xE7\xF5es de cena semelhantes) s\xE3o propagadas aos seguidores.</li>
        <li>Pode <strong>Terminar a confer\xEAncia</strong> para todos. Enquanto lidera, use a tecla <strong>B</strong> para ativar/desativar a tinta ef\xE9mera.</li>
        <li>Pode testar a confer\xEAncia num \xFAnico ambiente de trabalho com o bot\xE3o <strong>Open another user</strong>. Veja o v\xEDdeo de demonstra\xE7\xE3o: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Como pesquisar no IDC e adicionar a uma lista pessoal.",
    howto4Title: "Como carregar um estudo local num visualizador.",
    howto5Title: "Como usar a IA remota",
    howto6Title: "Como exportar um segmento para STL para impress\xE3o 3D.",
    howto7Title: "Como usar Reporting / DICOM SR."
  }
};

// locales/ko.ts
var ko2 = {
  chrome: {
    conferencing: "\uD654\uC0C1\uD68C\uC758",
    open: "\uC5F4\uAE30",
    close: "\uB2EB\uAE30",
    searchPortal: "\uAC80\uC0C9 \uD3EC\uD138",
    searchPortalTitle: "IDC \uAC80\uC0C9 \uD3EC\uD138 \uC5F4\uAE30",
    worklist: "\uC6CC\uD06C\uB9AC\uC2A4\uD2B8:",
    exploreIdc: "NCI Imaging Data Commons \uD0D0\uC0C9:",
    viewers: "\uBDF0\uC5B4:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "\uAC15\uC758:",
    anatomicalPlanes: "Classroom",
    currentContext: "\uD604\uC7AC \uCEE8\uD14D\uC2A4\uD2B8:",
    none: "\uC5C6\uC74C",
    colStudy: "\uAC80\uC0AC",
    colModalities: "\uBAA8\uB2EC\uB9AC\uD2F0",
    colFormat: "\uD615\uC2DD",
    colSize: "\uD06C\uAE30",
    language: "\uC5B8\uC5B4",
    openStudy: "\uAC80\uC0AC \uC5F4\uAE30",
    closeStudy: "\uC5F4\uB9B0 \uAC80\uC0AC \uB2EB\uAE30",
    closeContext: "\uD604\uC7AC \uCEE8\uD14D\uC2A4\uD2B8 \uB2EB\uAE30",
    cannotOpen: "\uC5F4 \uC218 \uC5C6\uC74C",
    saveWorklist: "\uC800\uC7A5",
    loadWorklist: "\uBD88\uB7EC\uC624\uAE30",
    saveWorklistTitle: "\uB0B4 \uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uB97C JSON\uC73C\uB85C \uC800\uC7A5",
    loadWorklistTitle: "JSON\uC5D0\uC11C \uB0B4 \uC6CC\uD06C\uB9AC\uC2A4\uD2B8 \uBD88\uB7EC\uC624\uAE30"
  },
  conference: CONFERENCE_BY_LOCALE.ko,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\uC774 \uC560\uD50C\uB9AC\uCF00\uC774\uC158 \uC815\uBCF4",
    aboutLinkLabel: "\uC815\uBCF4",
    aboutLinkSuffix: "\u2014 \uB77C\uC774\uC120\uC2A4, \uAC10\uC0AC\uC758 \uAE00, \uC0C1\uD45C.",
    quickStartTitle: "\uBE60\uB978 \uC2DC\uC791:",
    quickStartBody: "\uC624\uB978\uCABD\uC758 {{open}} \uBC84\uD2BC \uC911 \uD558\uB098\uB97C \uD074\uB9AD\uD558\uC5EC CR\uC744 \uC5F4\uACE0 \uB9C8\uBC95 \uC9C0\uD321\uC774 \uC544\uC774\uCF58 {{magicWand}}\uC73C\uB85C FleXray\uB97C \uC2E4\uD589\uD558\uC138\uC694.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "3D Slicer\uC5D0 Worklist \uC5F0\uACB0\uD558\uAE30.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Slicer WebSub Interface \uD655\uC7A5\uC744 \uC124\uCE58\uD569\uB2C8\uB2E4</li>
        <li><strong>3D Slicer</strong>\uC5D0\uC11C <strong>Hub Interface</strong> \uBAA8\uB4C8\uC744 \uC5F0 \uB2E4\uC74C <strong>Image Display Client</strong> \uC139\uC158\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4.</li>
        <li>\uD5C8\uBE0C\uB85C <strong>SLICER-HUB-CLOUD</strong>\uB97C \uC120\uD0DD\uD569\uB2C8\uB2E4(\uC774 \uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uC640 \uB3D9\uC77C\uD55C \uD074\uB77C\uC6B0\uB4DC \uD5C8\uBE0C). \uD3EC\uD2B8 2018\uC758 \uB85C\uCEEC \uD5C8\uBE0C\uB97C \uC2E4\uD589 \uC911\uC77C \uB54C\uB9CC <strong>SLICER-HUB</strong>\uB97C \uC0AC\uC6A9\uD558\uC138\uC694.</li>
        <li>OIDC\uB97C \uC0AC\uC6A9\uD558\uC9C0 \uC54A\uC73C\uBA74 <strong>User</strong>\uB97C \uD074\uB77C\uC6B0\uB4DC \uC6CC\uD06C\uB9AC\uC2A4\uD2B8(\uC67C\uCABD \uC704)\uC640 \uAC19\uC740 \uC0AC\uC6A9\uC790\uB85C \uC124\uC815\uD55C \uB4A4 <strong>Connect</strong>\uB97C \uD074\uB9AD\uD569\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>\uC5F0\uACB0\uB418\uBA74 \uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uC758 <strong>SlicerDesktop</strong> \uBDF0\uC5B4 \uBC84\uD2BC\uC774 \uD65C\uC131\uD654\uB418\uACE0, \uC120\uD0DD\uAE30\uAC00 \xAB3D Slicer\xBB\uB85C \uBC14\uB00C\uBA70 Slicer DICOM \uB370\uC774\uD130\uBCA0\uC774\uC2A4 \uB0B4\uC6A9\uC774 \uD45C\uC2DC\uB429\uB2C8\uB2E4. \uBAA9\uB85D\uC5D0\uC11C \uAC80\uC0AC\uB97C \uC5F4\uBA74 \uB370\uC2A4\uD06C\uD1B1 Slicer\uC5D0 \uB85C\uB4DC\uB429\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="\uBDF0\uC5B4(SlicerDesktop \uC120\uD0DD), \uC6D0\uACA9 AI, \uAC80\uC0AC \uBAA9\uB85D\uC774 \uC788\uB294 Worklist" width="870" height="498" />
        </li>
        <li>\uBE0C\uB77C\uC6B0\uC800 \uD654\uC0C1\uD68C\uC758 / \uB77C\uC774\uBE0C \uBCF4\uAE30\uB294 <strong>SlicerLive</strong>\uC640 <strong>\uD654\uC0C1\uD68C\uC758</strong>\uB97C \uC0AC\uC6A9\uD558\uC138\uC694. \uB2E4\uB978 \uC0AC\uC6A9\uC790\uAC00 \uB178\uB4DC\xB7\uCE74\uBA54\uB77C/\uD504\uB808\uC820\uD14C\uC774\uC158 \uBCC0\uACBD\uC744 \uB530\uB77C\uAC11\uB2C8\uB2E4.</li>
      </ol>
    `,
    howto1Title: "\uD654\uC0C1\uD68C\uC758\uC5D0 \uCC38\uAC00\uD558\uAE30.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uB97C \uC5F4\uACE0 \uC624\uB978\uCABD \uC704\uC758 <strong>\uD654\uC0C1\uD68C\uC758</strong>\uB97C \uD074\uB9AD\uD569\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\uD654\uC0C1\uD68C\uC758\uAC00 \uAC15\uC870\uB41C SlicerLive \uD5E4\uB354" width="477" height="117" />
        </li>
        <li>\uD5C8\uBE0C \uC778\uC2A4\uD134\uC2A4\uC5D0\uC11C \uC9C4\uD589 \uC911\uC778 \uD68C\uC758\uAC00 \uC788\uC73C\uBA74 \uB4DC\uB86D\uB2E4\uC6B4\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="\uD654\uC0C1\uD68C\uC758 \uCC38\uAC00: \uD65C\uC131 \uD68C\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uACFC \uCC38\uAC00 \uBC84\uD2BC" width="322" height="175" />
        </li>
        <li>\uD68C\uC758\uAC00 \uC544\uC9C1 \uC2DC\uC791\uB418\uC9C0 \uC54A\uC558\uB2E4\uBA74 \uCC38\uAC00 \uCD08\uB300\uB97C \uAE30\uB2E4\uB9AC\uC138\uC694:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="\uD68C\uC758 \uCD08\uB300: \uCC38\uAC00\uD558\uACE0 \uB530\uB77C\uAC00\uAE30, \uCC38\uAC00\uD558\uB418 \uB530\uB77C\uAC00\uC9C0 \uC54A\uAE30, \uB610\uB294 \uCC38\uAC00\uD558\uC9C0 \uC54A\uAE30" width="190" height="141" />
        </li>
        <li>\uB530\uB77C\uAC00\uAE30\uB97C \uC120\uD0DD\uD588\uB2E4\uBA74 \uD638\uC2A4\uD2B8\uC758 \uAC80\uC0AC\uC640 \uD504\uB808\uC820\uD14C\uC774\uC158\uC744 \uB530\uB78D\uB2C8\uB2E4. \uC5B8\uC81C\uB4E0\uC9C0 <strong>\uD68C\uC758 \uB098\uAC00\uAE30</strong>\uB85C \uB098\uAC11\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="\uD68C\uC758 \uB098\uAC00\uAE30, \uB0B4 \uC7A5\uC18C, \uB530\uB77C\uAC00\uB294 \uCC38\uAC00\uC790\uAC00 \uC788\uB294 \uD5E4\uB354" width="397" height="80" />
        </li>
        <li>\uD314\uB85C\uC6B0\uB97C \uC911\uC9C0\uD558\uBA74 \uB2E4\uC2DC \uD314\uB85C\uC6B0\uB97C \uC7AC\uAC1C\uD558\uAC70\uB098 \uD68C\uC758\uB97C \uC778\uC218\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="\uD314\uB85C\uC6B0 \uC911\uC9C0 \uD6C4 \uD314\uB85C\uC6B0 \uC7AC\uAC1C \uBC0F \uC778\uC218 \uBC84\uD2BC\uC774 \uC788\uB294 \uD5E4\uB354" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "\uD654\uC0C1\uD68C\uC758 \uB9CC\uB4E4\uAE30.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\uC6CC\uD06C\uB9AC\uC2A4\uD2B8\uB97C \uC5F4\uACE0 \uC624\uB978\uCABD \uC704\uC758 <strong>\uD654\uC0C1\uD68C\uC758</strong>\uB97C \uD074\uB9AD\uD569\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\uD654\uC0C1\uD68C\uC758\uAC00 \uAC15\uC870\uB41C SlicerLive \uD5E4\uB354" width="477" height="117" />
        </li>
        <li>\uD638\uC2A4\uD2B8\uB85C\uC11C <strong>\uD654\uC0C1\uD68C\uC758</strong>(\uC6CC\uD06C\uB9AC\uC2A4\uD2B8 \uD5E4\uB354 \uB610\uB294 SlicerLive \uBC14)\uB97C \uD074\uB9AD\uD569\uB2C8\uB2E4. \uC81C\uBAA9\uC744 \uC120\uD0DD\uD558\uACE0 \uB9CC\uB4E4\uBA74 <strong>leading</strong> \uC7A5\uC18C\uAC00 \uB429\uB2C8\uB2E4.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="\uD654\uC0C1\uD68C\uC758 \uB9CC\uB4E4\uAE30: \uC81C\uBAA9 \uD544\uB4DC \uBC0F \uD654\uC0C1\uD68C\uC758 \uB9CC\uB4E4\uAE30 \uBC84\uD2BC" width="167" height="192" />
        </li>
        <li>\uB9AC\uB529 \uC911 SlicerLive\uC758 \uBCC0\uACBD(\uB808\uC774\uC544\uC6C3, \uC708\uB3C4\uC6B0/\uB808\uBCA8, \uC138\uADF8\uBA3C\uD2B8 \uAC00\uC2DC\uC131, \uCE74\uBA54\uB77C, MPR \uC2A4\uD06C\uB864/\uD32C/\uC90C, \uC0AC\uB77C\uC9C0\uB294 \uC789\uD06C \uBC0F \uC720\uC0AC\uD55C \uC7A5\uBA74 \uC5C5\uB370\uC774\uD2B8)\uC774 \uD314\uB85C\uC6CC\uC5D0\uAC8C \uC804\uB2EC\uB429\uB2C8\uB2E4.</li>
        <li>\uBAA8\uB450\uB97C \uC704\uD574 <strong>\uD654\uC0C1\uD68C\uC758 \uC885\uB8CC</strong>\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uB9AC\uB529 \uC911 <strong>B</strong> \uB2E8\uCD95\uD0A4\uB85C \uC0AC\uB77C\uC9C0\uB294 \uC789\uD06C\uB97C \uCF1C\uACE0 \uB055\uB2C8\uB2E4.</li>
        <li>\uB2E8\uC77C \uB370\uC2A4\uD06C\uD1B1\uC5D0\uC11C <strong>Open another user</strong> \uBC84\uD2BC\uC73C\uB85C \uD654\uC0C1\uD68C\uC758\uB97C \uD14C\uC2A4\uD2B8\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uB370\uBAA8 \uB3D9\uC601\uC0C1: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "IDC \uAC80\uC0C9 \uBC0F \uAC1C\uC778 \uBAA9\uB85D\uC5D0 \uCD94\uAC00\uD558\uAE30.",
    howto4Title: "\uB85C\uCEEC \uAC80\uC0AC\uB97C \uBDF0\uC5B4\uC5D0 \uBD88\uB7EC\uC624\uAE30.",
    howto5Title: "\uC6D0\uACA9 AI \uC0AC\uC6A9\uD558\uAE30",
    howto6Title: "3D \uD504\uB9B0\uD305\uC6A9 STL\uB85C \uC138\uADF8\uBA3C\uD2B8 \uB0B4\uBCF4\uB0B4\uAE30.",
    howto7Title: "Reporting / DICOM SR \uC0AC\uC6A9\uD558\uAE30."
  }
};

// locales/pl.ts
var pl2 = {
  chrome: {
    conferencing: "Konferencja",
    open: "Otw\xF3rz",
    close: "Zamknij",
    searchPortal: "Portal wyszukiwania",
    searchPortalTitle: "Otw\xF3rz portal wyszukiwania IDC",
    worklist: "Worklist:",
    exploreIdc: "Przegl\u0105daj NCI Imaging Data Commons:",
    viewers: "Przegl\u0105darki:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurs:",
    anatomicalPlanes: "Classroom",
    currentContext: "Bie\u017C\u0105cy kontekst:",
    none: "brak",
    colStudy: "Badanie",
    colModalities: "Modalno\u015Bci",
    colFormat: "Format",
    colSize: "Rozmiar",
    language: "J\u0119zyk",
    openStudy: "Otw\xF3rz badanie",
    closeStudy: "Zamknij otwarte badanie",
    closeContext: "Zamknij bie\u017C\u0105cy kontekst",
    cannotOpen: "Nie mo\u017Cna otworzy\u0107",
    saveWorklist: "Zapisz",
    loadWorklist: "Wczytaj",
    saveWorklistTitle: "Zapisz moj\u0105 worklist\u0119 jako JSON",
    loadWorklistTitle: "Wczytaj moj\u0105 worklist\u0119 z JSON"
  },
  conference: CONFERENCE_BY_LOCALE.pl,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "O tej aplikacji",
    aboutLinkLabel: "O aplikacji",
    aboutLinkSuffix: "\u2014 licencje, podzi\u0119kowania i znaki towarowe.",
    quickStartTitle: "Szybki start:",
    quickStartBody: "Kliknij jeden z przycisk\xF3w {{open}} po prawej, aby otworzy\u0107 CR i u\u017Cy\u0107 ikony magicznej r\xF3\u017Cd\u017Cki {{magicWand}}, aby uruchomi\u0107 FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Jak po\u0142\u0105czy\u0107 Worklist z 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Zainstaluj rozszerzenie Slicer WebSub Interface</li>
        <li>W <strong>3D Slicer</strong> otw\xF3rz modul <strong>Hub Interface</strong>, a nast\u0119pnie sekcj\u0119 <strong>Image Display Client</strong>.</li>
        <li>Wybierz hub <strong>SLICER-HUB-CLOUD</strong> (ten sam hub w chmurze co ta worklist). U\u017Cyj <strong>SLICER-HUB</strong> tylko, gdy uruchamiasz lokalny hub na porcie 2018.</li>
        <li>Bez OIDC ustaw <strong>User</strong> na tego samego u\u017Cytkownika co w workli\u015Bcie w chmurze (lewy g\xF3rny r\xF3g), potem kliknij <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Po po\u0142\u0105czeniu przycisk przegl\u0105darki <strong>SlicerDesktop</strong> si\u0119 aktywuje, selektor zmienia si\u0119 na \xAB3D Slicer\xBB, a lista pokazuje zawarto\u015B\u0107 bazy DICOM Slicera. Otw\xF3rz badanie \u2014 wczyta si\u0119 w desktopowym Slicerze.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist z przegl\u0105darkami (wybrany SlicerDesktop), zdalnym AI i list\u0105 bada\u0144" width="870" height="498" />
        </li>
        <li>Do konferencji / widoku na \u017Cywo w przegl\u0105darce u\u017Cyj <strong>SlicerLive</strong> i <strong>Konferencji</strong>, gdy inni \u015Bledz\u0105 zmiany w\u0119z\u0142\xF3w oraz kamery/prezentacji.</li>
      </ol>
    `,
    howto1Title: "Jak do\u0142\u0105czy\u0107 do konferencji.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Otw\xF3rz worklist\u0119 i kliknij <strong>Konferencja</strong> w prawym g\xF3rnym rogu.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Nag\u0142\xF3wek SlicerLive z pod\u015Bwietlon\u0105 konferencj\u0105" width="477" height="117" />
        </li>
        <li>Je\u015Bli na Twojej instancji huba trwa konferencja, pojawi si\u0119 na li\u015Bcie rozwijanej.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Do\u0142\u0105cz do konferencji: lista aktywnych konferencji i przycisk Do\u0142\u0105cz" width="322" height="175" />
        </li>
        <li>Je\u015Bli konferencja jeszcze si\u0119 nie zacz\u0119\u0142a, poczekaj na zaproszenie do do\u0142\u0105czenia:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Zaproszenie: Do\u0142\u0105cz i \u015Bled\u017A, Do\u0142\u0105cz bez \u015Bledzenia lub Nie do\u0142\u0105czaj" width="190" height="141" />
        </li>
        <li>Je\u015Bli wybra\u0142e\u015B \u015Bledzenie, \u015Bledzisz badanie i prezentacj\u0119 hosta. Wyjd\u017A w dowolnym momencie przez <strong>Opu\u015B\u0107 konferencj\u0119</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Nag\u0142\xF3wek z Opu\u015B\u0107 konferencj\u0119, Twoim miejscem i \u015Bledz\u0105cym uczestnikiem" width="397" height="80" />
        </li>
        <li>Je\u015Bli przestaniesz \u015Bledzi\u0107, mo\u017Cesz nast\u0119pnie wznowi\u0107 \u015Bledzenie lub przej\u0105\u0107 konferencj\u0119.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Nag\u0142\xF3wek z Wzn\xF3w \u015Bledzenie i Przejmij po zatrzymaniu \u015Bledzenia" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Jak utworzy\u0107 konferencj\u0119.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Otw\xF3rz worklist\u0119 i kliknij <strong>Konferencja</strong> w prawym g\xF3rnym rogu.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Nag\u0142\xF3wek SlicerLive z wyr\xF3\u017Cnion\u0105 Konferencj\u0105" width="477" height="117" />
        </li>
        <li>Jako gospodarz kliknij <strong>Konferencja</strong> (nag\u0142\xF3wek worklisty lub pasek SlicerLive). Wybierz tytu\u0142 i utw\xF3rz \u2014 stajesz si\u0119 miejscem <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Utw\xF3rz konferencj\u0119: pole tytu\u0142u i przycisk Utw\xF3rz konferencj\u0119" width="167" height="192" />
        </li>
        <li>Podczas prowadzenia zmiany w SlicerLive (uk\u0142ad, okno/poziom, widoczno\u015B\u0107 segment\xF3w, kamera, przewijanie/pan/zoom MPR, znikaj\u0105cy atrament i podobne aktualizacje sceny) s\u0105 rozsy\u0142ane do obserwuj\u0105cych.</li>
        <li>Mo\u017Cesz <strong>Zako\u0144czy\u0107 konferencj\u0119</strong> dla wszystkich. Podczas prowadzenia u\u017Cyj klawisza <strong>B</strong>, aby w\u0142\u0105czy\u0107/wy\u0142\u0105czy\u0107 znikaj\u0105cy atrament.</li>
        <li>Mo\u017Cesz przetestowa\u0107 konferencj\u0119 na jednym pulpicie przyciskiem <strong>Open another user</strong>. Zobacz film demonstracyjny: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Jak wyszukiwa\u0107 w IDC i dodawa\u0107 do listy osobistej.",
    howto4Title: "Jak wczyta\u0107 lokalne badanie do przegl\u0105darki.",
    howto5Title: "Jak u\u017Cywa\u0107 zdalnego AI",
    howto6Title: "Jak wyeksportowa\u0107 segment do STL do druku 3D.",
    howto7Title: "Jak u\u017Cywa\u0107 Reporting / DICOM SR."
  }
};

// locales/uk.ts
var uk2 = {
  chrome: {
    conferencing: "\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F",
    open: "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438",
    close: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438",
    searchPortal: "\u041F\u043E\u0440\u0442\u0430\u043B \u043F\u043E\u0448\u0443\u043A\u0443",
    searchPortalTitle: "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u043F\u043E\u0440\u0442\u0430\u043B \u043F\u043E\u0448\u0443\u043A\u0443 IDC",
    worklist: "\u0420\u043E\u0431\u043E\u0447\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A:",
    exploreIdc: "\u041E\u0433\u043B\u044F\u0434 NCI Imaging Data Commons:",
    viewers: "\u041F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0447\u0456:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "\u041A\u0443\u0440\u0441:",
    anatomicalPlanes: "Classroom",
    currentContext: "\u041F\u043E\u0442\u043E\u0447\u043D\u0438\u0439 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442:",
    none: "\u043D\u0435\u043C\u0430\u0454",
    colStudy: "\u0414\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F",
    colModalities: "\u041C\u043E\u0434\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0456",
    colFormat: "\u0424\u043E\u0440\u043C\u0430\u0442",
    colSize: "\u0420\u043E\u0437\u043C\u0456\u0440",
    language: "\u041C\u043E\u0432\u0430",
    openStudy: "\u0412\u0456\u0434\u043A\u0440\u0438\u0442\u0438 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F",
    closeStudy: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0435 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F",
    closeContext: "\u0417\u0430\u043A\u0440\u0438\u0442\u0438 \u043F\u043E\u0442\u043E\u0447\u043D\u0438\u0439 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442",
    cannotOpen: "\u041D\u0435\u043C\u043E\u0436\u043B\u0438\u0432\u043E \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438",
    saveWorklist: "\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438",
    loadWorklist: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438",
    saveWorklistTitle: "\u0417\u0431\u0435\u0440\u0435\u0433\u0442\u0438 \u043C\u0456\u0439 \u0440\u043E\u0431\u043E\u0447\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u044F\u043A JSON",
    loadWorklistTitle: "\u0417\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438 \u043C\u0456\u0439 \u0440\u043E\u0431\u043E\u0447\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u0437 JSON"
  },
  conference: CONFERENCE_BY_LOCALE.uk,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\u041F\u0440\u043E \u0446\u044E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u0443",
    aboutLinkLabel: "\u041F\u0440\u043E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u0443",
    aboutLinkSuffix: "\u2014 \u043B\u0456\u0446\u0435\u043D\u0437\u0456\u0457, \u043F\u043E\u0434\u044F\u043A\u0438 \u0442\u0430 \u0442\u043E\u0440\u0433\u043E\u0432\u0435\u043B\u044C\u043D\u0456 \u043C\u0430\u0440\u043A\u0438.",
    quickStartTitle: "\u0428\u0432\u0438\u0434\u043A\u0438\u0439 \u0441\u0442\u0430\u0440\u0442:",
    quickStartBody: "\u041D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C \u043E\u0434\u043D\u0443 \u0437 \u043A\u043D\u043E\u043F\u043E\u043A {{open}} \u043F\u0440\u0430\u0432\u043E\u0440\u0443\u0447, \u0449\u043E\u0431 \u0432\u0456\u0434\u043A\u0440\u0438\u0442\u0438 CR \u0456 \u0432\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u0430\u0442\u0438 \u0437\u043D\u0430\u0447\u043E\u043A \u0447\u0430\u0440\u0456\u0432\u043D\u043E\u0457 \u043F\u0430\u043B\u0438\u0447\u043A\u0438 {{magicWand}} \u0434\u043B\u044F \u0437\u0430\u043F\u0443\u0441\u043A\u0443 FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "\u042F\u043A \u043F\u0456\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0438 Worklist \u0434\u043E 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u0456\u0442\u044C \u0440\u043E\u0437\u0448\u0438\u0440\u0435\u043D\u043D\u044F Slicer WebSub Interface</li>
        <li>\u0423 <strong>3D Slicer</strong> \u0432\u0456\u0434\u043A\u0440\u0438\u0439\u0442\u0435 \u043C\u043E\u0434\u0443\u043B\u044C <strong>Hub Interface</strong>, \u043F\u043E\u0442\u0456\u043C \u0440\u043E\u0437\u0434\u0456\u043B <strong>Image Display Client</strong>.</li>
        <li>\u0412\u0438\u0431\u0435\u0440\u0456\u0442\u044C \u0445\u0430\u0431 <strong>SLICER-HUB-CLOUD</strong> (\u0442\u043E\u0439 \u0441\u0430\u043C\u0438\u0439 \u0445\u043C\u0430\u0440\u043D\u0438\u0439 \u0445\u0430\u0431, \u0449\u043E \u0439 \u0443 \u0446\u0456\u0454\u0457 worklist). \u0412\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u0439\u0442\u0435 <strong>SLICER-HUB</strong> \u043B\u0438\u0448\u0435 \u044F\u043A\u0449\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u0454\u0442\u0435 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0438\u0439 \u0445\u0430\u0431 \u043D\u0430 \u043F\u043E\u0440\u0442\u0443 2018.</li>
        <li>\u0411\u0435\u0437 OIDC \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u0456\u0442\u044C <strong>User</strong> \u043D\u0430 \u0442\u043E\u0433\u043E \u0441\u0430\u043C\u043E\u0433\u043E \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0447\u0430, \u0449\u043E \u0439 \u0443 \u0445\u043C\u0430\u0440\u043D\u0456\u0439 worklist (\u0437\u043B\u0456\u0432\u0430 \u0432\u0433\u043E\u0440\u0456), \u043F\u043E\u0442\u0456\u043C \u043D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>\u041F\u0456\u0441\u043B\u044F \u043F\u0456\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044F \u043A\u043D\u043E\u043F\u043A\u0430 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0447\u0430 <strong>SlicerDesktop</strong> \u0430\u043A\u0442\u0438\u0432\u0443\u0454\u0442\u044C\u0441\u044F, \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440 \u0437\u043C\u0456\u043D\u044E\u0454\u0442\u044C\u0441\u044F \u043D\u0430 \xAB3D Slicer\xBB, \u0430 \u0441\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u043A\u0430\u0437\u0443\u0454 \u0432\u043C\u0456\u0441\u0442 DICOM-\u0431\u0430\u0437\u0438 Slicer. \u0412\u0456\u0434\u043A\u0440\u0438\u0439\u0442\u0435 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F \u2014 \u0432\u043E\u043D\u043E \u0437\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u044C\u0441\u044F \u0432 \u043D\u0430\u0441\u0442\u0456\u043B\u044C\u043D\u0438\u0439 Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist \u0437 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0447\u0430\u043C\u0438 (\u043E\u0431\u0440\u0430\u043D\u043E SlicerDesktop), \u0432\u0456\u0434\u0434\u0430\u043B\u0435\u043D\u0438\u043C \u0428\u0406 \u0442\u0430 \u0441\u043F\u0438\u0441\u043A\u043E\u043C \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u044C" width="870" height="498" />
        </li>
        <li>\u0414\u043B\u044F \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457 / \u0436\u0438\u0432\u043E\u0433\u043E \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0443 \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0456 \u0432\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u0439\u0442\u0435 <strong>SlicerLive</strong> \u0456 <strong>\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E</strong>, \u043A\u043E\u043B\u0438 \u0456\u043D\u0448\u0456 \u0441\u0442\u0435\u0436\u0430\u0442\u044C \u0437\u0430 \u0437\u043C\u0456\u043D\u0430\u043C\u0438 \u0432\u0443\u0437\u043B\u0456\u0432 \u0456 \u043A\u0430\u043C\u0435\u0440\u0438/\u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0456\u0457.</li>
      </ol>
    `,
    howto1Title: "\u042F\u043A \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\u0412\u0456\u0434\u043A\u0440\u0438\u0439\u0442\u0435 worklist \u0456 \u043D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C <strong>\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F</strong> \u0441\u043F\u0440\u0430\u0432\u0430 \u0432\u0433\u043E\u0440\u0438.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A SlicerLive \u0437 \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043E\u044E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0454\u044E" width="477" height="117" />
        </li>
        <li>\u042F\u043A\u0449\u043E \u043D\u0430 \u0432\u0430\u0448\u043E\u043C\u0443 \u0435\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0456 hub \u0443\u0436\u0435 \u0442\u0440\u0438\u0432\u0430\u0454 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F, \u0432\u043E\u043D\u0430 \u0437\u2019\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0443 \u0432\u0438\u043F\u0430\u0434\u0430\u044E\u0447\u043E\u043C\u0443 \u0441\u043F\u0438\u0441\u043A\u0443.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="\u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0434\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0457: \u0441\u043F\u0438\u0441\u043E\u043A \u0430\u043A\u0442\u0438\u0432\u043D\u0438\u0445 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0439 \u0456 \u043A\u043D\u043E\u043F\u043A\u0430 \u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F" width="322" height="175" />
        </li>
        <li>\u042F\u043A\u0449\u043E \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F \u0449\u0435 \u043D\u0435 \u043F\u043E\u0447\u0430\u043B\u0430\u0441\u044F, \u0437\u0430\u0447\u0435\u043A\u0430\u0439\u0442\u0435 \u043D\u0430 \u0437\u0430\u043F\u0440\u043E\u0448\u0435\u043D\u043D\u044F \u043F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="\u0417\u0430\u043F\u0440\u043E\u0448\u0435\u043D\u043D\u044F: \u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0439 \u0441\u0442\u0435\u0436\u0438\u0442\u0438, \u041F\u0440\u0438\u0454\u0434\u043D\u0430\u0442\u0438\u0441\u044F \u0431\u0435\u0437 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F \u0430\u0431\u043E \u041D\u0435 \u043F\u0440\u0438\u0454\u0434\u043D\u0443\u0432\u0430\u0442\u0438\u0441\u044F" width="190" height="141" />
        </li>
        <li>\u042F\u043A\u0449\u043E \u0432\u0438 \u043E\u0431\u0440\u0430\u043B\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F, \u0432\u0438 \u0432\u0456\u0434\u0441\u0442\u0435\u0436\u0443\u0454\u0442\u0435 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F \u0442\u0430 \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0456\u044E \u0432\u0435\u0434\u0443\u0447\u043E\u0433\u043E. \u0412\u0438\u0439\u0434\u0456\u0442\u044C \u0431\u0443\u0434\u044C-\u043A\u043E\u043B\u0438 \u0447\u0435\u0440\u0435\u0437 <strong>\u0417\u0430\u043B\u0438\u0448\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A \u0456\u0437 \u0417\u0430\u043B\u0438\u0448\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E, \u0432\u0430\u0448\u0438\u043C \u043C\u0456\u0441\u0446\u0435\u043C \u0456 \u0443\u0447\u0430\u0441\u043D\u0438\u043A\u043E\u043C, \u0449\u043E \u0441\u0442\u0435\u0436\u0438\u0442\u044C" width="397" height="80" />
        </li>
        <li>\u042F\u043A\u0449\u043E \u0432\u0438 \u0437\u0443\u043F\u0438\u043D\u0438\u0442\u0435 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F, \u043F\u043E\u0442\u0456\u043C \u043C\u043E\u0436\u0435\u0442\u0435 \u0432\u0456\u0434\u043D\u043E\u0432\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F \u0430\u0431\u043E \u043F\u0435\u0440\u0435\u0439\u043D\u044F\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A \u0456\u0437 \u0412\u0456\u0434\u043D\u043E\u0432\u0438\u0442\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F \u0442\u0430 \u041F\u0435\u0440\u0435\u0439\u043D\u044F\u0442\u0438 \u043F\u0456\u0441\u043B\u044F \u0437\u0443\u043F\u0438\u043D\u043A\u0438 \u0441\u0442\u0435\u0436\u0435\u043D\u043D\u044F" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "\u042F\u043A \u0441\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\u0412\u0456\u0434\u043A\u0440\u0438\u0439\u0442\u0435 worklist \u0456 \u043D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C <strong>\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F</strong> \u043F\u0440\u0430\u0432\u043E\u0440\u0443\u0447 \u0443\u0433\u043E\u0440\u0456.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A SlicerLive \u0437 \u0432\u0438\u0434\u0456\u043B\u0435\u043D\u043E\u044E \u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u0454\u044E" width="477" height="117" />
        </li>
        <li>\u042F\u043A \u043E\u0440\u0433\u0430\u043D\u0456\u0437\u0430\u0442\u043E\u0440 \u043D\u0430\u0442\u0438\u0441\u043D\u0456\u0442\u044C <strong>\u041A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044F</strong> (\u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A worklist \u0430\u0431\u043E \u043F\u0430\u043D\u0435\u043B\u044C SlicerLive). \u041E\u0431\u0435\u0440\u0456\u0442\u044C \u043D\u0430\u0437\u0432\u0443 \u0439 \u0441\u0442\u0432\u043E\u0440\u0456\u0442\u044C \u2014 \u0432\u0438 \u0441\u0442\u0430\u0454\u0442\u0435 \u043C\u0456\u0441\u0446\u0435\u043C <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="\u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E: \u043F\u043E\u043B\u0435 \u043D\u0430\u0437\u0432\u0438 \u0442\u0430 \u043A\u043D\u043E\u043F\u043A\u0430 \u0421\u0442\u0432\u043E\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E" width="167" height="192" />
        </li>
        <li>\u041F\u0456\u0434 \u0447\u0430\u0441 \u0432\u0435\u0434\u0435\u043D\u043D\u044F \u0437\u043C\u0456\u043D\u0438 \u0432 SlicerLive (\u043C\u0430\u043A\u0435\u0442, \u0432\u0456\u043A\u043D\u043E/\u0440\u0456\u0432\u0435\u043D\u044C, \u0432\u0438\u0434\u0438\u043C\u0456\u0441\u0442\u044C \u0441\u0435\u0433\u043C\u0435\u043D\u0442\u0456\u0432, \u043A\u0430\u043C\u0435\u0440\u0430, \u043F\u0440\u043E\u043A\u0440\u0443\u0447\u0443\u0432\u0430\u043D\u043D\u044F/pan/zoom MPR, \u0437\u043D\u0438\u043A\u0430\u044E\u0447\u0435 \u0447\u043E\u0440\u043D\u0438\u043B\u043E \u0442\u0430 \u043F\u043E\u0434\u0456\u0431\u043D\u0456 \u043E\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u044F \u0441\u0446\u0435\u043D\u0438) \u0440\u043E\u0437\u0441\u0438\u043B\u0430\u044E\u0442\u044C\u0441\u044F \u043F\u0456\u0434\u043F\u0438\u0441\u043D\u0438\u043A\u0430\u043C.</li>
        <li>\u0412\u0438 \u043C\u043E\u0436\u0435\u0442\u0435 <strong>\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E</strong> \u0434\u043B\u044F \u0432\u0441\u0456\u0445. \u041F\u0456\u0434 \u0447\u0430\u0441 \u0432\u0435\u0434\u0435\u043D\u043D\u044F \u0432\u0438\u043A\u043E\u0440\u0438\u0441\u0442\u043E\u0432\u0443\u0439\u0442\u0435 \u043A\u043B\u0430\u0432\u0456\u0448\u0443 <strong>B</strong>, \u0449\u043E\u0431 \u0443\u0432\u0456\u043C\u043A\u043D\u0443\u0442\u0438/\u0432\u0438\u043C\u043A\u043D\u0443\u0442\u0438 \u0437\u043D\u0438\u043A\u0430\u044E\u0447\u0435 \u0447\u043E\u0440\u043D\u0438\u043B\u043E.</li>
        <li>\u0412\u0438 \u043C\u043E\u0436\u0435\u0442\u0435 \u043F\u0435\u0440\u0435\u0432\u0456\u0440\u0438\u0442\u0438 \u043A\u043E\u043D\u0444\u0435\u0440\u0435\u043D\u0446\u0456\u044E \u043D\u0430 \u043E\u0434\u043D\u043E\u043C\u0443 \u043A\u043E\u043C\u043F\u2019\u044E\u0442\u0435\u0440\u0456 \u043A\u043D\u043E\u043F\u043A\u043E\u044E <strong>Open another user</strong>. \u0414\u0438\u0432\u0456\u0442\u044C\u0441\u044F \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0456\u0439\u043D\u0435 \u0432\u0456\u0434\u0435\u043E: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "\u042F\u043A \u0448\u0443\u043A\u0430\u0442\u0438 \u0432 IDC \u0456 \u0434\u043E\u0434\u0430\u0432\u0430\u0442\u0438 \u0434\u043E \u043E\u0441\u043E\u0431\u0438\u0441\u0442\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0443.",
    howto4Title: "\u042F\u043A \u0437\u0430\u0432\u0430\u043D\u0442\u0430\u0436\u0438\u0442\u0438 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0435 \u0434\u043E\u0441\u043B\u0456\u0434\u0436\u0435\u043D\u043D\u044F \u0443 \u043F\u0435\u0440\u0435\u0433\u043B\u044F\u0434\u0430\u0447.",
    howto5Title: "\u042F\u043A \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u0432\u0456\u0434\u0434\u0430\u043B\u0435\u043D\u0438\u043C \u0428\u0406",
    howto6Title: "\u042F\u043A \u0435\u043A\u0441\u043F\u043E\u0440\u0442\u0443\u0432\u0430\u0442\u0438 \u0441\u0435\u0433\u043C\u0435\u043D\u0442 \u0443 STL \u0434\u043B\u044F 3D-\u0434\u0440\u0443\u043A\u0443.",
    howto7Title: "\u042F\u043A \u043A\u043E\u0440\u0438\u0441\u0442\u0443\u0432\u0430\u0442\u0438\u0441\u044F Reporting / DICOM SR."
  }
};

// locales/cs.ts
var cs3 = {
  chrome: {
    conferencing: "Konference",
    open: "Otev\u0159\xEDt",
    close: "Zav\u0159\xEDt",
    searchPortal: "Vyhled\xE1vac\xED port\xE1l",
    searchPortalTitle: "Otev\u0159\xEDt vyhled\xE1vac\xED port\xE1l IDC",
    worklist: "Worklist:",
    exploreIdc: "Prozkoumat NCI Imaging Data Commons:",
    viewers: "Prohl\xED\u017Ee\u010De:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurz:",
    anatomicalPlanes: "Classroom",
    currentContext: "Aktu\xE1ln\xED kontext:",
    none: "\u017E\xE1dn\xFD",
    colStudy: "Studie",
    colModalities: "Modality",
    colFormat: "Form\xE1t",
    colSize: "Velikost",
    language: "Jazyk",
    openStudy: "Otev\u0159\xEDt studii",
    closeStudy: "Zav\u0159\xEDt otev\u0159enou studii",
    closeContext: "Zav\u0159\xEDt aktu\xE1ln\xED kontext",
    cannotOpen: "Nelze otev\u0159\xEDt",
    saveWorklist: "Ulo\u017Eit",
    loadWorklist: "Na\u010D\xEDst",
    saveWorklistTitle: "Ulo\u017Eit m\u016Fj worklist jako JSON",
    loadWorklistTitle: "Na\u010D\xEDst m\u016Fj worklist z JSON"
  },
  conference: CONFERENCE_BY_LOCALE.cs,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "O t\xE9to aplikaci",
    aboutLinkLabel: "O aplikaci",
    aboutLinkSuffix: "\u2014 licence, pod\u011Bkov\xE1n\xED a ochrann\xE9 zn\xE1mky.",
    quickStartTitle: "Rychl\xFD start:",
    quickStartBody: "Klikn\u011Bte na jedno z tla\u010D\xEDtek {{open}} vpravo pro otev\u0159en\xED CR a pou\u017Eijte ikonu kouzeln\xE9 h\u016Flky {{magicWand}} ke spu\u0161t\u011Bn\xED FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Jak p\u0159ipojit Worklist k 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Nainstalujte roz\u0161\xED\u0159en\xED Slicer WebSub Interface</li>
        <li>Ve <strong>3D Slicer</strong> otev\u0159ete modul <strong>Hub Interface</strong> a sekci <strong>Image Display Client</strong>.</li>
        <li>Zvolte hub <strong>SLICER-HUB-CLOUD</strong> (stejn\xFD cloudov\xFD hub jako tato worklist). <strong>SLICER-HUB</strong> pou\u017Eijte pouze p\u0159i lok\xE1ln\xEDm hubu na portu 2018.</li>
        <li>Bez OIDC nastavte <strong>User</strong> na stejn\xE9ho u\u017Eivatele jako cloudov\xE1 worklist (vlevo naho\u0159e) a klikn\u011Bte na <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Po p\u0159ipojen\xED se aktivuje tla\u010D\xEDtko prohl\xED\u017Ee\u010De <strong>SlicerDesktop</strong>, selektor se zm\u011Bn\xED na \xAB3D Slicer\xBB a seznam zobraz\xED obsah DICOM datab\xE1ze Slicer. Otev\u0159ete studii \u2014 na\u010Dte se v desktopov\xE9m Sliceru.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist s prohl\xED\u017Ee\u010Di (vybr\xE1n SlicerDesktop), vzd\xE1lenou AI a seznamem studi\xED" width="870" height="498" />
        </li>
        <li>Pro konferenci / \u017Eiv\xE9 zobrazen\xED v prohl\xED\u017Ee\u010Di pou\u017Eijte <strong>SlicerLive</strong> a <strong>Konferenci</strong>, kdy\u017E ostatn\xED sleduj\xED zm\u011Bny uzl\u016F a kamery/prezentace.</li>
      </ol>
    `,
    howto1Title: "Jak se p\u0159ipojit ke konferenci.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Otev\u0159ete worklist a klikn\u011Bte vpravo naho\u0159e na <strong>Konference</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Z\xE1hlav\xED SlicerLive se zv\xFDrazn\u011Bnou konferenc\xED" width="477" height="117" />
        </li>
        <li>Pokud na va\u0161\xED hub instanci ji\u017E konference prob\xEDh\xE1, zobraz\xED se v rozbalovac\xEDm seznamu.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="P\u0159ipojit se ke konferenci: rozbalovac\xED seznam aktivn\xEDch konferenc\xED a tla\u010D\xEDtko P\u0159ipojit" width="322" height="175" />
        </li>
        <li>Pokud konference je\u0161t\u011B neza\u010Dala, po\u010Dkejte na pozv\xE1nku k p\u0159ipojen\xED:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Pozv\xE1nka: P\u0159ipojit se a sledovat, P\u0159ipojit se bez sledov\xE1n\xED nebo Nep\u0159ipojovat se" width="190" height="141" />
        </li>
        <li>Pokud jste zvolili sledov\xE1n\xED, sledujete studii a prezentaci hostitele. Kdykoli odejd\u011Bte pomoc\xED <strong>Opustit konferenci</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Z\xE1hlav\xED s Opustit konferenci, va\u0161\xEDm m\xEDstem a sleduj\xEDc\xEDm \xFA\u010Dastn\xEDkem" width="397" height="80" />
        </li>
        <li>Pokud p\u0159estanete sledovat, m\u016F\u017Eete pot\xE9 sledov\xE1n\xED obnovit nebo konferenci p\u0159evz\xEDt.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Z\xE1hlav\xED s Obnovit sledov\xE1n\xED a P\u0159evz\xEDt po zastaven\xED sledov\xE1n\xED" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Jak vytvo\u0159it konferenci.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Otev\u0159ete worklist a klikn\u011Bte na <strong>Konference</strong> vpravo naho\u0159e.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Z\xE1hlav\xED SlicerLive se zv\xFDrazn\u011Bnou Konferenc\xED" width="477" height="117" />
        </li>
        <li>Jako hostitel klikn\u011Bte na <strong>Konference</strong> (z\xE1hlav\xED worklistu nebo li\u0161ta SlicerLive). Zvolte n\xE1zev a vytvo\u0159te \u2014 stanete se <strong>vedouc\xEDm</strong> m\xEDstem.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Vytvo\u0159it konferenci: pole n\xE1zvu a tla\u010D\xEDtko Vytvo\u0159it konferenci" width="167" height="192" />
        </li>
        <li>B\u011Bhem veden\xED se zm\u011Bny ve SlicerLive (rozlo\u017Een\xED, okno/\xFArove\u0148, viditelnost segment\u016F, kamera, MPR scroll/pan/zoom, mizej\xEDc\xED inkoust a podobn\xE9 aktualizace sc\xE9ny) \u0161\xED\u0159\xED k n\xE1sledovn\xEDk\u016Fm.</li>
        <li>M\u016F\u017Eete <strong>Ukon\u010Dit konferenci</strong> pro v\u0161echny. B\u011Bhem veden\xED pou\u017Eijte kl\xE1vesu <strong>B</strong> k zapnut\xED/vypnut\xED mizej\xEDc\xEDho inkoustu.</li>
        <li>Konferenci m\u016F\u017Eete vyzkou\u0161et na jednom po\u010D\xEDta\u010Di tla\u010D\xEDtkem <strong>Open another user</strong>. Uk\xE1zkov\xE9 video: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Jak vyhled\xE1vat v IDC a p\u0159id\xE1vat do osobn\xEDho seznamu.",
    howto4Title: "Jak na\u010D\xEDst m\xEDstn\xED studii do prohl\xED\u017Ee\u010De.",
    howto5Title: "Jak pou\u017E\xEDvat vzd\xE1lenou AI",
    howto6Title: "Jak exportovat segment do STL pro 3D tisk.",
    howto7Title: "Jak pou\u017E\xEDvat Reporting / DICOM SR."
  }
};

// locales/nl.ts
var nl2 = {
  chrome: {
    conferencing: "Conferentie",
    open: "Openen",
    close: "Sluiten",
    searchPortal: "Zoekportaal",
    searchPortalTitle: "IDC-zoekportaal openen",
    worklist: "Worklist:",
    exploreIdc: "NCI Imaging Data Commons verkennen:",
    viewers: "Viewers:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Cursus:",
    anatomicalPlanes: "Classroom",
    currentContext: "Huidige context:",
    none: "geen",
    colStudy: "Studie",
    colModalities: "Modaliteiten",
    colFormat: "Formaat",
    colSize: "Grootte",
    language: "Taal",
    openStudy: "Studie openen",
    closeStudy: "Open studie sluiten",
    closeContext: "Huidige context sluiten",
    cannotOpen: "Kan niet openen",
    saveWorklist: "Opslaan",
    loadWorklist: "Laden",
    saveWorklistTitle: "Mijn worklist opslaan als JSON",
    loadWorklistTitle: "Mijn worklist laden uit JSON"
  },
  conference: CONFERENCE_BY_LOCALE.nl,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Over deze toepassing",
    aboutLinkLabel: "Over",
    aboutLinkSuffix: "\u2014 licenties, dankbetuigingen en handelsmerken.",
    quickStartTitle: "Snel starten:",
    quickStartBody: "Klik rechts op een van de knoppen {{open}} om een CR te openen en het toverstafpictogram {{magicWand}} te gebruiken om FleXray uit te voeren.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Hoe Worklist te verbinden met 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Installeer de Slicer WebSub Interface-extensie</li>
        <li>Open in <strong>3D Slicer</strong> de module <strong>Hub Interface</strong> en de sectie <strong>Image Display Client</strong>.</li>
        <li>Kies hub <strong>SLICER-HUB-CLOUD</strong> (dezelfde cloudhub als deze worklist). Gebruik <strong>SLICER-HUB</strong> alleen als u een lokale hub op poort 2018 draait.</li>
        <li>Zonder OIDC stelt u <strong>User</strong> in op dezelfde gebruiker als uw cloudworklist (linksboven) en klikt u op <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Na verbinding licht de viewerknop <strong>SlicerDesktop</strong> op, de selector verandert naar \xAB3D Slicer\xBB en de lijst toont de inhoud van de Slicer DICOM-database. Open een studie \u2014 deze wordt in desktop-Slicer geladen.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist met viewers (SlicerDesktop geselecteerd), externe AI en studielijst" width="870" height="498" />
        </li>
        <li>Voor browserconferentie / liveweergave gebruikt u <strong>SlicerLive</strong> en <strong>Conferentie</strong> wanneer anderen uw knoop- en camera-/presentatiewijzigingen volgen.</li>
      </ol>
    `,
    howto1Title: "Hoe deel te nemen aan een conferentie.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Open de worklist en klik rechtsboven op <strong>Conferentie</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-kop met gemarkeerde conferentie" width="477" height="117" />
        </li>
        <li>Als er een conferentie actief is op uw hub-instantie, verschijnt die in een keuzelijst.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Deelnemen aan conferentie: keuzelijst actieve conferenties en knop Deelnemen" width="322" height="175" />
        </li>
        <li>Als de conferentie nog niet is gestart, wacht op de uitnodiging om deel te nemen:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Uitnodiging: Deelnemen en volgen, Deelnemen zonder volgen, of Niet deelnemen" width="190" height="141" />
        </li>
        <li>Als u volgen koos, volgt u de studie en presentatie van de host. Verlaat op elk moment met <strong>Conferentie verlaten</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Kop met Conferentie verlaten, uw plaats en een volgende deelnemer" width="397" height="80" />
        </li>
        <li>Als u stopt met volgen, kunt u daarna het volgen hervatten of de conferentie overnemen.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Kop met Volgen hervatten en Overnemen na stoppen met volgen" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Hoe een conferentie te maken.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Open de worklist en klik rechtsboven op <strong>Conferentie</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-koptekst met Conferentie gemarkeerd" width="477" height="117" />
        </li>
        <li>Als host klikt u op <strong>Conferentie</strong> (worklist-kop of SlicerLive-balk). Kies een titel en maak aan \u2014 u wordt de <strong>leidende</strong> plaats.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Conferentie maken: titelveld en knop Conferentie maken" width="167" height="192" />
        </li>
        <li>Terwijl u leidt, worden wijzigingen in SlicerLive (layout, window/level, segmentzichtbaarheid, camera, MPR scroll/pan/zoom, tijdelijke inkt en vergelijkbare sc\xE8ne-updates) naar volgers gestuurd.</li>
        <li>U kunt de <strong>Conferentie be\xEBindigen</strong> voor iedereen. Terwijl u leidt, gebruikt u de toets <strong>B</strong> om tijdelijke inkt aan/uit te zetten.</li>
        <li>U kunt conferencing op \xE9\xE9n desktop testen met de knop <strong>Open another user</strong>. Bekijk de demovideo: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Hoe te zoeken in IDC en toe te voegen aan een persoonlijke lijst.",
    howto4Title: "Hoe een lokale studie in een viewer te laden.",
    howto5Title: "Hoe externe AI te gebruiken",
    howto6Title: "Hoe een segment als STL te exporteren voor 3D-printen.",
    howto7Title: "Hoe Reporting / DICOM SR te gebruiken."
  }
};

// locales/el.ts
var el2 = {
  chrome: {
    conferencing: "\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7",
    open: "\u0386\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1",
    close: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF",
    searchPortal: "\u03A0\u03CD\u03BB\u03B7 \u03B1\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7\u03C2",
    searchPortalTitle: "\u0386\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1 \u03C0\u03CD\u03BB\u03B7\u03C2 \u03B1\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7\u03C2 IDC",
    worklist: "Worklist:",
    exploreIdc: "\u0395\u03BE\u03B5\u03C1\u03B5\u03C5\u03BD\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF NCI Imaging Data Commons:",
    viewers: "\u03A0\u03C1\u03BF\u03B2\u03BF\u03BB\u03B5\u03AF\u03C2:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "\u039C\u03AC\u03B8\u03B7\u03BC\u03B1:",
    anatomicalPlanes: "Classroom",
    currentContext: "\u03A4\u03C1\u03AD\u03C7\u03BF\u03BD \u03C0\u03BB\u03B1\u03AF\u03C3\u03B9\u03BF:",
    none: "\u03BA\u03B1\u03BD\u03AD\u03BD\u03B1",
    colStudy: "\u039C\u03B5\u03BB\u03AD\u03C4\u03B7",
    colModalities: "\u03A4\u03C1\u03CC\u03C0\u03BF\u03B9",
    colFormat: "\u039C\u03BF\u03C1\u03C6\u03AE",
    colSize: "\u039C\u03AD\u03B3\u03B5\u03B8\u03BF\u03C2",
    language: "\u0393\u03BB\u03CE\u03C3\u03C3\u03B1",
    openStudy: "\u0386\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7\u03C2",
    closeStudy: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF \u03B1\u03BD\u03BF\u03B9\u03C7\u03C4\u03AE\u03C2 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7\u03C2",
    closeContext: "\u039A\u03BB\u03B5\u03AF\u03C3\u03B9\u03BC\u03BF \u03C4\u03C1\u03AD\u03C7\u03BF\u03BD\u03C4\u03BF\u03C2 \u03C0\u03BB\u03B1\u03B9\u03C3\u03AF\u03BF\u03C5",
    cannotOpen: "\u0394\u03B5\u03BD \u03B5\u03AF\u03BD\u03B1\u03B9 \u03B4\u03C5\u03BD\u03B1\u03C4\u03CC \u03C4\u03BF \u03AC\u03BD\u03BF\u03B9\u03B3\u03BC\u03B1",
    saveWorklist: "\u0391\u03C0\u03BF\u03B8\u03AE\u03BA\u03B5\u03C5\u03C3\u03B7",
    loadWorklist: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7",
    saveWorklistTitle: "\u0391\u03C0\u03BF\u03B8\u03AE\u03BA\u03B5\u03C5\u03C3\u03B7 \u03C4\u03B7\u03C2 \u03BB\u03AF\u03C3\u03C4\u03B1\u03C2 \u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1\u03C2 \u03C9\u03C2 JSON",
    loadWorklistTitle: "\u03A6\u03CC\u03C1\u03C4\u03C9\u03C3\u03B7 \u03C4\u03B7\u03C2 \u03BB\u03AF\u03C3\u03C4\u03B1\u03C2 \u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1\u03C2 \u03B1\u03C0\u03CC JSON"
  },
  conference: CONFERENCE_BY_LOCALE.el,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "\u03A3\u03C7\u03B5\u03C4\u03B9\u03BA\u03AC \u03BC\u03B5 \u03B1\u03C5\u03C4\u03AE \u03C4\u03B7\u03BD \u03B5\u03C6\u03B1\u03C1\u03BC\u03BF\u03B3\u03AE",
    aboutLinkLabel: "\u03A3\u03C7\u03B5\u03C4\u03B9\u03BA\u03AC",
    aboutLinkSuffix: "\u2014 \u03AC\u03B4\u03B5\u03B9\u03B5\u03C2, \u03B5\u03C5\u03C7\u03B1\u03C1\u03B9\u03C3\u03C4\u03AF\u03B5\u03C2 \u03BA\u03B1\u03B9 \u03B5\u03BC\u03C0\u03BF\u03C1\u03B9\u03BA\u03AC \u03C3\u03AE\u03BC\u03B1\u03C4\u03B1.",
    quickStartTitle: "\u0393\u03C1\u03AE\u03B3\u03BF\u03C1\u03B7 \u03B5\u03BA\u03BA\u03AF\u03BD\u03B7\u03C3\u03B7:",
    quickStartBody: "\u039A\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA \u03C3\u03B5 \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC \u03C4\u03B1 \u03BA\u03BF\u03C5\u03BC\u03C0\u03B9\u03AC {{open}} \u03B4\u03B5\u03BE\u03B9\u03AC \u03B3\u03B9\u03B1 \u03BD\u03B1 \u03B1\u03BD\u03BF\u03AF\u03BE\u03B5\u03C4\u03B5 \u03AD\u03BD\u03B1 CR \u03BA\u03B1\u03B9 \u03BD\u03B1 \u03C7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03B5\u03C4\u03B5 \u03C4\u03BF \u03B5\u03B9\u03BA\u03BF\u03BD\u03AF\u03B4\u03B9\u03BF \u03BC\u03B1\u03B3\u03B9\u03BA\u03BF\u03CD \u03C1\u03B1\u03B2\u03B4\u03B9\u03BF\u03CD {{magicWand}} \u03B3\u03B9\u03B1 \u03BD\u03B1 \u03B5\u03BA\u03C4\u03B5\u03BB\u03AD\u03C3\u03B5\u03C4\u03B5 \u03C4\u03BF FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03C3\u03C5\u03BD\u03B4\u03AD\u03C3\u03B5\u03C4\u03B5 \u03C4\u03BF Worklist \u03BC\u03B5 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>\u0395\u03B3\u03BA\u03B1\u03C4\u03B1\u03C3\u03C4\u03AE\u03C3\u03C4\u03B5 \u03C4\u03B7\u03BD \u03B5\u03C0\u03AD\u03BA\u03C4\u03B1\u03C3\u03B7 Slicer WebSub Interface</li>
        <li>\u03A3\u03C4\u03BF <strong>3D Slicer</strong> \u03B1\u03BD\u03BF\u03AF\u03BE\u03C4\u03B5 \u03C4\u03B7 module <strong>Hub Interface</strong> \u03BA\u03B1\u03B9 \u03C4\u03B7\u03BD \u03B5\u03BD\u03CC\u03C4\u03B7\u03C4\u03B1 <strong>Image Display Client</strong>.</li>
        <li>\u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 hub <strong>SLICER-HUB-CLOUD</strong> (\u03C4\u03BF \u03AF\u03B4\u03B9\u03BF cloud hub \u03BC\u03B5 \u03B1\u03C5\u03C4\u03AE \u03C4\u03B7 worklist). \u03A7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03C4\u03B5 <strong>SLICER-HUB</strong> \u03BC\u03CC\u03BD\u03BF \u03B1\u03BD \u03C4\u03C1\u03AD\u03C7\u03B5\u03C4\u03B5 \u03C4\u03BF\u03C0\u03B9\u03BA\u03CC hub \u03C3\u03C4\u03B7 \u03B8\u03CD\u03C1\u03B1 2018.</li>
        <li>\u03A7\u03C9\u03C1\u03AF\u03C2 OIDC, \u03BF\u03C1\u03AF\u03C3\u03C4\u03B5 <strong>User</strong> \u03C3\u03C4\u03BF\u03BD \u03AF\u03B4\u03B9\u03BF \u03C7\u03C1\u03AE\u03C3\u03C4\u03B7 \u03BC\u03B5 \u03C4\u03BF cloud worklist (\u03C0\u03AC\u03BD\u03C9 \u03B1\u03C1\u03B9\u03C3\u03C4\u03B5\u03C1\u03AC) \u03BA\u03B1\u03B9 \u03BA\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>\u039C\u03B5\u03C4\u03AC \u03C4\u03B7 \u03C3\u03CD\u03BD\u03B4\u03B5\u03C3\u03B7, \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \u03C0\u03C1\u03BF\u03B2\u03BF\u03BB\u03AD\u03B1 <strong>SlicerDesktop</strong> \u03B5\u03BD\u03B5\u03C1\u03B3\u03BF\u03C0\u03BF\u03B9\u03B5\u03AF\u03C4\u03B1\u03B9, \u03BF \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AD\u03B1\u03C2 \u03B1\u03BB\u03BB\u03AC\u03B6\u03B5\u03B9 \u03C3\u03B5 \xAB3D Slicer\xBB \u03BA\u03B1\u03B9 \u03B7 \u03BB\u03AF\u03C3\u03C4\u03B1 \u03B4\u03B5\u03AF\u03C7\u03BD\u03B5\u03B9 \u03C4\u03BF \u03C0\u03B5\u03C1\u03B9\u03B5\u03C7\u03CC\u03BC\u03B5\u03BD\u03BF \u03C4\u03B7\u03C2 \u03B2\u03AC\u03C3\u03B7\u03C2 DICOM \u03C4\u03BF\u03C5 Slicer. \u0391\u03BD\u03BF\u03AF\u03BE\u03C4\u03B5 \u03BC\u03B9\u03B1 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7 \u2014 \u03C6\u03BF\u03C1\u03C4\u03CE\u03BD\u03B5\u03C4\u03B1\u03B9 \u03C3\u03C4\u03BF desktop Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist \u03BC\u03B5 \u03C0\u03C1\u03BF\u03B2\u03BF\u03BB\u03B5\u03AF\u03C2 (\u03B5\u03C0\u03B9\u03BB\u03B5\u03B3\u03BC\u03AD\u03BD\u03BF SlicerDesktop), \u03B1\u03C0\u03BF\u03BC\u03B1\u03BA\u03C1\u03C5\u03C3\u03BC\u03AD\u03BD\u03B7 AI \u03BA\u03B1\u03B9 \u03BB\u03AF\u03C3\u03C4\u03B1 \u03BC\u03B5\u03BB\u03B5\u03C4\u03CE\u03BD" width="870" height="498" />
        </li>
        <li>\u0393\u03B9\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03C3\u03C4\u03BF \u03C0\u03C1\u03CC\u03B3\u03C1\u03B1\u03BC\u03BC\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AE\u03B3\u03B7\u03C3\u03B7\u03C2 / \u03B6\u03C9\u03BD\u03C4\u03B1\u03BD\u03AE \u03C0\u03C1\u03BF\u03B2\u03BF\u03BB\u03AE, \u03C7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03C4\u03B5 <strong>SlicerLive</strong> \u03BA\u03B1\u03B9 <strong>\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong> \u03CC\u03C4\u03B1\u03BD \u03AC\u03BB\u03BB\u03BF\u03B9 \u03B1\u03BA\u03BF\u03BB\u03BF\u03C5\u03B8\u03BF\u03CD\u03BD \u03C4\u03B9\u03C2 \u03B1\u03BB\u03BB\u03B1\u03B3\u03AD\u03C2 \u03BA\u03CC\u03BC\u03B2\u03C9\u03BD \u03BA\u03B1\u03B9 \u03BA\u03AC\u03BC\u03B5\u03C1\u03B1\u03C2/\u03C0\u03B1\u03C1\u03BF\u03C5\u03C3\u03AF\u03B1\u03C3\u03B7\u03C2.</li>
      </ol>
    `,
    howto1Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AC\u03C3\u03C7\u03B5\u03C4\u03B5 \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\u0391\u03BD\u03BF\u03AF\u03BE\u03C4\u03B5 \u03C4\u03B7 worklist \u03BA\u03B1\u03B9 \u03BA\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA \u03C3\u03C4\u03BF <strong>\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong> \u03C0\u03AC\u03BD\u03C9 \u03B4\u03B5\u03BE\u03B9\u03AC.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u039A\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1 SlicerLive \u03BC\u03B5 \u03B5\u03C0\u03B9\u03C3\u03B7\u03BC\u03B1\u03C3\u03BC\u03AD\u03BD\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7" width="477" height="117" />
        </li>
        <li>\u0391\u03BD \u03C5\u03C0\u03AC\u03C1\u03C7\u03B5\u03B9 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03C3\u03B5 \u03B5\u03BE\u03AD\u03BB\u03B9\u03BE\u03B7 \u03C3\u03C4\u03BF hub \u03C3\u03B1\u03C2, \u03B5\u03BC\u03C6\u03B1\u03BD\u03AF\u03B6\u03B5\u03C4\u03B1\u03B9 \u03C3\u03B5 \u03B1\u03BD\u03B1\u03C0\u03C4\u03C5\u03C3\u03C3\u03CC\u03BC\u03B5\u03BD\u03BF \u03BC\u03B5\u03BD\u03BF\u03CD.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="\u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C3\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7: \u03BC\u03B5\u03BD\u03BF\u03CD \u03B5\u03BD\u03B5\u03C1\u03B3\u03CE\u03BD \u03B4\u03B9\u03B1\u03C3\u03BA\u03AD\u03C8\u03B5\u03C9\u03BD \u03BA\u03B1\u03B9 \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE" width="322" height="175" />
        </li>
        <li>\u0391\u03BD \u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03B4\u03B5\u03BD \u03AD\u03C7\u03B5\u03B9 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AE\u03C3\u03B5\u03B9, \u03C0\u03B5\u03C1\u03B9\u03BC\u03AD\u03BD\u03B5\u03C4\u03B5 \u03C4\u03B7\u03BD \u03C0\u03C1\u03CC\u03C3\u03BA\u03BB\u03B7\u03C3\u03B7 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE\u03C2:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="\u03A0\u03C1\u03CC\u03C3\u03BA\u03BB\u03B7\u03C3\u03B7: \u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03BA\u03B1\u03B9 \u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7, \u03A3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE \u03C7\u03C9\u03C1\u03AF\u03C2 \u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7 \u03AE \u039C\u03B7 \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03BF\u03C7\u03AE" width="190" height="141" />
        </li>
        <li>\u0391\u03BD \u03B5\u03C0\u03B9\u03BB\u03AD\u03BE\u03B1\u03C4\u03B5 \u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7, \u03B1\u03BA\u03BF\u03BB\u03BF\u03C5\u03B8\u03B5\u03AF\u03C4\u03B5 \u03C4\u03B7 \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7 \u03BA\u03B1\u03B9 \u03C4\u03B7\u03BD \u03C0\u03C1\u03BF\u03C3\u03BF\u03C5\u03C3\u03AF\u03B1\u03C3\u03B7 \u03C4\u03BF\u03C5 \u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7. \u0391\u03C0\u03BF\u03C7\u03C9\u03C1\u03AE\u03C3\u03C4\u03B5 \u03BF\u03C0\u03BF\u03B9\u03B1\u03B4\u03AE\u03C0\u03BF\u03C4\u03B5 \u03C3\u03C4\u03B9\u03B3\u03BC\u03AE \u03BC\u03B5 <strong>\u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7 \u03B1\u03C0\u03CC \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="\u039A\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1 \u03BC\u03B5 \u0391\u03C0\u03BF\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7 \u03B1\u03C0\u03CC \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7, \u03C4\u03B7 \u03B8\u03AD\u03C3\u03B7 \u03C3\u03B1\u03C2 \u03BA\u03B1\u03B9 \u03AD\u03BD\u03B1\u03BD \u03B1\u03BA\u03CC\u03BB\u03BF\u03C5\u03B8\u03BF \u03C3\u03C5\u03BC\u03BC\u03B5\u03C4\u03AD\u03C7\u03BF\u03BD\u03C4\u03B1" width="397" height="80" />
        </li>
        <li>\u0391\u03BD \u03B4\u03B9\u03B1\u03BA\u03CC\u03C8\u03B5\u03C4\u03B5 \u03C4\u03B7\u03BD \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7, \u03BC\u03C0\u03BF\u03C1\u03B5\u03AF\u03C4\u03B5 \u03C3\u03C4\u03B7 \u03C3\u03C5\u03BD\u03AD\u03C7\u03B5\u03B9\u03B1 \u03BD\u03B1 \u03C4\u03B7\u03BD \u03C3\u03C5\u03BD\u03B5\u03C7\u03AF\u03C3\u03B5\u03C4\u03B5 \u03AE \u03BD\u03B1 \u03B1\u03BD\u03B1\u03BB\u03AC\u03B2\u03B5\u03C4\u03B5 \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="\u039A\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1 \u03BC\u03B5 \u03A3\u03C5\u03BD\u03AD\u03C7\u03B5\u03B9\u03B1 \u03C0\u03B1\u03C1\u03B1\u03BA\u03BF\u03BB\u03BF\u03CD\u03B8\u03B7\u03C3\u03B7\u03C2 \u03BA\u03B1\u03B9 \u0391\u03BD\u03AC\u03BB\u03B7\u03C8\u03B7 \u03BC\u03B5\u03C4\u03AC \u03C4\u03B7 \u03B4\u03B9\u03B1\u03BA\u03BF\u03C0\u03AE" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03B4\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AE\u03C3\u03B5\u03C4\u03B5 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\u0391\u03BD\u03BF\u03AF\u03BE\u03C4\u03B5 \u03C4\u03B7 worklist \u03BA\u03B1\u03B9 \u03BA\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA \u03C3\u03C4\u03BF <strong>\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong> \u03C0\u03AC\u03BD\u03C9 \u03B4\u03B5\u03BE\u03B9\u03AC.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="\u039A\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1 SlicerLive \u03BC\u03B5 \u03B5\u03C0\u03B9\u03C3\u03B7\u03BC\u03B1\u03C3\u03BC\u03AD\u03BD\u03B7 \u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7" width="477" height="117" />
        </li>
        <li>\u03A9\u03C2 \u03BF\u03B9\u03BA\u03BF\u03B4\u03B5\u03C3\u03C0\u03CC\u03C4\u03B7\u03C2, \u03BA\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA \u03C3\u03C4\u03BF <strong>\u0394\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong> (\u03BA\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1 worklist \u03AE \u03B3\u03C1\u03B1\u03BC\u03BC\u03AE SlicerLive). \u0395\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03C4\u03AF\u03C4\u03BB\u03BF \u03BA\u03B1\u03B9 \u03B4\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AE\u03C3\u03C4\u03B5 \u2014 \u03B3\u03AF\u03BD\u03B5\u03C3\u03C4\u03B5 \u03C4\u03BF <strong>leading</strong> \u03BC\u03AD\u03C1\u03BF\u03C2.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="\u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2: \u03C0\u03B5\u03B4\u03AF\u03BF \u03C4\u03AF\u03C4\u03BB\u03BF\u03C5 \u03BA\u03B1\u03B9 \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \u0394\u03B7\u03BC\u03B9\u03BF\u03C5\u03C1\u03B3\u03AF\u03B1 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7\u03C2" width="167" height="192" />
        </li>
        <li>\u0395\u03BD\u03CE \u03BF\u03B4\u03B7\u03B3\u03B5\u03AF\u03C4\u03B5, \u03BF\u03B9 \u03B1\u03BB\u03BB\u03B1\u03B3\u03AD\u03C2 \u03C3\u03C4\u03BF SlicerLive (\u03B4\u03B9\u03AC\u03C4\u03B1\u03BE\u03B7, \u03C0\u03B1\u03C1\u03AC\u03B8\u03C5\u03C1\u03BF/\u03B5\u03C0\u03AF\u03C0\u03B5\u03B4\u03BF, \u03BF\u03C1\u03B1\u03C4\u03CC\u03C4\u03B7\u03C4\u03B1 \u03C4\u03BC\u03B7\u03BC\u03AC\u03C4\u03C9\u03BD, \u03BA\u03AC\u03BC\u03B5\u03C1\u03B1, \u03BA\u03CD\u03BB\u03B9\u03C3\u03B7/pan/zoom MPR, \u03BC\u03B5\u03BB\u03AC\u03BD\u03B9 \u03C0\u03BF\u03C5 \u03B5\u03BE\u03B1\u03C6\u03B1\u03BD\u03AF\u03B6\u03B5\u03C4\u03B1\u03B9 \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C1\u03CC\u03BC\u03BF\u03B9\u03B5\u03C2 \u03B5\u03BD\u03B7\u03BC\u03B5\u03C1\u03CE\u03C3\u03B5\u03B9\u03C2 \u03C3\u03BA\u03B7\u03BD\u03AE\u03C2) \u03B4\u03B9\u03B1\u03B4\u03AF\u03B4\u03BF\u03BD\u03C4\u03B1\u03B9 \u03C3\u03C4\u03BF\u03C5\u03C2 \u03B1\u03BA\u03CC\u03BB\u03BF\u03C5\u03B8\u03BF\u03C5\u03C2.</li>
        <li>\u039C\u03C0\u03BF\u03C1\u03B5\u03AF\u03C4\u03B5 \u03BD\u03B1 <strong>\u03A4\u03B5\u03C1\u03BC\u03B1\u03C4\u03AF\u03C3\u03B5\u03C4\u03B5 \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7</strong> \u03B3\u03B9\u03B1 \u03CC\u03BB\u03BF\u03C5\u03C2. \u0395\u03BD\u03CE \u03BF\u03B4\u03B7\u03B3\u03B5\u03AF\u03C4\u03B5, \u03C7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF \u03C0\u03BB\u03AE\u03BA\u03C4\u03C1\u03BF <strong>B</strong> \u03B3\u03B9\u03B1 \u03B5\u03BD\u03B1\u03BB\u03BB\u03B1\u03B3\u03AE \u03C4\u03BF\u03C5 \u03BC\u03B5\u03BB\u03B1\u03BD\u03B9\u03BF\u03CD \u03C0\u03BF\u03C5 \u03B5\u03BE\u03B1\u03C6\u03B1\u03BD\u03AF\u03B6\u03B5\u03C4\u03B1\u03B9.</li>
        <li>\u039C\u03C0\u03BF\u03C1\u03B5\u03AF\u03C4\u03B5 \u03BD\u03B1 \u03B4\u03BF\u03BA\u03B9\u03BC\u03AC\u03C3\u03B5\u03C4\u03B5 \u03C4\u03B7 \u03B4\u03B9\u03AC\u03C3\u03BA\u03B5\u03C8\u03B7 \u03C3\u03B5 \u03AD\u03BD\u03B1\u03BD \u03C5\u03C0\u03BF\u03BB\u03BF\u03B3\u03B9\u03C3\u03C4\u03AE \u03BC\u03B5 \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF <strong>Open another user</strong>. \u0394\u03B5\u03AF\u03C4\u03B5 \u03C4\u03BF \u03B2\u03AF\u03BD\u03C4\u03B5\u03BF \u03B5\u03C0\u03AF\u03B4\u03B5\u03B9\u03BE\u03B7\u03C2: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03B1\u03BD\u03B1\u03B6\u03B7\u03C4\u03AE\u03C3\u03B5\u03C4\u03B5 \u03C3\u03C4\u03BF IDC \u03BA\u03B1\u03B9 \u03BD\u03B1 \u03C0\u03C1\u03BF\u03C3\u03B8\u03AD\u03C3\u03B5\u03C4\u03B5 \u03C3\u03B5 \u03C0\u03C1\u03BF\u03C3\u03C9\u03C0\u03B9\u03BA\u03AE \u03BB\u03AF\u03C3\u03C4\u03B1.",
    howto4Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03C6\u03BF\u03C1\u03C4\u03CE\u03C3\u03B5\u03C4\u03B5 \u03C4\u03BF\u03C0\u03B9\u03BA\u03AE \u03BC\u03B5\u03BB\u03AD\u03C4\u03B7 \u03C3\u03B5 \u03C0\u03C1\u03BF\u03B2\u03BF\u03BB\u03AD\u03B1.",
    howto5Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03C7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03B5\u03C4\u03B5 \u03B1\u03C0\u03BF\u03BC\u03B1\u03BA\u03C1\u03C5\u03C3\u03BC\u03AD\u03BD\u03B7 AI",
    howto6Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03B5\u03BE\u03B1\u03B3\u03AC\u03B3\u03B5\u03C4\u03B5 \u03C4\u03BC\u03AE\u03BC\u03B1 \u03C3\u03B5 STL \u03B3\u03B9\u03B1 \u03B5\u03BA\u03C4\u03CD\u03C0\u03C9\u03C3\u03B7 3D.",
    howto7Title: "\u03A0\u03CE\u03C2 \u03BD\u03B1 \u03C7\u03C1\u03B7\u03C3\u03B9\u03BC\u03BF\u03C0\u03BF\u03B9\u03AE\u03C3\u03B5\u03C4\u03B5 Reporting / DICOM SR."
  }
};

// locales/lv.ts
var lv2 = {
  chrome: {
    conferencing: "Konference",
    open: "Atv\u0113rt",
    close: "Aizv\u0113rt",
    searchPortal: "Mekl\u0113\u0161anas port\u0101ls",
    searchPortalTitle: "Atv\u0113rt IDC mekl\u0113\u0161anas port\u0101lu",
    worklist: "Worklist:",
    exploreIdc: "Izp\u0113tiet NCI Imaging Data Commons:",
    viewers: "Skat\u012Bt\u0101ji:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurss:",
    anatomicalPlanes: "Classroom",
    currentContext: "Pa\u0161reiz\u0113jais konteksts:",
    none: "nav",
    colStudy: "P\u0113t\u012Bjums",
    colModalities: "Modalit\u0101tes",
    colFormat: "Form\u0101ts",
    colSize: "Izm\u0113rs",
    language: "Valoda",
    openStudy: "Atv\u0113rt p\u0113t\u012Bjumu",
    closeStudy: "Aizv\u0113rt atv\u0113rto p\u0113t\u012Bjumu",
    closeContext: "Aizv\u0113rt pa\u0161reiz\u0113jo kontekstu",
    cannotOpen: "Nevar atv\u0113rt",
    saveWorklist: "Saglab\u0101t",
    loadWorklist: "Iel\u0101d\u0113t",
    saveWorklistTitle: "Saglab\u0101t manu darba sarakstu k\u0101 JSON",
    loadWorklistTitle: "Iel\u0101d\u0113t manu darba sarakstu no JSON"
  },
  conference: CONFERENCE_BY_LOCALE.lv,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Par \u0161o lietotni",
    aboutLinkLabel: "Par",
    aboutLinkSuffix: "\u2014 licences, pateic\u012Bbas un pre\u010Du z\u012Bmes.",
    quickStartTitle: "\u0100trais s\u0101kums:",
    quickStartBody: "Noklik\u0161\u0137iniet uz vienas no {{open}} pog\u0101m labaj\u0101 pus\u0113, lai atv\u0113rtu CR un izmantotu burvju n\u016Bji\u0146as ikonu {{magicWand}}, lai palaistu FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "K\u0101 savienot Worklist ar 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Instal\u0113jiet Slicer WebSub Interface papla\u0161in\u0101jumu</li>
        <li><strong>3D Slicer</strong> atveriet moduli <strong>Hub Interface</strong> un sada\u013Cu <strong>Image Display Client</strong>.</li>
        <li>Izv\u0113lieties hubu <strong>SLICER-HUB-CLOUD</strong> (tas pats m\u0101ko\u0146a hubs k\u0101 \u0161ai worklist). Izmantojiet <strong>SLICER-HUB</strong> tikai, ja darbin\u0101t lok\u0101lu hubu port\u0101 2018.</li>
        <li>Bez OIDC iestatiet <strong>User</strong> uz to pa\u0161u lietot\u0101ju k\u0101 m\u0101ko\u0146a worklist (aug\u0161\u0101 pa kreisi), tad noklik\u0161\u0137iniet <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>P\u0113c savienojuma worklist <strong>SlicerDesktop</strong> skat\u012Bt\u0101ja poga iedegas, selektors main\u0101s uz \xAB3D Slicer\xBB, un saraksts r\u0101da Slicer DICOM datub\u0101zes saturu. Atveriet p\u0113t\u012Bjumu \u2014 tas iel\u0101d\u0113jas desktop Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist ar skat\u012Bt\u0101jiem (izv\u0113l\u0113ts SlicerDesktop), att\u0101lo AI un p\u0113t\u012Bjumu sarakstu" width="870" height="498" />
        </li>
        <li>P\u0101rl\u016Bkprogrammas konferencei / tie\u0161raidei izmantojiet <strong>SlicerLive</strong> un <strong>Konference</strong>, kad citi seko j\u016Bsu mezglu un kameras/prezent\u0101cijas izmai\u0146\u0101m.</li>
      </ol>
    `,
    howto1Title: "K\u0101 pievienoties konferencei.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Atveriet worklist un noklik\u0161\u0137iniet uz <strong>Konference</strong> aug\u0161\u0101 pa labi.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive galvene ar izceltu konferenci" width="477" height="117" />
        </li>
        <li>Ja j\u016Bsu hub instanc\u0113 jau notiek konference, t\u0101 par\u0101d\u012Bsies nolai\u017Eamaj\u0101 sarakst\u0101.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Pievienoties konferencei: akt\u012Bvo konferen\u010Du saraksts un poga Pievienoties" width="322" height="175" />
        </li>
        <li>Ja konference v\u0113l nav s\u0101kusies, gaidiet uzaicin\u0101jumu pievienoties:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Uzaicin\u0101jums: Pievienoties un sekot, Pievienoties bez seko\u0161anas vai Nepievienoties" width="190" height="141" />
        </li>
        <li>Ja izv\u0113l\u0113j\u0101ties sekot, sekojat saimnieka p\u0113t\u012Bjumam un prezent\u0101cijai. Izejiet jebkur\u0101 laik\u0101 ar <strong>Atst\u0101t konferenci</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Galvene ar Atst\u0101t konferenci, j\u016Bsu vietu un sekojo\u0161u dal\u012Bbnieku" width="397" height="80" />
        </li>
        <li>Ja p\u0101rtraucat seko\u0161anu, p\u0113c tam varat ats\u0101kt seko\u0161anu vai p\u0101r\u0146emt konferenci.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Galvene ar Ats\u0101kt seko\u0161anu un P\u0101r\u0146emt p\u0113c seko\u0161anas aptur\u0113\u0161anas" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "K\u0101 izveidot konferenci.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Atveriet worklist un noklik\u0161\u0137iniet uz <strong>Konference</strong> aug\u0161\u0113j\u0101 labaj\u0101 st\u016Br\u012B.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive galvene ar izcelto Konferenci" width="477" height="117" />
        </li>
        <li>K\u0101 saimnieks noklik\u0161\u0137iniet uz <strong>Konference</strong> (worklist galvene vai SlicerLive josla). Izv\u0113lieties virsrakstu un izveidojiet \u2014 k\u013C\u016Bstat par <strong>leading</strong> vietu.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Izveidot konferenci: virsraksta lauks un poga Izveidot konferenci" width="167" height="192" />
        </li>
        <li>Vadot izmai\u0146as SlicerLive (izk\u0101rtojums, logs/l\u012Bmenis, segmentu redzam\u012Bba, kamera, MPR ritin\u0101\u0161ana/pan/zoom, izz\u016Bdo\u0161a tinte un l\u012Bdz\u012Bgi ainas atjaunin\u0101jumi) tiek izplat\u012Btas sekot\u0101jiem.</li>
        <li>Varat <strong>Beigt konferenci</strong> visiem. Vadot izmantojiet tausti\u0146u <strong>B</strong>, lai iesl\u0113gtu/izsl\u0113gtu izz\u016Bdo\u0161o tinti.</li>
        <li>Varat p\u0101rbaud\u012Bt konferenci vien\u0101 dator\u0101 ar pogu <strong>Open another user</strong>. Demonstr\u0101cijas video: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "K\u0101 mekl\u0113t IDC un pievienot person\u012Bgajam sarakstam.",
    howto4Title: "K\u0101 iel\u0101d\u0113t lok\u0101lu p\u0113t\u012Bjumu skat\u012Bt\u0101j\u0101.",
    howto5Title: "K\u0101 lietot att\u0101lo AI",
    howto6Title: "K\u0101 eksport\u0113t segmentu STL fail\u0101 3D druk\u0101\u0161anai.",
    howto7Title: "K\u0101 lietot Reporting / DICOM SR."
  }
};

// locales/hu.ts
var hu2 = {
  chrome: {
    conferencing: "Konferencia",
    open: "Megnyit\xE1s",
    close: "Bez\xE1r\xE1s",
    searchPortal: "Keres\u0151port\xE1l",
    searchPortalTitle: "IDC keres\u0151port\xE1l megnyit\xE1sa",
    worklist: "Worklist:",
    exploreIdc: "Fedezze fel az NCI Imaging Data Commons-ot:",
    viewers: "Megjelen\xEDt\u0151k:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurzus:",
    anatomicalPlanes: "Classroom",
    currentContext: "Jelenlegi kontextus:",
    none: "nincs",
    colStudy: "Vizsg\xE1lat",
    colModalities: "Modalit\xE1sok",
    colFormat: "Form\xE1tum",
    colSize: "M\xE9ret",
    language: "Nyelv",
    openStudy: "Vizsg\xE1lat megnyit\xE1sa",
    closeStudy: "Nyitott vizsg\xE1lat bez\xE1r\xE1sa",
    closeContext: "Jelenlegi kontextus bez\xE1r\xE1sa",
    cannotOpen: "Nem nyithat\xF3 meg",
    saveWorklist: "Ment\xE9s",
    loadWorklist: "Bet\xF6lt\xE9s",
    saveWorklistTitle: "Saj\xE1t worklist ment\xE9se JSON-k\xE9nt",
    loadWorklistTitle: "Saj\xE1t worklist bet\xF6lt\xE9se JSON-b\xF3l"
  },
  conference: CONFERENCE_BY_LOCALE.hu,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Az alkalmaz\xE1sr\xF3l",
    aboutLinkLabel: "N\xE9vjegy",
    aboutLinkSuffix: "\u2014 licencek, k\xF6sz\xF6netnyilv\xE1n\xEDt\xE1sok \xE9s v\xE9djegyek.",
    quickStartTitle: "Gyors ind\xEDt\xE1s:",
    quickStartBody: "Kattintson jobbra az egyik {{open}} gombra egy CR megnyit\xE1s\xE1hoz, majd haszn\xE1lja a var\xE1zsp\xE1lca ikont {{magicWand}} a FleXray futtat\xE1s\xE1hoz.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "A Worklist csatlakoztat\xE1sa 3D Slicerhez.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Telep\xEDtse a Slicer WebSub Interface b\u0151v\xEDtm\xE9nyt</li>
        <li>A <strong>3D Slicer</strong>-ben nyissa meg a <strong>Hub Interface</strong> modult, majd az <strong>Image Display Client</strong> szekci\xF3t.</li>
        <li>V\xE1lassza a <strong>SLICER-HUB-CLOUD</strong> hubot (ugyanaz a felh\u0151 hub, mint enn\xE9l a worklistn\xE9l). A <strong>SLICER-HUB</strong>-ot csak akkor haszn\xE1lja, ha helyi hub fut a 2018-as porton.</li>
        <li>OIDC n\xE9lk\xFCl \xE1ll\xEDtsa a <strong>User</strong> mez\u0151t ugyanarra a felhaszn\xE1l\xF3ra, mint a felh\u0151 worklist (bal fels\u0151), majd kattintson a <strong>Connect</strong> gombra.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Csatlakoz\xE1s ut\xE1n a worklist <strong>SlicerDesktop</strong> megjelen\xEDt\u0151 gombja kivil\xE1gosodik, a v\xE1laszt\xF3 \xAB3D Slicer\xBB-re v\xE1lt, \xE9s a lista a Slicer DICOM adatb\xE1zis tartalm\xE1t mutatja. Nyisson meg egy vizsg\xE1latot \u2014 az asztali Slicerben t\xF6lt\u0151dik be.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist megjelen\xEDt\u0151kkel (SlicerDesktop kiv\xE1lasztva), t\xE1voli AI-val \xE9s vizsg\xE1latlist\xE1val" width="870" height="498" />
        </li>
        <li>B\xF6ng\xE9sz\u0151s konferenci\xE1hoz / \xE9l\u0151 n\xE9zethez haszn\xE1lja a <strong>SlicerLive</strong>-ot \xE9s a <strong>Konferencia</strong>t, amikor m\xE1sok k\xF6vetik a csom\xF3pont- \xE9s kamera/prezent\xE1ci\xF3-v\xE1ltoz\xE1sokat.</li>
      </ol>
    `,
    howto1Title: "Hogyan csatlakozzon konferenci\xE1hoz.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Nyissa meg a worklistet, \xE9s kattintson a jobb fels\u0151 <strong>Konferencia</strong> gombra.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive fejl\xE9c kiemelt konferenci\xE1val" width="477" height="117" />
        </li>
        <li>Ha a hub p\xE9ld\xE1ny\xE1n m\xE1r van folyamatban l\xE9v\u0151 konferencia, az egy leg\xF6rd\xFCl\u0151 list\xE1ban jelenik meg.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Csatlakoz\xE1s konferenci\xE1hoz: akt\xEDv konferenci\xE1k list\xE1ja \xE9s Csatlakoz\xE1s gomb" width="322" height="175" />
        </li>
        <li>Ha a konferencia m\xE9g nem indult el, v\xE1rja meg a csatlakoz\xE1si megh\xEDv\xF3t:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Megh\xEDv\xF3: Csatlakoz\xE1s \xE9s k\xF6vet\xE9s, Csatlakoz\xE1s k\xF6vet\xE9s n\xE9lk\xFCl vagy Nem csatlakozom" width="190" height="141" />
        </li>
        <li>Ha a k\xF6vet\xE9st v\xE1lasztotta, k\xF6veti a h\xE1zigazda vizsg\xE1lat\xE1t \xE9s prezent\xE1ci\xF3j\xE1t. B\xE1rmikor kil\xE9phet a <strong>Konferencia elhagy\xE1sa</strong> gombbal.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Fejl\xE9c Konferencia elhagy\xE1sa, az \xD6n helye \xE9s egy k\xF6vet\u0151 r\xE9sztvev\u0151" width="397" height="80" />
        </li>
        <li>Ha abbahagyja a k\xF6vet\xE9st, ezut\xE1n folytathatja a k\xF6vet\xE9st, vagy \xE1tveheti a konferenci\xE1t.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Fejl\xE9c K\xF6vet\xE9s folytat\xE1sa \xE9s \xC1tv\xE9tel a k\xF6vet\xE9s le\xE1ll\xEDt\xE1sa ut\xE1n" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Hogyan hozzon l\xE9tre konferenci\xE1t.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Nyissa meg a worklistet, \xE9s kattintson a <strong>Konferencia</strong> gombra jobbra fent.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive fejl\xE9c kiemelt Konferenci\xE1val" width="477" height="117" />
        </li>
        <li>H\xE1zigazdak\xE9nt kattintson a <strong>Konferencia</strong> gombra (worklist fejl\xE9c vagy SlicerLive s\xE1v). V\xE1lasszon c\xEDmet \xE9s hozza l\xE9tre \u2014 \xD6n lesz a <strong>vezet\u0151</strong> hely.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Konferencia l\xE9trehoz\xE1sa: c\xEDm mez\u0151 \xE9s Konferencia l\xE9trehoz\xE1sa gomb" width="167" height="192" />
        </li>
        <li>Vezet\xE9s k\xF6zben a SlicerLive v\xE1ltoz\xE1sai (elrendez\xE9s, ablak/szint, szegmensl\xE1that\xF3s\xE1g, kamera, MPR g\xF6rget\xE9s/pan/zoom, elt\u0171n\u0151 tinta \xE9s hasonl\xF3 jelenetfriss\xEDt\xE9sek) eljutnak a k\xF6vet\u0151kh\xF6z.</li>
        <li>Mindenki sz\xE1m\xE1ra <strong>Befejezheti a konferenci\xE1t</strong>. Vezet\xE9s k\xF6zben a <strong>B</strong> billenty\u0171vel kapcsolhatja az elt\u0171n\u0151 tint\xE1t.</li>
        <li>Egy asztalon a <strong>Open another user</strong> gombbal tesztelheti a konferenci\xE1t. Dem\xF3vide\xF3: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Keres\xE9s az IDC-ben \xE9s hozz\xE1ad\xE1s szem\xE9lyes list\xE1hoz.",
    howto4Title: "Helyi vizsg\xE1lat bet\xF6lt\xE9se megjelen\xEDt\u0151be.",
    howto5Title: "T\xE1voli AI haszn\xE1lata",
    howto6Title: "Szegmens export\xE1l\xE1sa STL-be 3D nyomtat\xE1shoz.",
    howto7Title: "Reporting / DICOM SR haszn\xE1lata."
  }
};

// locales/lt.ts
var lt3 = {
  chrome: {
    conferencing: "Konferencija",
    open: "Atidaryti",
    close: "U\u017Edaryti",
    searchPortal: "Paie\u0161kos portalas",
    searchPortalTitle: "Atidaryti IDC paie\u0161kos portal\u0105",
    worklist: "Worklist:",
    exploreIdc: "Nar\u0161ykite NCI Imaging Data Commons:",
    viewers: "Per\u017Ei\u016Bros programos:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kursas:",
    anatomicalPlanes: "Classroom",
    currentContext: "Dabartinis kontekstas:",
    none: "n\u0117ra",
    colStudy: "Tyrimas",
    colModalities: "Modalumai",
    colFormat: "Formatas",
    colSize: "Dydis",
    language: "Kalba",
    openStudy: "Atidaryti tyrim\u0105",
    closeStudy: "U\u017Edaryti atidaryt\u0105 tyrim\u0105",
    closeContext: "U\u017Edaryti dabartin\u012F kontekst\u0105",
    cannotOpen: "Nepavyksta atidaryti",
    saveWorklist: "I\u0161saugoti",
    loadWorklist: "\u012Ekelti",
    saveWorklistTitle: "I\u0161saugoti mano darb\u0173 s\u0105ra\u0161\u0105 kaip JSON",
    loadWorklistTitle: "\u012Ekelti mano darb\u0173 s\u0105ra\u0161\u0105 i\u0161 JSON"
  },
  conference: CONFERENCE_BY_LOCALE.lt,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Apie \u0161i\u0105 program\u0105",
    aboutLinkLabel: "Apie",
    aboutLinkSuffix: "\u2014 licencijos, pad\u0117kos ir preki\u0173 \u017Eenklai.",
    quickStartTitle: "Greita prad\u017Eia:",
    quickStartBody: "De\u0161in\u0117je spustel\u0117kite vien\u0105 mygtuk\u0173 {{open}}, kad atidarytum\u0117te CR ir naudotum\u0117te magijos lazdel\u0117s piktogram\u0105 {{magicWand}} FleXray paleisti.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Kaip prijungti Worklist prie 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>\u012Ediekite Slicer WebSub Interface pl\u0117tin\u012F</li>
        <li><strong>3D Slicer</strong> atidarykite modul\u012F <strong>Hub Interface</strong> ir skilt\u012F <strong>Image Display Client</strong>.</li>
        <li>Pasirinkite hub\u0105 <strong>SLICER-HUB-CLOUD</strong> (tas pats debesies hubas kaip \u0161ioje worklist). Naudokite <strong>SLICER-HUB</strong> tik kai vietinis hubas veikia 2018 prievade.</li>
        <li>Be OIDC nustatykite <strong>User</strong> t\u0105 pat\u012F vartotoj\u0105 kaip debesies worklist (vir\u0161uje kair\u0117je), tada spustel\u0117kite <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Prisijungus worklist <strong>SlicerDesktop</strong> per\u017Ei\u016Bros mygtukas u\u017Esidega, selektorius pasikei\u010Dia \u012F \xAB3D Slicer\xBB, o s\u0105ra\u0161as rodo Slicer DICOM duomen\u0173 baz\u0117s turin\u012F. Atidarykite tyrim\u0105 \u2014 jis \u012Fkeliamas \u012F darbalaukio Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist su per\u017Ei\u016Bros programomis (pasirinktas SlicerDesktop), nuotoliniu AI ir tyrim\u0173 s\u0105ra\u0161u" width="870" height="498" />
        </li>
        <li>Nar\u0161ykl\u0117s konferencijai / tiesioginei per\u017Ei\u016Brai naudokite <strong>SlicerLive</strong> ir <strong>Konferencija</strong>, kai kiti seka mazgo ir kameros/prezentacijos pakeitimus.</li>
      </ol>
    `,
    howto1Title: "Kaip prisijungti prie konferencijos.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Atidarykite worklist ir spustel\u0117kite <strong>Konferencija</strong> vir\u0161uje de\u0161in\u0117je.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive antra\u0161t\u0117 su pary\u0161kinta konferencija" width="477" height="117" />
        </li>
        <li>Jei j\u016Bs\u0173 hub egzemplioriuje jau vyksta konferencija, ji bus rodoma i\u0161skleid\u017Eiamajame s\u0105ra\u0161e.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Prisijungti prie konferencijos: aktyvi\u0173 konferencij\u0173 s\u0105ra\u0161as ir mygtukas Prisijungti" width="322" height="175" />
        </li>
        <li>Jei konferencija dar neprasid\u0117jo, palaukite kvietimo prisijungti:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Kvietimas: Prisijungti ir sekti, Prisijungti be sekimo arba Ne prisijungti" width="190" height="141" />
        </li>
        <li>Jei pasirinkote sekti, sekate \u0161eimininko tyrim\u0105 ir pristatym\u0105. I\u0161eikite bet kada su <strong>Palikti konferencij\u0105</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Antra\u0161t\u0117 su Palikti konferencij\u0105, j\u016Bs\u0173 vieta ir sekan\u010Diu dalyviu" width="397" height="80" />
        </li>
        <li>Jei nustojate sekti, v\u0117liau galite atnaujinti sekim\u0105 arba perimti konferencij\u0105.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Antra\u0161t\u0117 su Atnaujinti sekim\u0105 ir Perimti sustabd\u017Eius sekim\u0105" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Kaip sukurti konferencij\u0105.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Atidarykite worklist ir spustel\u0117kite <strong>Konferencija</strong> vir\u0161uje de\u0161in\u0117je.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive antra\u0161t\u0117 su pary\u0161kinta Konferencija" width="477" height="117" />
        </li>
        <li>Kaip \u0161eimininkas spustel\u0117kite <strong>Konferencija</strong> (worklist antra\u0161t\u0117 arba SlicerLive juosta). Pasirinkite pavadinim\u0105 ir sukurkite \u2014 tampate <strong>leading</strong> vieta.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Sukurti konferencij\u0105: pavadinimo laukas ir mygtukas Sukurti konferencij\u0105" width="167" height="192" />
        </li>
        <li>Vadovaujant SlicerLive pakeitimai (i\u0161d\u0117stymas, langas/lygis, segment\u0173 matomumas, kamera, MPR slinkimas/pan/zoom, nykstantis ra\u0161alas ir pana\u0161\u016Bs scenos atnaujinimai) perduodami sek\u0117jams.</li>
        <li>Galite <strong>Baigti konferencij\u0105</strong> visiems. Vadovaujant naudokite klavi\u0161\u0105 <strong>B</strong>, kad \u012Fjungtum\u0117te/i\u0161jungtum\u0117te nykstant\u012F ra\u0161al\u0105.</li>
        <li>Konferencij\u0105 galite i\u0161bandyti viename kompiuteryje mygtuku <strong>Open another user</strong>. Demonstracinis vaizdo \u012Fra\u0161as: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Kaip ie\u0161koti IDC ir prid\u0117ti prie asmeninio s\u0105ra\u0161o.",
    howto4Title: "Kaip \u012Fkelti vietin\u012F tyrim\u0105 \u012F per\u017Ei\u016Bros program\u0105.",
    howto5Title: "Kaip naudoti nuotolin\u012F AI",
    howto6Title: "Kaip eksportuoti segment\u0105 \u012F STL 3D spausdinimui.",
    howto7Title: "Kaip naudoti Reporting / DICOM SR."
  }
};

// locales/ro.ts
var ro3 = {
  chrome: {
    conferencing: "Conferin\u021B\u0103",
    open: "Deschide",
    close: "\xCEnchide",
    searchPortal: "Portal de c\u0103utare",
    searchPortalTitle: "Deschide portalul de c\u0103utare IDC",
    worklist: "Worklist:",
    exploreIdc: "Explora\u021Bi NCI Imaging Data Commons:",
    viewers: "Vizualizatoare:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Curs:",
    anatomicalPlanes: "Classroom",
    currentContext: "Context curent:",
    none: "niciunul",
    colStudy: "Studiu",
    colModalities: "Modalit\u0103\u021Bi",
    colFormat: "Format",
    colSize: "Dimensiune",
    language: "Limb\u0103",
    openStudy: "Deschide studiul",
    closeStudy: "\xCEnchide studiul deschis",
    closeContext: "\xCEnchide contextul curent",
    cannotOpen: "Nu se poate deschide",
    saveWorklist: "Salveaz\u0103",
    loadWorklist: "\xCEncarc\u0103",
    saveWorklistTitle: "Salveaz\u0103 worklist-ul meu ca JSON",
    loadWorklistTitle: "\xCEncarc\u0103 worklist-ul meu din JSON"
  },
  conference: CONFERENCE_BY_LOCALE.ro,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Despre aceast\u0103 aplica\u021Bie",
    aboutLinkLabel: "Despre",
    aboutLinkSuffix: "\u2014 licen\u021Be, mul\u021Bumiri \u0219i m\u0103rci comerciale.",
    quickStartTitle: "Start rapid:",
    quickStartBody: "Face\u021Bi clic pe unul dintre butoanele {{open}} din dreapta pentru a deschide un CR \u0219i a folosi pictograma baghetei magice {{magicWand}} pentru a rula FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Cum se conecteaz\u0103 Worklist la 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Instala\u021Bi extensia Slicer WebSub Interface</li>
        <li>\xCEn <strong>3D Slicer</strong>, deschide\u021Bi modulul <strong>Hub Interface</strong>, apoi sec\u021Biunea <strong>Image Display Client</strong>.</li>
        <li>Alege\u021Bi hub-ul <strong>SLICER-HUB-CLOUD</strong> (acela\u0219i hub cloud ca aceast\u0103 worklist). Folosi\u021Bi <strong>SLICER-HUB</strong> doar c\xE2nd rula\u021Bi un hub local pe portul 2018.</li>
        <li>F\u0103r\u0103 OIDC, seta\u021Bi <strong>User</strong> la acela\u0219i utilizator ca worklist-ul cloud (st\xE2nga sus), apoi face\u021Bi clic pe <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>Dup\u0103 conectare, butonul vizualizator <strong>SlicerDesktop</strong> se activeaz\u0103, selectorul trece la \xAB3D Slicer\xBB, iar lista afi\u0219eaz\u0103 con\u021Binutul bazei DICOM Slicer. Deschide\u021Bi un studiu \u2014 se \xEEncarc\u0103 \xEEn Slicer desktop.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist cu vizualizatoare (SlicerDesktop selectat), AI la distan\u021B\u0103 \u0219i list\u0103 de studii" width="870" height="498" />
        </li>
        <li>Pentru conferin\u021B\u0103 \xEEn browser / vizualizare live, folosi\u021Bi <strong>SlicerLive</strong> \u0219i <strong>Conferin\u021B\u0103</strong> c\xE2nd al\u021Bii urm\u0103resc modific\u0103rile de nod \u0219i camer\u0103/prezentare.</li>
      </ol>
    `,
    howto1Title: "Cum se al\u0103tur\u0103 unei conferin\u021Be.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>Deschide\u021Bi worklist \u0219i face\u021Bi clic pe <strong>Conferin\u021B\u0103</strong> \xEEn dreapta sus.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Antet SlicerLive cu conferin\u021Ba eviden\u021Biat\u0103" width="477" height="117" />
        </li>
        <li>Dac\u0103 pe instan\u021Ba hub exist\u0103 o conferin\u021B\u0103 \xEEn curs, va ap\u0103rea \xEEntr-o list\u0103 derulant\u0103.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Al\u0103turare la conferin\u021B\u0103: lista conferin\u021Belor active \u0219i butonul Al\u0103tur\u0103-te" width="322" height="175" />
        </li>
        <li>Dac\u0103 conferin\u021Ba nu a \xEEnceput \xEEnc\u0103, a\u0219tepta\u021Bi invita\u021Bia de al\u0103turare:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Invita\u021Bie: Al\u0103turare \u0219i urm\u0103rire, Al\u0103turare f\u0103r\u0103 urm\u0103rire sau Nu m\u0103 al\u0103tur" width="190" height="141" />
        </li>
        <li>Dac\u0103 a\u021Bi ales urm\u0103rirea, urm\u0103ri\u021Bi studiul \u0219i prezentarea gazdei. Ie\u0219i\u021Bi oric\xE2nd cu <strong>P\u0103r\u0103se\u0219te conferin\u021Ba</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Antet cu P\u0103r\u0103se\u0219te conferin\u021Ba, locul dvs. \u0219i un participant care urmeaz\u0103" width="397" height="80" />
        </li>
        <li>Dac\u0103 opri\u021Bi urm\u0103rirea, pute\u021Bi apoi relua urm\u0103rirea sau prelua conferin\u021Ba.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Antet cu Relua\u021Bi urm\u0103rirea \u0219i Preia\u021Bi dup\u0103 oprirea urm\u0103ririi" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Cum se creeaz\u0103 o conferin\u021B\u0103.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>Deschide\u021Bi worklist-ul \u0219i face\u021Bi clic pe <strong>Conferin\u021B\u0103</strong> \xEEn dreapta sus.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="Antet SlicerLive cu Conferin\u021B\u0103 eviden\u021Biat\u0103" width="477" height="117" />
        </li>
        <li>Ca gazd\u0103, face\u021Bi clic pe <strong>Conferin\u021B\u0103</strong> (antet worklist sau bara SlicerLive). Alege\u021Bi un titlu \u0219i crea\u021Bi \u2014 deveni\u021Bi locul <strong>leading</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Crea\u021Bi conferin\u021Ba: c\xE2mp titlu \u0219i buton Crea\u021Bi conferin\u021Ba" width="167" height="192" />
        </li>
        <li>\xCEn timp ce conduce\u021Bi, modific\u0103rile din SlicerLive (aspect, fereastr\u0103/nivel, vizibilitate segmente, camer\u0103, scroll/pan/zoom MPR, cerneal\u0103 efemer\u0103 \u0219i actualiz\u0103ri similare de scen\u0103) sunt propagate urm\u0103ritorilor.</li>
        <li>Pute\u021Bi <strong>\xCEncheia conferin\u021Ba</strong> pentru toat\u0103 lumea. \xCEn timp ce conduce\u021Bi, folosi\u021Bi tasta <strong>B</strong> pentru a activa/dezactiva cerneala efemer\u0103.</li>
        <li>Pute\u021Bi testa conferin\u021Ba pe un singur desktop cu butonul <strong>Open another user</strong>. Vede\u021Bi videoclipul demo: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Cum se caut\u0103 \xEEn IDC \u0219i se adaug\u0103 la o list\u0103 personal\u0103.",
    howto4Title: "Cum se \xEEncarc\u0103 un studiu local \xEEntr-un vizualizator.",
    howto5Title: "Cum se utilizeaz\u0103 AI la distan\u021B\u0103",
    howto6Title: "Cum se export\u0103 un segment \xEEn STL pentru imprimare 3D.",
    howto7Title: "Cum se utilizeaz\u0103 Reporting / DICOM SR."
  }
};

// locales/no.ts
var no3 = {
  chrome: {
    conferencing: "Konferanse",
    open: "\xC5pne",
    close: "Lukk",
    searchPortal: "S\xF8keportal",
    searchPortalTitle: "\xC5pne IDC-s\xF8keportalen",
    worklist: "Worklist:",
    exploreIdc: "Utforsk NCI Imaging Data Commons:",
    viewers: "Visere:",
    reportingClients: "Report Creators:",
    localAi: "Evidence Creators:",
    remoteAi: "Evidence Creators:",
    classroom: "Kurs:",
    anatomicalPlanes: "Classroom",
    currentContext: "Gjeldende kontekst:",
    none: "ingen",
    colStudy: "Studie",
    colModalities: "Modaliteter",
    colFormat: "Format",
    colSize: "St\xF8rrelse",
    language: "Spr\xE5k",
    openStudy: "\xC5pne studie",
    closeStudy: "Lukk \xE5pen studie",
    closeContext: "Lukk gjeldende kontekst",
    cannotOpen: "Kan ikke \xE5pne",
    saveWorklist: "Lagre",
    loadWorklist: "Last inn",
    saveWorklistTitle: "Lagre min worklist som JSON",
    loadWorklistTitle: "Last inn min worklist fra JSON"
  },
  conference: CONFERENCE_BY_LOCALE.no,
  help: {
    modalTitle: "Worklist",
    aboutSummary: "Om denne applikasjonen",
    aboutLinkLabel: "Om",
    aboutLinkSuffix: "\u2014 lisenser, takk og varemerker.",
    quickStartTitle: "Hurtigstart:",
    quickStartBody: "Klikk en av {{open}}-knappene til h\xF8yre for \xE5 \xE5pne et CR og bruke tryllestavikonet {{magicWand}} for \xE5 kj\xF8re FleXray.",
    introHtml: `
        <p>
          This application uses the
          <a href="https://imaging.datacommons.cancer.gov/" target="_blank" rel="noopener">Imaging Data Commons</a>
          (IDC) together with
          <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">WebSub integration</a>
          and open-source viewers to provide a collaborative conferencing
          environment for education. Lessons are organized as
          <strong>courses</strong> that educators can extend by adding folders
          under the courses folder.
        </p>
        <p>
          The IDC is part of the NCI Cancer Research Data Commons. It hosts large,
          publicly available collections of cancer imaging data in the cloud so
          researchers, clinicians, and educators can explore real clinical-grade
          studies without setting up their own archive.
        </p>
        <p>
          IDC invests in education and open tooling so students and teachers can
          learn medical imaging with authentic data, reproducible workflows, and
          freely available viewers\u2014not only research pipelines.
        </p>
        <p>
          Viewing is powered by open-source platforms that share IDC\u2019s commitment
          to accessible medical imaging:
        </p>
        <ul class="wl-help-steps">
          <li>
            <a href="https://ohif.org/" target="_blank" rel="noopener">OHIF</a>
            \u2014 a web-based medical image viewer built on open standards (including
            DICOMweb). It is widely used in research and education, and is designed
            so modes and extensions can grow with teaching and clinical workflows.
          </li>
          <li>
            <a href="https://github.com/ImagingDataCommons/slim" target="_blank" rel="noopener">Slim</a>
            \u2014 an interoperable slide microscopy viewer from the Imaging Data
            Commons (National Cancer Institute), for teaching and research with
            whole-slide imaging.
          </li>
          <li>
            <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>
            \u2014 a desktop platform for visualization, analysis, and research.
            <a href="https://github.com/mbellehumeur/SlicerWebSub" target="_blank" rel="noopener">Slicer WebSub</a>
            runs as a Slicer extension so Classroom, conferencing, and image
            display can share one open messaging stack with the same data and tools.
          </li>
        </ul>
        <p>
          For free, open anatomy education, see the
          <a href="https://www.openanatomy.org/" target="_blank" rel="noopener">Open Anatomy Project</a>
          at Brigham and Women\u2019s Hospital. It distributes high-quality anatomy
          atlases and open-source software worldwide\u2014democratizing medical
          knowledge for students, clinicians, researchers, and the public,
          wherever they live and in many languages. Atlases are viewed in the
          web-based Open Anatomy Browser; the group also created
          <a href="https://www.slicer.org/" target="_blank" rel="noopener">3D Slicer</a>,
          which was used to build the atlases.
        </p>
        <p>
          The University of Twente
          <a href="https://bonehub.github.io/Educational-Atlas/" target="_blank" rel="noopener">BoneHub Educational Atlas</a>
          offers interactive full-skeleton 3D models of the Visible Human Male
          and Female for teaching, visualization, and 3D printing. Free STL
          meshes and IGES/STEP CAD files (CC BY 4.0) are available from the
          <a href="https://huggingface.co/datasets/BoneHub/visible-human-3d-models" target="_blank" rel="noopener">visible-human-3d-models</a>
          dataset on Hugging Face.
        </p>
    `,
    howto0Title: "Slik kobler du Worklist til 3D Slicer.",
    howto0Body: `
      <ol class="wl-help-steps">
        <li>Installer Slicer WebSub Interface-utvidelsen</li>
        <li>I <strong>3D Slicer</strong>, \xE5pne modulen <strong>Hub Interface</strong>, deretter seksjonen <strong>Image Display Client</strong>.</li>
        <li>Velg hub <strong>SLICER-HUB-CLOUD</strong> (samme skyhub som denne worklisten). Bruk <strong>SLICER-HUB</strong> bare n\xE5r du kj\xF8rer en lokal hub p\xE5 port 2018.</li>
        <li>Uten OIDC, sett <strong>User</strong> til samme bruker som sky-worklisten (\xF8verst til venstre), og klikk <strong>Connect</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/image-display-client-connect.png" alt="Image Display Client: hub SLICER-HUB-CLOUD, topic, Connect, Connected" width="585" height="127" />
        </li>
        <li>N\xE5r du er tilkoblet, lyser worklist-knappen <strong>SlicerDesktop</strong> opp, velgeren endres til \xAB3D Slicer\xBB, og listen viser innholdet i Slicer DICOM-databasen. \xC5pne en studie \u2014 den lastes i desktop Slicer.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/worklist-viewers-slicer-qt.png" alt="Worklist med visere (SlicerDesktop valgt), ekstern AI og studieliste" width="870" height="498" />
        </li>
        <li>For nettleserkonferanse / direktevisning, bruk <strong>SlicerLive</strong> og <strong>Konferanse</strong> n\xE5r andre f\xF8lger node- og kamera-/presentasjonsendringene dine.</li>
      </ol>
    `,
    howto1Title: "Slik blir du med i en konferanse.",
    howto1Body: `
      <ol class="wl-help-steps">
        <li>\xC5pne worklisten og klikk <strong>Konferanse</strong> \xF8verst til h\xF8yre.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-header med konferanse uthevet" width="477" height="117" />
        </li>
        <li>Hvis en konferanse p\xE5g\xE5r p\xE5 hub-instansen din, vises den i en nedtrekksliste.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-join.png" alt="Bli med i konferanse: nedtrekksliste for aktive konferanser og knappen Bli med" width="322" height="175" />
        </li>
        <li>Hvis konferansen ikke har startet, vent p\xE5 invitasjonen om \xE5 bli med:</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-invitation.png" alt="Konferanseinvitasjon: Bli med og f\xF8lge, Bli med uten \xE5 f\xF8lge, eller Ikke bli med" width="190" height="141" />
        </li>
        <li>Hvis du valgte \xE5 f\xF8lge, f\xF8lger du vertens studie og presentasjon. Forlat n\xE5r som helst med <strong>Forlat konferanse</strong>.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/conference-chips.png" alt="Header med Forlat konferanse, din plass og en f\xF8lgende deltaker" width="397" height="80" />
        </li>
        <li>Hvis du stopper \xE5 f\xF8lge, kan du deretter gjenoppta f\xF8lging eller ta over konferansen.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/ResumeTakeOverConference.png" alt="Header med Fortsett \xE5 f\xF8lge og Ta over etter \xE5 ha stoppet f\xF8lging" width="643" height="42" />
        </li>
      </ol>
    `,
    howto2Title: "Slik oppretter du en konferanse.",
    howto2Body: `
      <ol class="wl-help-steps">
        <li>\xC5pne worklisten og klikk <strong>Konferanse</strong> \xF8verst til h\xF8yre.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/slicerlive-start-conference.png" alt="SlicerLive-topptekst med Konferanse uthevet" width="477" height="117" />
        </li>
        <li>Som vert klikker du <strong>Konferanse</strong> (worklist-topptekst eller SlicerLive-linjen). Velg en tittel og opprett \u2014 du blir det <strong>ledende</strong> stedet.</li>
        <li class="wl-help-figure">
          <img class="wl-help-img" src="./help-images/create-conference.png" alt="Opprett konferanse: tittelfelt og Opprett konferanse-knapp" width="167" height="192" />
        </li>
        <li>Mens du leder, sendes endringer i SlicerLive (layout, vindusniv\xE5, segmentvisning, kamera, MPR scroll/pan/zoom, midlertidig blekk og lignende sceneoppdateringer) til f\xF8lgere.</li>
        <li>Du kan <strong>Avslutt konferanse</strong> for alle. Mens du leder, bruker du <strong>B</strong>-tasten for \xE5 sl\xE5 midlertidig blekk av/p\xE5.</li>
        <li>Du kan teste konferanse p\xE5 \xE9n desktop med knappen <strong>Open another user</strong>. Se demovideoen: <a href="https://youtu.be/xKQEOs1_9Bg" target="_blank" rel="noopener noreferrer">https://youtu.be/xKQEOs1_9Bg</a></li>
      </ol>
    `,
    howto3Title: "Slik s\xF8ker du i IDC og legger til i en personlig liste.",
    howto4Title: "Slik laster du en lokal studie til en viser.",
    howto5Title: "Slik bruker du ekstern AI",
    howto6Title: "Slik eksporterer du et segment til STL for 3D-utskrift.",
    howto7Title: "Slik bruker du Reporting / DICOM SR."
  }
};

// i18n.ts
var NON_EN = new Set(
  APP_LOCALES.map((l) => l.code).filter((c) => c !== "en")
);
var ready = false;
async function initI18n() {
  if (ready) return instance;
  const lng = resolveStoredLocale();
  await instance.init({
    lng,
    fallbackLng: "en",
    defaultNS: "chrome",
    ns: ["chrome", "help", "conference"],
    resources: {
      en: { chrome: en3.chrome, help: en3.help, conference: en3.conference },
      ar: { chrome: ar3.chrome, help: ar3.help, conference: ar3.conference },
      fr: { chrome: fr3.chrome, help: fr3.help, conference: fr3.conference },
      es: { chrome: es2.chrome, help: es2.help, conference: es2.conference },
      ca: { chrome: ca2.chrome, help: ca2.help, conference: ca2.conference },
      de: { chrome: de3.chrome, help: de3.help, conference: de3.conference },
      it: { chrome: it3.chrome, help: it3.help, conference: it3.conference },
      pt: { chrome: pt4.chrome, help: pt4.help, conference: pt4.conference },
      ko: { chrome: ko2.chrome, help: ko2.help, conference: ko2.conference },
      pl: { chrome: pl2.chrome, help: pl2.help, conference: pl2.conference },
      uk: { chrome: uk2.chrome, help: uk2.help, conference: uk2.conference },
      cs: { chrome: cs3.chrome, help: cs3.help, conference: cs3.conference },
      nl: { chrome: nl2.chrome, help: nl2.help, conference: nl2.conference },
      el: { chrome: el2.chrome, help: el2.help, conference: el2.conference },
      lv: { chrome: lv2.chrome, help: lv2.help, conference: lv2.conference },
      hu: { chrome: hu2.chrome, help: hu2.help, conference: hu2.conference },
      lt: { chrome: lt3.chrome, help: lt3.help, conference: lt3.conference },
      ro: { chrome: ro3.chrome, help: ro3.help, conference: ro3.conference },
      no: { chrome: no3.chrome, help: no3.help, conference: no3.conference }
    },
    interpolation: { escapeValue: false },
    returnNull: false
  });
  ready = true;
  persistLocale(lng);
  return instance;
}
function getLocale() {
  const lng = (instance.language || "en").split("-")[0];
  if (NON_EN.has(lng)) return lng;
  return "en";
}
async function setLocale(code) {
  await instance.changeLanguage(code);
  persistLocale(code);
}
function t2(key, options) {
  return String(instance.t(key, options));
}
function conferenceStrings() {
  return conferenceStringsFor(getLocale());
}
function onLanguageChanged(handler) {
  const fn2 = () => handler();
  instance.on("languageChanged", fn2);
  return () => {
    instance.off("languageChanged", fn2);
  };
}
function applyChromeLabels() {
  document.querySelectorAll("[data-i18n]").forEach((el6) => {
    const key = el6.getAttribute("data-i18n");
    if (!key) return;
    el6.textContent = t2(key);
  });
  document.querySelectorAll("[data-i18n-title]").forEach((el6) => {
    const key = el6.getAttribute("data-i18n-title");
    if (!key) return;
    el6.title = t2(key);
  });
  document.querySelectorAll("[data-i18n-aria]").forEach((el6) => {
    const key = el6.getAttribute("data-i18n-aria");
    if (!key) return;
    el6.setAttribute("aria-label", t2(key));
  });
}

// help.ts
var HOWTO_COUNT = 8;
var HELP_IMG_CACHE = "20260929c";
var MAGIC_WAND_SVG = `<span class="wl-help-magic-wand-frame" aria-hidden="true"><svg class="wl-help-magic-wand" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4V2"/><path d="M15 16v-2"/><path d="M8 9h2"/><path d="M20 9h2"/><path d="M17.8 11.8 19 13"/><path d="M15 9h0"/><path d="M17.8 6.2 19 5"/><path d="m3 21 9-9"/><path d="M12.2 6.2 11 5"/></svg></span>`;
function withHelpImgCacheBust(html) {
  return html.replace(
    /(src="\.\/help-images\/[^"?]+)(")/g,
    `$1?v=${HELP_IMG_CACHE}$2`
  );
}
function helpModalHtml() {
  const items = [];
  for (let i = 0; i < HOWTO_COUNT; i++) {
    const title = t2(`help:howto${i}Title`);
    const bodyKey = `help:howto${i}Body`;
    const bodyRaw = t2(bodyKey);
    const body = bodyRaw && bodyRaw !== bodyKey ? `<div class="wl-help-item-body">${withHelpImgCacheBust(bodyRaw.trim())}</div>` : "";
    items.push(
      `<li><details class="wl-help-details"><summary class="wl-help-item-title">${title}</summary>${body}</details></li>`
    );
  }
  return `
    <details class="wl-help-details wl-help-intro-details">
      <summary class="wl-help-item-title">${t2("help:aboutSummary")}</summary>
      <div class="wl-help-item-body wl-help-intro">
        ${t2("help:introHtml")}
      </div>
    </details>
    <ol class="wl-help-howto">
      ${items.join("\n")}
    </ol>
    <p class="wl-help-about-link">
      <a href="./about.html">${t2("help:aboutLinkLabel")}</a> ${t2("help:aboutLinkSuffix")}
    </p>
  `;
}
function showHelp(helpModal) {
  const content = helpModal.querySelector(
    "#helpModalContent"
  );
  const titleEl = helpModal.querySelector("#helpTitle");
  const quickStartEl = helpModal.querySelector(
    "#helpQuickStart"
  );
  if (titleEl) titleEl.textContent = t2("help:modalTitle");
  if (quickStartEl) {
    const openBtn = `<button type="button" class="wl-open-btn wl-open-btn-start-hint wl-help-open-sample" tabindex="-1" aria-hidden="true">${t2("chrome:open")}</button>`;
    const body = t2("help:quickStartBody").replaceAll("{{open}}", openBtn).replaceAll("{{magicWand}}", MAGIC_WAND_SVG);
    quickStartEl.innerHTML = `<strong>${t2("help:quickStartTitle")}</strong> ${body}`;
  }
  if (content) content.innerHTML = helpModalHtml();
  helpModal.hidden = false;
}
function refreshHelpIfOpen(helpModal) {
  if (!helpModal || helpModal.hidden) return;
  showHelp(helpModal);
}

// config.ts
var LOG_PREFIX = "[@slicer-hub/worklist]";
var PRODUCT_NAME = "WKLST";
var WORKLIST_ACTOR = "WORKLIST_CLIENT";
var IMAGE_DISPLAY_ACTOR = "ID";
var SUBSCRIBE_EVENTS = [
  $i,
  xi,
  k("STATUS"),
  Zi,
  Be,
  Ji
];
var EMPTY_CAST_CONTEXT = {
  "context.type": "",
  context: []
};
var PATIENT_REFERENCE = "Patient/503824b8-fe8c-4227-b061-7181ba6c3926";
var WORKLIST_ORG_MINE = "mine";
var WORKLIST_ORG_IDC_SEG = "idc-segmentations";
var WORKLIST_ORG_IDC_WSI = "idc-wsi";
var WORKLIST_ORG_SLICER_SCENES = "slicer-scenes";
var WORKLIST_ORG_CBCT_DENTAL = "cbct-dental";
var WORKLIST_ORG_TXRV = "torchxrayvision";
var WORKLIST_ORG_FLEXRAY = "flexray";
var WORKLIST_ORG_VOX2SEGLAM = "vox2seglam";
var WORKLIST_ORG_3D_SLICER = "3d-slicer";
var WORKLIST_IDC_CATEGORY_FILTER_PREFIX = "idc-category:";
var IDC_CHEST_SUBCATEGORIES = [
  {
    id: "CHEST:NODULES_LIDC",
    label: "IDC \xB7 CHEST \xB7 Nodules (LIDC)",
    namePrefix: "CHEST \xB7 Nodules",
    collections: ["lidc_idri"]
  },
  {
    id: "CHEST:MEDIASTINAL_LN",
    label: "IDC \xB7 CHEST \xB7 Mediastinal LN",
    namePrefix: "CHEST \xB7 Mediastinal LN",
    collections: ["mediastinal_lymph_node_seg"]
  },
  {
    id: "CHEST:NLST_TOTALSEG",
    label: "IDC \xB7 CHEST \xB7 NLST (TotalSeg)",
    namePrefix: "CHEST \xB7 NLST",
    collections: ["nlst"]
  },
  {
    id: "CHEST:AIMI_LUNG_FDG",
    label: "IDC \xB7 CHEST \xB7 AIMI lung/FDG",
    namePrefix: "CHEST \xB7 AIMI",
    collections: ["acrin_nsclc_fdg_pet", "lung_pet_ct_dx", "rider_lung_pet_ct"]
  },
  {
    id: "CHEST:OTHER",
    label: "IDC \xB7 CHEST \xB7 Other",
    namePrefix: "CHEST \xB7 Other",
    collections: "other"
  }
];
var CHEST_COLLECTION_TO_SUBCATEGORY = (() => {
  const map = /* @__PURE__ */ new Map();
  for (const sub of IDC_CHEST_SUBCATEGORIES) {
    if (sub.collections === "other") continue;
    for (const col of sub.collections) {
      map.set(col, sub);
    }
  }
  return map;
})();
var CHEST_OTHER_SUBCATEGORY = IDC_CHEST_SUBCATEGORIES.find((s2) => s2.collections === "other");
function idcChestSubcategoryForCollection(collectionId) {
  return CHEST_COLLECTION_TO_SUBCATEGORY.get(String(collectionId || "").trim()) || CHEST_OTHER_SUBCATEGORY;
}
var IDC_KITS_CATEGORY = {
  id: "KIDNEY:KITS",
  label: "IDC \xB7 KIDNEY \xB7 KiTS",
  namePrefix: "KiTS",
  collectionId: "c4kc_kits"
};
var IDC_MODALITY_SPLIT_BASES = [
  "ABDOMEN",
  "BREAST",
  "LIVER",
  "LUNG",
  "CHEST:AIMI_LUNG_FDG",
  "CHEST:OTHER"
];
var MODALITY_SPLIT_BASE_SET = new Set(IDC_MODALITY_SPLIT_BASES);
function idcNeedsModalitySplit(baseCategory) {
  return MODALITY_SPLIT_BASE_SET.has(String(baseCategory || "").trim().toUpperCase());
}
function idcApplyModalitySplit(baseCategory, namePrefix, modality) {
  const base = String(baseCategory || "").trim().toUpperCase();
  const prefix = String(namePrefix || "").trim() || base;
  const mod = String(modality || "").trim().toUpperCase();
  if (!idcNeedsModalitySplit(base) || !mod || mod === "SEG") {
    return { id: base, namePrefix: prefix };
  }
  return {
    id: `${base}:${mod}`,
    namePrefix: `${prefix} \xB7 ${mod}`
  };
}
var IDC_CATEGORIES = [
  "ABDOMEN:CT",
  "ABDOMEN:PT",
  "ABDOMEN:MR",
  "ADRENAL",
  "BRAIN",
  "BREAST:MR",
  "BREAST:PT",
  "CHEST:NODULES_LIDC",
  "CHEST:MEDIASTINAL_LN",
  "CHEST:NLST_TOTALSEG",
  "CHEST:AIMI_LUNG_FDG:CT",
  "CHEST:AIMI_LUNG_FDG:PT",
  "CHEST:OTHER:CT",
  "CHEST:OTHER:PT",
  "KIDNEY",
  IDC_KITS_CATEGORY.id,
  "LIVER:CT",
  "LIVER:MR",
  "LUNG:CT",
  "LUNG:PT",
  "PANCREAS",
  "PELVIS",
  "PROSTATE",
  "WHOLEBODY"
];
function idcBodyRegionsForCategories(categoryIds) {
  const regions = /* @__PURE__ */ new Set();
  for (const id of categoryIds) {
    const cat = String(id || "").trim().toUpperCase();
    if (!cat) continue;
    if (cat === "CHEST" || cat.startsWith("CHEST:")) {
      regions.add("CHEST");
    } else if (cat === "KIDNEY:KITS") {
      regions.add("ABDOMEN");
    } else if (cat.includes(":")) {
      regions.add(cat.split(":")[0] || cat);
    } else {
      regions.add(cat);
    }
  }
  return regions;
}
function isIdcCategoryFilterValue(value) {
  return String(value || "").startsWith(WORKLIST_IDC_CATEGORY_FILTER_PREFIX);
}
function idcCategoryFromFilterValue(value) {
  const v2 = String(value || "").trim();
  if (!isIdcCategoryFilterValue(v2)) return null;
  const cat = v2.slice(WORKLIST_IDC_CATEGORY_FILTER_PREFIX.length).trim().toUpperCase();
  return cat || null;
}
var VIEWER_OPEN_TITLE_DISABLED = "Subscribe to the hub first";
var VIEWER_OPEN_TITLE_REPORTING = "Open IRA Report Creator";
var VIEWER_OPEN_TITLE_IRA = "Open SlicerLive";
var VIEWER_OPEN_TITLE_SLICER = "3D Slicer Image Display is connected";
var VIEWER_OPEN_TITLE_SLICER_INACTIVE = "3D Slicer Image Display not connected";
var VIEWER_OPEN_TITLE_SLICER_MIRROR = "Open 3D Slicer web mirror (slicer-mirror LiveScene stream)";
var VIEWER_OPEN_TITLE_SLICER_MIRROR_ACTIVE = "3D Slicer web mirror is active";
var VIEWER_OPEN_TITLE_OHIF = "Open an OHIF viewer instance";
var VIEWER_OPEN_TITLE_SCENEVIEWS = "Scene Views for connected image displays";
var VIEWER_OPEN_TITLE_SEGROULETTE = "Spin SegRoulette and open an IDC SEG case on Image Displays";
var VIEWER_URLS_LOCAL = {
  reporting: "http://localhost:8150/",
  classroom: "http://localhost:8160/",
  ira: "http://localhost:8130/ira/ira.html",
  ohif: "http://localhost:3000/viewer/",
  slim: "http://localhost:3001/"
};
var SLICER_MIRROR_URL_LOCAL = "http://localhost:8130/slicer-mirror/slicer-mirror.html";
var THEME_STORAGE_KEY = "pw46.worklist.theme";
var THEME_SLICERLIVE = "slicerlive";
var USER_NAME_KEY = "pw46.worklist.userName";
var USER_HUB_STARTED_AT_KEY = "pw46.worklist.userName.hubStartedAt";
var USER_HUB_ORIGIN_KEY = "pw46.worklist.userName.hubOrigin";
var HUB_CREDENTIALS = {
  client_id: "client_id_3d_Slicer",
  client_secret: "client_secret_3d_Slicer"
};
var HUB_DEFINITIONS = {
  local: {
    label: "3D Slicer local",
    hubEndpoint: "http://127.0.0.1:2018/api/hub",
    authorizeEndpoint: "http://127.0.0.1:2018/oauth/login",
    tokenEndpoint: "http://127.0.0.1:2018/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloud: {
    label: "3D Slicer cloud (mock)",
    hubEndpoint: "https://bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  },
  cloudOidc: {
    label: "3D Slicer cloud (OIDC)",
    hubEndpoint: "https://oidc.bellehumeur-engineering.com/api/hub",
    authorizeEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/login",
    tokenEndpoint: "https://oidc.bellehumeur-engineering.com/oauth/token",
    ...HUB_CREDENTIALS
  }
};
function isHostedOnCastHub(location = window.location) {
  const path = String(location.pathname || "");
  return path.startsWith("/worklist-client") || path.startsWith("/reporting-client") || path.startsWith("/classroom-client");
}
function shouldUseSameOriginHub(location = window.location) {
  return isHostedOnCastHub(location) || Qt(location);
}
var SPA_SOURCE_KEY = "pw46.hub.spaSource";
var SPA_SOURCES = ["auto", "dev", "hub"];
function normalizeSpaSource(value) {
  return SPA_SOURCES.includes(value) ? value : "auto";
}
function getSpaSource(location = window.location) {
  try {
    const fromQuery = new URL(location.href).searchParams.get("spa");
    if (fromQuery) return normalizeSpaSource(fromQuery);
  } catch {
  }
  try {
    return normalizeSpaSource(localStorage.getItem(SPA_SOURCE_KEY));
  } catch {
    return "auto";
  }
}
function setSpaSource(next, location = window.location) {
  const value = normalizeSpaSource(next);
  try {
    localStorage.setItem(SPA_SOURCE_KEY, value);
  } catch {
  }
  try {
    const url = new URL(location.href);
    if (value === "auto") url.searchParams.delete("spa");
    else url.searchParams.set("spa", value);
    window.history.replaceState(null, "", url.toString());
  } catch {
  }
  return value;
}
var DEFAULT_VIEWER_KEY = "pw46.hub.defaultViewer";
var DEFAULT_VIEWERS = [
  "slicerlive",
  "ohif"
];
function normalizeDefaultViewer(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (raw === "ira" || raw === "slicer" || raw === "slicer-live") {
    return "slicerlive";
  }
  return DEFAULT_VIEWERS.includes(raw) ? raw : "slicerlive";
}
function getDefaultViewer(location = window.location) {
  try {
    const fromQuery = new URL(location.href).searchParams.get("viewer");
    if (fromQuery) return normalizeDefaultViewer(fromQuery);
  } catch {
  }
  try {
    return normalizeDefaultViewer(localStorage.getItem(DEFAULT_VIEWER_KEY));
  } catch {
    return "slicerlive";
  }
}
function setDefaultViewer(next, location = window.location) {
  const value = normalizeDefaultViewer(next);
  try {
    localStorage.setItem(DEFAULT_VIEWER_KEY, value);
  } catch {
  }
  try {
    const url = new URL(location.href);
    if (value === "slicerlive") url.searchParams.delete("viewer");
    else url.searchParams.set("viewer", value);
    window.history.replaceState(null, "", url.toString());
  } catch {
  }
  return value;
}
function applySpaParam(url) {
  const spa = getSpaSource();
  if (spa === "auto") url.searchParams.delete("spa");
  else url.searchParams.set("spa", spa);
  return url;
}
function shouldUseHubMountUrls(location = window.location) {
  const spa = getSpaSource(location);
  if (spa === "dev") return false;
  if (spa === "hub") return true;
  return shouldUseSameOriginHub(location);
}
function resolveMountOrigin(location, hubOrigin) {
  const fromArg = String(hubOrigin || "").trim().replace(/\/$/, "");
  if (fromArg) return fromArg;
  if (shouldUseSameOriginHub(location)) return location.origin;
  try {
    return new URL(HUB_DEFINITIONS.local.hubEndpoint).origin;
  } catch {
    return location.origin;
  }
}
function sameOriginHubDefinition(origin, label) {
  return {
    label,
    hubEndpoint: `${origin}/api/hub`,
    authorizeEndpoint: `${origin}/oauth/login`,
    tokenEndpoint: `${origin}/oauth/token`,
    ...HUB_CREDENTIALS
  };
}
function getHubDefinitions(location = window.location) {
  if (!shouldUseSameOriginHub(location)) {
    return HUB_DEFINITIONS;
  }
  const origin = location.origin;
  const hosted = sameOriginHubDefinition(origin, "This Slicer hub");
  return {
    local: { ...hosted, label: "This Slicer hub" },
    cloud: { ...hosted, label: "This Slicer hub" }
  };
}
function resolveViewerUrls(location = window.location, opts = {}) {
  if (!shouldUseHubMountUrls(location)) {
    return { ...VIEWER_URLS_LOCAL };
  }
  const origin = resolveMountOrigin(location, opts.hubOrigin);
  return {
    reporting: `${origin}/reporting-client/`,
    classroom: `${origin}/classroom-client/`,
    ira: `${origin}/slicerlive/`,
    ohif: `${origin}/ohif/viewer/`,
    slim: `${origin}/slim/`
  };
}
function resolveSlicerMirrorUrl(location = window.location, opts = {}) {
  if (!shouldUseHubMountUrls(location)) {
    return SLICER_MIRROR_URL_LOCAL;
  }
  return `${resolveMountOrigin(location, opts.hubOrigin)}/slicer-mirror/`;
}
function hubOriginFromEndpoint(hubEndpoint2) {
  const trimmed = String(hubEndpoint2 || "").trim();
  if (!trimmed) return null;
  try {
    return new URL(trimmed).origin;
  } catch {
    return null;
  }
}
function resolveHubAuthConfigUrl(hubEndpoint2) {
  const trimmed = String(hubEndpoint2 || "").trim();
  if (!trimmed) return null;
  try {
    const base = trimmed.endsWith("/") ? trimmed : `${trimmed}/`;
    return new URL("auth/config", base).href;
  } catch {
    return null;
  }
}
function getStoredUserName() {
  try {
    return localStorage.getItem(USER_NAME_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function getStoredUserHubStartedAt() {
  try {
    return localStorage.getItem(USER_HUB_STARTED_AT_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function getStoredUserHubOrigin() {
  try {
    return localStorage.getItem(USER_HUB_ORIGIN_KEY)?.trim() || "";
  } catch {
    return "";
  }
}
function clearStoredUserName() {
  try {
    localStorage.removeItem(USER_NAME_KEY);
    localStorage.removeItem(USER_HUB_STARTED_AT_KEY);
    localStorage.removeItem(USER_HUB_ORIGIN_KEY);
  } catch {
  }
}
function setStoredUserName(userName, hubStartedAt, hubOrigin) {
  const trimmed = String(userName || "").trim();
  try {
    if (!trimmed) {
      clearStoredUserName();
      return;
    }
    localStorage.setItem(USER_NAME_KEY, trimmed);
    if (hubStartedAt) {
      localStorage.setItem(USER_HUB_STARTED_AT_KEY, hubStartedAt);
    }
    if (hubOrigin) {
      localStorage.setItem(USER_HUB_ORIGIN_KEY, hubOrigin);
    }
  } catch {
  }
}
async function fetchHubStartedAt(hubEndpoint2) {
  const configUrl = resolveHubAuthConfigUrl(hubEndpoint2);
  if (!configUrl) return null;
  try {
    const response = await fetch(configUrl, {
      method: "GET",
      headers: { Accept: "application/json" }
    });
    if (!response.ok) return null;
    const data = await response.json();
    const started = data?.started_at;
    return typeof started === "string" && started.trim() ? started.trim() : null;
  } catch {
    return null;
  }
}
function setStoredTheme(theme) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
  }
}

// inference-servers.ts
var BUTTON_IDS = {
  eucaim: "openEucaimBtn",
  vox2seglam: "openVox2seglamBtn",
  mhub: "openMhubBtn",
  totalseg: "openTotalSegmentatorBtn",
  dental: "openDentalSegmentatorBtn",
  txrv: "openTorchXrayVisionBtn",
  flexray: "openFlexRayBtn"
};
var INFERENCE_SERVERS = A.map((server) => ({
  ...server,
  worklistButtonId: BUTTON_IDS[server.id] || `open${server.id}Btn`
}));
var LOCAL_AI_WORKLIST_SERVERS = INFERENCE_SERVERS.filter((server) => server.localCapable === true);
function applyInferenceServerButtonVisibility() {
  const enabledIds = new Set(INFERENCE_SERVERS.map((s2) => s2.id));
  for (const [id, buttonId] of Object.entries(BUTTON_IDS)) {
    const btn = document.getElementById(buttonId);
    if (!btn) continue;
    btn.hidden = !enabledIds.has(id);
  }
  for (const server of INFERENCE_SERVERS) {
    if (!server.localCapable) continue;
    const btn = document.getElementById(server.worklistButtonId);
    if (!btn) continue;
    btn.classList.add("wl-viewer-btn-connected");
    btn.title = `${server.title} \xB7 Available`;
  }
}

// segroulette-catalog.ts
var MANIFEST_URL = "./segroulette.json";
var IDC_MANIFEST_URL = "./segroulette-idc.json";
var WORKLIST_MANIFEST_URL = "./segroulette-worklist.json";
var cached = null;
var loadPromise = null;
var cachedIdc = null;
var loadIdcPromise = null;
var cachedWorklist = null;
var loadWorklistPromise = null;
function primaryRegion(loc, fallbackCol) {
  const raw = String(loc || "").trim();
  if (!raw) return "OTHER";
  const first = raw.split(",")[0]?.trim().toUpperCase();
  return first || "OTHER";
}
function humanizeCollection(col) {
  return String(col || "").replace(/_/g, " ").trim();
}
function seriesReelLabel(entry2) {
  const mod = String(entry2.m || "?").toUpperCase();
  const sd = String(entry2.sd || "Segmentation").trim();
  const short = sd.length > 36 ? `${sd.slice(0, 34)}\u2026` : sd;
  return `${mod} \xB7 ${short}`;
}
function buildCatalog(rows, collMeta) {
  const byRegion = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (!row?.c || !row?.col) continue;
    const meta = collMeta[row.col] || {};
    const region2 = primaryRegion(meta.loc, row.col);
    let byCol = byRegion.get(region2);
    if (!byCol) {
      byCol = /* @__PURE__ */ new Map();
      byRegion.set(region2, byCol);
    }
    const list = byCol.get(row.col) || [];
    list.push(row);
    byCol.set(row.col, list);
  }
  const regions = [...byRegion.keys()].sort((a, b) => a.localeCompare(b));
  return { entries: rows, byRegion, regions };
}
function entriesForBodyRegions(catalog2, allowedRegions) {
  const picked = [];
  for (const region2 of catalog2.regions) {
    if (!allowedRegions.has(region2)) continue;
    const byCol = catalog2.byRegion.get(region2);
    if (!byCol) continue;
    const collections2 = [...byCol.keys()].sort((a, b) => a.localeCompare(b));
    for (const col of collections2) {
      const list = byCol.get(col);
      if (!list?.length) continue;
      for (const entry2 of list) {
        picked.push({ entry: entry2, region: region2 });
      }
    }
  }
  return picked;
}
async function fetchCatalog(url) {
  const res = await fetch(`${url}?t=${Date.now()}`);
  if (!res.ok) {
    throw new Error(`Failed to load SegRoulette catalog ${url} (HTTP ${res.status})`);
  }
  const data = await res.json();
  const rows = Array.isArray(data.rows) ? data.rows : data;
  const collMeta = data.stats?.collMeta || {};
  return buildCatalog(rows, collMeta);
}
async function loadSegrouletteCatalog() {
  if (cached) return cached;
  if (loadPromise) return loadPromise;
  loadPromise = (async () => {
    cached = await fetchCatalog(MANIFEST_URL);
    return cached;
  })();
  try {
    return await loadPromise;
  } catch (err) {
    loadPromise = null;
    throw err;
  }
}
async function loadIdcEnrichedCatalog() {
  if (cachedIdc) return cachedIdc;
  if (loadIdcPromise) return loadIdcPromise;
  loadIdcPromise = (async () => {
    try {
      cachedIdc = await fetchCatalog(IDC_MANIFEST_URL);
      return cachedIdc;
    } catch (err) {
      console.warn(
        "[@slicer-hub/worklist] segroulette-idc.json unavailable; falling back to compact catalog",
        err
      );
      loadIdcPromise = null;
      return loadSegrouletteCatalog();
    }
  })();
  try {
    return await loadIdcPromise;
  } catch (err) {
    loadIdcPromise = null;
    throw err;
  }
}
async function loadWorklistCatalogRows() {
  if (cachedWorklist) return cachedWorklist;
  if (loadWorklistPromise) return loadWorklistPromise;
  loadWorklistPromise = (async () => {
    try {
      const res = await fetch(`${WORKLIST_MANIFEST_URL}?t=${Date.now()}`);
      if (!res.ok) {
        throw new Error(
          `Failed to load ${WORKLIST_MANIFEST_URL} (HTTP ${res.status})`
        );
      }
      const data = await res.json();
      const rows = Array.isArray(data.rows) ? data.rows : data;
      cachedWorklist = rows.filter((r) => r?.c && r?.col && r.idcCategory);
      return cachedWorklist;
    } catch (err) {
      console.warn(
        "[@slicer-hub/worklist] segroulette-worklist.json unavailable; deriving from enriched catalog",
        err
      );
      loadWorklistPromise = null;
      throw err;
    }
  })();
  try {
    return await loadWorklistPromise;
  } catch (err) {
    loadWorklistPromise = null;
    throw err;
  }
}
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}
function spinSegrouletteEntry(catalog2) {
  const region2 = pickRandom(catalog2.regions);
  const byCol = catalog2.byRegion.get(region2);
  const collections2 = [...byCol.keys()];
  const collection2 = pickRandom(collections2);
  const entry2 = pickRandom(byCol.get(collection2));
  return { region: region2, collection: collection2, entry: entry2 };
}
function reelSpinLabels(catalog2, kind, count = 24) {
  const set = /* @__PURE__ */ new Set();
  if (kind === "region") {
    for (const r of catalog2.regions) set.add(r);
  } else if (kind === "collection") {
    for (const byCol of catalog2.byRegion.values()) {
      for (const col of byCol.keys()) set.add(humanizeCollection(col));
    }
  } else {
    for (const e of catalog2.entries) {
      set.add(seriesReelLabel(e));
      if (set.size >= 80) break;
    }
  }
  const all = [...set];
  for (let i = all.length - 1; i > 0; i--) {
    const j2 = Math.floor(Math.random() * (i + 1));
    [all[i], all[j2]] = [all[j2], all[i]];
  }
  const out = [];
  while (out.length < count) {
    out.push(...all);
  }
  return out.slice(0, count);
}

// samples.ts
var FORMAT_DICOM = "DICOM";
var FORMAT_NIFTI = "NifTI";
var FORMAT_NRRD = "Nrrd";
var FORMAT_SLICERLIVE = "SlicerLive";
var FORMAT_LIVESCENE = "LiveScene";
var LIVESCENE_MIME = "application/vnd.slicerlive.scene+json";
function idcBucketPrefixUrl(bucket, crdc) {
  const b = String(bucket || "idc-open-data").trim() || "idc-open-data";
  return `https://${b}.s3.amazonaws.com/${crdc}/`;
}
function attachImagingStudyDescription(context, description) {
  const desc = String(description || "").trim();
  if (!desc || !Array.isArray(context)) return context;
  return context.map((item) => {
    if (!item || typeof item !== "object") return item;
    const row = item;
    if (String(row.key || "") !== "study" || !row.resource) return item;
    return {
      ...row,
      resource: { ...row.resource, description: desc }
    };
  });
}
function attachImagingStudyModality(context, modality) {
  let mod = String(modality || "").trim().toUpperCase();
  if (mod === "MRI") mod = "MR";
  if (mod === "PET") mod = "PT";
  if (!mod || !Array.isArray(context)) return context;
  if (mod !== "CT" && mod !== "MR" && mod !== "PT" && mod !== "NM" && mod !== "CR" && mod !== "DX") {
    return context;
  }
  return context.map((item) => {
    if (!item || typeof item !== "object") return item;
    const row = item;
    if (String(row.key || "") !== "study" || !row.resource) return item;
    if (row.resource.modality != null) return item;
    return {
      ...row,
      resource: {
        ...row.resource,
        modality: [
          {
            coding: [
              {
                system: "http://dicom.nema.org/resources/ontology/DCM",
                code: mod
              }
            ]
          }
        ]
      }
    };
  });
}
function attachLiveSceneToContext(context, scene) {
  if (!scene || typeof scene !== "object" || !Array.isArray(context)) {
    return context;
  }
  const nodes = scene.nodes;
  const blobBase = String(scene.blobBase || "").trim();
  if (!nodes || typeof nodes !== "object" || !blobBase) return context;
  const resource = { ...scene, blobBase, nodes };
  const withoutScene = context.filter((item) => {
    if (!item || typeof item !== "object") return true;
    return item.key !== "scene";
  });
  withoutScene.push({ key: "scene", resource });
  return withoutScene;
}
function liveSceneDocFromSample(sample) {
  const scene = sample.scene;
  if (scene && typeof scene === "object") {
    const nodes = scene.nodes;
    const blobBase = String(scene.blobBase || "").trim();
    if (nodes && typeof nodes === "object" && blobBase) {
      const url = String(scene.url || sample.sourceUrl || sample.url || "").trim() || void 0;
      return { ...scene, blobBase, nodes, ...url ? { url } : {} };
    }
  }
  return null;
}
function buildIdcDirectImagingStudyOpenContext(entry2, sampleId) {
  const bucket = entry2.cb || "idc-open-data";
  const segBucket = entry2.sb || bucket;
  const files = [
    {
      url: idcBucketPrefixUrl(bucket, entry2.c),
      fileName: `${entry2.c}/`,
      label: String(entry2.m || "CT").toUpperCase(),
      role: "volume"
    }
  ];
  if (entry2.s) {
    files.push({
      url: idcBucketPrefixUrl(segBucket, entry2.s),
      fileName: `${entry2.s}/`,
      label: "SEG",
      role: "seg"
    });
  }
  return attachImagingStudyModality(
    attachImagingStudyDescription(
      Ls({
        id: sampleId,
        studyInstanceUID: entry2.st || `urn:segroulette:${entry2.c}`,
        seriesInstanceUID: entry2.c,
        sourceBucket: "aws",
        patientReference: PATIENT_REFERENCE,
        files
      }),
      entry2.sd
    ),
    entry2.m
  );
}
function segrouletteSampleId(entry2) {
  const c = String(entry2.c || "").trim();
  const s2 = String(entry2.s || "").trim();
  return s2 ? `segroulette-${c}-${s2}` : `segroulette-${c}`;
}
function worklistSampleFromSegrouletteEntry(entry2, bodyRegion, organization = WORKLIST_ORG_IDC_SEG, idcCategory) {
  const id = segrouletteSampleId(entry2);
  const col = humanizeCollection(entry2.col);
  const sd = String(entry2.sd || "SEG").trim();
  const region2 = String(bodyRegion || "").trim();
  const patient = String(entry2.pid || "").trim();
  const seriesTag = patient || String(entry2.c || "").slice(0, 8);
  const name = region2 ? `${region2} \xB7 ${col} \xB7 ${seriesTag}` : `${col} \xB7 ${seriesTag}`;
  const size = entry2.sizeMB != null && Number.isFinite(Number(entry2.sizeMB)) ? `${Math.ceil(Number(entry2.sizeMB))} MB` : void 0;
  const modalities = Array.isArray(entry2.modalities) && entry2.modalities.length ? entry2.modalities.map((x2) => String(x2).toUpperCase()) : [String(entry2.m || "?").toUpperCase()];
  const category = String(idcCategory || "").trim() || region2 || void 0;
  return {
    id,
    name,
    description: sd,
    size,
    format: FORMAT_DICOM,
    organization,
    idcCategory: category,
    modalities,
    studyInstanceUID: entry2.st,
    seriesInstanceUID: entry2.c,
    openMode: ye,
    ctCrdc: entry2.c,
    segCrdc: entry2.s,
    bucket: entry2.cb || "idc-open-data",
    segBucket: entry2.sb || entry2.cb || "idc-open-data",
    segroulette: { ...entry2 },
    files: [
      {
        url: idcBucketPrefixUrl(entry2.cb || "idc-open-data", entry2.c),
        fileName: `${entry2.c}/`
      },
      ...entry2.s ? [
        {
          url: idcBucketPrefixUrl(
            entry2.sb || entry2.cb || "idc-open-data",
            entry2.s
          ),
          fileName: `${entry2.s}/`
        }
      ] : []
    ]
  };
}
function isIdcSegmentationSample(sample) {
  return sample?.organization === WORKLIST_ORG_IDC_SEG;
}
function worklistSampleModalitiesLabel(sample) {
  const fromSample = Array.isArray(sample.modalities) ? sample.modalities.map((x2) => String(x2).trim()).filter(Boolean) : [];
  if (fromSample.length) return fromSample.join(", ");
  const fromEntry = sample.segroulette?.modalities;
  if (Array.isArray(fromEntry) && fromEntry.length) {
    return fromEntry.map((x2) => String(x2).trim()).filter(Boolean).join(", ");
  }
  const m = String(sample.segroulette?.m || "").trim();
  return m || "\u2014";
}
function isMyWorklistSample(sample) {
  return sample?.organization === WORKLIST_ORG_MINE;
}
function sampleSizeSortKey(sample) {
  const n = Number(sample.segroulette?.sizeMB);
  if (!Number.isFinite(n)) return [1, 0];
  return [0, n];
}
function isKitsCollection(col) {
  return String(col || "").trim() === IDC_KITS_CATEGORY.collectionId;
}
async function loadIdcSegmentationStudiesFromEnriched() {
  const catalog2 = await loadIdcEnrichedCatalog();
  const bodyRegions = idcBodyRegionsForCategories(IDC_CATEGORIES);
  const picked = entriesForBodyRegions(catalog2, bodyRegions);
  const samples = picked.map(({ entry: entry2, region: region2 }) => {
    let baseId;
    let namePrefix;
    if (isKitsCollection(entry2.col)) {
      baseId = IDC_KITS_CATEGORY.id;
      namePrefix = IDC_KITS_CATEGORY.namePrefix;
    } else if (region2 === "CHEST") {
      const sub = idcChestSubcategoryForCollection(entry2.col);
      baseId = sub.id;
      namePrefix = sub.namePrefix;
    } else {
      baseId = region2;
      namePrefix = region2;
    }
    const split = idcApplyModalitySplit(baseId, namePrefix, String(entry2.m || ""));
    return worklistSampleFromSegrouletteEntry(
      entry2,
      split.namePrefix,
      WORKLIST_ORG_IDC_SEG,
      split.id
    );
  });
  samples.sort((a, b) => {
    const [af, av] = sampleSizeSortKey(a);
    const [bf, bv] = sampleSizeSortKey(b);
    return af - bf || av - bv;
  });
  return samples;
}
async function loadIdcSegmentationStudies() {
  try {
    const rows = await loadWorklistCatalogRows();
    const allowed = new Set(IDC_CATEGORIES);
    const samples = [];
    for (const entry2 of rows) {
      const category = String(entry2.idcCategory || "").trim().toUpperCase();
      if (!category || !allowed.has(category)) continue;
      const namePrefix = String(entry2.namePrefix || "").trim() || (category.startsWith("CHEST:") ? idcChestSubcategoryForCollection(entry2.col).namePrefix : category === IDC_KITS_CATEGORY.id ? IDC_KITS_CATEGORY.namePrefix : category);
      samples.push(
        worklistSampleFromSegrouletteEntry(
          entry2,
          namePrefix,
          WORKLIST_ORG_IDC_SEG,
          category
        )
      );
    }
    return samples;
  } catch {
    return loadIdcSegmentationStudiesFromEnriched();
  }
}
function isDicomwebWorklistSample(sample) {
  return String(sample?.openMode || "").trim() === W && Boolean(sample?.studyInstanceUID?.trim());
}
function worklistSampleFiles(sample) {
  if (Array.isArray(sample.files) && sample.files.length > 0) {
    return sample.files;
  }
  return [{ url: sample.url || "", fileName: sample.filename }];
}
function normalizeFormatLabel(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) return "";
  const lower = trimmed.toLowerCase();
  if (lower === "dicom") return FORMAT_DICOM;
  if (lower === "nifti") return FORMAT_NIFTI;
  if (lower === "nrrd") return FORMAT_NRRD;
  if (lower === "slicerlive" || lower === "slicer live") return FORMAT_SLICERLIVE;
  if (lower === "livescene" || lower === "live scene") return FORMAT_LIVESCENE;
  return trimmed;
}
function formatFromFileName(fileName) {
  const lower = String(fileName || "").trim().toLowerCase();
  if (!lower) return "";
  if (lower.endsWith(".nii") || lower.endsWith(".nii.gz")) return FORMAT_NIFTI;
  if (lower.endsWith(".nrrd") || lower.endsWith(".nhdr") || lower.endsWith(".raw.gz")) {
    return FORMAT_NRRD;
  }
  if (lower.endsWith(".dcm") || lower.endsWith(".dicom") || lower.endsWith(".ima") || lower.endsWith(".zip")) {
    return FORMAT_DICOM;
  }
  if (lower.endsWith(".json")) return FORMAT_LIVESCENE;
  return "";
}
function worklistSampleFormatLabel(sample) {
  const explicit = normalizeFormatLabel(sample?.format);
  if (explicit) return explicit;
  if (sample?.openMode === ge || sample?.openMode === ye || sample?.studyInstanceUID) {
    return FORMAT_DICOM;
  }
  const names = [];
  if (Array.isArray(sample?.files)) {
    for (const file of sample.files) {
      if (file?.fileName) names.push(file.fileName);
    }
  }
  if (sample?.filename) names.push(sample.filename);
  const formats = [
    ...new Set(names.map(formatFromFileName).filter(Boolean))
  ];
  if (formats.length === 1) return formats[0];
  if (formats.length > 1) {
    if (formats.includes(FORMAT_NIFTI)) return FORMAT_NIFTI;
    return formats[0];
  }
  return "\u2014";
}
function isWorklistSampleActionDisabled(sample) {
  if (worklistSampleFormatLabel(sample) === FORMAT_NRRD) return true;
  return Boolean(sample?.openDisabled);
}
function worklistSampleActionDisabledReason(sample) {
  if (worklistSampleFormatLabel(sample) === FORMAT_NRRD) {
    return "Nrrd format is not supported yet";
  }
  if (sample?.openDisabled) {
    return String(sample.openDisabledReason || "").trim() || "This study cannot be opened yet";
  }
  return "";
}
function withoutIdcSegmentationSamples(studies) {
  return studies.filter((s2) => !isIdcSegmentationSample(s2));
}
function upsertIdcSegmentationSample(studies, sample) {
  const idx = studies.findIndex((s2) => s2.id === sample.id);
  if (idx >= 0) {
    const next = studies.slice();
    next[idx] = sample;
    return next;
  }
  return [...studies, sample];
}
function replaceIdcSegmentationStudies(studies, idcSamples) {
  return [...withoutIdcSegmentationSamples(studies), ...idcSamples];
}
function isIdcWsiSample(sample) {
  return sample?.organization === WORKLIST_ORG_IDC_WSI;
}
function withoutIdcWsiSamples(studies) {
  return studies.filter((s2) => !isIdcWsiSample(s2));
}
function replaceIdcWsiStudies(studies, wsiSamples) {
  return [...withoutIdcWsiSamples(studies), ...wsiSamples];
}
function isSlicerSceneSample(sample) {
  return sample?.organization === WORKLIST_ORG_SLICER_SCENES;
}
function isSlicerDicomSample(sample) {
  return sample?.organization === WORKLIST_ORG_3D_SLICER;
}
function withoutSlicerDicomSamples(studies) {
  return studies.filter((s2) => !isSlicerDicomSample(s2));
}
function replaceSlicerDicomStudies(studies, slicerSamples) {
  return [...withoutSlicerDicomSamples(studies), ...slicerSamples];
}
function worklistSamplesFromSlicerWorklistStudies(rows) {
  if (!Array.isArray(rows)) return [];
  const out = [];
  for (const entry2 of rows) {
    const studyInstanceUID = String(entry2?.studyInstanceUID || "").trim();
    const openMode = String(entry2?.openMode || "").trim();
    const id = String(entry2?.id || "").trim() || (studyInstanceUID ? `slicer-dicom:${studyInstanceUID}` : "");
    if (!id) continue;
    if (openMode !== "live-scene" && !studyInstanceUID) continue;
    const modalities = Array.isArray(entry2?.modalities) ? entry2.modalities.map((m) => String(m || "").trim()).filter(Boolean) : void 0;
    out.push({
      id,
      name: String(entry2?.name || id).trim() || id,
      description: String(entry2?.description || "").trim() || void 0,
      size: String(entry2?.size || "").trim() || void 0,
      format: String(entry2?.format || (openMode === "live-scene" ? "LiveScene" : "DICOM")).trim() || "DICOM",
      organization: WORKLIST_ORG_3D_SLICER,
      modalities,
      patientName: String(entry2?.patientName || "").trim() || void 0,
      patientID: String(entry2?.patientID || "").trim() || void 0,
      studyDate: String(entry2?.studyDate || "").trim() || void 0,
      studyInstanceUID: studyInstanceUID || void 0,
      seriesInstanceUID: String(entry2?.seriesInstanceUID || "").trim() || void 0,
      openMode: openMode || "local-dicom"
    });
  }
  return out;
}
function withoutSlicerSceneSamples(studies) {
  return studies.filter((s2) => !isSlicerSceneSample(s2));
}
function replaceSlicerSceneStudies(studies, sceneSamples) {
  return [...withoutSlicerSceneSamples(studies), ...sceneSamples];
}
function isCbctDentalSample(sample) {
  return sample?.organization === WORKLIST_ORG_CBCT_DENTAL;
}
function withoutCbctDentalSamples(studies) {
  return studies.filter((s2) => !isCbctDentalSample(s2));
}
function replaceCbctDentalStudies(studies, dentalSamples) {
  return [...withoutCbctDentalSamples(studies), ...dentalSamples];
}
async function loadCbctDentalStudies() {
  const res = await fetch("./cbct-dental-manifest.json");
  if (!res.ok) {
    throw new Error(`Failed to load CBCT Dental manifest (${res.status})`);
  }
  const data = await res.json();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    if (!id) continue;
    const files = Array.isArray(entry2.files) ? entry2.files.map((f2) => {
      const url = String(f2?.url || "").trim();
      const fileName = String(f2?.fileName || "").trim() || void 0;
      const role = String(f2?.role || "").trim() || void 0;
      const label = String(f2?.label || "").trim() || void 0;
      const mimeType = String(f2?.mimeType || "").trim() || void 0;
      return { url, fileName, role, label, mimeType };
    }).filter((f2) => f2.url) : [];
    const fallbackUrl = String(entry2.url || "").trim();
    if (!files.length && fallbackUrl) {
      files.push({
        url: fallbackUrl,
        fileName: String(entry2.filename || "").trim() || fallbackUrl.split("/").pop() || "volume.nii.gz"
      });
    }
    if (!files.length) continue;
    const modalities = Array.isArray(entry2.modalities) ? entry2.modalities.map((m) => String(m).toUpperCase()).filter(Boolean) : ["CT"];
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "CBCT Dental sample",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || FORMAT_NIFTI).trim() || FORMAT_NIFTI,
      organization: WORKLIST_ORG_CBCT_DENTAL,
      modalities,
      openMode: String(entry2.openMode || O).trim() || O,
      files,
      url: files[0]?.url,
      filename: files[0]?.fileName
    });
  }
  return out;
}
function isTxrvSample(sample) {
  return sample?.organization === WORKLIST_ORG_TXRV;
}
function withoutTxrvSamples(studies) {
  return studies.filter((s2) => !isTxrvSample(s2));
}
function replaceTxrvStudies(studies, txrvSamples) {
  return [...withoutTxrvSamples(studies), ...txrvSamples];
}
async function loadTxrvStudies() {
  const res = await fetch("./torchxrayvision-manifest.json");
  if (!res.ok) {
    throw new Error(
      `Failed to load TorchXRayVision manifest (${res.status})`
    );
  }
  const data = await res.json();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    const studyInstanceUID = String(entry2?.studyInstanceUID || "").trim();
    const seriesInstanceUID = String(entry2?.seriesInstanceUID || "").trim();
    const ctCrdc = String(entry2?.ctCrdc || "").trim() || seriesInstanceUID;
    if (!id || !ctCrdc) continue;
    const modalities = Array.isArray(entry2.modalities) ? entry2.modalities.map((m) => String(m).toUpperCase()).filter(Boolean) : ["DX"];
    const bucket = String(entry2.bucket || "").trim() || "idc-open-data";
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "TorchXRayVision CXR sample",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || FORMAT_DICOM).trim() || FORMAT_DICOM,
      organization: WORKLIST_ORG_TXRV,
      modalities,
      studyInstanceUID: studyInstanceUID || void 0,
      seriesInstanceUID: seriesInstanceUID || void 0,
      openMode: String(entry2.openMode || ye).trim() || ye,
      ctCrdc,
      bucket,
      files: [
        {
          url: idcBucketPrefixUrl(bucket, ctCrdc),
          fileName: `${ctCrdc}/`,
          role: "volume"
        }
      ]
    });
  }
  return out;
}
function isFlexraySample(sample) {
  return sample?.organization === WORKLIST_ORG_FLEXRAY;
}
function withoutFlexraySamples(studies) {
  return studies.filter((s2) => !isFlexraySample(s2));
}
function replaceFlexrayStudies(studies, flexraySamples) {
  return [...withoutFlexraySamples(studies), ...flexraySamples];
}
async function loadFlexrayStudies() {
  const res = await fetch("./flexray-manifest.json");
  if (!res.ok) {
    throw new Error(`Failed to load FleXray manifest (${res.status})`);
  }
  const data = await res.json();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    const studyInstanceUID = String(entry2?.studyInstanceUID || "").trim();
    const seriesInstanceUID = String(entry2?.seriesInstanceUID || "").trim();
    const ctCrdc = String(entry2?.ctCrdc || "").trim() || seriesInstanceUID;
    if (!id || !ctCrdc) continue;
    const modalities = Array.isArray(entry2.modalities) ? entry2.modalities.map((m) => String(m).toUpperCase()).filter(Boolean) : ["DX"];
    const bucket = String(entry2.bucket || "").trim() || "idc-open-data";
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "FleXray CR/DX sample",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || FORMAT_DICOM).trim() || FORMAT_DICOM,
      organization: WORKLIST_ORG_FLEXRAY,
      modalities,
      studyInstanceUID: studyInstanceUID || void 0,
      seriesInstanceUID: seriesInstanceUID || void 0,
      openMode: String(entry2.openMode || ye).trim() || ye,
      ctCrdc,
      bucket,
      files: [
        {
          url: idcBucketPrefixUrl(bucket, ctCrdc),
          fileName: `${ctCrdc}/`,
          role: "volume"
        }
      ]
    });
  }
  return out;
}
function isVox2SegLamSample(sample) {
  return sample?.organization === WORKLIST_ORG_VOX2SEGLAM;
}
function withoutVox2SegLamSamples(studies) {
  return studies.filter((s2) => !isVox2SegLamSample(s2));
}
function replaceVox2SegLamStudies(studies, vox2Samples) {
  return [...withoutVox2SegLamSamples(studies), ...vox2Samples];
}
async function loadVox2SegLamStudies() {
  const res = await fetch("./vox2seglam-manifest.json");
  if (!res.ok) {
    throw new Error(`Failed to load Vox2SegLAM manifest (${res.status})`);
  }
  const data = await res.json();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    const studyInstanceUID = String(entry2?.studyInstanceUID || "").trim();
    const seriesInstanceUID = String(entry2?.seriesInstanceUID || "").trim();
    const ctCrdc = String(entry2?.ctCrdc || "").trim() || seriesInstanceUID;
    if (!id || !ctCrdc) continue;
    const modalities = Array.isArray(entry2.modalities) ? entry2.modalities.map((m) => String(m).toUpperCase()).filter(Boolean) : ["MR"];
    const bucket = String(entry2.bucket || "").trim() || "idc-open-data";
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "Vox2SegLAM T1 MRI sample",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || FORMAT_DICOM).trim() || FORMAT_DICOM,
      organization: WORKLIST_ORG_VOX2SEGLAM,
      modalities,
      studyInstanceUID: studyInstanceUID || void 0,
      seriesInstanceUID: seriesInstanceUID || void 0,
      openMode: String(entry2.openMode || ye).trim() || ye,
      ctCrdc,
      bucket,
      files: [
        {
          url: idcBucketPrefixUrl(bucket, ctCrdc),
          fileName: `${ctCrdc}/`,
          role: "volume"
        }
      ]
    });
  }
  return out;
}
async function loadIdcWsiStudies() {
  const res = await fetch("./idc-wsi-manifest.json");
  if (!res.ok) {
    throw new Error(`Failed to load IDC WSI manifest (${res.status})`);
  }
  const data = await res.json();
  const root = String(data.dicomwebRoot || "").trim();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    const studyInstanceUID = String(entry2?.studyInstanceUID || "").trim();
    if (!id || !studyInstanceUID) continue;
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "IDC whole slide microscopy",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || "DICOM").trim() || "DICOM",
      organization: WORKLIST_ORG_IDC_WSI,
      modalities: ["SM"],
      studyInstanceUID,
      seriesInstanceUID: String(entry2.seriesInstanceUID || "").trim() || void 0,
      openMode: String(entry2.openMode || W).trim() || W,
      dicomwebRoot: String(entry2.dicomwebRoot || root).trim() || root || void 0
    });
  }
  return out;
}
function embeddedSceneFromManifestStudy(entry2) {
  const nodes = entry2.nodes;
  const blobBase = String(entry2.blobBase || "").trim();
  if (!nodes || typeof nodes !== "object" || !blobBase) return null;
  const scene = { blobBase, nodes };
  const sourceUrl = String(entry2.sourceUrl || "").trim();
  if (sourceUrl) scene.url = sourceUrl;
  if (typeof entry2.mrson === "string" && entry2.mrson.trim()) {
    scene.mrson = entry2.mrson.trim();
  }
  return scene;
}
async function loadSlicerSceneStudies() {
  const res = await fetch("./slicer-scenes-manifest.json");
  if (!res.ok) {
    throw new Error(`Failed to load Slicer scenes manifest (${res.status})`);
  }
  const data = await res.json();
  const rows = Array.isArray(data.studies) ? data.studies : [];
  const out = [];
  for (const entry2 of rows) {
    const id = String(entry2?.id || "").trim();
    const scene = embeddedSceneFromManifestStudy(entry2);
    const sourceUrl = String(entry2.sourceUrl || "").trim();
    const files = Array.isArray(entry2.files) ? entry2.files.map((f2) => {
      const url = String(f2?.url || "").trim();
      const fileName = String(f2?.fileName || "").trim() || void 0;
      const role = String(f2?.role || "").trim() || "scene";
      const label = String(f2?.label || "").trim() || void 0;
      const mimeType = String(f2?.mimeType || "").trim() || LIVESCENE_MIME;
      return { url, fileName, role, label, mimeType };
    }).filter((f2) => f2.url) : [];
    if (!files.length && sourceUrl) {
      let fileName = "scene.json";
      try {
        const base = new URL(sourceUrl).pathname.split("/").pop();
        if (base) fileName = base;
      } catch {
      }
      files.push({
        url: sourceUrl,
        fileName,
        role: "scene",
        label: "LiveScene",
        mimeType: LIVESCENE_MIME
      });
    }
    if (!id || !scene && !files.length) continue;
    const modalities = Array.isArray(entry2.modalities) ? entry2.modalities.map((m) => String(m).toUpperCase()).filter(Boolean) : ["CT"];
    out.push({
      id,
      name: String(entry2.name || id).trim() || id,
      description: String(entry2.description || "").trim() || "LiveScene sample",
      size: String(entry2.size || "").trim() || void 0,
      format: String(entry2.format || FORMAT_LIVESCENE).trim() || FORMAT_LIVESCENE,
      organization: WORKLIST_ORG_SLICER_SCENES,
      modalities,
      openMode: String(entry2.openMode || O).trim() || O,
      files: files.length ? files : void 0,
      scene: scene || void 0,
      sourceUrl: sourceUrl || void 0
    });
  }
  return out;
}
var upsertSegrouletteSample = upsertIdcSegmentationSample;
function myWorklistStudies(studies) {
  return studies.filter(isMyWorklistSample);
}
var MY_WORKLIST_STORAGE_KEY = "pw46.worklist.mine.v1";
var SAVE_DEBOUNCE_MS = 400;
var saveTimer = null;
function loadMyWorklistFromStorage() {
  try {
    const raw = localStorage.getItem(MY_WORKLIST_STORAGE_KEY);
    if (!raw) return [];
    return parseMyWorklistFile(JSON.parse(raw));
  } catch {
    return [];
  }
}
function saveMyWorklistToStorage(studies) {
  try {
    const payload = {
      version: 1,
      studies: myWorklistStudies(studies),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    localStorage.setItem(MY_WORKLIST_STORAGE_KEY, JSON.stringify(payload));
  } catch {
  }
}
function scheduleSaveMyWorklist(studies) {
  const snapshot = studies.slice();
  if (saveTimer != null) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveMyWorklistToStorage(snapshot);
  }, SAVE_DEBOUNCE_MS);
}
function parseMyWorklistFile(data) {
  let rows = [];
  if (Array.isArray(data)) {
    rows = data;
  } else if (data && typeof data === "object" && Array.isArray(data.studies)) {
    rows = data.studies;
  }
  const out = [];
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    const sample = row;
    if (!sample.id) continue;
    out.push({ ...sample, organization: WORKLIST_ORG_MINE });
  }
  return out;
}
function mergeMyWorklistStudies(studies, incoming) {
  let next = studies;
  for (const sample of incoming) {
    next = upsertIdcSegmentationSample(next, {
      ...sample,
      organization: WORKLIST_ORG_MINE
    });
  }
  scheduleSaveMyWorklist(next);
  return next;
}
function myWorklistCopyId(sampleId) {
  const id = String(sampleId || "").trim();
  if (!id) return id;
  return id.startsWith("mine:") ? id : `mine:${id}`;
}
function isSampleInMyWorklist(studies, sample) {
  if (sample.organization === WORKLIST_ORG_MINE) return true;
  const mineId = myWorklistCopyId(sample.id);
  return studies.some(
    (s2) => s2.organization === WORKLIST_ORG_MINE && (s2.id === mineId || s2.id === sample.id)
  );
}
function addSampleToMyWorklist(studies, sample) {
  if (isSampleInMyWorklist(studies, sample)) return studies;
  const mineId = sample.organization === WORKLIST_ORG_MINE ? sample.id : myWorklistCopyId(sample.id);
  const next = upsertIdcSegmentationSample(studies, {
    ...sample,
    id: mineId,
    organization: WORKLIST_ORG_MINE
  });
  scheduleSaveMyWorklist(next);
  return next;
}
function filterWorklistStudies(studies, organization) {
  if (!organization) return studies;
  if (organization === WORKLIST_ORG_MINE) {
    return myWorklistStudies(studies);
  }
  const idcCategory = idcCategoryFromFilterValue(organization);
  if (idcCategory) {
    return studies.filter(
      (s2) => s2.organization === WORKLIST_ORG_IDC_SEG && s2.idcCategory === idcCategory
    );
  }
  return studies.filter((s2) => s2.organization === organization);
}
function findWorklistSample(sampleId, studies) {
  return studies.find((s2) => s2.id === sampleId);
}

// hub.ts
var onStatusChange = null;
var onWorklistChange = null;
var openStartHintDismissed = false;
function dismissOpenStartHint() {
  openStartHintDismissed = true;
}
function shouldShowOpenStartHint(state) {
  return !openStartHintDismissed && !state.lastImagingStudyOpenContext.length;
}
function createInitialState() {
  const hubs = getHubDefinitions();
  const pageInCloud = Qt();
  const hubKey = Is(
    hubs,
    ["local", "cloud", "cloudOidc"],
    pageInCloud
  ) || (pageInCloud ? "cloud" : "local");
  const params = new URLSearchParams(window.location.search);
  const hubOverride = params.get("hub");
  let resolvedKey = hubKey;
  if (hubOverride === "local" || hubOverride === "cloud" || hubOverride === "cloudOidc") {
    resolvedKey = hubOverride;
  }
  const urlUserName = String(params.get("userName") || "").trim();
  const urlTopic = String(params.get("topic") || "").trim();
  return {
    client: null,
    hubKey: resolvedKey,
    topic: urlTopic,
    subscriberName: Pe(PRODUCT_NAME),
    userName: urlUserName || getStoredUserName(),
    hubStartedAt: "",
    lastAuthCode: "",
    lastImagingStudyOpenContext: [],
    openWorklistSampleId: null,
    allStudies: [],
    connection: "idle",
    connectionDetail: "Not connected",
    conference: null,
    conferenceFollowHost: false,
    conferenceFollowChoice: null,
    connectedApps: /* @__PURE__ */ new Map(),
    inferenceStatus: /* @__PURE__ */ new Map(),
    slicerWorklistFetched: false,
    slicerStudyInfo: null
  };
}
function setStatusListener(fn2) {
  onStatusChange = fn2;
}
function setWorklistListener(fn2) {
  onWorklistChange = fn2;
}
function notifyStatus(state) {
  onStatusChange?.(state);
}
function notifyWorklist(state) {
  onWorklistChange?.(state);
}
function setConnection(state, connection, detail) {
  const wasConnected = state.connection === "connected";
  state.connection = connection;
  state.connectionDetail = detail;
  if (wasConnected && connection !== "connected") {
    clearConnectedApps(state);
    clearInferenceStatus(state);
    setConferenceView(state, null);
  }
  notifyStatus(state);
  if (connection === "connected") {
    void syncConferenceView(state);
    void probeTopicStatus(state);
  }
}
function setConferenceView(state, view) {
  state.conference = view;
  if (!view) {
    state.conferenceFollowHost = false;
    state.conferenceFollowChoice = null;
  } else if (view.selfRole === "leading") {
    state.conferenceFollowHost = false;
    state.conferenceFollowChoice = null;
  } else if (view.selfRole === "following") {
    if (state.conferenceFollowChoice === null) {
      state.conferenceFollowChoice = true;
      state.conferenceFollowHost = true;
    } else {
      state.conferenceFollowHost = state.conferenceFollowChoice;
    }
  }
  notifyStatus(state);
}
function setConferenceFollowHost(state, followHost) {
  state.conferenceFollowChoice = Boolean(followHost);
  if (state.conference?.selfRole === "leading") {
    state.conferenceFollowHost = false;
    notifyStatus(state);
    return;
  }
  state.conferenceFollowHost = state.conferenceFollowChoice;
  notifyStatus(state);
}
var conferenceHubHandler = null;
function setConferenceHubHandler(fn2) {
  conferenceHubHandler = fn2;
}
function connectedActorsFromState(state) {
  const actors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const info of state.connectedApps.values()) {
    const actor = String(info.actor || "").trim();
    if (!actor || seen.has(actor)) continue;
    seen.add(actor);
    actors.push(actor);
  }
  return actors;
}
async function syncConferenceView(state) {
  if (state.connection !== "connected") {
    setConferenceView(state, null);
    return;
  }
  const token = state.client?.getConnectionState?.()?.token?.trim() || "";
  if (!token) {
    return;
  }
  try {
    const view = await ws(
      hubEndpoint(state),
      state.topic,
      state.subscriberName,
      state.userName,
      token
    );
    setConferenceView(state, view);
  } catch {
  }
}
function handleConferenceHubEvent(state, message) {
  if (conferenceHubHandler?.(message)) {
    return true;
  }
  const event = message?.event;
  const hubEvent = te(event);
  if (hubEvent === "conference-start") {
    void syncConferenceView(state);
    return true;
  }
  if (hubEvent === "conference-end") {
    const context = event?.context && typeof event.context === "object" ? event.context : {};
    const leaveTopic = String(context.leaveTopic ?? "").trim();
    if (!leaveTopic || leaveTopic === state.topic) {
      setConferenceView(state, null);
    } else {
      void syncConferenceView(state);
    }
    return true;
  }
  return false;
}
var CONNECTED_PRODUCT_BUTTONS = [
  {
    id: "openIraBtn",
    match: (p) => As(p, "ira")
  },
  {
    id: "openOhifBtn",
    match: (p) => As(p, "ohif")
  },
  {
    id: "openSlicerBtn",
    match: (p) => As(p, "slicer")
  },
  {
    id: "openSlicerMirrorBtn",
    match: (p) => As(p, "slicerMirror")
  },
  {
    // UI label is "DICOM SR"
    id: "openReportingBtn",
    match: (p) => As(p, "reporting")
  },
  {
    // UI label is "Classroom" (i18n chrome:anatomicalPlanes)
    id: "openSt444Btn",
    match: (p) => As(p, "classroom")
  }
];
var CONNECTED_APP_REMOVAL_GRACE_MS = 0;
var connectedAppRemovalTimers = /* @__PURE__ */ new Map();
function cancelConnectedAppRemoval(subscriber) {
  const timer = connectedAppRemovalTimers.get(subscriber);
  if (timer !== void 0) {
    globalThis.clearTimeout(timer);
    connectedAppRemovalTimers.delete(subscriber);
  }
}
function clearConnectedAppRemovalTimers() {
  for (const timer of connectedAppRemovalTimers.values()) {
    globalThis.clearTimeout(timer);
  }
  connectedAppRemovalTimers.clear();
}
function clearConnectedApps(state) {
  clearConnectedAppRemovalTimers();
  const hadSlicer = hasConnectedThreeDSlicer(state);
  state.slicerWorklistFetched = false;
  if (state.connectedApps.size === 0) {
    updateConnectedAppButtons(state);
    if (hadSlicer) onThreeDSlicerDisconnected(state);
    return;
  }
  state.connectedApps.clear();
  updateConnectedAppButtons(state);
  if (hadSlicer) onThreeDSlicerDisconnected(state);
}
function markConnectedApp(state, message) {
  const subscriber = no(message);
  if (!subscriber) return;
  const productName = ro(message);
  upsertConnectedApp(state, {
    subscriber,
    productName,
    actor: io(message)
  });
  if (As(productName, "slicer")) {
    enterSlicerWorklistMode(state);
  }
}
function upsertConnectedApp(state, info) {
  const subscriber = String(info.subscriber || "").trim();
  if (!subscriber) return;
  const productName = String(info.productName || "").trim();
  const productKey = productName.toUpperCase();
  const actor = String(info.actor || "").trim();
  let replacedSlicerPeer = false;
  if (productKey) {
    for (const [name, existing] of state.connectedApps) {
      if (name !== subscriber && existing.productName.trim().toUpperCase() === productKey) {
        cancelConnectedAppRemoval(name);
        state.connectedApps.delete(name);
        if (As(existing.productName, "slicer")) {
          replacedSlicerPeer = true;
        }
      }
    }
  }
  cancelConnectedAppRemoval(subscriber);
  const isNewSubscriber = !state.connectedApps.has(subscriber);
  state.connectedApps.set(subscriber, {
    productName,
    actor
  });
  if (As(productName, "slicer") && (isNewSubscriber || replacedSlicerPeer)) {
    state.slicerWorklistFetched = false;
    state.slicerStudyInfo = null;
  }
  updateConnectedAppButtons(state);
}
function isPresenceStatusResponder(actor, productName) {
  const actorKey = actor.trim().toUpperCase();
  if (actorKey === IMAGE_DISPLAY_ACTOR || actorKey === "REPORTING_CLIENT") {
    return true;
  }
  return CONNECTED_PRODUCT_BUTTONS.some((entry2) => entry2.match(productName));
}
function applyConnectedAppsFromStatusResponses(state, responses) {
  for (const item of responses) {
    const subscriber = String(item.subscriber ?? "").trim();
    const productName = String(item.productName ?? "").trim();
    const actor = String(item.actor ?? "").trim();
    const data = item.data;
    const dataProduct = data && typeof data === "object" ? String(data.product ?? "").trim() : "";
    const resolvedProduct = productName || dataProduct;
    if (!subscriber) continue;
    if (!isPresenceStatusResponder(actor, resolvedProduct)) continue;
    upsertConnectedApp(state, {
      subscriber,
      productName: resolvedProduct,
      actor
    });
    if (As(resolvedProduct, "slicer")) {
      enterSlicerWorklistMode(state);
    }
  }
}
function selectThreeDSlicerOrg() {
  const orgSelect = document.getElementById(
    "worklistOrgSelect"
  );
  if (!orgSelect) return;
  const opt = [...orgSelect.options].find(
    (o) => o.value === WORKLIST_ORG_3D_SLICER
  );
  if (opt?.hidden) return;
  orgSelect.value = WORKLIST_ORG_3D_SLICER;
}
function defaultWorklistOrgFilter() {
  return WORKLIST_ORG_FLEXRAY;
}
function selectDefaultWorklistOrg() {
  const orgSelect = document.getElementById(
    "worklistOrgSelect"
  );
  if (!orgSelect) return;
  orgSelect.value = defaultWorklistOrgFilter();
}
function syncThreeDSlicerOrgOption(state) {
  const orgSelect = document.getElementById(
    "worklistOrgSelect"
  );
  if (!orgSelect) return;
  const opt = [...orgSelect.options].find(
    (o) => o.value === WORKLIST_ORG_3D_SLICER
  );
  if (!opt) return;
  const show = hasConnectedThreeDSlicer(state);
  opt.hidden = !show;
  if (!show && orgSelect.value === WORKLIST_ORG_3D_SLICER) {
    selectDefaultWorklistOrg();
  }
}
function isSlicerWorklistMode(state) {
  return hasConnectedThreeDSlicer(state);
}
function enterSlicerWorklistMode(state) {
  selectThreeDSlicerOrg();
  notifyWorklist(state);
  void fetchSlicerWorklist(state);
}
function onThreeDSlicerDisconnected(state) {
  state.slicerWorklistFetched = false;
  state.slicerStudyInfo = null;
  state.allStudies = replaceSlicerDicomStudies(state.allStudies, []);
  selectDefaultWorklistOrg();
  notifyWorklist(state);
}
function studiesFromSlicerWorklistResult(result) {
  const requestResult = result && typeof result === "object" ? result : {};
  const envelope = requestResult.ok !== false ? de(requestResult.data) : de(null);
  for (const item of envelope.responses) {
    const productName = String(item.productName ?? "").trim();
    const data = item.data;
    if (!data || typeof data !== "object") continue;
    const dataObj = data;
    const resolvedProduct = productName || String(dataObj.product ?? "").trim();
    if (!As(resolvedProduct, "slicer") && String(dataObj.source || "").trim().toLowerCase() !== "slicerworklist") {
      continue;
    }
    if (!("studies" in dataObj)) continue;
    return Array.isArray(dataObj.studies) ? dataObj.studies : [];
  }
  return null;
}
function imagingStudyResourceFromStudyInfoResult(result) {
  const requestResult = result && typeof result === "object" ? result : {};
  const envelope = requestResult.ok !== false ? de(requestResult.data) : de(null);
  for (const item of envelope.responses) {
    const data = item.data;
    if (!data || typeof data !== "object") continue;
    const dataObj = data;
    if (dataObj.ok === false) continue;
    const context = dataObj.context;
    if (!Array.isArray(context)) continue;
    for (const entry2 of context) {
      if (!entry2 || typeof entry2 !== "object") continue;
      const row = entry2;
      if (String(row.key || "") !== "study") continue;
      if (row.resource && typeof row.resource === "object") {
        return row.resource;
      }
    }
  }
  return null;
}
async function fetchSlicerWorklist(state) {
  if (state.slicerWorklistFetched) return;
  if (state.connection !== "connected") return;
  if (!hasConnectedThreeDSlicer(state)) return;
  if (!state.client) return;
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) return;
  try {
    const result = await po(state.client, {
      subscriberName: subscriber,
      subscriberProductName: PRODUCT_NAME,
      subscriberActor: WORKLIST_ACTOR,
      topic: state.topic || void 0,
      targetActor: IMAGE_DISPLAY_ACTOR
    });
    if (state.connection !== "connected" || !hasConnectedThreeDSlicer(state)) {
      return;
    }
    const rows = studiesFromSlicerWorklistResult(result);
    if (rows === null) {
      console.warn(`${LOG_PREFIX} slicerworklist: no studies in responses`);
      state.slicerWorklistFetched = true;
      notifyWorklist(state);
      return;
    }
    const samples = worklistSamplesFromSlicerWorklistStudies(rows);
    state.allStudies = replaceSlicerDicomStudies(state.allStudies, samples);
    state.slicerWorklistFetched = true;
    selectThreeDSlicerOrg();
    notifyWorklist(state);
    console.info(
      `${LOG_PREFIX} slicerworklist adopted studies`,
      `count=${samples.length}`
    );
  } catch (err) {
    console.warn(`${LOG_PREFIX} slicerworklist-request failed`, err);
    if (state.connection === "connected" && hasConnectedThreeDSlicer(state)) {
      state.slicerWorklistFetched = true;
      notifyWorklist(state);
    }
  }
}
async function handleSlicerWorklistRowClick(state, sampleId) {
  const sample = findWorklistSample(sampleId, state.allStudies);
  const studyInstanceUID = String(sample?.studyInstanceUID || "").trim();
  if (!sample || !studyInstanceUID) return;
  if (!state.client || state.connection !== "connected") return;
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) return;
  state.slicerStudyInfo = {
    sampleId,
    studyInstanceUID,
    loading: true,
    error: void 0,
    resource: null
  };
  notifyWorklist(state);
  try {
    const result = await So(state.client, {
      subscriberName: subscriber,
      subscriberProductName: PRODUCT_NAME,
      subscriberActor: WORKLIST_ACTOR,
      topic: state.topic || void 0,
      targetActor: IMAGE_DISPLAY_ACTOR,
      studyInstanceUID
    });
    if (state.slicerStudyInfo?.sampleId !== sampleId) return;
    const resource = imagingStudyResourceFromStudyInfoResult(result);
    if (!resource) {
      state.slicerStudyInfo = {
        sampleId,
        studyInstanceUID,
        loading: false,
        error: "No study details returned",
        resource: null
      };
    } else {
      state.slicerStudyInfo = {
        sampleId,
        studyInstanceUID,
        loading: false,
        resource
      };
    }
    notifyWorklist(state);
  } catch (err) {
    if (state.slicerStudyInfo?.sampleId !== sampleId) return;
    state.slicerStudyInfo = {
      sampleId,
      studyInstanceUID,
      loading: false,
      error: err instanceof Error ? err.message : String(err),
      resource: null
    };
    notifyWorklist(state);
  }
}
function hasConnectedThreeDSlicer(state) {
  return [...state.connectedApps.values()].some(
    (info) => As(info.productName, "slicer")
  );
}
function hasConnectedIra(state) {
  return [...state.connectedApps.values()].some(
    (info) => As(info.productName, "ira")
  );
}
function hasConnectedSlicerMirror(state) {
  return [...state.connectedApps.values()].some(
    (info) => As(info.productName, "slicerMirror")
  );
}
function hasConnectedReporting(state) {
  return [...state.connectedApps.values()].some(
    (info) => As(info.productName, "reporting")
  );
}
function openSlicerButtonTitle(hubOn, slicerOn) {
  if (!hubOn) return VIEWER_OPEN_TITLE_DISABLED;
  if (!slicerOn) return VIEWER_OPEN_TITLE_SLICER_INACTIVE;
  return VIEWER_OPEN_TITLE_SLICER;
}
function openSlicerMirrorButtonTitle(hubOn, slicerOn, slicerMirrorOn) {
  if (!hubOn) return VIEWER_OPEN_TITLE_DISABLED;
  if (!slicerOn) return VIEWER_OPEN_TITLE_SLICER_INACTIVE;
  if (slicerMirrorOn) return VIEWER_OPEN_TITLE_SLICER_MIRROR_ACTIVE;
  return VIEWER_OPEN_TITLE_SLICER_MIRROR;
}
function setSlicerDependentViewerButton(id, canOpen, title) {
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.disabled = !canOpen;
  if (canOpen) btn.removeAttribute("disabled");
  else btn.setAttribute("disabled", "");
  btn.title = title;
}
function applyLocalImagingStudyContext(state, context) {
  state.lastImagingStudyOpenContext = eo(context);
  syncOpenSampleId(state);
  notifyWorklist(state);
}
function statusRowProductName(item) {
  const productName = String(item.productName ?? "").trim();
  if (productName) return productName;
  const data = item.data;
  if (data && typeof data === "object") {
    return String(data.product ?? "").trim();
  }
  return "";
}
function statusImagingStudyDonorRank(actor, productName) {
  const actorKey = actor.trim().toUpperCase();
  if (As(productName, "ohif")) return 0;
  if (As(productName, "ira")) return 1;
  if (actorKey === IMAGE_DISPLAY_ACTOR) return 2;
  if (actorKey === "REPORTING_CLIENT") return 3;
  return -1;
}
function adoptImagingStudyFromStatusResponses(state, responses) {
  if (state.lastImagingStudyOpenContext.length) return;
  let best = null;
  for (const item of responses) {
    if (!item || typeof item !== "object") continue;
    const row = item;
    const actor = String(row.actor ?? "").trim();
    const productName = statusRowProductName(row);
    const rank = statusImagingStudyDonorRank(actor, productName);
    if (rank < 0) continue;
    const itemData = row.data;
    if (!itemData || typeof itemData !== "object") continue;
    if (itemData["context.type"] !== "ImagingStudy") continue;
    const context = eo(itemData.context);
    if (!context.length) continue;
    if (!best || rank < best.rank) {
      best = { rank, actor, productName, context };
    }
  }
  if (!best) return;
  applyLocalImagingStudyContext(state, best.context);
  console.info(
    `${LOG_PREFIX} STATUS adopted ImagingStudy from`,
    best.productName || best.actor || "(peer)",
    `items=${best.context.length}`,
    "(local only, not published)"
  );
}
function removeConnectedApp(state, message) {
  const subscriber = no(message);
  if (!subscriber || !state.connectedApps.has(subscriber)) return false;
  cancelConnectedAppRemoval(subscriber);
  const timer = globalThis.setTimeout(() => {
    connectedAppRemovalTimers.delete(subscriber);
    const existing = state.connectedApps.get(subscriber);
    if (!existing) return;
    const removedWasSlicer = As(
      existing.productName,
      "slicer"
    );
    state.connectedApps.delete(subscriber);
    updateConnectedAppButtons(state);
    if (removedWasSlicer && !hasConnectedThreeDSlicer(state)) {
      onThreeDSlicerDisconnected(state);
    }
    if (state.connectedApps.size === 0 && state.lastImagingStudyOpenContext.length > 0) {
      state.lastImagingStudyOpenContext = [];
      state.openWorklistSampleId = null;
      notifyWorklist(state);
    }
  }, CONNECTED_APP_REMOVAL_GRACE_MS);
  connectedAppRemovalTimers.set(subscriber, timer);
  return true;
}
function updateConnectedAppButtons(state) {
  const products = new Set(
    [...state.connectedApps.values()].map((info) => info.productName.trim().toUpperCase()).filter(Boolean)
  );
  for (const { id, match } of CONNECTED_PRODUCT_BUTTONS) {
    const btn = document.getElementById(id);
    if (!btn) continue;
    const connected = [...products].some((p) => match(p));
    btn.classList.toggle("wl-viewer-btn-connected", connected);
  }
  const hubOn = state.connection === "connected";
  const slicerOn = hasConnectedThreeDSlicer(state);
  const slicerMirrorOn = hasConnectedSlicerMirror(state);
  const canOpen = hubOn && slicerOn;
  setSlicerDependentViewerButton(
    "openSlicerBtn",
    canOpen,
    openSlicerButtonTitle(hubOn, slicerOn)
  );
  setSlicerDependentViewerButton(
    "openSlicerMirrorBtn",
    canOpen,
    openSlicerMirrorButtonTitle(hubOn, slicerOn, slicerMirrorOn)
  );
  syncThreeDSlicerOrgOption(state);
  updateInferenceServerButtons(state);
}
function updateInferenceServerButtons(state) {
  for (const server of INFERENCE_SERVERS) {
    const btn = document.getElementById(
      server.worklistButtonId
    );
    if (!btn) continue;
    const status = state.inferenceStatus.get(server.id) || "unknown";
    const online = server.localCapable === true || status === "online";
    btn.classList.toggle("wl-viewer-btn-connected", online && !btn.disabled);
    const label = server.localCapable === true ? "Available" : status === "online" ? "Online" : status === "offline" ? "Offline" : void 0;
    btn.title = Ys(server, label);
  }
}
function clearInferenceStatus(state) {
  state.inferenceStatus.clear();
  updateInferenceServerButtons(state);
}
async function probeTopicStatus(state) {
  if (!state.client || state.connection !== "connected") return;
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) return;
  try {
    const result = await It(state.client, {
      subscriberName: subscriber,
      subscriberProductName: PRODUCT_NAME,
      subscriberActor: WORKLIST_ACTOR,
      topic: state.topic || void 0,
      targetActor: "*"
    });
    if (state.connection !== "connected") return;
    const mapped = Di(result);
    for (const { server, probe } of mapped) {
      state.inferenceStatus.set(server.id, probe.online ? "online" : "offline");
    }
    const requestResult = result && typeof result === "object" ? result : {};
    const envelope = requestResult.ok !== false ? de(requestResult.data) : de(null);
    applyConnectedAppsFromStatusResponses(state, envelope.responses);
    updateInferenceServerButtons(state);
    adoptImagingStudyFromStatusResponses(state, envelope.responses);
    const online = mapped.filter((r) => r.probe.online).map((r) => r.server.title);
    const presence = [...state.connectedApps.values()].map((info) => info.productName || info.actor).filter(Boolean);
    console.info(
      `${LOG_PREFIX} STATUS probe:`,
      online.length ? `AI ${online.join(", ")}` : "no AI online",
      presence.length ? `peers ${presence.join(", ")}` : "no peers"
    );
  } catch (err) {
    console.warn(`${LOG_PREFIX} STATUS probe failed`, err);
  }
}
function handleImagingStudyMessage(state, message) {
  const event = message?.event;
  const name = te(event);
  if (name === "imagingstudy-close") {
    state.lastImagingStudyOpenContext = [];
    state.openWorklistSampleId = null;
    notifyWorklist(state);
    return true;
  }
  if (name !== "imagingstudy-open") return false;
  if (state.conference && !state.conferenceFollowHost && state.conference.selfRole !== "leading") {
    return true;
  }
  const context = eo(to(message));
  state.lastImagingStudyOpenContext = context;
  syncOpenSampleId(state);
  notifyWorklist(state);
  if (state.conference && state.conferenceFollowHost) {
    console.info(
      `${LOG_PREFIX} conference follow: ImagingStudy-open \u2192 ensure IRA (no button)`
    );
    ensureSlicerLiveViewer(state, { reason: "conference-follow" });
  }
  return true;
}
function extractActorKeywords(actor) {
  if (actor == null) return [];
  if (typeof actor === "string") {
    const keyword2 = actor.trim();
    return keyword2 ? [keyword2] : [];
  }
  if (Array.isArray(actor)) {
    return actor.flatMap((entry2) => extractActorKeywords(entry2));
  }
  if (typeof actor === "object") {
    const obj = actor;
    const candidate = obj.id || obj.key || obj.name;
    if (candidate == null) return [];
    const keyword2 = String(candidate).trim();
    return keyword2 ? [keyword2] : [];
  }
  const keyword = String(actor).trim();
  return keyword ? [keyword] : [];
}
function syncOpenSampleId(state) {
  if (!state.lastImagingStudyOpenContext.length) {
    state.openWorklistSampleId = null;
    return;
  }
  state.openWorklistSampleId = G(state.lastImagingStudyOpenContext) || null;
}
function hubDef(state) {
  return getHubDefinitions()[state.hubKey];
}
function hubEndpoint(state) {
  return hubDef(state).hubEndpoint;
}
function spaResolveOpts(state) {
  return { hubOrigin: hubOriginFromEndpoint(hubEndpoint(state)) };
}
function sidePopupPlacement(width, height) {
  const gap = 16;
  const availLeft = Number(window.screen.availLeft) || 0;
  const availTop = Number(window.screen.availTop) || 0;
  const availW = window.screen.availWidth || window.screen.width;
  const availH = window.screen.availHeight || window.screen.height;
  const openerLeft = window.screenX ?? window.screenLeft ?? 0;
  const openerTop = window.screenY ?? window.screenTop ?? 0;
  const openerW = window.outerWidth || 800;
  const openerH = window.outerHeight || 600;
  let left = openerLeft - width - gap;
  let top = openerTop;
  if (left < availLeft) {
    left = openerLeft + openerW + gap;
  }
  if (left + width > availLeft + availW) {
    left = Math.min(
      Math.max(availLeft, openerLeft),
      availLeft + availW - width
    );
    top = openerTop + openerH + gap;
  }
  if (top + height > availTop + availH) {
    top = Math.max(availTop, availTop + availH - height);
  }
  left = Math.max(availLeft, Math.min(left, availLeft + availW - width));
  top = Math.max(availTop, Math.min(top, availTop + availH - height));
  return {
    width,
    height,
    left: Math.floor(left),
    top: Math.floor(top)
  };
}
function iraPopupPlacement() {
  return sidePopupPlacement(1280, 810);
}
function slicerMirrorPopupPlacement() {
  return sidePopupPlacement(Math.round(1280 * 0.7), Math.round(810 * 0.7));
}
function reportingPopupPlacement() {
  if (slicerLiveWindow && !slicerLiveWindow.closed) {
    try {
      const w2 = slicerLiveWindow.outerWidth || 0;
      const h = slicerLiveWindow.outerHeight || 0;
      if (w2 > 0 && h > 0) {
        return us({
          left: slicerLiveWindow.screenX ?? slicerLiveWindow.screenLeft ?? 0,
          top: slicerLiveWindow.screenY ?? slicerLiveWindow.screenTop ?? 0,
          width: w2,
          height: h
        });
      }
    } catch {
    }
  }
  return us();
}
function placePopupWindow(win, place) {
  fs(win, place);
}
var REPORTING_WINDOW_NAME = os;
var CLASSROOM_WINDOW_NAME = cs;
var slicerLiveWindow = null;
var slicerMirrorWindow = null;
var ohifWindow = null;
var reportingWindow = null;
var classroomWindow = null;
function iraWindowName(state) {
  return `hubViewer-ira-${String(state.topic || "anon").replace(/[^\w.-]+/g, "_")}`;
}
function ohifWindowName(state) {
  return `hubViewer-ohif-${String(state.topic || "anon").replace(/[^\w.-]+/g, "_")}`;
}
function hasOpenSlicerLive() {
  return Boolean(slicerLiveWindow && !slicerLiveWindow.closed);
}
function focusExistingSlicerLiveWindow(state) {
  if (slicerLiveWindow && !slicerLiveWindow.closed) {
    try {
      slicerLiveWindow.focus();
    } catch {
    }
    return true;
  }
  slicerLiveWindow = null;
  let existing = null;
  try {
    existing = window.open("", iraWindowName(state));
  } catch {
    return false;
  }
  if (!existing || existing.closed) return false;
  try {
    const href = String(existing.location?.href || "");
    if (!href || href === "about:blank") return false;
  } catch {
  }
  try {
    existing.focus();
  } catch {
  }
  slicerLiveWindow = existing;
  return true;
}
function focusExistingOhifWindow(state) {
  if (ohifWindow && !ohifWindow.closed) {
    try {
      ohifWindow.focus();
    } catch {
    }
    return true;
  }
  ohifWindow = null;
  let existing = null;
  try {
    existing = window.open("", ohifWindowName(state));
  } catch {
    return false;
  }
  if (!existing || existing.closed) return false;
  try {
    const href = String(existing.location?.href || "");
    if (!href || href === "about:blank") return false;
  } catch {
  }
  try {
    existing.focus();
  } catch {
  }
  ohifWindow = existing;
  return true;
}
function popupFeaturesFromPlacement(place) {
  return [
    "popup",
    `width=${place.width}`,
    `height=${place.height}`,
    `left=${place.left}`,
    `top=${place.top}`
  ].join(",");
}
function viewerPopupFeatures(kind) {
  const place = kind === "reporting" ? reportingPopupPlacement() : kind === "ira" ? iraPopupPlacement() : {
    width: 800,
    height: 600,
    left: Math.max(0, Math.floor((window.screen.width - 800) / 2)),
    top: Math.max(0, Math.floor((window.screen.height - 600) / 2))
  };
  const parts = [popupFeaturesFromPlacement(place)];
  if (kind !== "reporting" && kind !== "ira") {
    parts.push("noopener", "noreferrer");
  }
  return parts.join(",");
}
function focusExistingReportingWindow() {
  if (!reportingWindow || reportingWindow.closed) {
    reportingWindow = null;
    return false;
  }
  try {
    reportingWindow.focus();
  } catch {
  }
  return true;
}
function reclaimReportingWindowByName() {
  let existing = null;
  try {
    existing = window.open("", REPORTING_WINDOW_NAME);
  } catch {
    return false;
  }
  if (!existing || existing.closed) return false;
  let blank = false;
  try {
    const href = String(existing.location?.href || "");
    blank = !href || href === "about:blank";
  } catch {
  }
  if (blank) {
    try {
      existing.close();
    } catch {
    }
    return false;
  }
  try {
    existing.focus();
  } catch {
  }
  reportingWindow = existing;
  return true;
}
function openReportingViewer(state) {
  if (focusExistingReportingWindow()) return;
  if (hasConnectedReporting(state)) {
    reclaimReportingWindowByName();
    return;
  }
  const url = new URL(
    resolveViewerUrls(void 0, spaResolveOpts(state)).reporting
  );
  if (state.topic) {
    url.searchParams.set("topic", state.topic);
  }
  const token = state.client?.getConnectionState?.()?.token?.trim();
  if (token) {
    url.searchParams.set("id-token", token);
  }
  applySpaParam(url);
  const place = reportingPopupPlacement();
  const win = window.open(
    url.toString(),
    REPORTING_WINDOW_NAME,
    viewerPopupFeatures("reporting")
  );
  if (!win) return;
  reportingWindow = win;
  placePopupWindow(win, place);
}
function focusExistingClassroomWindow() {
  if (!classroomWindow || classroomWindow.closed) {
    classroomWindow = null;
    return false;
  }
  try {
    classroomWindow.focus();
  } catch {
  }
  return true;
}
function classroomOpenTarget() {
  try {
    if (window.matchMedia("(pointer: coarse)").matches) return "_self";
  } catch {
  }
  return "_blank";
}
function classroomViewerUrl(state) {
  const url = new URL(
    resolveViewerUrls(void 0, spaResolveOpts(state)).classroom
  );
  if (state.topic) {
    url.searchParams.set("topic", state.topic);
  }
  const token = state.client?.getConnectionState?.()?.token?.trim();
  if (token) {
    url.searchParams.set("id-token", token);
  }
  applySpaParam(url);
  return url;
}
function syncClassroomOpenLink(state, enabled) {
  const link = document.getElementById(
    "openSt444Btn"
  );
  if (!link || link.tagName !== "A") return;
  const title = t2("chrome:anatomicalPlanes");
  link.title = enabled ? title : VIEWER_OPEN_TITLE_DISABLED;
  link.setAttribute("aria-disabled", enabled ? "false" : "true");
  if (!enabled) {
    link.href = "#";
    link.removeAttribute("target");
    link.removeAttribute("rel");
    link.tabIndex = -1;
    return;
  }
  link.removeAttribute("tabindex");
  const url = state ? classroomViewerUrl(state) : applySpaParam(new URL(resolveViewerUrls().classroom));
  link.href = url.toString();
  const target = classroomOpenTarget();
  if (target === "_self") {
    link.target = "_self";
    link.removeAttribute("rel");
  } else {
    link.target = CLASSROOM_WINDOW_NAME;
    link.rel = "noreferrer";
  }
}
function tryFocusClassroomWindow(_state) {
  if (classroomOpenTarget() === "_self") return false;
  return focusExistingClassroomWindow();
}
function navigateClassroomUrl(url) {
  const target = classroomOpenTarget();
  if (target === "_self") {
    window.location.assign(url.toString());
    return;
  }
  const a = document.createElement("a");
  a.href = url.toString();
  a.target = CLASSROOM_WINDOW_NAME;
  a.rel = "noreferrer";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
function openClassroomViewer(state) {
  syncClassroomOpenLink(state, true);
  if (tryFocusClassroomWindow(state)) return;
  const url = classroomViewerUrl(state);
  if (classroomOpenTarget() === "_blank") {
    const win = window.open(url.toString(), CLASSROOM_WINDOW_NAME);
    if (win) {
      classroomWindow = win;
      try {
        win.focus();
      } catch {
      }
      return;
    }
  }
  navigateClassroomUrl(url);
}
function handleClassroomOpenClick(state, ev) {
  const link = ev.currentTarget;
  if (!link || link.tagName !== "A") return;
  if (link.getAttribute("aria-disabled") === "true") {
    ev.preventDefault();
    return;
  }
  syncClassroomOpenLink(state, true);
  if (tryFocusClassroomWindow(state)) {
    ev.preventDefault();
    return;
  }
  if (classroomOpenTarget() === "_blank") {
    ev.preventDefault();
    const url = classroomViewerUrl(state);
    const win = window.open(url.toString(), CLASSROOM_WINDOW_NAME);
    if (win) {
      classroomWindow = win;
      try {
        win.focus();
      } catch {
      }
      return;
    }
    navigateClassroomUrl(url);
    return;
  }
}
function openHubViewer(state, kind) {
  if (kind === "reporting") {
    openReportingViewer(state);
    return true;
  }
  if (kind === "classroom") {
    openClassroomViewer(state);
    return true;
  }
  const url = new URL(resolveViewerUrls(void 0, spaResolveOpts(state))[kind]);
  if (state.topic) {
    url.searchParams.set("topic", state.topic);
  }
  const token = state.client?.getConnectionState?.()?.token?.trim();
  if (token) {
    url.searchParams.set("id-token", token);
  }
  applySpaParam(url);
  if (kind === "ira" && state.conference) {
    if (state.conferenceFollowChoice === false) {
      url.searchParams.set("followHost", "0");
    } else if (state.conferenceFollowHost) {
      url.searchParams.set("followHost", "1");
    }
  }
  if (kind === "ira") {
    if (focusExistingSlicerLiveWindow(state)) return true;
    const iraName = iraWindowName(state);
    const win = window.open(url.toString(), iraName);
    if (win) {
      slicerLiveWindow = win;
      try {
        win.focus();
      } catch {
      }
      return true;
    }
    console.warn(
      `${LOG_PREFIX} IRA window.open blocked (popup blocker or no user gesture)`
    );
    yt2(
      "Browser blocked opening SlicerLive \u2014 click SlicerLive or allow popups"
    );
    return false;
  }
  if (kind === "ohif") {
    url.searchParams.set("lng", appLocaleToOhifLng(resolveStoredLocale()));
    if (focusExistingOhifWindow(state)) return true;
    const win = window.open(url.toString(), ohifWindowName(state));
    if (win) {
      ohifWindow = win;
      try {
        win.focus();
      } catch {
      }
      return true;
    }
    console.warn(
      `${LOG_PREFIX} OHIF window.open blocked (popup blocker or no user gesture)`
    );
    yt2(
      "Browser blocked opening OHIF \u2014 click OHIF or allow popups"
    );
    return false;
  }
  window.open(
    url.toString(),
    `hubViewer-${kind}`,
    viewerPopupFeatures(kind)
  );
  return true;
}
function openSlicerMirrorViewer(state) {
  if (state.connection !== "connected" || !state.client) {
    console.warn(`${LOG_PREFIX} slicer-mirror skipped: not connected`);
    return;
  }
  if (!hasConnectedThreeDSlicer(state)) {
    console.warn(`${LOG_PREFIX} slicer-mirror skipped: 3D Slicer not connected`);
    return;
  }
  const url = new URL(resolveSlicerMirrorUrl(void 0, spaResolveOpts(state)));
  if (state.topic) {
    url.searchParams.set("topic", state.topic);
  }
  const token = state.client.getConnectionState?.()?.token?.trim();
  if (token) {
    url.searchParams.set("id-token", token);
  }
  applySpaParam(url);
  const place = slicerMirrorPopupPlacement();
  const win = window.open(
    url.toString(),
    "hubViewer-slicer-mirror",
    popupFeaturesFromPlacement(place)
  );
  if (win) {
    slicerMirrorWindow = win;
    placePopupWindow(win, place);
  }
}
function ensureSlicerLiveViewer(state, opts) {
  const reason = opts?.reason || "open";
  if (!state.client) {
    console.info(`${LOG_PREFIX} ensure IRA skip (${reason}): not connected`);
    return false;
  }
  if (hasConnectedThreeDSlicer(state)) {
    console.info(
      `${LOG_PREFIX} ensure IRA skip (${reason}): 3D Slicer ID connected`
    );
    return true;
  }
  if (hasConnectedIra(state) || hasOpenSlicerLive()) {
    if (focusExistingSlicerLiveWindow(state)) {
      console.info(
        `${LOG_PREFIX} ensure IRA (${reason}): focus existing SlicerLive tab`
      );
      return true;
    }
    console.info(
      `${LOG_PREFIX} ensure IRA (${reason}): reclaim/open SlicerLive tab`
    );
    return openHubViewer(state, "ira");
  }
  console.info(
    `${LOG_PREFIX} ensure IRA launch (${reason}): opening SlicerLive tab`
  );
  return openHubViewer(state, "ira");
}
function isVolumeModality(modality) {
  const tokens = Array.isArray(modality) ? modality : [modality];
  return tokens.some((t3) => {
    let m = String(t3 || "").trim().toUpperCase();
    if (m === "MRI") m = "MR";
    if (m === "PET") m = "PT";
    return m === "CT" || m === "MR" || m === "PT";
  });
}
function sampleModalities(sample) {
  if (Array.isArray(sample.modalities) && sample.modalities.length) {
    return sample.modalities;
  }
  return sample.segroulette?.m;
}
function sampleIsSlicerScene(sample) {
  if (isSlicerSceneSample(sample)) return true;
  if (liveSceneDocFromSample(sample)) return true;
  const format = String(sample.format || "").trim().toLowerCase();
  return format === "livescene" || format === "live scene";
}
function ensureViewerAfterOpen(state, sampleOrModality, opts) {
  const reason = opts?.reason || "open";
  if (sampleOrModality && typeof sampleOrModality === "object") {
    if (sampleIsSlicerScene(sampleOrModality)) {
      console.info(
        `${LOG_PREFIX} ensure SlicerLive (${reason}): Slicer scene \u2192 IRA only`
      );
      return ensureSlicerLiveViewer(state, opts);
    }
    if (isVolumeModality(sampleModalities(sampleOrModality))) {
      if (getDefaultViewer() === "slicerlive") {
        console.info(
          `${LOG_PREFIX} ensure SlicerLive (${reason}): CT/MR/PT + defaultViewer=slicerlive`
        );
        return ensureSlicerLiveViewer(state, opts);
      }
      console.info(
        `${LOG_PREFIX} ensure OHIF (${reason}): CT/MR/PT + defaultViewer=ohif`
      );
      return openHubViewer(state, "ohif");
    }
    console.info(
      `${LOG_PREFIX} ensure OHIF (${reason}): non-volume modality \u2192 OHIF`
    );
    return openHubViewer(state, "ohif");
  }
  if (isVolumeModality(sampleOrModality)) {
    if (getDefaultViewer() === "slicerlive") {
      console.info(
        `${LOG_PREFIX} ensure SlicerLive (${reason}): CT/MR/PT + defaultViewer=slicerlive`
      );
      return ensureSlicerLiveViewer(state, opts);
    }
    console.info(
      `${LOG_PREFIX} ensure OHIF (${reason}): CT/MR/PT + defaultViewer=ohif`
    );
    return openHubViewer(state, "ohif");
  }
  console.info(
    `${LOG_PREFIX} ensure OHIF (${reason}): non-volume modality \u2192 OHIF`
  );
  return openHubViewer(state, "ohif");
}
function setViewerButtonsEnabled(enabled, state) {
  const infoServers = INFERENCE_SERVERS;
  const inferenceTitles = new Map(
    infoServers.map((server) => [
      server.worklistButtonId,
      Ys(server)
    ])
  );
  const inferenceButtonIds = new Set(
    infoServers.map((server) => server.worklistButtonId)
  );
  const buttons = [
    { id: "openReportingBtn", title: VIEWER_OPEN_TITLE_REPORTING },
    { id: "openSt444Btn", title: t2("chrome:anatomicalPlanes") },
    { id: "openSlicerBtn", title: VIEWER_OPEN_TITLE_SLICER },
    { id: "openSlicerMirrorBtn", title: VIEWER_OPEN_TITLE_SLICER_MIRROR },
    { id: "openIraBtn", title: VIEWER_OPEN_TITLE_IRA },
    { id: "openOhifBtn", title: VIEWER_OPEN_TITLE_OHIF },
    { id: "openSlimBtn", title: "Slim" },
    { id: "openSceneviewsBtn", title: VIEWER_OPEN_TITLE_SCENEVIEWS },
    ...infoServers.map((server) => ({
      id: server.worklistButtonId,
      title: inferenceTitles.get(server.worklistButtonId) || server.title
    })),
    { id: "openSegrouletteBtn", title: VIEWER_OPEN_TITLE_SEGROULETTE },
    { id: "endConferenceBtn", title: conferenceStrings().endConference },
    { id: "startConferenceBtn", title: conferenceStrings().conferencing }
  ];
  const unavailable = [
    { id: "openFhirDrBtn", title: "Not available yet" },
    { id: "openHl7OruBtn", title: "Not available yet" },
    { id: "openHl7CdaBtn", title: "Not available yet" },
    { id: "openOsirixBtn", title: "Not available yet" }
  ];
  for (const { id, title } of unavailable) {
    const btn = document.getElementById(id);
    if (!btn) continue;
    btn.disabled = true;
    btn.setAttribute("disabled", "");
    btn.title = title;
  }
  const slicerOn = Boolean(state && hasConnectedThreeDSlicer(state));
  const slicerMirrorOn = Boolean(state && hasConnectedSlicerMirror(state));
  const slicerCanOpen = enabled && slicerOn;
  for (const { id, title } of buttons) {
    if (id === "openSt444Btn") {
      syncClassroomOpenLink(state, enabled);
      continue;
    }
    const btn = document.getElementById(id);
    if (!btn) continue;
    if (inferenceButtonIds.has(id)) {
      btn.disabled = false;
      btn.removeAttribute("disabled");
      btn.title = title;
      continue;
    }
    if (id === "openOhifBtn") {
      btn.classList.remove("wl-viewer-btn-inert");
    }
    if (id === "openSlicerBtn") {
      setSlicerDependentViewerButton(
        id,
        slicerCanOpen,
        openSlicerButtonTitle(enabled, slicerOn)
      );
      continue;
    }
    if (id === "openSlicerMirrorBtn") {
      setSlicerDependentViewerButton(
        id,
        slicerCanOpen,
        openSlicerMirrorButtonTitle(enabled, slicerOn, slicerMirrorOn)
      );
      continue;
    }
    if (id === "endConferenceBtn" || id === "startConferenceBtn") {
      btn.disabled = !enabled || btn.hidden;
      if (enabled && !btn.hidden) {
        btn.removeAttribute("disabled");
        btn.title = title;
      }
      continue;
    }
    btn.disabled = !enabled;
    if (enabled) {
      btn.removeAttribute("disabled");
    }
    btn.title = enabled ? title : VIEWER_OPEN_TITLE_DISABLED;
  }
  if (state) updateConnectedAppButtons(state);
}
async function syncStoredUserNameWithHub(state) {
  const endpoint = hubEndpoint(state);
  const currentOrigin = hubOriginFromEndpoint(endpoint) || "";
  const currentStartedAt = await fetchHubStartedAt(endpoint);
  if (currentStartedAt) state.hubStartedAt = currentStartedAt;
  const storedUser = getStoredUserName();
  if (!storedUser) return;
  const storedStartedAt = getStoredUserHubStartedAt();
  const storedOrigin = getStoredUserHubOrigin();
  const hubRestarted = Boolean(currentStartedAt && storedStartedAt) && storedStartedAt !== currentStartedAt;
  const hubChanged = Boolean(storedOrigin && currentOrigin) && storedOrigin !== currentOrigin;
  const missingHubBinding = Boolean(currentStartedAt) && (!storedStartedAt || !storedOrigin);
  if (hubRestarted || hubChanged || missingHubBinding) {
    console.info(
      `${LOG_PREFIX} discarding stored user name (hub restarted or changed)`
    );
    clearStoredUserName();
    state.userName = "";
    state.client?.setUserName("");
  }
}
function buildWorklistStatusResponseData(state) {
  const clientWindow = {
    left: Math.floor(window.screenX ?? window.screenLeft ?? 0),
    top: Math.floor(window.screenY ?? window.screenTop ?? 0),
    width: Math.floor(window.outerWidth || 800),
    height: Math.floor(window.outerHeight || 600)
  };
  if (state.lastImagingStudyOpenContext.length) {
    return {
      "context.type": "ImagingStudy",
      context: eo(state.lastImagingStudyOpenContext),
      clientWindow
    };
  }
  return {
    ...EMPTY_CAST_CONTEXT,
    clientWindow
  };
}
function handleIncomingStatusRequest(state, message) {
  const event = message?.event;
  if (!event || !Qi(te(event))) return false;
  const context = event.context && typeof event.context === "object" ? event.context : {};
  const correlationId = context.id;
  if (typeof correlationId !== "string" || !correlationId) return false;
  const requestedTargets = extractActorKeywords(message["target.actor"]);
  if (requestedTargets.length > 0 && !requestedTargets.includes("*") && !requestedTargets.includes(WORKLIST_ACTOR)) {
    return false;
  }
  if (String(context.dataType || "").toUpperCase() !== "STATUS") return false;
  markConnectedApp(state, message);
  state.client?.sendHubRequestResponse(
    correlationId,
    "STATUS",
    buildWorklistStatusResponseData(state),
    event["hub.topic"]
  );
  return true;
}
function handleSubscriptionRemoved(state, message) {
  const event = message?.event;
  if (!event || te(event) !== "subscription-removed") {
    return false;
  }
  return removeConnectedApp(state, message);
}
function handleStructureReportUpdate(_state, message) {
  const event = message?.event;
  if (te(event) !== Ji) return false;
  focusExistingReportingWindow();
  return true;
}
function ensureClient(state, recreate = false) {
  if (!state.client || recreate) {
    state.client?.close();
    if (recreate) clearConnectedApps(state);
    const hub = hubDef(state);
    state.client = new fe(
      {
        name: "demo",
        version: "1.0",
        hub_endpoint: hub.hubEndpoint,
        authorization_endpoint: hub.authorizeEndpoint,
        token_endpoint: hub.tokenEndpoint,
        client_id: hub.client_id,
        client_secret: hub.client_secret
      },
      {
        subscriberName: state.subscriberName,
        productName: PRODUCT_NAME,
        productVersion: "1.0",
        actors: [WORKLIST_ACTOR],
        topic: state.topic,
        events: SUBSCRIBE_EVENTS,
        lease: 7200,
        defaultTargetActor: "*",
        userName: String(state.userName || "").trim() || getStoredUserName() || void 0
      },
      {
        callbackUrl: `${window.location.origin}/castCallback`,
        autoReconnect: true
      }
    );
    state.client.onMessage((message) => {
      if (handleSubscriptionRemoved(state, message)) return;
      if (handleStructureReportUpdate(state, message)) return;
      if (handleConferenceHubEvent(state, message)) return;
      if (handleImagingStudyMessage(state, message)) return;
      handleIncomingStatusRequest(state, message);
    });
    state.client.onConnectionStateChange((wsState) => {
      if (wsState === "connecting") {
        setConnection(state, "connecting", "Websocket connecting");
      } else if (wsState === "connected") {
        setConnection(state, "connected", "Websocket connected");
      } else if (wsState === "error") {
        setConnection(state, "error", "Websocket error");
      } else {
        setConnection(state, "disconnected", "Websocket disconnected");
      }
    });
  }
  state.client.setTopic(state.topic);
  const bootUserName = String(state.userName || "").trim() || getStoredUserName();
  state.client.setUserName(bootUserName || "");
  return state.client;
}
var idcSegLoadPromise = null;
var idcSegCatalogLoaded = false;
async function ensureIdcSegmentationsLoaded(state, onStatus) {
  if (idcSegCatalogLoaded) return;
  if (idcSegLoadPromise) return idcSegLoadPromise;
  idcSegLoadPromise = (async () => {
    onStatus?.("Loading IDC segmentations\u2026");
    try {
      const samples = await loadIdcSegmentationStudies();
      state.allStudies = replaceIdcSegmentationStudies(state.allStudies, samples);
      idcSegCatalogLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `IDC segmentations \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded IDC segmentations`,
        samples.length,
        WORKLIST_ORG_IDC_SEG
      );
    } catch (err) {
      idcSegLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load IDC segmentations"
      );
      throw err;
    }
  })();
  return idcSegLoadPromise;
}
var idcWsiLoadPromise = null;
var idcWsiLoaded = false;
async function ensureIdcWsiLoaded(state, onStatus) {
  if (idcWsiLoaded) return;
  if (idcWsiLoadPromise) return idcWsiLoadPromise;
  idcWsiLoadPromise = (async () => {
    onStatus?.("Loading IDC Whole Slide Imaging\u2026");
    try {
      const samples = await loadIdcWsiStudies();
      state.allStudies = replaceIdcWsiStudies(state.allStudies, samples);
      idcWsiLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `IDC Whole Slide Imaging \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded IDC WSI`,
        samples.length,
        WORKLIST_ORG_IDC_WSI
      );
    } catch (err) {
      idcWsiLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load IDC Whole Slide Imaging"
      );
      throw err;
    }
  })();
  return idcWsiLoadPromise;
}
var slicerScenesLoadPromise = null;
var slicerScenesLoaded = false;
async function ensureSlicerScenesLoaded(state, onStatus) {
  if (slicerScenesLoaded) return;
  if (slicerScenesLoadPromise) return slicerScenesLoadPromise;
  slicerScenesLoadPromise = (async () => {
    onStatus?.("Loading Slicer scenes\u2026");
    try {
      const samples = await loadSlicerSceneStudies();
      state.allStudies = replaceSlicerSceneStudies(state.allStudies, samples);
      slicerScenesLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `Slicer scenes \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded Slicer scenes`,
        samples.length,
        WORKLIST_ORG_SLICER_SCENES
      );
    } catch (err) {
      slicerScenesLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load Slicer scenes"
      );
      throw err;
    }
  })();
  return slicerScenesLoadPromise;
}
var cbctDentalLoadPromise = null;
var cbctDentalLoaded = false;
async function ensureCbctDentalLoaded(state, onStatus) {
  if (cbctDentalLoaded) return;
  if (cbctDentalLoadPromise) return cbctDentalLoadPromise;
  cbctDentalLoadPromise = (async () => {
    onStatus?.("Loading CBCT Dental\u2026");
    try {
      const samples = await loadCbctDentalStudies();
      state.allStudies = replaceCbctDentalStudies(state.allStudies, samples);
      cbctDentalLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `CBCT Dental \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded CBCT Dental`,
        samples.length,
        WORKLIST_ORG_CBCT_DENTAL
      );
    } catch (err) {
      cbctDentalLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load CBCT Dental"
      );
      throw err;
    }
  })();
  return cbctDentalLoadPromise;
}
var txrvLoadPromise = null;
var txrvLoaded = false;
async function ensureTxrvLoaded(state, onStatus) {
  if (txrvLoaded) return;
  if (txrvLoadPromise) return txrvLoadPromise;
  txrvLoadPromise = (async () => {
    onStatus?.("Loading TorchXRayVision\u2026");
    try {
      const samples = await loadTxrvStudies();
      state.allStudies = replaceTxrvStudies(state.allStudies, samples);
      txrvLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `TorchXRayVision \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded TorchXRayVision`,
        samples.length,
        WORKLIST_ORG_TXRV
      );
    } catch (err) {
      txrvLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load TorchXRayVision"
      );
      throw err;
    }
  })();
  return txrvLoadPromise;
}
var flexrayLoadPromise = null;
var flexrayLoaded = false;
async function ensureFlexrayLoaded(state, onStatus) {
  if (flexrayLoaded) return;
  if (flexrayLoadPromise) return flexrayLoadPromise;
  flexrayLoadPromise = (async () => {
    onStatus?.("Loading FleXray\u2026");
    try {
      const samples = await loadFlexrayStudies();
      state.allStudies = replaceFlexrayStudies(state.allStudies, samples);
      flexrayLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `FleXray \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded FleXray`,
        samples.length,
        WORKLIST_ORG_FLEXRAY
      );
    } catch (err) {
      flexrayLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load FleXray"
      );
      throw err;
    }
  })();
  return flexrayLoadPromise;
}
var vox2SegLamLoadPromise = null;
var vox2SegLamLoaded = false;
async function ensureVox2SegLamLoaded(state, onStatus) {
  if (vox2SegLamLoaded) return;
  if (vox2SegLamLoadPromise) return vox2SegLamLoadPromise;
  vox2SegLamLoadPromise = (async () => {
    onStatus?.("Loading Vox2SegLAM\u2026");
    try {
      const samples = await loadVox2SegLamStudies();
      state.allStudies = replaceVox2SegLamStudies(state.allStudies, samples);
      vox2SegLamLoaded = true;
      notifyWorklist(state);
      onStatus?.(
        `Vox2SegLAM \xB7 ${samples.length.toLocaleString()} studies`
      );
      console.info(
        `${LOG_PREFIX} loaded Vox2SegLAM`,
        samples.length,
        WORKLIST_ORG_VOX2SEGLAM
      );
    } catch (err) {
      vox2SegLamLoadPromise = null;
      onStatus?.(
        err instanceof Error ? err.message : "Failed to load Vox2SegLAM"
      );
      throw err;
    }
  })();
  return vox2SegLamLoadPromise;
}
function buildPublishPayload(state, hubEvent, context) {
  return {
    event: {
      "hub.topic": state.topic,
      "hub.event": hubEvent,
      context
    },
    actor: WORKLIST_ACTOR,
    // Fan out to all topic subscribers (Image Displays and Reporting client).
    "target.actor": "*",
    "target.product.name": "*"
  };
}
async function publishImagingStudyOpen(state, context) {
  if (!state.client) {
    console.warn(`${LOG_PREFIX} open study: subscribe first`);
    return false;
  }
  const payload = buildPublishPayload(state, $i, context);
  try {
    const res = await state.client.publish(payload);
    if (res && res.ok) {
      state.lastImagingStudyOpenContext = eo(context);
      syncOpenSampleId(state);
      notifyWorklist(state);
      return true;
    }
    console.warn(
      `${LOG_PREFIX} open study failed`,
      res ? `HTTP ${res.status}` : "No response"
    );
    return false;
  } catch (err) {
    console.error(`${LOG_PREFIX} open study exception`, err);
    return false;
  }
}
async function requestStatusFromHostWorklist(state, hostTopic) {
  const topic = String(hostTopic || "").trim();
  if (!topic) {
    console.warn(`${LOG_PREFIX} host STATUS skip: no host topic`);
    return;
  }
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} host STATUS skip: not connected`);
    return;
  }
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) {
    console.warn(`${LOG_PREFIX} host STATUS skip: no subscriber name`);
    return;
  }
  try {
    console.info(`${LOG_PREFIX} STATUS request \u2192 * topic=`, topic);
    const result = await state.client.request({
      "subscriber.name": subscriber,
      "subscriber.product.name": PRODUCT_NAME,
      "subscriber.actor": WORKLIST_ACTOR,
      "target.actor": "*",
      event: {
        "hub.event": k("STATUS"),
        "hub.topic": topic,
        context: { dataType: "STATUS" }
      }
    });
    if (!result.ok) {
      console.warn(
        `${LOG_PREFIX} host STATUS failed`,
        `HTTP ${result.status ?? "?"}`
      );
      return;
    }
    const envelope = result.data && typeof result.data === "object" ? result.data : {};
    const responses = Array.isArray(envelope.responses) ? envelope.responses : [];
    let chosen;
    for (const item of responses) {
      const itemData = item?.data;
      if (!itemData || typeof itemData !== "object" || itemData["context.type"] !== "ImagingStudy") {
        continue;
      }
      const actor = String(item?.actor ?? "").trim().toUpperCase();
      if (actor === WORKLIST_ACTOR || chosen === void 0) {
        chosen = itemData;
        if (actor === WORKLIST_ACTOR) break;
      }
    }
    if (!chosen) {
      console.info(
        `${LOG_PREFIX} host STATUS: no ImagingStudy in ${responses.length} response(s)`
      );
      return;
    }
    const context = eo(chosen.context);
    if (!context.length) {
      console.info(`${LOG_PREFIX} host STATUS: ImagingStudy context empty`);
      return;
    }
    if (Rs(context, state.lastImagingStudyOpenContext) || state.openWorklistSampleId && G(context) === state.openWorklistSampleId) {
      console.info(
        `${LOG_PREFIX} host STATUS: same study already open \u2014 skip republish`
      );
      ensureSlicerLiveViewer(state, { reason: "reopen-focus" });
      yt2(vs);
      return;
    }
    const ok = await publishImagingStudyOpen(state, context);
    console.info(
      `${LOG_PREFIX} host STATUS applied ImagingStudy items=`,
      context.length,
      ok ? "published" : "publish failed"
    );
  } catch (err) {
    console.error(`${LOG_PREFIX} host STATUS exception`, err);
  }
}
async function publishImagingStudyClose(state) {
  if (!state.client) {
    console.warn(`${LOG_PREFIX} close study: subscribe first`);
    return false;
  }
  if (!state.lastImagingStudyOpenContext.length) {
    console.warn(`${LOG_PREFIX} close study: no open context`);
    return false;
  }
  const context = eo(state.lastImagingStudyOpenContext);
  const payload = buildPublishPayload(state, xi, context);
  try {
    const res = await state.client.publish(payload);
    if (res && res.ok) {
      state.lastImagingStudyOpenContext = [];
      state.openWorklistSampleId = null;
      notifyWorklist(state);
      return true;
    }
    console.warn(
      `${LOG_PREFIX} close study failed`,
      res ? `HTTP ${res.status}` : "No response"
    );
    return false;
  } catch (err) {
    console.error(`${LOG_PREFIX} close study exception`, err);
    return false;
  }
}
async function requestLiveSceneFromSlicer(state) {
  if (!state.client || state.connection !== "connected") {
    console.warn(`${LOG_PREFIX} LiveScene request skipped: not connected`);
    return;
  }
  const subscriber = state.subscriberName || state.client.getSessionConfig()?.subscriberName?.trim() || "";
  if (!subscriber) {
    console.warn(`${LOG_PREFIX} LiveScene request skipped: no subscriber`);
    return;
  }
  try {
    console.info(`${LOG_PREFIX} requesting LiveScene publish from 3D Slicer\u2026`);
    const result = await go(state.client, {
      subscriberName: subscriber,
      subscriberProductName: PRODUCT_NAME,
      subscriberActor: WORKLIST_ACTOR,
      topic: state.topic || void 0,
      targetActor: IMAGE_DISPLAY_ACTOR
    });
    const requestResult = result && typeof result === "object" ? result : {};
    const envelope = requestResult.ok !== false ? de(requestResult.data) : de(null);
    const first = envelope.responses[0]?.data;
    if (first && first.ok === false) {
      console.warn(`${LOG_PREFIX} LiveScene request failed`, first.error);
      return;
    }
    console.info(`${LOG_PREFIX} LiveScene request acknowledged`, first || envelope);
    ensureSlicerLiveViewer(state);
  } catch (err) {
    console.warn(`${LOG_PREFIX} LiveScene request error`, err);
  }
}
async function handleWorklistSampleOpen(state, sampleId) {
  dismissOpenStartHint();
  if (state.lastImagingStudyOpenContext.length && state.openWorklistSampleId === sampleId) {
    const openSample = findWorklistSample(sampleId, state.allStudies);
    ensureViewerAfterOpen(state, openSample, { reason: "reopen-focus" });
    return;
  }
  if (state.lastImagingStudyOpenContext.length) {
    const closed = await publishImagingStudyClose(state);
    if (!closed) return;
  }
  const sample = findWorklistSample(sampleId, state.allStudies);
  if (!sample) {
    console.warn(`${LOG_PREFIX} unknown sample`, sampleId);
    return;
  }
  if (isWorklistSampleActionDisabled(sample)) return;
  const openMode = String(sample.openMode || "").trim();
  if (openMode === "live-scene" || sample.id === "slicer-live-scene") {
    await requestLiveSceneFromSlicer(state);
    return;
  }
  const files = worklistSampleFiles(sample);
  let context;
  if (openMode === pe) {
    context = Us({
      id: sample.id,
      studyInstanceUID: sample.studyInstanceUID || "",
      seriesInstanceUID: sample.seriesInstanceUID,
      patientReference: PATIENT_REFERENCE
    });
  } else if (openMode === W || isDicomwebWorklistSample(sample)) {
    context = Ts({
      id: sample.id,
      studyInstanceUID: sample.studyInstanceUID,
      seriesInstanceUID: sample.seriesInstanceUID,
      dicomwebRoot: sample.dicomwebRoot,
      patientReference: PATIENT_REFERENCE,
      files: sample.files
    });
  } else if (openMode === ye || Boolean(String(sample.ctCrdc || "").trim())) {
    context = buildIdcDirectImagingStudyOpenContext(
      {
        c: sample.ctCrdc || sample.seriesInstanceUID || "",
        s: sample.segCrdc,
        m: String(sample.modalities?.[0] || "CT"),
        col: sample.organization,
        cb: sample.bucket,
        sb: sample.segBucket,
        st: sample.studyInstanceUID,
        sd: sample.description
      },
      sample.id
    );
  } else if (openMode === ge) {
    context = Ns({
      id: sample.id,
      files,
      patientReference: PATIENT_REFERENCE
    });
  } else {
    context = ln({
      id: sample.id,
      files,
      patientReference: PATIENT_REFERENCE
    });
  }
  context = attachImagingStudyDescription(
    context,
    sample.name || sample.description
  );
  context = attachImagingStudyModality(
    context,
    sample.modalities?.[0] || sample.segroulette?.m
  );
  const liveScene = liveSceneDocFromSample(sample);
  if (liveScene) {
    context = attachLiveSceneToContext(context, liveScene);
  }
  state.lastImagingStudyOpenContext = eo(context);
  syncOpenSampleId(state);
  notifyWorklist(state);
  await publishImagingStudyOpen(state, context);
  ensureViewerAfterOpen(state, sample);
}
async function handleWorklistClose(state) {
  await publishImagingStudyClose(state);
}
async function publishSegrouletteOpen(state, entry2) {
  dismissOpenStartHint();
  const sampleId = segrouletteSampleId(entry2);
  if (state.lastImagingStudyOpenContext.length && state.openWorklistSampleId === sampleId) {
    return;
  }
  if (state.lastImagingStudyOpenContext.length) {
    const closed = await publishImagingStudyClose(state);
    if (!closed) return;
  }
  const context = buildIdcDirectImagingStudyOpenContext(entry2, sampleId);
  const onList = findWorklistSample(sampleId, state.allStudies);
  const displayName = String(
    onList?.name || worklistSampleFromSegrouletteEntry(entry2).name || entry2.sd || ""
  ).trim();
  const labeled = attachImagingStudyDescription(context, displayName);
  state.lastImagingStudyOpenContext = eo(labeled);
  state.openWorklistSampleId = onList ? sampleId : null;
  notifyWorklist(state);
  const ok = await publishImagingStudyOpen(state, labeled);
  ensureViewerAfterOpen(state, entry2.m);
  if (ok) {
    console.info(
      `${LOG_PREFIX} SegRoulette ImagingStudy-open`,
      sampleId,
      entry2.col,
      entry2.c
    );
  }
}
async function publishIdcRestSeriesOpen(state, opts) {
  dismissOpenStartHint();
  const crdc = String(opts.crdcSeriesUuid || "").trim();
  if (!crdc) {
    throw new Error("Missing CRDC series UUID for IDC open");
  }
  const sampleId = `idc-rest-${crdc}`;
  if (state.lastImagingStudyOpenContext.length && state.openWorklistSampleId === sampleId) {
    return;
  }
  if (state.lastImagingStudyOpenContext.length) {
    const closed = await publishImagingStudyClose(state);
    if (!closed) return;
  }
  const entry2 = {
    c: crdc,
    m: String(opts.modality || "CT").toUpperCase(),
    col: String(opts.collectionId || "idc"),
    cb: String(opts.bucket || "idc-open-data").trim() || "idc-open-data",
    st: String(opts.studyInstanceUID || "").trim() || void 0,
    sd: String(opts.seriesDescription || "").trim() || void 0
  };
  const context = buildIdcDirectImagingStudyOpenContext(entry2, sampleId);
  const onList = findWorklistSample(sampleId, state.allStudies);
  const displayName = String(
    onList?.name || opts.seriesDescription || entry2.sd || ""
  ).trim();
  const labeled = attachImagingStudyDescription(context, displayName);
  state.lastImagingStudyOpenContext = eo(labeled);
  state.openWorklistSampleId = onList ? sampleId : null;
  notifyWorklist(state);
  const ok = await publishImagingStudyOpen(state, labeled);
  ensureViewerAfterOpen(state, entry2.m);
  if (ok) {
    console.info(`${LOG_PREFIX} IDC REST ImagingStudy-open`, sampleId, crdc);
  }
}
async function addSegrouletteToWorklist(state, entry2) {
  const catalog2 = await loadSegrouletteCatalog();
  let region2 = "";
  for (const [reg, byCol] of catalog2.byRegion) {
    if (byCol.has(entry2.col) && byCol.get(entry2.col)?.some((e) => e.c === entry2.c)) {
      region2 = reg;
      break;
    }
  }
  const sample = worklistSampleFromSegrouletteEntry(
    entry2,
    region2,
    WORKLIST_ORG_MINE
  );
  state.allStudies = upsertSegrouletteSample(state.allStudies, sample);
  notifyWorklist(state);
  console.info(`${LOG_PREFIX} SegRoulette added to worklist`, sample.id);
}
function addWorklistSampleToMine(state, sampleId) {
  const sample = findWorklistSample(sampleId, state.allStudies);
  if (!sample) return;
  if (isSampleInMyWorklist(state.allStudies, sample)) return;
  state.allStudies = addSampleToMyWorklist(state.allStudies, sample);
  const orgSelect = document.getElementById(
    "worklistOrgSelect"
  );
  if (orgSelect) {
    orgSelect.value = WORKLIST_ORG_MINE;
    dismissOpenStartHint();
  }
  notifyWorklist(state);
  console.info(`${LOG_PREFIX} added to My Worklist`, sample.id);
}
function handleWorklistRowAction(state, sampleId, action) {
  if (action === "close") {
    handleWorklistClose(state).catch((err) => {
      console.error(`${LOG_PREFIX} close study failed`, err);
    });
    return;
  }
  if (action === "add-to-mine") {
    addWorklistSampleToMine(state, sampleId);
    return;
  }
  handleWorklistSampleOpen(state, sampleId).catch((err) => {
    console.error(`${LOG_PREFIX} open study failed`, err);
  });
}
async function rebindSessionUserName(state, userName) {
  const next = String(userName || "").trim();
  if (!next) throw new Error("User name is required");
  const client = state.client;
  if (!client) {
    state.userName = next;
    setStoredUserName(next);
    notifyStatus(state);
    return;
  }
  setConnection(state, "connecting", "Switching user");
  try {
    const result = await client.rebindUserName(next);
    const session = client.getSessionConfig();
    state.userName = String(result.user_name || next).trim() || next;
    state.topic = String(result.topic || session.topic || next).trim() || next;
    if (session.subscriberName) state.subscriberName = session.subscriberName;
    const startedAt = state.hubStartedAt || await fetchHubStartedAt(hubEndpoint(state));
    if (startedAt) state.hubStartedAt = startedAt;
    setStoredUserName(
      state.userName,
      startedAt,
      hubOriginFromEndpoint(hubEndpoint(state))
    );
    if (result.status === 202) {
      setConnection(state, "connected", "Websocket connected");
    } else {
      setConnection(
        state,
        "disconnected",
        `Subscribe failed (${String(result.status)})`
      );
    }
  } catch (err) {
    setConnection(
      state,
      "error",
      err instanceof Error ? err.message : String(err)
    );
    throw err;
  }
}
async function autoConnect(state) {
  await Es();
  await syncStoredUserNameWithHub(state);
  setConnection(state, "connecting", "Authenticating");
  try {
    const client = ensureClient(state, true);
    const preferredName = String(state.userName || "").trim() || getStoredUserName();
    if (preferredName) client.setUserName(preferredName);
    else client.setUserName("");
    if (state.topic) client.setTopic(state.topic);
    console.info(`${LOG_PREFIX} auto-connect: authenticate`);
    const result = await client.authenticate();
    const userName = result?.user_name || preferredName || "";
    const code = result?.code || "";
    const tokensReady = Boolean(result?.tokensReady);
    const redirecting = Boolean(result?.redirecting);
    if (redirecting) {
      setConnection(state, "connecting", "Redirecting to login");
      return;
    }
    if (userName) {
      const startedAt = state.hubStartedAt || await fetchHubStartedAt(hubEndpoint(state));
      if (startedAt) state.hubStartedAt = startedAt;
      setStoredUserName(
        userName,
        startedAt,
        hubOriginFromEndpoint(hubEndpoint(state))
      );
      state.userName = userName;
    }
    state.lastAuthCode = code;
    if (!tokensReady && !code) {
      setConnection(state, "disconnected", "Authenticate failed");
      return;
    }
    console.info(`${LOG_PREFIX} auto-connect: authorize`);
    setConnection(state, "connecting", "Getting token");
    const authCode = state.lastAuthCode;
    state.lastAuthCode = "";
    const ok = await client.getToken(authCode || "");
    if (!ok) {
      setConnection(state, "disconnected", "Token failed");
      return;
    }
    const session = client.getSessionConfig();
    if (session.subscriberName) state.subscriberName = session.subscriberName;
    if (session.topic) state.topic = session.topic;
    if (session.userName && !String(state.userName || "").trim()) {
      state.userName = String(session.userName).trim();
    }
    notifyStatus(state);
    console.info(`${LOG_PREFIX} auto-connect: subscribe`);
    const status = await client.subscribe();
    if (status === 202) {
      setConnection(state, "connected", "Websocket connected");
      console.info(`${LOG_PREFIX} auto-connect done`);
    } else {
      setConnection(
        state,
        "disconnected",
        `Subscribe failed (${String(status)})`
      );
    }
  } catch (err) {
    console.error(`${LOG_PREFIX} auto-connect failed`, err);
    setConnection(
      state,
      "error",
      err instanceof Error ? err.message : String(err)
    );
  }
}

// segroulette-dialog.ts
var ITEM_H = 40;
var catalog = null;
var spinning = false;
var region = "";
var collection = "";
var entry = null;
var wired = false;
function el3(id) {
  return document.getElementById(id);
}
function fillReelStrip(strip, labels, finalLabel) {
  strip.replaceChildren();
  for (const text of [...labels, finalLabel]) {
    const item = document.createElement("div");
    item.className = "wl-slot-item";
    item.textContent = text;
    strip.append(item);
  }
}
function showSingleOnReel(strip, label) {
  strip.replaceChildren();
  const item = document.createElement("div");
  item.className = "wl-slot-item";
  item.textContent = label;
  strip.append(item);
  strip.style.transition = "none";
  strip.style.transform = "translateY(0)";
}
function animateReel(strip, durationMs, delayMs) {
  return new Promise((resolve) => {
    const count = strip.children.length;
    const targetY = -((count - 1) * ITEM_H);
    strip.style.transition = "none";
    strip.style.transform = "translateY(0)";
    void strip.offsetWidth;
    window.setTimeout(() => {
      strip.style.transition = `transform ${durationMs}ms cubic-bezier(0.12, 0.75, 0.12, 1)`;
      strip.style.transform = `translateY(${targetY}px)`;
      window.setTimeout(resolve, durationMs + 40);
    }, delayMs);
  });
}
async function ensureCatalog(statusEl) {
  if (catalog) return catalog;
  statusEl.textContent = "Loading catalog\u2026";
  catalog = await loadSegrouletteCatalog();
  return catalog;
}
function collectionsInRegion(cat, reg) {
  const byCol = cat.byRegion.get(reg);
  return byCol ? [...byCol.keys()].sort((a, b) => a.localeCompare(b)) : [];
}
function entriesInCollection(cat, reg, col) {
  return cat.byRegion.get(reg)?.get(col) || [];
}
function updateStatus() {
  const statusEl = el3("segrouletteStatus");
  if (!entry) {
    statusEl.textContent = "\u2014";
    return;
  }
  statusEl.textContent = `${region} \xB7 ${humanizeCollection(collection)} \xB7 ${seriesReelLabel(entry)}`;
}
function setActionButtonsEnabled(on2) {
  el3("segrouletteOpenBtn").disabled = !on2;
  el3("segrouletteAddBtn").disabled = !on2;
  const spinBtn = document.getElementById(
    "segrouletteSpinBtn"
  );
  if (spinBtn) spinBtn.disabled = !on2;
}
function syncReelsFromSelection() {
  if (!entry) return;
  showSingleOnReel(el3("segrouletteReelRegion"), region);
  showSingleOnReel(
    el3("segrouletteReelCollection"),
    humanizeCollection(collection)
  );
  showSingleOnReel(el3("segrouletteReelSeries"), seriesReelLabel(entry));
  updateStatus();
}
function applySelection(nextRegion, nextCollection, nextEntry) {
  region = nextRegion;
  collection = nextCollection;
  entry = nextEntry;
  syncReelsFromSelection();
}
function nudgeRegion(cat, delta) {
  const list = cat.regions;
  if (!list.length) return;
  let i = list.indexOf(region);
  if (i < 0) i = 0;
  i = (i + delta + list.length) % list.length;
  const reg = list[i];
  const cols = collectionsInRegion(cat, reg);
  const col = cols[0];
  const entries = entriesInCollection(cat, reg, col);
  if (!entries.length) return;
  applySelection(reg, col, entries[0]);
}
function nudgeCollection(cat, delta) {
  const cols = collectionsInRegion(cat, region);
  if (!cols.length) return;
  let i = cols.indexOf(collection);
  if (i < 0) i = 0;
  i = (i + delta + cols.length) % cols.length;
  const col = cols[i];
  const entries = entriesInCollection(cat, region, col);
  if (!entries.length) return;
  applySelection(region, col, entries[0]);
}
function nudgeSeries(cat, delta) {
  const entries = entriesInCollection(cat, region, collection);
  if (!entries.length || !entry) return;
  let i = entries.findIndex((e) => e.c === entry.c);
  if (i < 0) i = 0;
  i = (i + delta + entries.length) % entries.length;
  applySelection(region, collection, entries[i]);
}
function bindReelInteraction(windowId, nudge) {
  const win = el3(windowId);
  win.tabIndex = 0;
  win.classList.add("wl-slot-interactive");
  win.title = "Scroll or click to change";
  win.addEventListener(
    "wheel",
    (ev) => {
      if (spinning || !catalog) return;
      ev.preventDefault();
      nudge(ev.deltaY > 0 ? 1 : -1);
    },
    { passive: false }
  );
  win.addEventListener("click", (ev) => {
    if (spinning || !catalog) return;
    const rect = win.getBoundingClientRect();
    const mid = rect.top + rect.height / 2;
    nudge(ev.clientY >= mid ? 1 : -1);
  });
}
async function runIntroSpin(cat) {
  const statusEl = el3("segrouletteStatus");
  spinning = true;
  setActionButtonsEnabled(false);
  statusEl.textContent = "Spinning\u2026";
  const result = spinSegrouletteEntry(cat);
  region = result.region;
  collection = result.collection;
  entry = result.entry;
  const regionStrip = el3("segrouletteReelRegion");
  const colStrip = el3("segrouletteReelCollection");
  const seriesStrip = el3("segrouletteReelSeries");
  fillReelStrip(regionStrip, reelSpinLabels(cat, "region"), result.region);
  fillReelStrip(
    colStrip,
    reelSpinLabels(cat, "collection"),
    humanizeCollection(result.collection)
  );
  fillReelStrip(
    seriesStrip,
    reelSpinLabels(cat, "series"),
    seriesReelLabel(result.entry)
  );
  await Promise.all([
    animateReel(regionStrip, 1400, 0),
    animateReel(colStrip, 1700, 180),
    animateReel(seriesStrip, 2e3, 360)
  ]);
  syncReelsFromSelection();
  spinning = false;
  setActionButtonsEnabled(true);
}
function openSegrouletteDialog(handlers) {
  const backdrop = el3("segrouletteModal");
  const statusEl = el3("segrouletteStatus");
  const openBtn = el3("segrouletteOpenBtn");
  const addBtn = el3("segrouletteAddBtn");
  const spinBtn = el3("segrouletteSpinBtn");
  entry = null;
  setActionButtonsEnabled(false);
  backdrop.hidden = false;
  statusEl.textContent = "Loading catalog\u2026";
  if (!wired) {
    wired = true;
    bindReelInteraction("segrouletteWindowRegion", (d) => {
      if (catalog) nudgeRegion(catalog, d);
    });
    bindReelInteraction("segrouletteWindowCollection", (d) => {
      if (catalog) nudgeCollection(catalog, d);
    });
    bindReelInteraction("segrouletteWindowSeries", (d) => {
      if (catalog) nudgeSeries(catalog, d);
    });
    spinBtn.addEventListener("click", () => {
      if (spinning || !catalog) return;
      void runIntroSpin(catalog).catch((err) => {
        spinning = false;
        setActionButtonsEnabled(true);
        statusEl.textContent = err instanceof Error ? err.message : "Spin failed";
      });
    });
    openBtn.addEventListener("click", () => {
      if (!entry || spinning) return;
      const chosen = entry;
      backdrop.hidden = true;
      void Promise.resolve(handlers.onOpen(chosen));
    });
    addBtn.addEventListener("click", () => {
      if (!entry || spinning) return;
      void Promise.resolve(handlers.onAddToWorklist(entry)).then(() => {
        statusEl.textContent = `Added to worklist \xB7 ${seriesReelLabel(entry)}`;
      });
    });
    backdrop.querySelectorAll("[data-close-segroulette]").forEach((node) => {
      node.addEventListener("click", () => {
        if (spinning) return;
        backdrop.hidden = true;
      });
    });
  }
  void ensureCatalog(statusEl).then((cat) => runIntroSpin(cat)).catch((err) => {
    spinning = false;
    statusEl.textContent = err instanceof Error ? err.message : "Failed to load catalog";
  });
}

// idc-nl-hub.ts
function hubAuthHeaders(state) {
  const headers = {};
  const token = state.client?.getConnectionState?.()?.token?.trim();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}
function resolveHubIdcNlApiBase(state) {
  const origin = hubOriginFromEndpoint(hubEndpoint(state));
  if (!origin) return null;
  return `${origin}/api/hub/idc-nl`;
}
async function fetchIdcNlHubStatus(state) {
  const base = resolveHubIdcNlApiBase(state);
  if (!base) return { anthropic: false };
  try {
    const res = await fetch(`${base}/status`, {
      headers: hubAuthHeaders(state)
    });
    if (!res.ok) return { anthropic: false };
    const body = await res.json();
    return {
      anthropic: Boolean(body?.anthropic)
    };
  } catch {
    return { anthropic: false };
  }
}
async function searchIdcViaAnthropic(state, prompt, options = {}) {
  const base = resolveHubIdcNlApiBase(state);
  if (!base) {
    throw new Error("Slicer hub endpoint is not configured");
  }
  const maxRows = options.maxRows || 20;
  const res = await fetch(`${base}/search`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...hubAuthHeaders(state)
    },
    body: JSON.stringify({ prompt, max_rows: maxRows })
  });
  let body = {};
  try {
    body = await res.json();
  } catch {
    body = {};
  }
  if (!res.ok) {
    const detail = body.detail || body.message || res.statusText;
    throw new Error(
      typeof detail === "string" ? detail : JSON.stringify(detail)
    );
  }
  const queryRaw = body.query && typeof body.query === "object" ? body.query : body;
  if (!queryRaw || typeof queryRaw !== "object") {
    throw new Error("Hub response missing SearchQuery");
  }
  return {
    text: String(body.text || ""),
    query: queryRaw,
    toolName: String(body.toolName || "anthropic")
  };
}

// idc-nl-series.ts
var IDC_NL_MAX_SERIES_FILES = 300;
var IDC_NL_MAX_STUDIES = 20;
function parseS3SeriesUrl(seriesAwsUrl) {
  const match = String(seriesAwsUrl || "").trim().match(/^s3:\/\/([^/]+)\/(.+)$/i);
  if (!match) return null;
  const bucket = match[1];
  const prefix = match[2].replace(/\*?$/, "").replace(/\/$/, "");
  return { bucket, prefix };
}
function s3ObjectHttpUrl(bucket, key) {
  const encodedKey = key.split("/").map(encodeURIComponent).join("/");
  return `https://${bucket}.s3.amazonaws.com/${encodedKey}`;
}
function appendS3ListingContents(doc, bucket, files) {
  const contents = doc.getElementsByTagName("Contents");
  for (let i = 0; i < contents.length; i += 1) {
    const node = contents[i];
    const key = node.getElementsByTagName("Key")[0]?.textContent || "";
    if (key && !key.endsWith("/")) {
      const size = Number(
        node.getElementsByTagName("Size")[0]?.textContent || 0
      );
      files.push({
        url: s3ObjectHttpUrl(bucket, key),
        fileName: key.slice(key.lastIndexOf("/") + 1),
        size
      });
    }
  }
}
async function fetchS3ListingPage(bucket, prefix, continuationToken) {
  const url = new URL(`https://${bucket}.s3.amazonaws.com/`);
  url.searchParams.set("list-type", "2");
  url.searchParams.set("prefix", `${prefix}/`);
  if (continuationToken) {
    url.searchParams.set("continuation-token", continuationToken);
  }
  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`S3 list failed (HTTP ${response.status}) for ${prefix}`);
  }
  const doc = new DOMParser().parseFromString(
    await response.text(),
    "application/xml"
  );
  if (doc.getElementsByTagName("parsererror").length) {
    throw new Error("Failed to parse S3 listing response");
  }
  const truncated = (doc.getElementsByTagName("IsTruncated")[0]?.textContent || "").trim() === "true";
  const nextToken = truncated ? doc.getElementsByTagName("NextContinuationToken")[0]?.textContent || null : null;
  return { doc, nextToken };
}
async function listIdcSeriesFiles(seriesAwsUrl) {
  const parsed = parseS3SeriesUrl(seriesAwsUrl);
  if (!parsed) return [];
  const files = [];
  async function listNextPage(continuationToken) {
    const { doc, nextToken } = await fetchS3ListingPage(
      parsed.bucket,
      parsed.prefix,
      continuationToken
    );
    appendS3ListingContents(doc, parsed.bucket, files);
    if (nextToken) await listNextPage(nextToken);
  }
  await listNextPage(null);
  return files;
}
function formatIdcSeriesSizeLabel(row) {
  const sizeMb = Number(
    row.series_size_MB ?? row.series_size_mb ?? row.seriesSizeMB ?? 0
  );
  const sliceCount = Number(row.instanceCount ?? row.instance_count ?? 0);
  if (Number.isFinite(sizeMb) && sizeMb > 0) {
    return `${sizeMb.toFixed(1)} MB`;
  }
  return `${sliceCount || "?"} DICOM`;
}
function idcNlOrganizationId(prompt) {
  const seed = `${prompt || ""}:${Date.now()}`;
  let hash = 5381;
  for (let i = 0; i < seed.length; i += 1) {
    hash = Math.imul(33, hash) + seed.charCodeAt(i);
    hash %= 4294967296;
  }
  const digest = Math.abs(hash).toString(16).padStart(8, "0");
  const stamp = Date.now().toString(36).slice(-4);
  return `idc-custom-${digest.slice(0, 6)}${stamp}`;
}
function idcNlMaxStudiesForPrompt(prompt) {
  const match = String(prompt || "").match(
    /\b(?:top|first|limit)\s+(\d{1,3})\b/i
  );
  if (match) {
    const parsed = Number(match[1]);
    if (Number.isFinite(parsed) && parsed > 0) {
      return Math.min(parsed, IDC_NL_MAX_STUDIES);
    }
  }
  return IDC_NL_MAX_STUDIES;
}
function nlSeriesToPendingStudy(series, orgId, index) {
  const row = series || {};
  const firstString2 = (...keys) => {
    for (const key of keys) {
      const value = row[key];
      if (value == null) continue;
      const text = String(value).trim();
      if (text) return text;
    }
    return "";
  };
  const studyUid = firstString2("StudyInstanceUID", "studyInstanceUID", "study_uid");
  const seriesUid = firstString2(
    "SeriesInstanceUID",
    "seriesInstanceUID",
    "series_uid"
  );
  const patientId = firstString2("PatientID", "patientId", "patient_id");
  const descriptionRaw = firstString2(
    "SeriesDescription",
    "seriesDescription",
    "description"
  );
  const collection2 = firstString2(
    "collection_id",
    "collectionId",
    "collection"
  );
  const modality = firstString2("Modality", "modality");
  const sliceCount = Number(row.instanceCount || row.instance_count || 0);
  const labelParts = [collection2, patientId, descriptionRaw || modality].filter(
    Boolean
  );
  const description = labelParts.join(" \u2014 ") || descriptionRaw || `IDC study ${index}`;
  const nameParts = [collection2, patientId, modality].filter(Boolean);
  const name = nameParts.join(" \xB7 ") || `IDC ${index}`;
  const studyId = seriesUid ? `idc-nl-${seriesUid.slice(-24)}` : `${orgId}-${String(index).padStart(2, "0")}`;
  const sizeLabel = formatIdcSeriesSizeLabel(row);
  const bucketRaw = firstString2("aws_bucket", "awsBucket", "bucket") || "aws";
  const seriesAwsUrl = firstString2(
    "series_aws_url",
    "seriesAwsUrl",
    "aws_url",
    "awsUrl",
    "seriesUrl",
    "series_url"
  );
  const crdcSeriesUuid = firstString2(
    "crdc_series_uuid",
    "crdcSeriesUuid",
    "crdc_uuid",
    "crdcUuid",
    "series_uuid"
  );
  return {
    id: studyId,
    name,
    description,
    size: sizeLabel,
    studyInstanceUID: studyUid,
    seriesInstanceUID: seriesUid,
    sourceBucket: bucketRaw.includes("gcs") ? "gcs" : "aws",
    instanceCount: sliceCount || void 0,
    organization: orgId,
    seriesAwsUrl,
    crdcSeriesUuid,
    raw: row
  };
}
async function resolveIdcNlWorklistSample(study, organization) {
  const org = String(organization || study.organization || "").trim();
  const seriesAwsUrl = String(study.seriesAwsUrl || "").trim();
  if (!seriesAwsUrl) {
    throw new Error("No AWS series URL to resolve DICOM files.");
  }
  if (!/^s3:\/\//i.test(seriesAwsUrl)) {
    throw new Error(
      "Per-file worklist entries require an s3:// series prefix (GCS not supported in browser)."
    );
  }
  const listed = await listIdcSeriesFiles(seriesAwsUrl);
  if (!listed.length) {
    throw new Error("No DICOM files found for this series.");
  }
  if (listed.length > IDC_NL_MAX_SERIES_FILES) {
    throw new Error(
      `Series has ${listed.length} files (max ${IDC_NL_MAX_SERIES_FILES}).`
    );
  }
  const files = listed.map(({ url, fileName }) => ({ url, fileName }));
  return {
    id: study.id,
    name: study.name,
    description: study.description,
    size: study.size,
    format: "DICOM",
    organization: org,
    modalities: void 0,
    studyInstanceUID: study.studyInstanceUID,
    seriesInstanceUID: study.seriesInstanceUID,
    openMode: ge,
    files,
    ctCrdc: study.crdcSeriesUuid || void 0
  };
}

// idc-nl-worklists.ts
var WORKLIST_ORG_IDC_CUSTOM_PREFIX = "idc-custom-";
var IDC_CUSTOM_WORKLISTS_STORAGE_KEY = "pw46.worklist.idcCustomWorklists";
var customWorklists = [];
function loadIdcCustomWorklistsFromSession() {
  try {
    const raw = sessionStorage.getItem(IDC_CUSTOM_WORKLISTS_STORAGE_KEY);
    if (!raw) {
      customWorklists = [];
      return customWorklists;
    }
    const parsed = JSON.parse(raw);
    customWorklists = Array.isArray(parsed) ? parsed.filter(
      (e) => e && typeof e === "object" && String(e.organization || "").startsWith(
        WORKLIST_ORG_IDC_CUSTOM_PREFIX
      )
    ) : [];
  } catch {
    customWorklists = [];
  }
  return customWorklists;
}
function saveIdcCustomWorklistsToSession() {
  try {
    sessionStorage.setItem(
      IDC_CUSTOM_WORKLISTS_STORAGE_KEY,
      JSON.stringify(customWorklists)
    );
  } catch {
  }
}
function ensureIdcCustomWorklistEntry(meta) {
  const org = String(meta.organization || "").trim();
  if (!org.startsWith(WORKLIST_ORG_IDC_CUSTOM_PREFIX)) return null;
  let entry2 = customWorklists.find((e) => e.organization === org);
  if (!entry2) {
    entry2 = {
      organization: org,
      label: String(meta.label || org).trim() || org,
      prompt: meta.prompt,
      createdAt: Date.now()
    };
    customWorklists.push(entry2);
  } else {
    if (meta.label) entry2.label = String(meta.label).trim() || entry2.label;
    if (meta.prompt) entry2.prompt = meta.prompt;
  }
  saveIdcCustomWorklistsToSession();
  return entry2;
}
function refreshOrgSelectWithCustomWorklists(select) {
  const current = select.value;
  select.querySelectorAll('option[data-idc-custom="1"]').forEach((n) => n.remove());
  for (const entry2 of customWorklists) {
    const opt = document.createElement("option");
    opt.value = entry2.organization;
    opt.textContent = entry2.label || entry2.organization;
    opt.dataset.idcCustom = "1";
    select.append(opt);
  }
  if (current && [...select.options].some((o) => o.value === current)) {
    select.value = current;
  }
}

// idc-rest.ts
var IDC_REST_BASE_URL = "https://api.imaging.datacommons.cancer.gov";
async function idcFetch(path, init2) {
  const url = `${IDC_REST_BASE_URL}${path}`;
  const res = await fetch(url, init2);
  let body = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) {
    const errObj = body && typeof body === "object" ? body : {};
    const nested = errObj.error && typeof errObj.error === "object" ? errObj.error : null;
    const detail = nested && (nested.message || nested.code) || errObj.detail || errObj.message || res.statusText;
    throw new Error(
      typeof detail === "string" ? detail : JSON.stringify(detail)
    );
  }
  return body;
}
async function fetchIdcAttributes() {
  const rows = await idcFetch("/v3/attributes");
  return Array.isArray(rows) ? rows : [];
}
async function fetchIdcAttributeValues(attribute, limit = 500) {
  const name = encodeURIComponent(attribute);
  const data = await idcFetch(
    `/v3/attributes/${name}/values?limit=${limit}`
  );
  const values = Array.isArray(data?.values) ? data.values : [];
  return {
    attribute: String(data?.attribute || attribute),
    values,
    truncated: Boolean(data?.truncated)
  };
}
async function fetchIdcCollections() {
  const rows = await idcFetch("/v3/collections");
  return Array.isArray(rows) ? rows : [];
}
async function fetchIdcAnalysisResults() {
  const rows = await idcFetch("/v3/analysis_results");
  return Array.isArray(rows) ? rows : [];
}
async function postIdcCohortCounts(filters) {
  return idcFetch("/v3/cohort/counts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filters })
  });
}
async function postIdcCohortManifest(options) {
  const page2 = options.page ?? 0;
  const page_size = options.pageSize ?? 25;
  return idcFetch("/v3/cohort/manifest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      filters: options.filters,
      page: page2,
      page_size,
      include_rows: true
    })
  });
}
async function postIdcSql(options) {
  const body = { sql: options.sql };
  if (options.maxRows != null) body.max_rows = options.maxRows;
  return idcFetch("/v3/sql", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
}

// idc-manifest-enrich.ts
var MANIFEST_PAGE_SIZE = 25;
var MAX_MANIFEST_ROWS = 40;
var SERIES_PER_STUDY_PAGE = 25;
function firstString(row, ...keys) {
  for (const key of keys) {
    const value = row[key];
    if (value == null) continue;
    const text = String(value).trim();
    if (text) return text;
  }
  return "";
}
function uniqueUids(series, ...keys) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const row of series || []) {
    const uid = firstString(row, ...keys);
    if (!uid || seen.has(uid)) continue;
    seen.add(uid);
    out.push(uid);
  }
  return out;
}
function extractSeriesInstanceUids(series) {
  return uniqueUids(
    series,
    "SeriesInstanceUID",
    "seriesInstanceUID",
    "series_uid"
  );
}
function extractStudyInstanceUids(series) {
  return uniqueUids(
    series,
    "StudyInstanceUID",
    "studyInstanceUID",
    "study_uid",
    "StudyInstanceUIDs"
  );
}
function chunk(items, size) {
  const out = [];
  for (let i = 0; i < items.length; i += size) {
    out.push(items.slice(i, i + size));
  }
  return out;
}
async function manifestBySeriesUids(seriesUids) {
  const byUid = /* @__PURE__ */ new Map();
  for (const uidBatch of chunk(seriesUids, MANIFEST_PAGE_SIZE)) {
    const manifest = await postIdcCohortManifest({
      filters: { terms: { SeriesInstanceUID: uidBatch } },
      page: 0,
      pageSize: Math.max(uidBatch.length, MANIFEST_PAGE_SIZE)
    });
    for (const row of manifest.series || []) {
      const uid = String(row.SeriesInstanceUID || "").trim();
      if (uid) byUid.set(uid, row);
    }
  }
  const rows = [];
  const missingUids = [];
  for (const uid of seriesUids) {
    const row = byUid.get(uid);
    if (row) rows.push(row);
    else missingUids.push(uid);
  }
  return { rows, missingUids };
}
async function manifestByStudyUids(studyUids) {
  const rows = [];
  const seenSeries = /* @__PURE__ */ new Set();
  for (const studyUid of studyUids) {
    if (rows.length >= MAX_MANIFEST_ROWS) break;
    const pageSize = Math.min(
      SERIES_PER_STUDY_PAGE,
      MAX_MANIFEST_ROWS - rows.length
    );
    const manifest = await postIdcCohortManifest({
      filters: { terms: { StudyInstanceUID: [studyUid] } },
      page: 0,
      pageSize
    });
    for (const row of manifest.series || []) {
      const seriesUid = String(row.SeriesInstanceUID || "").trim();
      if (!seriesUid || seenSeries.has(seriesUid)) continue;
      seenSeries.add(seriesUid);
      rows.push(row);
      if (rows.length >= MAX_MANIFEST_ROWS) break;
    }
  }
  return rows;
}
async function enrichSeriesViaIdcManifest(series) {
  const requestedSeriesUids = extractSeriesInstanceUids(series);
  const requestedStudyUids = extractStudyInstanceUids(series);
  if (requestedSeriesUids.length) {
    const { rows, missingUids } = await manifestBySeriesUids(
      requestedSeriesUids
    );
    if (rows.length) {
      return {
        rows,
        mode: "series",
        requestedSeriesUids,
        requestedStudyUids,
        missingSeriesUids: missingUids
      };
    }
  }
  if (requestedStudyUids.length) {
    const rows = await manifestByStudyUids(requestedStudyUids);
    return {
      rows,
      mode: rows.length ? "study" : "none",
      requestedSeriesUids,
      requestedStudyUids,
      missingSeriesUids: requestedSeriesUids
    };
  }
  return {
    rows: [],
    mode: "none",
    requestedSeriesUids,
    requestedStudyUids,
    missingSeriesUids: []
  };
}

// idc-search-query.ts
var CORE_FILTER_DEFS = [
  { attribute: "collection_id", label: "Collection", type: "term" },
  { attribute: "Modality", label: "Modality", type: "term" },
  { attribute: "BodyPartExamined", label: "Body part", type: "term" },
  { attribute: "analysis_result_id", label: "Analysis data", type: "term" }
];
var ADD_FILTER_GROUPS = [
  {
    id: "suggested",
    label: "Suggested",
    attributes: [
      "Manufacturer",
      "license_short_name",
      "StudyDate",
      "PatientSex"
    ]
  },
  {
    id: "acquisition",
    label: "Acquisition",
    attributes: [
      "ManufacturerModelName",
      "instanceCount",
      "series_size_MB",
      "sop_class_name"
    ]
  }
];
var filterSeq = 0;
function nextFilterId(prefix = "f") {
  filterSeq += 1;
  return `${prefix}-${filterSeq}`;
}
function createCoreSearchQuery() {
  return {
    filters: CORE_FILTER_DEFS.map((def) => ({
      id: nextFilterId("core"),
      label: def.label,
      attribute: def.attribute,
      type: def.type,
      values: [],
      core: true
    }))
  };
}
function cloneSearchQuery(query2) {
  return {
    filters: query2.filters.map((f2) => ({
      ...f2,
      values: f2.values ? [...f2.values] : void 0
    }))
  };
}
function hasActivePredicates(query2) {
  return query2.filters.some((f2) => {
    if (f2.type === "range") {
      return f2.min != null || f2.max != null;
    }
    return Array.isArray(f2.values) && f2.values.length > 0;
  });
}
function searchQueryToIdcFilters(query2) {
  const terms = {};
  const ranges = {};
  for (const filter of query2.filters) {
    const attr = String(filter.attribute || "").trim();
    if (!attr) continue;
    if (filter.type === "range") {
      const range = {};
      if (filter.min != null && Number.isFinite(filter.min)) {
        range.gte = filter.min;
      }
      if (filter.max != null && Number.isFinite(filter.max)) {
        range.lte = filter.max;
      }
      if (range.gte != null || range.lte != null) {
        ranges[attr] = range;
      }
      continue;
    }
    const values = (filter.values || []).map((v2) => String(v2 || "").trim()).filter(Boolean);
    if (values.length) {
      terms[attr] = values;
    }
  }
  const out = {};
  if (Object.keys(terms).length) out.terms = terms;
  if (Object.keys(ranges).length) out.ranges = ranges;
  return out;
}
function humanizeAttributeName(attribute) {
  const known = {
    collection_id: "Collection",
    analysis_result_id: "Analysis data",
    BodyPartExamined: "Body part",
    Modality: "Modality",
    Manufacturer: "Manufacturer",
    ManufacturerModelName: "Manufacturer model",
    PatientSex: "Patient sex",
    license_short_name: "License",
    sop_class_name: "SOP class",
    instanceCount: "Instance count",
    series_size_MB: "Series size (MB)",
    StudyDate: "Study date",
    SeriesDate: "Series date",
    PatientID: "Patient ID",
    StudyInstanceUID: "Study UID",
    SeriesInstanceUID: "Series UID",
    source_DOI: "Source DOI"
  };
  if (known[attribute]) return known[attribute];
  return attribute.replace(/_/g, " ");
}
function formatCount(n) {
  if (n == null || !Number.isFinite(n)) return "\u2014";
  return Math.trunc(n).toLocaleString();
}
function truncateUid(uid, head = 10, tail = 6) {
  const s2 = String(uid || "").trim();
  if (s2.length <= head + tail + 1) return s2 || "\u2014";
  return `${s2.slice(0, head)}\u2026${s2.slice(-tail)}`;
}

// idc-nl-execute.ts
function clampLimit(raw, fallback = 20) {
  const n = typeof raw === "number" ? raw : Number(raw);
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(Math.trunc(n), 100);
}
function normalizeFilter(raw) {
  const attribute = String(raw.attribute || "").trim();
  if (!attribute) return null;
  const op = String(raw.op || "").trim().toLowerCase();
  const ftype = String(raw.type || "").trim().toLowerCase();
  if (ftype === "range" || op === "between" || op === "gte" || op === "lte" || op === "range") {
    const min = raw.min != null && Number.isFinite(Number(raw.min)) ? Number(raw.min) : raw.gte != null && Number.isFinite(Number(raw.gte)) ? Number(raw.gte) : void 0;
    const max = raw.max != null && Number.isFinite(Number(raw.max)) ? Number(raw.max) : raw.lte != null && Number.isFinite(Number(raw.lte)) ? Number(raw.lte) : void 0;
    if (min == null && max == null) return null;
    return {
      id: nextFilterId("nl"),
      label: humanizeAttributeName(attribute),
      attribute,
      type: "range",
      min,
      max
    };
  }
  if (op === "contains") {
    throw new Error(
      `Filter op "contains" is not supported on IDC REST terms (${attribute}). Use SQL.`
    );
  }
  let values = [];
  if (Array.isArray(raw.values)) {
    values = raw.values.map((v2) => String(v2 || "").trim()).filter(Boolean);
  } else if (raw.value != null && String(raw.value).trim()) {
    values = [String(raw.value).trim()];
  }
  if (!values.length) return null;
  return {
    id: nextFilterId("nl"),
    label: humanizeAttributeName(attribute),
    attribute,
    type: "term",
    values
  };
}
function normalizeNlSearchQuery(raw, defaultLimit = 20) {
  if (!raw || typeof raw !== "object") {
    throw new Error("Missing SearchQuery from Anthropic");
  }
  const body = raw;
  const limit = clampLimit(body.limit, defaultLimit);
  const queryType = String(body.queryType || body.query_type || "").trim().toLowerCase();
  const sql = String(body.sql || "").trim();
  if (queryType === "sql" || !queryType && sql && !body.filters) {
    if (!sql) throw new Error("queryType sql requires a non-empty sql string");
    return { queryType: "sql", sql, limit };
  }
  const filtersRaw = Array.isArray(body.filters) ? body.filters : [];
  const filters = [];
  for (const item of filtersRaw) {
    if (!item || typeof item !== "object") continue;
    const normalized = normalizeFilter(item);
    if (normalized) {
      filters.push({
        attribute: normalized.attribute,
        type: normalized.type,
        values: normalized.values,
        min: normalized.min,
        max: normalized.max
      });
    }
  }
  if (!filters.length && sql) {
    return { queryType: "sql", sql, limit };
  }
  if (!filters.length) {
    throw new Error("SearchQuery has neither usable filters nor SQL");
  }
  return { queryType: "filters", filters, limit };
}
function toSearchQuery(nl3) {
  const filters = [];
  for (const raw of nl3.filters || []) {
    const normalized = normalizeFilter(raw);
    if (normalized) filters.push(normalized);
  }
  return { filters };
}
function formatFiltersDisplay(nl3) {
  return JSON.stringify(
    {
      queryType: "filters",
      filters: nl3.filters || [],
      limit: nl3.limit
    },
    null,
    2
  );
}
function rowNeedsEnrich(row) {
  const crdc = String(
    row.crdc_series_uuid || row.crdcSeriesUuid || ""
  ).trim();
  const aws = String(row.series_aws_url || row.seriesAwsUrl || "").trim();
  return !crdc && !aws;
}
async function executeNlSearchQuery(rawQuery, defaultLimit = 20) {
  const nl3 = normalizeNlSearchQuery(rawQuery, defaultLimit);
  const limit = nl3.limit ?? defaultLimit;
  if (nl3.queryType === "sql") {
    const sql = String(nl3.sql || "").trim();
    const result = await postIdcSql({ sql, maxRows: limit });
    let rows2 = Array.isArray(result.rows) ? result.rows.map((r) => ({ ...r })) : [];
    let enriched = false;
    if (rows2.length && rows2.some(rowNeedsEnrich)) {
      const hydrated = await enrichSeriesViaIdcManifest(rows2);
      if (hydrated.rows.length) {
        rows2 = hydrated.rows;
        enriched = true;
      }
    }
    return {
      rows: rows2,
      mode: "sql",
      displayQuery: sql,
      enriched,
      limit
    };
  }
  const searchQuery = toSearchQuery(nl3);
  const filters = searchQueryToIdcFilters(searchQuery);
  if (!filters.terms && !filters.ranges) {
    throw new Error("No active filter predicates to send to IDC REST");
  }
  const manifest = await postIdcCohortManifest({
    filters,
    page: 0,
    pageSize: limit
  });
  const rows = manifest.series || [];
  return {
    rows,
    mode: "filters",
    displayQuery: formatFiltersDisplay(nl3),
    enriched: false,
    limit
  };
}

// idc-series-actions.ts
function isPendingStudy(value) {
  return Boolean(value) && typeof value === "object" && "raw" in value && "seriesAwsUrl" in value && "organization" in value;
}
function toIdcSeriesActionRow(series) {
  if (isPendingStudy(series)) {
    const raw = series.raw || {};
    return {
      collection_id: String(raw.collection_id || raw.collectionId || "").trim() || null,
      PatientID: String(raw.PatientID || raw.patientId || "").trim() || null,
      StudyInstanceUID: series.studyInstanceUID || null,
      SeriesInstanceUID: series.seriesInstanceUID || null,
      Modality: String(raw.Modality || raw.modality || "").trim() || null,
      SeriesDescription: String(raw.SeriesDescription || raw.description || "").trim() || null,
      instanceCount: series.instanceCount ?? null,
      aws_bucket: String(raw.aws_bucket || "").trim() || null,
      crdc_series_uuid: series.crdcSeriesUuid || null,
      series_aws_url: series.seriesAwsUrl || null
    };
  }
  return series;
}
function idcSeriesDisplayName(row, fallback = "IDC series") {
  return [row.collection_id, row.PatientID, row.Modality].filter(Boolean).join(" \xB7 ") || fallback;
}
function canViewIdcSeries(row) {
  return Boolean(
    String(row.crdc_series_uuid || "").trim() || String(row.SeriesInstanceUID || "").trim()
  );
}
async function viewIdcSeries(state, series, setStatus3) {
  let row = toIdcSeriesActionRow(series);
  let crdc = String(row.crdc_series_uuid || "").trim();
  const seriesUid = String(row.SeriesInstanceUID || "").trim();
  if (!crdc && !seriesUid) {
    setStatus3?.("Series is missing CRDC UUID and SeriesInstanceUID.");
    return;
  }
  if (state.connection !== "connected") {
    setStatus3?.("Connect to Hub to open this series.");
    return;
  }
  try {
    if (!crdc && seriesUid) {
      setStatus3?.("Resolving CRDC UUID via IDC manifest\u2026", true);
      const enriched = await enrichSeriesViaIdcManifest([
        {
          SeriesInstanceUID: seriesUid,
          StudyInstanceUID: row.StudyInstanceUID || void 0
        }
      ]);
      const match = enriched.rows.find(
        (r) => String(r.SeriesInstanceUID || "").trim() === seriesUid
      ) || enriched.rows[0];
      if (match) {
        row = {
          ...row,
          ...match,
          crdc_series_uuid: String(match.crdc_series_uuid || "").trim() || row.crdc_series_uuid,
          aws_bucket: String(match.aws_bucket || "").trim() || row.aws_bucket
        };
        crdc = String(row.crdc_series_uuid || "").trim();
      }
    }
    if (!crdc) {
      setStatus3?.("Series is missing CRDC UUID; cannot open via Hub.");
      return;
    }
    setStatus3?.(`Opening ${row.collection_id || "series"}\u2026`, true);
    await publishIdcRestSeriesOpen(state, {
      crdcSeriesUuid: crdc,
      studyInstanceUID: String(row.StudyInstanceUID || ""),
      seriesDescription: String(row.SeriesDescription || ""),
      modality: String(row.Modality || "CT"),
      collectionId: String(row.collection_id || ""),
      bucket: String(row.aws_bucket || "idc-open-data")
    });
    setStatus3?.("Opened on Hub Image Displays.");
  } catch (err) {
    setStatus3?.(err instanceof Error ? err.message : String(err));
  }
}
function worklistSampleFromIdcCrdc(pending, organization, row) {
  const actionRow = row || toIdcSeriesActionRow(pending);
  const crdc = String(pending.crdcSeriesUuid || "").trim();
  if (!crdc) {
    throw new Error("Missing CRDC series UUID for IDC worklist sample");
  }
  const bucket = String(actionRow.aws_bucket || "idc-open-data").trim() || "idc-open-data";
  const modality = String(actionRow.Modality || "CT").trim().toUpperCase() || "CT";
  return {
    id: pending.id,
    name: pending.name,
    description: pending.description,
    size: pending.size,
    format: "DICOM",
    organization,
    modalities: [modality],
    studyInstanceUID: pending.studyInstanceUID || void 0,
    seriesInstanceUID: pending.seriesInstanceUID || crdc,
    openMode: ye,
    ctCrdc: crdc,
    bucket,
    files: [
      {
        url: `https://${bucket}.s3.amazonaws.com/${crdc}/`,
        fileName: `${crdc}/`
      }
    ]
  };
}
async function resolveViaHubOrS3(_state, series, organization, index = 1) {
  const pending = isPendingStudy(series) ? series : nlSeriesToPendingStudy(
    series,
    organization,
    index
  );
  const row = toIdcSeriesActionRow(pending);
  if (String(pending.crdcSeriesUuid || "").trim()) {
    return worklistSampleFromIdcCrdc(pending, organization, row);
  }
  const studyUid = String(pending.studyInstanceUID || "").trim();
  if (studyUid) {
    try {
      const resolved = await pn({
        studyInstanceUID: studyUid,
        seriesInstanceUID: pending.seriesInstanceUID || void 0
      });
      const enrichedPending = {
        ...pending,
        crdcSeriesUuid: resolved.crdcSeriesUuid,
        studyInstanceUID: resolved.studyInstanceUID,
        seriesInstanceUID: resolved.seriesInstanceUID || pending.seriesInstanceUID
      };
      const enrichedRow = {
        ...row,
        StudyInstanceUID: resolved.studyInstanceUID,
        SeriesInstanceUID: resolved.seriesInstanceUID || row.SeriesInstanceUID,
        Modality: resolved.modality || row.Modality,
        SeriesDescription: resolved.seriesDescription || row.SeriesDescription,
        aws_bucket: resolved.awsBucket,
        crdc_series_uuid: resolved.crdcSeriesUuid,
        collection_id: resolved.collectionId || row.collection_id
      };
      return worklistSampleFromIdcCrdc(
        enrichedPending,
        organization,
        enrichedRow
      );
    } catch {
    }
  }
  return resolveIdcNlWorklistSample(pending, organization);
}

// worklist-ui.ts
function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
var sizeSortDir = "asc";
function toggleSizeSortDir() {
  sizeSortDir = sizeSortDir === "asc" ? "desc" : "asc";
  return sizeSortDir;
}
function sampleSizeMbSortKey(sample) {
  const fromSeg = Number(sample.segroulette?.sizeMB);
  if (Number.isFinite(fromSeg)) return [0, fromSeg];
  const raw = String(sample.size || "").replace(/~/g, "").trim();
  const m = raw.match(/([\d.]+)/);
  if (m) {
    const n = Number(m[1]);
    if (Number.isFinite(n)) return [0, n];
  }
  return [1, 0];
}
function sortStudiesBySize(studies, dir2) {
  const sign = dir2 === "asc" ? 1 : -1;
  return studies.slice().sort((a, b) => {
    const [af, av] = sampleSizeMbSortKey(a);
    const [bf, bv] = sampleSizeMbSortKey(b);
    if (af !== bf) return (af - bf) * sign;
    if (av !== bv) return (av - bv) * sign;
    return String(a.name || a.id).localeCompare(String(b.name || b.id));
  });
}
function syncSizeSortHeader() {
  const th = document.getElementById("worklistSizeSortTh");
  const ind = th?.querySelector(".wl-th-sort-ind");
  if (!th) return;
  const asc = sizeSortDir === "asc";
  th.setAttribute("aria-sort", asc ? "ascending" : "descending");
  if (ind) ind.textContent = asc ? "\u25B2" : "\u25BC";
}
var WL_DOWNLOAD_ICON_SVG = `<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
  <path fill="currentColor" d="M8 1.5a.75.75 0 0 1 .75.75v6.19l2.22-2.22a.75.75 0 1 1 1.06 1.06l-3.5 3.5a.75.75 0 0 1-1.06 0l-3.5-3.5a.75.75 0 0 1 1.06-1.06l2.22 2.22V2.25A.75.75 0 0 1 8 1.5ZM2.75 12a.75.75 0 0 0 0 1.5h10.5a.75.75 0 0 0 0-1.5H2.75Z"/>
</svg>`;
var WL_ADD_ICON_SVG = `<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
  <path fill="currentColor" d="M8 2.5a.75.75 0 0 1 .75.75v4h4a.75.75 0 0 1 0 1.5h-4v4a.75.75 0 0 1-1.5 0v-4h-4a.75.75 0 0 1 0-1.5h4v-4A.75.75 0 0 1 8 2.5Z"/>
</svg>`;
function createWorklistStyleActions(handlers) {
  const inner = document.createElement("div");
  inner.className = "wl-row-actions-inner";
  const downloadBtn = document.createElement("button");
  downloadBtn.type = "button";
  downloadBtn.className = "wl-icon-btn wl-row-icon-btn";
  downloadBtn.title = "Download";
  downloadBtn.setAttribute("aria-label", "Download");
  downloadBtn.innerHTML = WL_DOWNLOAD_ICON_SVG;
  const addBtn = document.createElement("button");
  addBtn.type = "button";
  addBtn.className = "wl-icon-btn wl-row-icon-btn";
  addBtn.innerHTML = WL_ADD_ICON_SVG;
  const addState = handlers.addState || "idle";
  const canAdd = handlers.canAdd !== false;
  if (addState === "added") {
    addBtn.disabled = true;
    addBtn.title = "Added to worklist";
    addBtn.setAttribute("aria-label", "Added to worklist");
  } else if (addState === "adding") {
    addBtn.disabled = true;
    addBtn.title = "Adding\u2026";
    addBtn.setAttribute("aria-label", "Adding\u2026");
  } else if (!canAdd) {
    addBtn.disabled = true;
    addBtn.title = handlers.addDisabledTitle || "Cannot add";
    addBtn.setAttribute("aria-label", handlers.addDisabledTitle || "Cannot add");
  } else {
    addBtn.title = "Add to My Worklist";
    addBtn.setAttribute("aria-label", "Add to My Worklist");
    addBtn.addEventListener("click", () => handlers.onAdd());
  }
  const openBtn = document.createElement("button");
  openBtn.type = "button";
  openBtn.className = "wl-open-btn";
  openBtn.textContent = t2("chrome:open");
  if (handlers.canOpen === false) {
    openBtn.disabled = true;
    openBtn.title = handlers.openDisabledTitle || t2("chrome:cannotOpen");
  } else {
    openBtn.title = t2("chrome:openStudy");
    openBtn.addEventListener("click", () => handlers.onOpen());
  }
  inner.append(downloadBtn, addBtn, openBtn);
  return inner;
}
function syncSlicerWorklistModeUi(state) {
  const slicerMode = isSlicerWorklistMode(state);
  const normal = document.getElementById("worklistNormalPanel");
  const slicer = document.getElementById("slicerWorklistPanel");
  const orgSelect = document.getElementById("worklistOrgSelect");
  const downloadBtn = document.getElementById("downloadWorklistBtn");
  const uploadBtn = document.getElementById("uploadWorklistBtn");
  if (normal) normal.hidden = slicerMode;
  if (slicer) slicer.hidden = !slicerMode;
  if (orgSelect) orgSelect.hidden = slicerMode;
  if (downloadBtn) downloadBtn.hidden = slicerMode;
  if (uploadBtn) uploadBtn.hidden = slicerMode;
  const title = document.getElementById("worklistTitle");
  if (title) {
    title.textContent = slicerMode ? "Slicer worklist:" : t2("chrome:worklist");
  }
}
function buildSlicerWorklistRow(sample, state) {
  const tr2 = document.createElement("tr");
  tr2.dataset.worklistSampleId = sample.id;
  const isOpen = Boolean(state.lastImagingStudyOpenContext.length) && state.openWorklistSampleId === sample.id;
  const selected = state.slicerStudyInfo?.sampleId === sample.id || !state.slicerStudyInfo && isOpen;
  tr2.classList.toggle("is-open", isOpen);
  tr2.classList.toggle("is-selected", Boolean(selected));
  const patient = String(sample.patientName || "").trim() || String(sample.name || sample.id).trim();
  const studyDate = String(sample.studyDate || "").trim() || "\u2014";
  const description = String(sample.description || "").trim() || "\u2014";
  const modalities = worklistSampleModalitiesLabel(sample);
  const disabled = isWorklistSampleActionDisabled(sample);
  const disabledReason = worklistSampleActionDisabledReason(sample);
  tr2.innerHTML = `
    <td>
      <div class="wl-study-name">${escapeHtml(patient)}</div>
      <div class="wl-study-desc">${escapeHtml(sample.patientID || sample.studyInstanceUID || "")}</div>
    </td>
    <td class="wl-muted">${escapeHtml(studyDate)}</td>
    <td class="wl-muted">${escapeHtml(description)}</td>
    <td class="wl-muted">${escapeHtml(modalities)}</td>
    <td class="wl-row-actions">
      <div class="wl-row-actions-inner">
        <button type="button" class="wl-open-btn" data-sample-id="${escapeHtml(
    sample.id
  )}"></button>
      </div>
    </td>
  `;
  tr2.addEventListener("click", (ev) => {
    const target = ev.target;
    if (target?.closest("button")) return;
    handleSlicerWorklistRowClick(state, sample.id).catch((err) => {
      console.warn("[@slicer-hub/worklist] slicerstudyinfo failed", err);
    });
  });
  const btn = tr2.querySelector(".wl-open-btn");
  if (disabled) {
    btn.disabled = true;
    btn.textContent = t2("chrome:open");
    btn.title = disabledReason || t2("chrome:cannotOpen");
  } else if (isOpen) {
    btn.disabled = false;
    btn.textContent = t2("chrome:close");
    btn.classList.add("is-close");
    btn.dataset.worklistAction = "close";
    btn.title = t2("chrome:closeStudy");
  } else {
    btn.disabled = false;
    btn.textContent = t2("chrome:open");
    btn.classList.remove("is-close");
    btn.dataset.worklistAction = "open";
    btn.title = t2("chrome:openStudy");
  }
  btn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    handleWorklistRowAction(
      state,
      sample.id,
      btn.dataset.worklistAction || "open"
    );
  });
  return tr2;
}
function renderSlicerStudyInfoPanel(info) {
  const el6 = document.getElementById("slicerStudyInfo");
  if (!el6) return;
  if (!info) {
    el6.hidden = true;
    el6.replaceChildren();
    return;
  }
  el6.hidden = false;
  if (info.loading) {
    el6.innerHTML = `<p class="wl-muted">Loading study details\u2026</p>`;
    return;
  }
  if (info.error) {
    el6.innerHTML = `<p class="wl-muted">${escapeHtml(info.error)}</p>`;
    return;
  }
  const resource = info.resource;
  if (!resource || typeof resource !== "object") {
    el6.innerHTML = `<p class="wl-muted">No series details.</p>`;
    return;
  }
  const series = Array.isArray(resource.series) ? resource.series : [];
  const desc = String(resource.description || "").trim();
  const started = String(resource.started || "").trim();
  const nSeries = resource.numberOfSeries ?? series.length;
  const nInstances = resource.numberOfInstances;
  const headerBits = [
    desc || "Study details",
    started ? `Started ${started}` : "",
    nSeries != null ? `${nSeries} series` : "",
    nInstances != null ? `${nInstances} instances` : ""
  ].filter(Boolean);
  const rows = series.map((entry2) => {
    if (!entry2 || typeof entry2 !== "object") return "";
    const s2 = entry2;
    const modalityCoding = s2.modality?.coding;
    const modality = Array.isArray(modalityCoding) && modalityCoding[0]?.code || String(s2.modality?.code || "").trim() || "\u2014";
    const number = s2.number != null ? String(s2.number) : "\u2014";
    const description = String(s2.description || "").trim() || "\u2014";
    const count = s2.numberOfInstances != null ? String(s2.numberOfInstances) : Array.isArray(s2.instance) ? String(s2.instance.length) : "\u2014";
    const uid = String(s2.uid || "").trim();
    return `<tr>
        <td class="wl-muted">${escapeHtml(number)}</td>
        <td>${escapeHtml(modality)}</td>
        <td>${escapeHtml(description)}</td>
        <td class="wl-muted">${escapeHtml(count)}</td>
        <td class="wl-muted wl-slicer-uid">${escapeHtml(uid)}</td>
      </tr>`;
  }).join("");
  el6.innerHTML = `
    <div class="wl-slicer-studyinfo-header">${escapeHtml(headerBits.join(" \xB7 "))}</div>
    <table class="wl-table wl-slicer-series-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Modality</th>
          <th>Series</th>
          <th>Images</th>
          <th>Series UID</th>
        </tr>
      </thead>
      <tbody>${rows || `<tr><td colspan="5" class="wl-muted">No series.</td></tr>`}</tbody>
    </table>
  `;
}
function renderSlicerWorklistTable(state) {
  const tableBody = document.getElementById("slicerWorklistBody");
  const emptyRow = document.getElementById("slicerWorklistEmpty");
  if (!tableBody || !emptyRow) return;
  const studies = state.allStudies.filter(isSlicerDicomSample);
  tableBody.replaceChildren();
  renderWorklistContext(state);
  renderSlicerStudyInfoPanel(state.slicerStudyInfo);
  if (!studies.length) {
    emptyRow.hidden = false;
    emptyRow.textContent = state.slicerWorklistFetched ? "No studies in the Slicer DICOM database." : "Waiting for Slicer worklist response\u2026";
    return;
  }
  emptyRow.hidden = true;
  const showStartHint = shouldShowOpenStartHint(state);
  let startHintAssigned = false;
  for (const sample of studies) {
    const row = buildSlicerWorklistRow(sample, state);
    if (showStartHint && !startHintAssigned) {
      const btn = row.querySelector(".wl-open-btn");
      if (btn && !btn.disabled && !btn.classList.contains("is-close")) {
        btn.classList.add("wl-open-btn-start-hint");
        startHintAssigned = true;
      }
    }
    tableBody.append(row);
  }
}
function renderWorklistTable(tableBody, emptyRow, state, organization) {
  syncSlicerWorklistModeUi(state);
  if (isSlicerWorklistMode(state)) {
    renderSlicerWorklistTable(state);
    return;
  }
  const studies = sortStudiesBySize(
    filterWorklistStudies(state.allStudies, organization),
    sizeSortDir
  );
  tableBody.replaceChildren();
  renderWorklistContext(state);
  syncSizeSortHeader();
  if (!studies.length) {
    emptyRow.hidden = false;
    return;
  }
  emptyRow.hidden = true;
  const showStartHint = shouldShowOpenStartHint(state);
  let startHintAssigned = false;
  for (const sample of studies) {
    const row = buildWorklistRow(sample, state);
    if (showStartHint && !startHintAssigned) {
      const btn = row.querySelector(".wl-open-btn");
      if (btn && !btn.disabled && !btn.classList.contains("is-close")) {
        btn.classList.add("wl-open-btn-start-hint");
        startHintAssigned = true;
      }
    }
    tableBody.append(row);
  }
}
function imagingStudyOpenDescription(state) {
  if (state.openWorklistSampleId) {
    const sample = state.allStudies.find(
      (s2) => s2.id === state.openWorklistSampleId
    );
    const name = String(sample?.name || "").trim();
    if (name) return name;
    const description = String(sample?.description || "").trim();
    if (description) return description;
  }
  const ctx = state.lastImagingStudyOpenContext;
  if (Array.isArray(ctx)) {
    for (const item of ctx) {
      if (!item || typeof item !== "object") continue;
      const row = item;
      const key = String(row.key || "");
      if (key !== "study" && key !== "scene") continue;
      const description = String(row.resource?.description ?? "").trim();
      if (description) return description;
    }
  }
  return "";
}
function renderWorklistContext(state) {
  const el6 = document.getElementById("worklistContext");
  if (!el6) return;
  const capsule = el6.closest(".wl-capsule");
  const open = state.lastImagingStudyOpenContext.length > 0;
  const description = open ? imagingStudyOpenDescription(state) : "";
  const hasContext = Boolean(open && description);
  capsule?.classList.toggle("is-open", hasContext);
  el6.replaceChildren();
  const label = document.createElement("span");
  label.className = "wl-context-label";
  label.textContent = t2("chrome:currentContext");
  const value = document.createElement("span");
  value.className = "wl-context-value";
  value.textContent = hasContext ? description : t2("chrome:none");
  el6.append(label, " ", value);
  const closeBtn = document.getElementById(
    "closeContextBtn"
  );
  if (closeBtn) {
    closeBtn.hidden = !hasContext;
    closeBtn.disabled = !hasContext;
  }
}
function buildWorklistRow(sample, state) {
  const tr2 = document.createElement("tr");
  tr2.dataset.worklistSampleId = sample.id;
  const isOpen = Boolean(state.lastImagingStudyOpenContext.length) && state.openWorklistSampleId === sample.id;
  tr2.classList.toggle("is-open", isOpen);
  const disabled = isWorklistSampleActionDisabled(sample);
  const disabledReason = worklistSampleActionDisabledReason(sample);
  const format = worklistSampleFormatLabel(sample);
  const size = sample.size || "\u2014";
  const modalities = worklistSampleModalitiesLabel(sample);
  const alreadyInMine = isSampleInMyWorklist(state.allStudies, sample);
  tr2.innerHTML = `
    <td>
      <div class="wl-study-name">${escapeHtml(sample.name || sample.id)}</div>
      <div class="wl-study-desc">${escapeHtml(sample.description || "")}</div>
    </td>
    <td class="wl-muted">${escapeHtml(modalities)}</td>
    <td class="wl-muted">${escapeHtml(format)}</td>
    <td class="wl-muted">${escapeHtml(size)}</td>
    <td class="wl-row-actions">
      <div class="wl-row-actions-inner">
      <button
        type="button"
        class="wl-icon-btn wl-row-icon-btn"
        data-worklist-action="download"
        data-sample-id="${escapeHtml(sample.id)}"
        title="Download"
        aria-label="Download"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
          <path
            fill="currentColor"
            d="M8 1.5a.75.75 0 0 1 .75.75v6.19l2.22-2.22a.75.75 0 1 1 1.06 1.06l-3.5 3.5a.75.75 0 0 1-1.06 0l-3.5-3.5a.75.75 0 0 1 1.06-1.06l2.22 2.22V2.25A.75.75 0 0 1 8 1.5ZM2.75 12a.75.75 0 0 0 0 1.5h10.5a.75.75 0 0 0 0-1.5H2.75Z"
          />
        </svg>
      </button>
      <button
        type="button"
        class="wl-icon-btn wl-row-icon-btn"
        data-worklist-action="add-to-mine"
        data-sample-id="${escapeHtml(sample.id)}"
        title="${alreadyInMine ? "Already in My Worklist" : "Add to My Worklist"}"
        aria-label="${alreadyInMine ? "Already in My Worklist" : "Add to My Worklist"}"
        ${alreadyInMine ? "disabled" : ""}
      >
        <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
          <path
            fill="currentColor"
            d="M8 2.5a.75.75 0 0 1 .75.75v4h4a.75.75 0 0 1 0 1.5h-4v4a.75.75 0 0 1-1.5 0v-4h-4a.75.75 0 0 1 0-1.5h4v-4A.75.75 0 0 1 8 2.5Z"
          />
        </svg>
      </button>
      <button type="button" class="wl-open-btn" data-sample-id="${escapeHtml(
    sample.id
  )}"></button>
      </div>
    </td>
  `;
  const addBtn = tr2.querySelector(
    '[data-worklist-action="add-to-mine"]'
  );
  if (addBtn && !alreadyInMine) {
    addBtn.addEventListener("click", () => {
      handleWorklistRowAction(state, sample.id, "add-to-mine");
    });
  }
  const btn = tr2.querySelector(".wl-open-btn");
  if (disabled) {
    btn.disabled = true;
    btn.textContent = t2("chrome:open");
    btn.title = disabledReason || t2("chrome:cannotOpen");
  } else if (isOpen) {
    btn.disabled = false;
    btn.textContent = t2("chrome:close");
    btn.classList.add("is-close");
    btn.dataset.worklistAction = "close";
    btn.title = t2("chrome:closeStudy");
  } else {
    btn.disabled = false;
    btn.textContent = t2("chrome:open");
    btn.classList.remove("is-close");
    btn.dataset.worklistAction = "open";
    btn.title = t2("chrome:openStudy");
  }
  btn.addEventListener("click", () => {
    handleWorklistRowAction(
      state,
      sample.id,
      btn.dataset.worklistAction || "open"
    );
  });
  return tr2;
}
var sessionStatusControl = null;
var sessionStatusLabel = null;
function setSessionStatusControl(control) {
  sessionStatusControl = control.button;
  sessionStatusLabel = control.label;
}
function updateConnectionStatusUi(statusWrap, state) {
  const wrap = sessionStatusLabel || statusWrap;
  if (!wrap) {
    renderConferenceRoster(state);
    return;
  }
  const visual = Ct(state.connection, {
    conferenceActive: Boolean(state.conference)
  });
  wrap.classList.remove(
    "wl-status-idle",
    "wl-status-connecting",
    "wl-status-connected",
    "wl-status-disconnected",
    "wl-status-error",
    "wl-status-pulse"
  );
  wrap.classList.add(`wl-status-${visual.tone}`);
  wrap.classList.toggle("wl-status-pulse", visual.pulse);
  const label = String(state.topic || "").trim() || "\u2014";
  wrap.textContent = label;
  const tip = state.conference?.title ? `${state.connectionDetail} \xB7 ${state.conference.title}` : state.connectionDetail;
  wrap.title = tip;
  const btn = sessionStatusControl || wrap.closest("button");
  if (btn) {
    if (state.conference?.places?.length) {
      btn.title = tip ? `Participants \u2014 ${tip}` : "Participants";
      btn.setAttribute("aria-label", `Participants (${label})`);
    } else {
      btn.title = tip ? `Session info \u2014 ${tip}` : "Session info";
      btn.setAttribute("aria-label", `Session info (${label})`);
    }
  }
  renderConferenceRoster(state);
}
function renderConferenceRoster(state) {
  const statusControl = sessionStatusControl;
  const statusLabelEl = sessionStatusLabel;
  const startBtn = document.getElementById(
    "startConferenceBtn"
  );
  const endBtn = document.getElementById(
    "endConferenceBtn"
  );
  const stopFollowBtn = document.getElementById(
    "stopFollowingBtn"
  );
  const resumeFollowBtn = document.getElementById(
    "resumeFollowingBtn"
  );
  const takeOverBtn = document.getElementById(
    "takeOverConferenceBtn"
  );
  if (!startBtn && !endBtn && !statusControl) return;
  const view = state.conference;
  const connected = state.connection === "connected";
  const followHost = Boolean(state.conferenceFollowHost);
  if (statusControl instanceof HTMLElement) {
    ht({
      view,
      statusControl,
      statusLabelEl,
      classPrefix: "wl-conference",
      selfStatusMode: "short",
      followHost
    });
  }
  pt2({
    view,
    followHost,
    connected,
    strings: conferenceStrings(),
    startBtn,
    endBtn,
    stopFollowBtn,
    resumeFollowBtn,
    takeOverBtn
  });
}
function closeMenus(...menus) {
  for (const menu of menus) {
    menu.hidden = true;
  }
}

// idc-nl-dialog.ts
var IDC_NL_DEFAULT_PROMPT = "Find a CT of the kidneys with at least 50 slices but no more than 100";
var IDC_NL_DEFAULT_ORG_LABEL = "test worklist";
var wired2 = false;
var anthropicAvailable = false;
var searchBusy = false;
var pendingOrg = "";
var pendingLabel = "";
var pendingPrompt = "";
var pendingStudies = [];
var pendingSql = "";
var sqlVisible = false;
var addedIds = /* @__PURE__ */ new Set();
var addingIds = /* @__PURE__ */ new Set();
function el4(id) {
  return document.getElementById(id);
}
function setStatus(text, busy = false) {
  const status = el4("idcNlStatus");
  const spinner = el4("idcNlStatusSpinner");
  const row = el4("idcNlStatusRow");
  if (status) {
    status.textContent = text || "";
    status.classList.toggle("is-busy", busy);
  }
  if (spinner) spinner.hidden = !busy;
  if (row) row.setAttribute("aria-busy", busy ? "true" : "false");
}
function appendLog(line) {
  const log = el4("idcNlJobLog");
  if (!log) return;
  log.hidden = false;
  const prev = log.textContent || "";
  log.textContent = prev ? `${prev}
${line}` : line;
  log.scrollTop = log.scrollHeight;
}
function clearLog() {
  const log = el4("idcNlJobLog");
  if (!log) return;
  log.textContent = "";
  log.hidden = true;
}
function syncAvailability() {
  const avail = el4("idcNlAvailability");
  const searchBtn = el4("idcNlSearchBtn");
  if (avail) {
    avail.textContent = anthropicAvailable ? "" : "Anthropic unavailable \u2014 connect hub with ANTHROPIC_API_KEY.";
  }
  if (searchBtn) searchBtn.disabled = !anthropicAvailable || searchBusy;
}
function syncSqlPanel() {
  const section = el4("idcNlSqlSection");
  const toggle = el4("idcNlToggleSqlBtn");
  const panel = el4("idcNlSqlPanel");
  if (!section || !toggle || !panel) return;
  const sql = pendingSql.trim();
  if (!sql) {
    section.hidden = true;
    toggle.hidden = true;
    panel.hidden = true;
    panel.textContent = "";
    sqlVisible = false;
    return;
  }
  section.hidden = false;
  toggle.hidden = false;
  panel.textContent = sql;
  panel.hidden = !sqlVisible;
  toggle.textContent = sqlVisible ? "Hide IDC query" : "Show IDC query";
  toggle.setAttribute("aria-expanded", sqlVisible ? "true" : "false");
}
function clearResults() {
  pendingStudies = [];
  pendingSql = "";
  sqlVisible = false;
  addedIds.clear();
  addingIds.clear();
  const results = el4("idcNlResults");
  const section = el4("idcNlResultsSection");
  if (results) results.replaceChildren();
  if (section) section.hidden = true;
  const citation = el4("idcNlCitation");
  if (citation) citation.textContent = "";
  syncSqlPanel();
}
function renderResults(handlers) {
  const resultsEl = el4("idcNlResults");
  const sectionEl = el4("idcNlResultsSection");
  if (!resultsEl || !sectionEl) return;
  resultsEl.replaceChildren();
  if (!pendingStudies.length) {
    sectionEl.hidden = true;
    return;
  }
  sectionEl.hidden = false;
  for (const study of pendingStudies) {
    const row = document.createElement("div");
    row.className = "wl-idc-nl-result-row";
    const text = document.createElement("div");
    text.className = "wl-idc-nl-result-text";
    const title = document.createElement("div");
    title.className = "wl-idc-nl-result-title";
    title.textContent = study.name || study.id;
    const desc = document.createElement("div");
    desc.className = "wl-idc-nl-result-desc";
    desc.textContent = study.description || "";
    const meta = document.createElement("div");
    meta.className = "wl-idc-nl-result-meta";
    meta.textContent = study.size || "";
    text.append(title, desc, meta);
    const actions = document.createElement("div");
    actions.className = "wl-idc-nl-result-actions";
    const actionRow = toIdcSeriesActionRow(study);
    const studyId = study.id;
    const addState = addedIds.has(studyId) ? "added" : addingIds.has(studyId) ? "adding" : "idle";
    const canAdd = Boolean(
      study.crdcSeriesUuid || study.seriesInstanceUID || study.seriesAwsUrl
    ) && addState === "idle";
    actions.append(
      createWorklistStyleActions({
        canOpen: canViewIdcSeries(actionRow),
        openDisabledTitle: "Missing CRDC UUID and SeriesInstanceUID",
        onOpen: () => {
          void viewStudy(handlers, study);
        },
        addState,
        canAdd,
        addDisabledTitle: "Series is missing CRDC UUID / SeriesInstanceUID / series_aws_url",
        onAdd: () => {
          void addStudy(handlers, studyId);
        }
      })
    );
    row.append(text, actions);
    resultsEl.append(row);
  }
}
async function viewStudy(handlers, study) {
  const state = handlers.getState();
  await viewIdcSeries(state, study, setStatus);
}
async function addStudy(handlers, studyId) {
  const study = pendingStudies.find((s2) => s2.id === studyId);
  if (!study || addedIds.has(studyId) || addingIds.has(studyId)) return;
  const entry2 = ensureIdcCustomWorklistEntry({
    organization: pendingOrg,
    label: pendingLabel,
    prompt: pendingPrompt
  });
  if (!entry2) {
    setStatus("Worklist organization is missing.");
    return;
  }
  if (!study.crdcSeriesUuid && !study.seriesInstanceUID && !study.seriesAwsUrl) {
    setStatus(
      "Series is missing CRDC UUID / SeriesInstanceUID / series_aws_url; cannot add. Re-run search after hub update, or use REST search."
    );
    return;
  }
  addingIds.add(studyId);
  renderResults(handlers);
  setStatus(`Adding ${study.name}\u2026`, true);
  appendLog(
    study.crdcSeriesUuid ? `Adding IDC/CRDC row for ${study.id}\u2026` : `Resolving files for ${study.id}\u2026`
  );
  try {
    const state = handlers.getState();
    const sample = await resolveViaHubOrS3(
      state,
      study,
      pendingOrg
    );
    const actionRow = toIdcSeriesActionRow(study);
    sample.id = study.crdcSeriesUuid ? `idc-nl-${study.crdcSeriesUuid.slice(-24)}` : study.seriesInstanceUID ? `idc-nl-${study.seriesInstanceUID.slice(-24)}` : study.id;
    sample.name = idcSeriesDisplayName(actionRow, sample.name);
    state.allStudies = upsertIdcSegmentationSample(state.allStudies, sample);
    addedIds.add(studyId);
    const orgSelect = document.getElementById(
      "worklistOrgSelect"
    );
    if (orgSelect) {
      refreshOrgSelectWithCustomWorklists(orgSelect);
      handlers.setOrgFilter(pendingOrg);
    }
    handlers.onStudiesChanged();
    const via = sample.openMode === "idc" && sample.ctCrdc ? "IDC/CRDC" : `${sample.files?.length || 0} files`;
    setStatus(`Added ${sample.name} (${via}).`);
    appendLog(`Added ${sample.id}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    setStatus(msg);
    appendLog(msg);
  } finally {
    addingIds.delete(studyId);
    renderResults(handlers);
  }
}
async function runSearch(handlers) {
  if (searchBusy) return;
  if (!anthropicAvailable) {
    setStatus("Anthropic unavailable on Slicer hub.");
    return;
  }
  const prompt = el4("idcNlPrompt")?.value?.trim() || "";
  if (!prompt) {
    setStatus("Enter a natural-language IDC query.");
    return;
  }
  const organizationLabel = el4("idcNlOrgLabel")?.value?.trim() || IDC_NL_DEFAULT_ORG_LABEL;
  searchBusy = true;
  clearResults();
  clearLog();
  syncAvailability();
  setStatus("Translating query via Anthropic\u2026", true);
  appendLog("Anthropic \u2192 SearchQuery\u2026");
  try {
    const searchStart = performance.now();
    const state = handlers.getState();
    const maxRows = idcNlMaxStudiesForPrompt(prompt);
    const anthropicStart = performance.now();
    const hubResult = await searchIdcViaAnthropic(state, prompt, {
      maxRows
    });
    appendLog(
      `Anthropic: ${((performance.now() - anthropicStart) / 1e3).toFixed(1)}s`
    );
    const org = idcNlOrganizationId(prompt);
    pendingOrg = org;
    pendingLabel = organizationLabel;
    pendingPrompt = prompt;
    const queryType = String(hubResult.query?.queryType || "?");
    appendLog(`queryType=${queryType}`);
    setStatus("Executing SearchQuery via IDC REST\u2026", true);
    const restStart = performance.now();
    const executed = await executeNlSearchQuery(hubResult.query, maxRows);
    appendLog(
      `IDC REST: ${((performance.now() - restStart) / 1e3).toFixed(1)}s`
    );
    appendLog(
      `Total: ${((performance.now() - searchStart) / 1e3).toFixed(1)}s`
    );
    appendLog(
      `mode=${executed.mode} rows=${executed.rows.length}` + (executed.enriched ? " (SQL rows enriched via manifest)" : "")
    );
    pendingSql = executed.displayQuery || "";
    pendingStudies = executed.rows.map(
      (row, i) => nlSeriesToPendingStudy(row, org, i + 1)
    );
    ensureIdcCustomWorklistEntry({
      organization: org,
      label: organizationLabel,
      prompt
    });
    const citation = el4("idcNlCitation");
    if (citation) citation.textContent = "";
    syncSqlPanel();
    renderResults(handlers);
    setStatus(
      pendingStudies.length ? `Found ${pendingStudies.length} series via IDC REST (${executed.mode}). Use Open or + when ready.` : hubResult.text.trim() || "No series matched this SearchQuery."
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    setStatus(msg);
    appendLog(msg);
  } finally {
    searchBusy = false;
    syncAvailability();
  }
}
async function refreshAnthropic(handlers) {
  const status = await fetchIdcNlHubStatus(handlers.getState());
  anthropicAvailable = Boolean(status.anthropic);
  syncAvailability();
}
function openIdcNlDialog(handlers) {
  const overlay = el4("idcNlModal");
  if (!overlay) return;
  const prompt = el4("idcNlPrompt");
  const orgLabel = el4("idcNlOrgLabel");
  if (prompt && !prompt.value.trim()) prompt.value = IDC_NL_DEFAULT_PROMPT;
  if (orgLabel && !orgLabel.value.trim()) {
    orgLabel.value = IDC_NL_DEFAULT_ORG_LABEL;
  }
  wireOnce(handlers);
  overlay.hidden = false;
  setStatus("");
  void refreshAnthropic(handlers).then(() => {
    prompt?.focus();
  });
}
function closeIdcNlDialog() {
  const overlay = el4("idcNlModal");
  if (overlay) overlay.hidden = true;
}
function wireOnce(handlers) {
  if (wired2) return;
  wired2 = true;
  el4("idcNlSearchBtn")?.addEventListener("click", () => {
    void runSearch(handlers);
  });
  document.querySelectorAll("[data-close-idc-nl]").forEach((node) => {
    node.addEventListener("click", () => closeIdcNlDialog());
  });
  el4("idcNlToggleSqlBtn")?.addEventListener("click", () => {
    sqlVisible = !sqlVisible;
    syncSqlPanel();
  });
  el4("idcNlModal")?.addEventListener("click", (ev) => {
    if (ev.target === ev.currentTarget) closeIdcNlDialog();
  });
}

// idc-search-dialog.ts
var PAGE_SIZE = 25;
var COUNTS_DEBOUNCE_MS = 350;
var DEFAULT_ORG_LABEL = "IDC REST search";
var wired3 = false;
var metaLoaded = false;
var metaBusy = false;
var countsBusy = false;
var resultsBusy = false;
var countsTimer = null;
var countsGen = 0;
var query = createCoreSearchQuery();
var attributes = [];
var collections = [];
var analysisResults = [];
var valueCache = /* @__PURE__ */ new Map();
var counts = null;
var seriesRows = [];
var page = 0;
var totalSeries = 0;
var addFilterOpen = false;
var addingKeys = /* @__PURE__ */ new Set();
var addedKeys = /* @__PURE__ */ new Set();
function el5(id) {
  return document.getElementById(id);
}
function setStatus2(text, busy = false) {
  const status = el5("idcSearchStatus");
  const spinner = el5("idcSearchStatusSpinner");
  if (status) {
    status.textContent = text || "";
    status.classList.toggle("is-busy", busy);
  }
  if (spinner) spinner.hidden = !busy;
}
function rowKey(row, index) {
  return String(row.SeriesInstanceUID || row.crdc_series_uuid || "").trim() || `row-${index}`;
}
async function ensureMeta() {
  if (metaLoaded || metaBusy) return;
  metaBusy = true;
  setStatus2("Loading IDC attributes\u2026", true);
  try {
    const [attrs, cols, analysis] = await Promise.all([
      fetchIdcAttributes(),
      fetchIdcCollections(),
      fetchIdcAnalysisResults()
    ]);
    attributes = attrs;
    collections = cols.slice().sort(
      (a, b) => String(a.collection_id).localeCompare(String(b.collection_id))
    );
    analysisResults = analysis.slice().sort(
      (a, b) => String(a.analysis_result_title || a.analysis_result_id).localeCompare(
        String(b.analysis_result_title || b.analysis_result_id)
      )
    );
    metaLoaded = true;
    setStatus2("");
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    setStatus2(msg);
  } finally {
    metaBusy = false;
  }
}
async function loadValuesForAttribute(attribute) {
  const cached2 = valueCache.get(attribute);
  if (cached2) return cached2;
  if (attribute === "collection_id") {
    const opts2 = collections.map((c) => ({
      value: c.collection_id,
      label: c.collection_name ? `${c.collection_id} \u2014 ${c.collection_name}` : c.collection_id
    }));
    valueCache.set(attribute, opts2);
    return opts2;
  }
  if (attribute === "analysis_result_id") {
    const opts2 = analysisResults.map((a) => ({
      value: a.analysis_result_id,
      label: a.analysis_result_title ? `${a.analysis_result_id} \u2014 ${a.analysis_result_title}` : a.analysis_result_id
    }));
    valueCache.set(attribute, opts2);
    return opts2;
  }
  const attrInfo = attributes.find((a) => a.name === attribute);
  if (attrInfo && attrInfo.kind === "range") {
    valueCache.set(attribute, []);
    return [];
  }
  const res = await fetchIdcAttributeValues(attribute, 1e3);
  const opts = res.values.map((v2) => ({
    value: String(v2.value),
    label: v2.count != null ? `${v2.value} (${formatCount(v2.count)})` : String(v2.value)
  }));
  valueCache.set(attribute, opts);
  return opts;
}
function scheduleCounts() {
  if (countsTimer) clearTimeout(countsTimer);
  countsTimer = setTimeout(() => {
    void refreshCounts();
  }, COUNTS_DEBOUNCE_MS);
}
async function refreshCounts() {
  const gen = ++countsGen;
  const matching = el5("idcSearchMatching");
  if (!hasActivePredicates(query)) {
    counts = null;
    if (matching) {
      matching.textContent = "Matching: select at least one filter to see counts";
    }
    el5("idcSearchShowResultsBtn").disabled = true;
    return;
  }
  countsBusy = true;
  el5("idcSearchShowResultsBtn").disabled = true;
  if (matching) matching.textContent = "Matching: \u2026";
  try {
    const filters = searchQueryToIdcFilters(query);
    const next = await postIdcCohortCounts(filters);
    if (gen !== countsGen) return;
    counts = next;
    if (matching) {
      matching.textContent = `Matching: ${formatCount(next.patients)} patients \xB7 ${formatCount(next.studies)} studies \xB7 ${formatCount(next.series)} series`;
      if (next.warnings?.length) {
        matching.textContent += ` \u2014 ${next.warnings[0]}`;
      }
    }
    el5("idcSearchShowResultsBtn").disabled = false;
  } catch (err) {
    if (gen !== countsGen) return;
    const msg = err instanceof Error ? err.message : String(err);
    if (matching) matching.textContent = `Matching: ${msg}`;
    setStatus2(msg);
  } finally {
    if (gen === countsGen) countsBusy = false;
  }
}
async function showResults(nextPage = 0) {
  if (resultsBusy || !hasActivePredicates(query)) return;
  resultsBusy = true;
  page = nextPage;
  setStatus2("Loading series\u2026", true);
  const section = el5("idcSearchResultsSection");
  try {
    const filters = searchQueryToIdcFilters(query);
    const manifest = await postIdcCohortManifest({
      filters,
      page,
      pageSize: PAGE_SIZE
    });
    counts = manifest.counts;
    seriesRows = manifest.series || [];
    totalSeries = manifest.total_series || 0;
    addedKeys.clear();
    const matching = el5("idcSearchMatching");
    if (matching && counts) {
      matching.textContent = `Matching: ${formatCount(counts.patients)} patients \xB7 ${formatCount(counts.studies)} studies \xB7 ${formatCount(counts.series)} series`;
    }
    if (section) section.hidden = false;
    renderResults2();
    setStatus2(
      seriesRows.length ? `Showing ${seriesRows.length} of ${formatCount(totalSeries)} series` : "No series matched these filters."
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    setStatus2(msg);
  } finally {
    resultsBusy = false;
  }
}
function renderFilterRows(handlers) {
  const host = el5("idcSearchFilterRows");
  if (!host) return;
  host.replaceChildren();
  for (const filter of query.filters) {
    const row = document.createElement("div");
    row.className = "wl-idc-search-filter-row";
    row.dataset.filterId = filter.id;
    const label = document.createElement("label");
    label.className = "wl-idc-search-filter-label";
    label.textContent = filter.label;
    const controls = document.createElement("div");
    controls.className = "wl-idc-search-filter-controls";
    if (filter.type === "range") {
      const minInput = document.createElement("input");
      minInput.type = "number";
      minInput.className = "wl-idc-search-range";
      minInput.placeholder = "Min";
      minInput.value = filter.min != null ? String(filter.min) : "";
      minInput.addEventListener("change", () => {
        const v2 = minInput.value.trim();
        filter.min = v2 === "" ? void 0 : Number(v2);
        scheduleCounts();
      });
      const maxInput = document.createElement("input");
      maxInput.type = "number";
      maxInput.className = "wl-idc-search-range";
      maxInput.placeholder = "Max";
      maxInput.value = filter.max != null ? String(filter.max) : "";
      maxInput.addEventListener("change", () => {
        const v2 = maxInput.value.trim();
        filter.max = v2 === "" ? void 0 : Number(v2);
        scheduleCounts();
      });
      controls.append(minInput, maxInput);
    } else {
      const select = document.createElement("select");
      select.className = "wl-idc-search-select";
      const anyOpt = document.createElement("option");
      anyOpt.value = "";
      anyOpt.textContent = "Any";
      select.append(anyOpt);
      void loadValuesForAttribute(filter.attribute).then((opts) => {
        const current = filter.values?.[0] || "";
        for (const opt of opts) {
          const o = document.createElement("option");
          o.value = opt.value;
          o.textContent = opt.label;
          if (opt.value === current) o.selected = true;
          select.append(o);
        }
        if (!current) anyOpt.selected = true;
      }).catch((err) => {
        setStatus2(err instanceof Error ? err.message : String(err));
      });
      select.addEventListener("change", () => {
        const v2 = select.value.trim();
        filter.values = v2 ? [v2] : [];
        scheduleCounts();
      });
      controls.append(select);
    }
    row.append(label, controls);
    if (!filter.core) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "wl-idc-search-remove";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => {
        query.filters = query.filters.filter((f2) => f2.id !== filter.id);
        renderFilterRows(handlers);
        renderAddFilterPanel(handlers);
        scheduleCounts();
      });
      row.append(remove);
    }
    host.append(row);
  }
}
function usedAttributes() {
  return new Set(query.filters.map((f2) => f2.attribute));
}
function renderAddFilterPanel(handlers) {
  const panel = el5("idcSearchAddFilterPanel");
  if (!panel) return;
  panel.hidden = !addFilterOpen;
  if (!addFilterOpen) return;
  panel.replaceChildren();
  const search = document.createElement("input");
  search.type = "search";
  search.className = "wl-idc-search-add-search";
  search.placeholder = "Search filters\u2026";
  panel.append(search);
  const list = document.createElement("div");
  list.className = "wl-idc-search-add-list";
  panel.append(list);
  const used = usedAttributes();
  const attrByName = new Map(attributes.map((a) => [a.name, a]));
  const renderList = (q2) => {
    list.replaceChildren();
    const needle = q2.trim().toLowerCase();
    const appendGroup = (title, names) => {
      const filtered = names.filter((name) => {
        if (used.has(name)) return false;
        if (!attrByName.has(name)) return false;
        if (!needle) return true;
        const label = humanizeAttributeName(name).toLowerCase();
        return label.includes(needle) || name.toLowerCase().includes(needle);
      });
      if (!filtered.length) return;
      const h = document.createElement("div");
      h.className = "wl-idc-search-add-group";
      h.textContent = title;
      list.append(h);
      for (const name of filtered) {
        const info = attrByName.get(name);
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "wl-idc-search-add-item";
        btn.textContent = humanizeAttributeName(name);
        btn.title = info.description || name;
        btn.addEventListener("click", () => addFilter(handlers, info));
        list.append(btn);
      }
    };
    for (const group of ADD_FILTER_GROUPS) {
      appendGroup(group.label, group.attributes);
    }
    const advancedNames = attributes.map((a) => a.name).filter((name) => !CORE_FILTER_ATTRIBUTE_SET.has(name));
    appendGroup("Advanced", advancedNames);
  };
  search.addEventListener("input", () => renderList(search.value));
  renderList("");
}
var CORE_FILTER_ATTRIBUTE_SET = /* @__PURE__ */ new Set([
  "collection_id",
  "Modality",
  "BodyPartExamined",
  "analysis_result_id"
]);
function addFilter(handlers, info) {
  if (usedAttributes().has(info.name)) return;
  const filter = {
    id: nextFilterId("extra"),
    label: humanizeAttributeName(info.name),
    attribute: info.name,
    type: info.kind === "range" ? "range" : "term",
    values: [],
    core: false
  };
  query.filters.push(filter);
  addFilterOpen = false;
  renderFilterRows(handlers);
  renderAddFilterPanel(handlers);
  scheduleCounts();
}
function renderResults2() {
  const tbody = el5("idcSearchResultsBody");
  const pager = el5("idcSearchPager");
  if (!tbody) return;
  tbody.replaceChildren();
  seriesRows.forEach((row, index) => {
    const tr2 = document.createElement("tr");
    const key = rowKey(row, index);
    const cells = [
      String(row.collection_id || "\u2014"),
      String(row.PatientID || "\u2014"),
      truncateUid(String(row.StudyInstanceUID || "")),
      String(
        row.SeriesDescription || truncateUid(String(row.SeriesInstanceUID || "")) || "\u2014"
      ),
      String(row.Modality || "\u2014"),
      formatIdcSeriesSizeLabel(row)
    ];
    for (const text of cells) {
      const td = document.createElement("td");
      td.textContent = text;
      td.title = text;
      tr2.append(td);
    }
    const actions = document.createElement("td");
    actions.className = "wl-idc-search-actions";
    const addState = addedKeys.has(key) ? "added" : addingKeys.has(key) ? "adding" : "idle";
    actions.append(
      createWorklistStyleActions({
        canOpen: canViewIdcSeries(row),
        openDisabledTitle: "Missing CRDC UUID and SeriesInstanceUID",
        onOpen: () => {
          void viewSeries(row);
        },
        addState,
        canAdd: addState === "idle",
        onAdd: () => {
          void addSeries(row, key);
        }
      })
    );
    tr2.append(actions);
    tbody.append(tr2);
  });
  if (pager) {
    const maxPage = Math.max(0, Math.ceil(totalSeries / PAGE_SIZE) - 1);
    pager.hidden = totalSeries <= PAGE_SIZE;
    const prev = el5("idcSearchPrevBtn");
    const next = el5("idcSearchNextBtn");
    const label = el5("idcSearchPageLabel");
    if (prev) prev.disabled = page <= 0 || resultsBusy;
    if (next) next.disabled = page >= maxPage || resultsBusy;
    if (label) {
      label.textContent = `Page ${page + 1} of ${maxPage + 1}`;
    }
  }
}
async function viewSeries(row) {
  const state = handlersRef?.getState();
  if (!state) return;
  await viewIdcSeries(state, row, setStatus2);
}
async function addSeries(row, key) {
  if (!handlersRef || addedKeys.has(key) || addingKeys.has(key)) return;
  const state = handlersRef.getState();
  const orgLabel = el5("idcSearchOrgLabel")?.value?.trim() || DEFAULT_ORG_LABEL;
  const org = idcNlOrganizationId(`rest:${orgLabel}:${key}`);
  ensureIdcCustomWorklistEntry({
    organization: org,
    label: orgLabel,
    prompt: `IDC REST: ${JSON.stringify(searchQueryToIdcFilters(query))}`
  });
  addingKeys.add(key);
  renderResults2();
  setStatus2(`Adding ${row.collection_id || key}\u2026`, true);
  try {
    const sample = await resolveViaHubOrS3(state, row, org);
    sample.id = `idc-rest-${String(row.SeriesInstanceUID || key).slice(-24)}`;
    sample.name = idcSeriesDisplayName(row, sample.name);
    state.allStudies = upsertIdcSegmentationSample(state.allStudies, sample);
    addedKeys.add(key);
    const orgSelect = document.getElementById(
      "worklistOrgSelect"
    );
    if (orgSelect) {
      refreshOrgSelectWithCustomWorklists(orgSelect);
      handlersRef.setOrgFilter(org);
    }
    handlersRef.onStudiesChanged();
    setStatus2(`Added ${sample.name}.`);
  } catch (err) {
    setStatus2(err instanceof Error ? err.message : String(err));
  } finally {
    addingKeys.delete(key);
    renderResults2();
  }
}
var handlersRef = null;
function wireOnce2(handlers) {
  if (wired3) return;
  wired3 = true;
  handlersRef = handlers;
  document.querySelectorAll("[data-close-idc-search]").forEach((node) => {
    node.addEventListener("click", () => closeIdcSearchDialog());
  });
  el5("idcSearchModal")?.addEventListener("click", (ev) => {
    if (ev.target === ev.currentTarget) closeIdcSearchDialog();
  });
  el5("idcSearchAddFilterBtn")?.addEventListener(
    "click",
    () => {
      addFilterOpen = !addFilterOpen;
      renderAddFilterPanel(handlers);
    }
  );
  el5("idcSearchShowResultsBtn")?.addEventListener(
    "click",
    () => {
      void showResults(0);
    }
  );
  el5("idcSearchPrevBtn")?.addEventListener("click", () => {
    if (page > 0) void showResults(page - 1);
  });
  el5("idcSearchNextBtn")?.addEventListener("click", () => {
    void showResults(page + 1);
  });
}
function openIdcSearchDialog(handlers) {
  const overlay = el5("idcSearchModal");
  if (!overlay) return;
  handlersRef = handlers;
  wireOnce2(handlers);
  if (!query.filters.length) {
    query = createCoreSearchQuery();
  } else {
    query = cloneSearchQuery(query);
  }
  const orgLabel = el5("idcSearchOrgLabel");
  if (orgLabel && !orgLabel.value.trim()) {
    orgLabel.value = DEFAULT_ORG_LABEL;
  }
  addFilterOpen = false;
  seriesRows = [];
  const section = el5("idcSearchResultsSection");
  if (section) section.hidden = true;
  overlay.hidden = false;
  setStatus2("");
  void ensureMeta().then(() => {
    renderFilterRows(handlers);
    renderAddFilterPanel(handlers);
    scheduleCounts();
  });
}
function closeIdcSearchDialog() {
  const overlay = el5("idcSearchModal");
  if (overlay) overlay.hidden = true;
  addFilterOpen = false;
}

// ../websub-worker-clients/dist/websub-worker-clients.js
var f = Object.freeze([
  {
    name: "bamf_nnunet_ct_kidney",
    label: "BAMF CT Kidney Seg (nnU-Net)",
    description: "An nnU-Net based model to segment kidney from CT scans",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Kidney"
    ],
    segments: [
      "KIDNEY",
      "KIDNEY+NEOPLASM_MALIGNANT_PRIMARY",
      "KIDNEY+CYST"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_nnunet_ct_kidney",
    githubUrl: "https://github.com/bamf-health/aimi-kidney-ct",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "bamf_nnunet_ct_liver",
    label: "BAMF CT Liver Seg (nnU-Net)",
    description: "An nnU-Net based model to segment liver from CT scans",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Liver"
    ],
    segments: [
      "LIVER"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_nnunet_ct_liver",
    githubUrl: "https://github.com/bamf-health/aimi-liver-ct",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "bamf_nnunet_mr_liver",
    label: "BAMF MR Liver Seg (nnU-Net)",
    description: "An nnU-Net based model to segment liver from T1 weighted MRI scans",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Liver"
    ],
    segments: [
      "LIVER"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_nnunet_mr_liver",
    githubUrl: "https://github.com/bamf-health/aimi-liver-mr",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "bamf_nnunet_mr_prostate",
    label: "BAMF MR Prostate Seg (nnU-Net)",
    description: "bamf_nnunet_mr_prostate model is a semantic segmentation model where an NNUnet model is finetuned for MR images",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Prostate"
    ],
    segments: [
      "PROSTATE"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_nnunet_mr_prostate",
    githubUrl: "https://github.com/bamf-health/aimi-prostate-mr",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "bamf_pet_ct_breast_tumor",
    label: "BAMF PET CT Breast Seg (nnU-Net)",
    description: "This model used to detect FDG-avid lesions in breast from FDG PET/CT scans",
    modalities: [
      "CT",
      "PT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Breast"
    ],
    segments: [
      "BREAST+FDG_AVID_TUMOR"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_pet_ct_breast_tumor",
    githubUrl: "https://github.com/bamf-health/aimi-breast-pet-ct",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "casust",
    label: "CaSuSt",
    description: "A deep learning model for cardiac sub-structure delineation on planning CT scans. The model delineates the heart contours and seven cardiac substructures based on individually trained binary models.",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "HEART",
      "LEFT_VENTRICLE",
      "RIGHT_VENTRICLE",
      "LEFT_ATRIUM",
      "RIGHT_ATRIUM",
      "CORONARY_ARTERY_LAD",
      "CORONARY_ARTERY_CFLX",
      "CORONARY_ARTERY_RIGHT"
    ],
    websiteUrl: "https://mhub.ai/models/casust",
    githubUrl: "https://github.com/LennyN95/CaSuSt",
    cite: "N\xFCrnberg, L, Bontempi, D, De Ruysscher, D, et al. Deep learning segmentation of heart substructures in radiotherapy treatment planning. Physica Medica: European journal of medical physics, 2022",
    citeUrl: "https://cris.maastrichtuniversity.nl/en/publications/deep-learning-segmentation-of-heart-substructures-in-radiotherapy"
  },
  {
    name: "gc_node21_baseline",
    label: "Chest Radiograph Nodule Locator (NODE21 Baseline)",
    description: "This model detects the location of nodules in Chest radiographs, and generates bounding boxes around these nodules.",
    modalities: [
      "CR"
    ],
    category: "Prediction",
    bodyParts: [
      "Chest"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_node21_baseline",
    githubUrl: "https://github.com/node21challenge/node21_detection_baseline",
    cite: "E. Sogancioglu et al., Nodule detection and generation on chest X-rays: NODE21 Challenge, in IEEE Transactions on Medical Imaging, doi: 10.1109/TMI.2024.3382042.",
    citeUrl: "https://doi.org/10.1109/TMI.2024.3382042"
  },
  {
    name: "nnunet_liver",
    label: "CT Liver Seg (nnU-Net)",
    description: "nnU-Net's liver segmentation model is an AI-based pipeline for the automated segmentation of the liver and liver cancer in portal venous phase CT scans.",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Abdomen"
    ],
    segments: [
      "LIVER",
      "LIVER+NEOPLASM_MALIGNANT_PRIMARY"
    ],
    websiteUrl: "https://mhub.ai/models/nnunet_liver",
    githubUrl: "https://github.com/MIC-DKFZ/nnUNet/tree/nnunetv1",
    cite: "Isensee, F., Jaeger, P. F., Kohl, S. A., Petersen, J., & Maier-Hein, K. H. (2020). nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods, 1-9.",
    citeUrl: "https://www.nature.com/articles/s41592-020-01008-z"
  },
  {
    name: "gc_grt123_lung_cancer",
    label: "CT Lung cancer risk prediction",
    description: "This algorithm analyzes non-contrast CT scans of the thorax and predicts the lung cancer risk. The model consists of two modules. The first one is a 3D region proposal network for nodule detection, which outputs all suspicious nodules for a subject. The second one selects the top five nodules based on the detection confidence, evaluates their cancer probabilities and combines them with a leaky noisy-or gate to obtain the probability of lung cancer for the subject. This model was the winner of the Data Science Bowl 2017 competition hosted on Kaggle.",
    modalities: [
      "CT"
    ],
    category: "Prediction",
    bodyParts: [
      "Chest"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_grt123_lung_cancer",
    githubUrl: "https://github.com/DIAGNijmegen/bodyct-dsb2017-grt123",
    cite: "F. Liao, M. Liang, Z. Li, X. Hu and S. Song, 'Evaluate the Malignancy of Pulmonary Nodules Using the 3D Deep Leaky Noisy-or Network', in IEEE Transactions on Neural Networks and Learning Systems, vol. 30, no. 11, pp. 3484-3495, Nov. 2019, doi: 10.1109/TNNLS.2019.2892409.",
    citeUrl: "https://doi.org/10.1109/TNNLS.2019.2892409"
  },
  {
    name: "bamf_pet_ct_lung_tumor",
    label: "FDG PET/CT Lung and Lung Tumor Annotation",
    description: "An nnU-Net based model to segment Lung and FDG-avid lesions in the lung from FDG PET/CT scans",
    modalities: [
      "CT",
      "PT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Lung"
    ],
    segments: [
      "LUNG",
      "LUNG+FDG_AVID_TUMOR"
    ],
    websiteUrl: "https://mhub.ai/models/bamf_pet_ct_lung_tumor",
    githubUrl: "https://github.com/bamf-health/aimi-lung-pet-ct",
    cite: "Murugesan, Gowtham Krishnan, Diana McCrumb, Mariam Aboian, Tej Verma, Rahul Soni, Fatima Memon, and Jeff Van Oss. The AIMI Initiative: AI-Generated Annotations for Imaging Data Commons Collections. arXiv preprint arXiv:2310.14897 (2023).",
    citeUrl: "https://arxiv.org/abs/2310.14897"
  },
  {
    name: "fmcib_radiomics",
    label: "Foundation Model for Cancer Imaging Biomarkers",
    description: "A foundation model for cancer imaging biomarker discovery trained through self-supervised learning using a dataset of 11,467 radiographic lesions. The model features can be used as a data-driven substitute for classical radiomic features",
    modalities: [
      "CT",
      "SEG"
    ],
    category: "Prediction",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/fmcib_radiomics",
    githubUrl: "https://github.com/AIM-Harvard/foundation-cancer-image-biomarker",
    cite: "Pai, S., Bontempi, D., Hadzic, I. et al. Foundation model for cancer imaging biomarkers. Nat Mach Intell (2024). https://doi.org/10.1038/s42256-024-00807-9",
    citeUrl: "https://doi.org/10.1038/s42256-024-00807-9"
  },
  {
    name: "lungmask",
    label: "LungMask",
    description: "LungMask is an AI-based pipeline for the automated lungs and pulmonary lobes segmentation in CT (robust to the presence of severe pathologies).",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "RIGHT_LUNG",
      "LEFT_LUNG",
      "LEFT_UPPER_LUNG_LOBE",
      "LEFT_LOWER_LUNG_LOBE",
      "RIGHT_UPPER_LUNG_LOBE",
      "RIGHT_MIDDLE_LUNG_LOBE",
      "RIGHT_LOWER_LUNG_LOBE"
    ],
    websiteUrl: "https://mhub.ai/models/lungmask",
    githubUrl: "https://github.com/JoHof/lungmask",
    cite: "Hofmanninger, J., Prayer, F., Pan, J. et al. Automatic lung segmentation in routine imaging is primarily a data diversity problem, not a methodology problem. Eur Radiol Exp 4, 50 (2020). https://doi.org/10.1186/s41747-020-00173-2",
    citeUrl: "https://doi.org/10.1186/s41747-020-00173-2"
  },
  {
    name: "mrsegmentator",
    label: "MRSegmentator",
    description: "MRSegmentator is an AI-based pipeline for the segmentation of 40 anatomical structures in MR images (with and without contrast).",
    modalities: [
      "MRI|CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [
      "SPLEEN",
      "RIGHT_KIDNEY",
      "LEFT_KIDNEY",
      "GALLBLADDER",
      "LIVER",
      "STOMACH",
      "PANCREAS",
      "RIGHT_ADRENAL_GLAND",
      "LEFT_ADRENAL_GLAND",
      "LEFT_LUNG",
      "RIGHT_LUNG",
      "HEART",
      "AORTA",
      "INFERIOR_VENA_CAVA",
      "PORTAL_AND_SPLENIC_VEIN",
      "LEFT_ILIAC_ARTERY",
      "RIGHT_ILIAC_ARTERY",
      "ESOPHAGUS",
      "SMALL_INTESTINE",
      "DUODENUM",
      "COLON",
      "URINARY_BLADDER",
      "SPINE",
      "SACRUM",
      "LEFT_HIP",
      "RIGHT_HIP",
      "LEFT_FEMUR",
      "RIGHT_FEMUR",
      "LEFT_AUTOCHTHONOUS_BACK_MUSCLE",
      "RIGHT_AUTOCHTHONOUS_BACK_MUSCLE",
      "LEFT_ILIOPSOAS",
      "RIGHT_ILIOPSOAS",
      "LEFT_GLUTEUS_MAXIMUS",
      "RIGHT_GLUTEUS_MAXIMUS",
      "LEFT_GLUTEUS_MEDIUS",
      "RIGHT_GLUTEUS_MEDIUS",
      "LEFT_GLUTEUS_MINIMUS",
      "RIGHT_GLUTEUS_MINIMUS"
    ],
    websiteUrl: "https://mhub.ai/models/mrsegmentator",
    githubUrl: "https://github.com/hhaentze/MRSegmentator",
    cite: "Hartmut H\xE4ntze, Lina Xu, Felix J. Dorfner, Leonhard Donle, Daniel Truhn, Hugo Aerts, Mathias Prokop, Bram van Ginneken, Alessa Hering, Lisa C. Adams, and Keno K. Bressem. MRSegmentator: Robust multi-modality segmentation of 40 classes in MRI and CT sequences. arXiv, 2024.",
    citeUrl: "https://arxiv.org/pdf/2405.06463"
  },
  {
    name: "nnunet_pancreas",
    label: "Pancreas Seg (nnU-Net)",
    description: "nnU-Net's pancreas segmentation model is an AI-based pipeline for the automated segmentation of the pancreas and pancreatic cancer in portal venous phase CT scans.",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Abdomen"
    ],
    segments: [
      "PANCREAS",
      "PANCREAS+NEOPLASM_MALIGNANT_PRIMARY"
    ],
    websiteUrl: "https://mhub.ai/models/nnunet_pancreas",
    githubUrl: "https://github.com/MIC-DKFZ/nnUNet/tree/nnunetv1",
    cite: "Isensee, F., Jaeger, P. F., Kohl, S. A., Petersen, J., & Maier-Hein, K. H. (2020). nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods, 1-9.",
    citeUrl: "https://www.nature.com/articles/s41592-020-01008-z"
  },
  {
    name: "gc_nnunet_pancreas",
    label: "Pancreatic Ductal Adenocarcinoma Detection in CT",
    description: "This algorithm produces a tumor likelihood heatmap for the presence of pancreatic ductal adenocarcinoma (PDAC) in an input venous-phase contrast-enhanced computed tomography scan (CECT). Additionally, the algorithm provides the segmentation of multiple surrounding anatomical structures such as the pancreatic duct, common bile duct, veins and arteries. The heatmap and segmentations are resampled to the same spatial resolution and physical dimensions as the input CECT image for easier visualisation.",
    modalities: [
      "CT"
    ],
    category: "Prediction",
    bodyParts: [
      "Abdomen"
    ],
    segments: [
      "VEIN",
      "ARTERY",
      "PANCREAS",
      "PANCREATIC_DUCT",
      "BILE_DUCT"
    ],
    websiteUrl: "https://mhub.ai/models/gc_nnunet_pancreas",
    githubUrl: "https://github.com/DIAGNijmegen/CE-CT_PDAC_AutomaticDetection_nnUnet",
    cite: "Alves N, Schuurmans M, Litjens G, Bosma JS, Hermans J, Huisman H. Fully Automatic Deep Learning Framework for Pancreatic Ductal Adenocarcinoma Detection on Computed Tomography. Cancers (Basel). 2022 Jan 13;14(2):376. doi: 10.3390/cancers14020376. PMID: 35053538; PMCID: PMC8774174.",
    citeUrl: "https://doi.org/10.3390/cancers14020376"
  },
  {
    name: "gc_picai_baseline",
    label: "PI-CAI challenge baseline",
    description: "This algorithm predicts a detection map for the likelihood of clinically significant prostate cancer (csPCa) using biparametric MRI (bpMRI). The algorithm ensembles 5-fold cross-validation models that were trained on the PI-CAI: Public Training and Development Dataset v2.0. The detection map is at the same spatial resolution and physical dimensions as the input axial T2-weighted image. This model algorithm was used as a baseline for the PI-CAI challenge hosted on Grand Challenge.",
    modalities: [
      "MR"
    ],
    category: "Prediction",
    bodyParts: [
      "Prostate"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_picai_baseline",
    githubUrl: "https://github.com/DIAGNijmegen/picai_nnunet_semi_supervised_gc_algorithm",
    cite: 'J. S. Bosma, A. Saha, M. Hosseinzadeh, I. Slootweg, M. de Rooij, and H. Huisman, "Semisupervised Learning with Report-guided Pseudo Labels for Deep Learning\u2013based Prostate Cancer Detection Using Biparametric MRI", Radiology: Artificial Intelligence, 230031, 2023. DOI: 10.1148/ryai.230031',
    citeUrl: "https://doi.org/10.1148/ryai.230031"
  },
  {
    name: "platipy",
    label: "Platipy",
    description: "Platipy's cardiac substructures segmentation model is a hybrid pipeline (AI- and atlas-based) for the automated segmentation of 16 cardiac substructures in CT scans (with and without contrast).",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "HEART",
      "AORTA",
      "LEFT_ATRIUM",
      "LEFT_VENTRICLE",
      "RIGHT_ATRIUM",
      "RIGHT_VENTRICLE",
      "CORONARY_ARTERY_LAD",
      "CORONARY_ARTERY_CFLX",
      "CORONARY_ARTERY_RIGHT",
      "PULMONARY_ARTERY",
      "SINOTRIAL_NODE",
      "TRICUSPID_VALVE",
      "PULMONARY_VALVE",
      "MITRAL_VALVE",
      "SUPERIOR_VENA_CAVA",
      "AORTIC_VALVE",
      "ATRIOVENTRICULAR_NODE"
    ],
    websiteUrl: "https://mhub.ai/models/platipy",
    githubUrl: "https://github.com/pyplati/platipy",
    cite: "Finnegan, R.N., Chin, V., Chlap, P. et al. Open-source, fully-automated hybrid cardiac substructure segmentation: development and optimisation. Phys Eng Sci Med 46, 377\u2013393 (2023).",
    citeUrl: "https://link.springer.com/article/10.1007/s13246-023-01231-w"
  },
  {
    name: "nnunet_prostate_zonal_task05",
    label: "Prostate Transitional and Peripheral Zone Seg (nnU-Net)",
    description: "nnU-Net's zonal prostate segmentation model is a multi-modality input AI-based pipeline for the automated segmentation of the peripheral and transition zone of the prostate on MRI scans.",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Prostate"
    ],
    segments: [
      "PROSTATE_PERIPHERAL_ZONE",
      "PROSTATE_TRANSITION_ZONE"
    ],
    websiteUrl: "https://mhub.ai/models/nnunet_prostate_zonal_task05",
    githubUrl: "https://github.com/MIC-DKFZ/nnUNet/tree/nnunetv1",
    cite: "Isensee, F., Jaeger, P. F., Kohl, S. A., Petersen, J., & Maier-Hein, K. H. (2020). nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods, 1-9.",
    citeUrl: "https://www.nature.com/articles/s41592-020-01008-z"
  },
  {
    name: "monai_prostate158",
    label: "Prostate Transitional and Peripheral Zone Seg (Prostate158)",
    description: "Prostate158 is a zonal prostate segmentation model, a multi-modality input AI-based pipeline for the automated segmentation of the peripheral and central gland of the prostate on MRI T2 axial scans.",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Prostate"
    ],
    segments: [
      "PROSTATE_TRANSITION_ZONE",
      "PROSTATE_PERIPHERAL_ZONE"
    ],
    websiteUrl: "https://mhub.ai/models/monai_prostate158",
    githubUrl: "https://github.com/Project-MONAI/model-zoo/tree/dev/models/prostate_mri_anatomy",
    cite: "Lisa C. Adams and Marcus R. Makowski and G\xFCnther Engel and Maximilian Rattunde and Felix Busch and Patrick Asbach and Stefan M. Niehues and Shankeeth Vinayahalingam and Bram {van Ginneken} and Geert Litjens and Keno K. Bressem, Prostate158 - An expert-annotated 3T MRI dataset and algorithm for prostate cancer detection",
    citeUrl: "https://doi.org/10.1016/j.compbiomed.2022.105817"
  },
  {
    name: "gc_lunglobes",
    label: "Pulmonary Lobes Seg (RTSU-Net)",
    description: "RTSU-Net is an AI-based pipeline for the automated pulmonary lobes segmentation in CT (robust to the presence of severe pathologies).",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "LEFT_UPPER_LUNG_LOBE",
      "LEFT_LOWER_LUNG_LOBE",
      "RIGHT_UPPER_LUNG_LOBE",
      "RIGHT_MIDDLE_LUNG_LOBE",
      "RIGHT_LOWER_LUNG_LOBE"
    ],
    websiteUrl: "https://mhub.ai/models/gc_lunglobes",
    githubUrl: "https://github.com/DIAGNijmegen/bodyct-pulmonary-lobe-segmentation",
    cite: "W. Xie, C. Jacobs, J. -P. Charbonnier and B. van Ginneken, 'Relational Modeling for Robust and Efficient Pulmonary Lobe Segmentation in CT Scans,' in IEEE Transactions on Medical Imaging, vol. 39, no. 8, pp. 2664-2675, Aug. 2020, doi: 10.1109/TMI.2020.2995108.",
    citeUrl: "https://doi.org/10.1109/TMI.2020.2995108"
  },
  {
    name: "pyradiomics",
    label: "PyRadiomics",
    description: "Run PyRadiomics directly on DICOM files with MHub.",
    modalities: [
      "CT",
      "SEG"
    ],
    category: "Prediction",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/pyradiomics",
    githubUrl: "https://github.com/AIM-Harvard/pyradiomics",
    cite: "van Griethuysen JJM, Fedorov A, Parmar C, Hosny A, Aucoin N, Narayan V, Beets-Tan RGH, Fillion-Robin JC, Pieper S, Aerts HJWL. Computational Radiomics System to Decode the Radiographic Phenotype. Cancer Res. 2017 Nov 1;77(21):e104-e107. doi: 10.1158/0008-5472.CAN-17-0339. PMID: 29092951; PMCID: PMC5672828.",
    citeUrl: "https://doi.org/10.1158/0008-5472.CAN-17-0339"
  },
  {
    name: "gc_autopet_fpr",
    label: "Second place in AutoPET challenge: False Positive Reduction Network",
    description: "This algorithm segments tumor lesions in whole-body FDG-PET/CT. To prevent over-segmenting tumor regions due to high-uptake organs or inflammations, the model uses a false positive reduction network. First a self-supervised pre-trained global segmentation module coarsely delineates the candidate tumor regions using a self-supervised pre-trained encoder. The candidate tumor regions are then refined by removing false positives via a local refinement module.",
    modalities: [
      "PT",
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [
      "BACKGROUND",
      "NEOPLASM_MALIGNANT_PRIMARY"
    ],
    websiteUrl: "https://mhub.ai/models/gc_autopet_fpr",
    githubUrl: "https://github.com/YigePeng/AutoPET_False_Positive_Reduction",
    cite: "Y. Peng, J. Kim, D. Feng and L. Bi, 'Automatic Tumor Segmentation via False Positive Reduction Network for Whole-Body Multi-Modal PET/CT Images', In arXiv:2209.07705, doi: 10.48550/arXiv:2209.07705.",
    citeUrl: "https://arxiv.org/abs/2209.07705"
  },
  {
    name: "msk_smit_lung_gtv",
    label: "SMIT Self-supervised Lung GTV Segmentation",
    description: "A Lung GTV segmentation model, fine-tuned from a foundation model pretrained with 10K CT scans",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "LUNG+NEOPLASM_MALIGNANT_PRIMARY"
    ],
    websiteUrl: "https://mhub.ai/models/msk_smit_lung_gtv",
    githubUrl: "https://github.com/The-Veeraraghavan-Lab/CTRobust_Transformers.git",
    cite: "Jiang, Jue, and Harini Veeraraghavan. Self-supervised pretraining in the wild imparts image acquisition robustness to medical image transformers: an application to lung cancer segmentation. Proceedings of machine learning research 250 (2024): 708.",
    citeUrl: "https://openreview.net/pdf?id=G9Te2IevNm"
  },
  {
    name: "gc_spider_baseline",
    label: "Spine Seg (SPIDER Baseline)",
    description: "This model segments three anatomical structures in lumbar spine MRI: vertebrae, intervertebral discs (IVDs), and spinal canal. Each vertebrae and IVD is labeled according to standard naming convention.",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Spine"
    ],
    segments: [
      "VERTEBRAE_L5",
      "VERTEBRAE_L4",
      "VERTEBRAE_L3",
      "VERTEBRAE_L2",
      "VERTEBRAE_L1",
      "VERTEBRAE_T12",
      "VERTEBRAE_T11",
      "VERTEBRAE_T10",
      "VERTEBRAE_T9",
      "VERTEBRAE_T8",
      "VERTEBRAE_T7",
      "VERTEBRAE_T6",
      "VERTEBRAE_T5",
      "VERTEBRAE_T4",
      "VERTEBRAE_T3",
      "VERTEBRAE_T2",
      "VERTEBRAE_T1",
      "VERTEBRAE_C7",
      "VERTEBRAE_C6",
      "VERTEBRAE_C5",
      "VERTEBRAE_C4",
      "VERTEBRAE_C3",
      "VERTEBRAE_C2",
      "VERTEBRAE_C1",
      "VERTEBRAE_DISK_L5S1",
      "VERTEBRAE_DISK_L4L5",
      "VERTEBRAE_DISK_L3L4",
      "VERTEBRAE_DISK_L2L3",
      "VERTEBRAE_DISK_L1L2",
      "VERTEBRAE_DISK_T12L1",
      "VERTEBRAE_DISK_T11T12",
      "VERTEBRAE_DISK_T10T11",
      "VERTEBRAE_DISK_T9T10",
      "VERTEBRAE_DISK_T8T9",
      "VERTEBRAE_DISK_T7T8",
      "VERTEBRAE_DISK_T6T7",
      "VERTEBRAE_DISK_T5T6",
      "VERTEBRAE_DISK_T4T5",
      "VERTEBRAE_DISK_T3T4",
      "VERTEBRAE_DISK_T2T3",
      "VERTEBRAE_DISK_T1T2",
      "VERTEBRAE_DISK_C7T1",
      "VERTEBRAE_DISK_C6C7",
      "VERTEBRAE_DISK_C5C6",
      "VERTEBRAE_DISK_C4C5",
      "VERTEBRAE_DISK_C3C4",
      "VERTEBRAE_DISK_C2C3",
      "SPINAL_CANAL"
    ],
    websiteUrl: "https://mhub.ai/models/gc_spider_baseline",
    githubUrl: "https://github.com/DIAGNijmegen/SPIDER-Baseline-IIS",
    cite: "van der Graaf, J.W., van Hooff, M.L., Buckens, C.F.M. et al. Lumbar spine segmentation in MR images: a dataset and a public benchmark. Sci Data 11, 264 (2024). doi: 10.1038/s41597-024-03090-w",
    citeUrl: "https://doi.org/10.1038/s41597-024-03090-w"
  },
  {
    name: "gc_stoic_baseline",
    label: "STOIC2021 baseline",
    description: "This model predicts the probability and severity of COVID-19 in lung-CT scans. Severe COVID-19 is defined as patient intubation or death within one month from the acquisition of the CT scan.",
    modalities: [
      "CT"
    ],
    category: "Prediction",
    bodyParts: [
      "Chest"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_stoic_baseline",
    githubUrl: "https://github.com/luukboulogne/stoic2021-baseline",
    cite: "Luuk H. Boulogne, Julian Lorenz, Daniel Kienzle, Robin Schon, Katja Ludwig, Rainer Lienhart, Simon Jegou, Guang Li, Cong Chen, Qi Wang, Derik Shi, Mayug Maniparambil, Dominik Muller, Silvan Mertes, Niklas Schroter, Fabio Hellmann, Miriam Elia, Ine Dirks, Matias Nicolas Bossa, Abel Diaz Berenguer, Tanmoy Mukherjee, Jef Vandemeulebroucke, Hichem Sahli, Nikos Deligiannis, Panagiotis Gonidakis, Ngoc Dung Huynh, Imran Razzak, Reda Bouadjenek, Mario Verdicchio, Pasquale Borrelli, Marco Aiello, James A. Meakin, Alexander Lemm, Christoph Russ, Razvan Ionasec, Nikos Paragios, Bram van Ginneken, Marie-Pierre Revel Dubois, The STOIC2021 COVID-19 AI challenge: applying reusable training methodologies to private data, arXiv:2306.10484, 2023, https://arxiv.org/abs/2306.10484v2",
    citeUrl: "https://arxiv.org/abs/2306.10484v2"
  },
  {
    name: "nnunet_segthor",
    label: "Thoracic OAR (nnU-Net)",
    description: "nnU-Net's thoracic OAR segmentation model is an AI-based pipeline for the automated segmentation of the heart, the aorta, the esophagus and the trachea in CT scans (with and without contrast).",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "Chest"
    ],
    segments: [
      "ESOPHAGUS",
      "HEART",
      "TRACHEA",
      "AORTA"
    ],
    websiteUrl: "https://mhub.ai/models/nnunet_segthor",
    githubUrl: "https://github.com/MIC-DKFZ/nnUNet/tree/nnunetv1",
    cite: "Isensee, F., Jaeger, P. F., Kohl, S. A., Petersen, J., & Maier-Hein, K. H. (2020). nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods, 1-9.",
    citeUrl: "https://www.nature.com/articles/s41592-020-01008-z"
  },
  {
    name: "gc_tiger_lb2",
    label: "TIGER challenge winner: Team VUNO",
    description: "This algorithm predicts the percentage of stromal area covered by tumour infiltrating lymphocytes (TIL) on H&E-stained whole-slide images of breast cancer histopathology. This algorithm first segments invasive tumor and tumor-associated stroma and subsequently detects lymphocytes and plasma cells, which are finally combined to estimate the relevant regions for TIL estimation. This model algorithm was the challenge winner of the TIGER challenge hosted on Grand Challenge.",
    modalities: [
      "SM"
    ],
    category: "Prediction",
    bodyParts: [
      "Breast"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_tiger_lb2",
    githubUrl: "https://github.com/vuno/tiger_challenge",
    citeUrl: "https://github.com/vuno/tiger_challenge/blob/720f8dfca4624792c8e57915c4222efec5a0c2d4/figure/method_description.pdf"
  },
  {
    name: "gc_wsi_bgseg",
    label: "Tissue-Background segmentation in histopathological whole-slide images",
    description: "This algorithm segments the background and tissue in histopathological whole-slide images.",
    modalities: [
      "SM"
    ],
    category: "Prediction",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [],
    websiteUrl: "https://mhub.ai/models/gc_wsi_bgseg",
    githubUrl: "https://github.com/DIAGNijmegen/pathology-tissue-background-segmentation-processor",
    cite: "B\xE1ndi P, Balkenhol M, van Ginneken B, van der Laak J, Litjens G. 2019. Resolution-agnostic tissue segmentation in whole-slide histopathology images with convolutional neural networks. PeerJ 7:e8242",
    citeUrl: "https://peerj.com/articles/8242/"
  },
  {
    name: "totalsegmentator",
    label: "TotalSegmentator",
    description: "TotalSegmentator is an AI-based pipeline for the segmentation of 104 anatomical structures in CT images (with and without contrast).",
    modalities: [
      "CT"
    ],
    category: "Segmentation",
    bodyParts: [
      "WHOLEBODY"
    ],
    segments: [
      "SPLEEN",
      "RIGHT_KIDNEY",
      "LEFT_KIDNEY",
      "GALLBLADDER",
      "LIVER",
      "STOMACH",
      "AORTA",
      "INFERIOR_VENA_CAVA",
      "PORTAL_AND_SPLENIC_VEIN",
      "PANCREAS",
      "RIGHT_ADRENAL_GLAND",
      "LEFT_ADRENAL_GLAND",
      "LEFT_UPPER_LUNG_LOBE",
      "LEFT_LOWER_LUNG_LOBE",
      "RIGHT_UPPER_LUNG_LOBE",
      "RIGHT_MIDDLE_LUNG_LOBE",
      "RIGHT_LOWER_LUNG_LOBE",
      "VERTEBRAE_L5",
      "VERTEBRAE_L4",
      "VERTEBRAE_L3",
      "VERTEBRAE_L2",
      "VERTEBRAE_L1",
      "VERTEBRAE_T12",
      "VERTEBRAE_T11",
      "VERTEBRAE_T10",
      "VERTEBRAE_T9",
      "VERTEBRAE_T8",
      "VERTEBRAE_T7",
      "VERTEBRAE_T6",
      "VERTEBRAE_T5",
      "VERTEBRAE_T4",
      "VERTEBRAE_T3",
      "VERTEBRAE_T2",
      "VERTEBRAE_T1",
      "VERTEBRAE_C7",
      "VERTEBRAE_C6",
      "VERTEBRAE_C5",
      "VERTEBRAE_C4",
      "VERTEBRAE_C3",
      "VERTEBRAE_C2",
      "VERTEBRAE_C1",
      "ESOPHAGUS",
      "TRACHEA",
      "MYOCARDIUM",
      "LEFT_ATRIUM",
      "LEFT_VENTRICLE",
      "RIGHT_ATRIUM",
      "RIGHT_VENTRICLE",
      "PULMONARY_ARTERY",
      "BRAIN",
      "LEFT_ILIAC_ARTERY",
      "RIGHT_ILIAC_ARTERY",
      "LEFT_ILIAC_VEIN",
      "RIGHT_ILIAC_VEIN",
      "SMALL_INTESTINE",
      "DUODENUM",
      "COLON",
      "LEFT_RIB_1",
      "LEFT_RIB_2",
      "LEFT_RIB_3",
      "LEFT_RIB_4",
      "LEFT_RIB_5",
      "LEFT_RIB_6",
      "LEFT_RIB_7",
      "LEFT_RIB_8",
      "LEFT_RIB_9",
      "LEFT_RIB_10",
      "LEFT_RIB_11",
      "LEFT_RIB_12",
      "RIGHT_RIB_1",
      "RIGHT_RIB_2",
      "RIGHT_RIB_3",
      "RIGHT_RIB_4",
      "RIGHT_RIB_5",
      "RIGHT_RIB_6",
      "RIGHT_RIB_7",
      "RIGHT_RIB_8",
      "RIGHT_RIB_9",
      "RIGHT_RIB_10",
      "RIGHT_RIB_11",
      "RIGHT_RIB_12",
      "LEFT_HUMERUS",
      "RIGHT_HUMERUS",
      "LEFT_SCAPULA",
      "RIGHT_SCAPULA",
      "LEFT_CLAVICLE",
      "RIGHT_CLAVICLE",
      "LEFT_FEMUR",
      "RIGHT_FEMUR",
      "LEFT_HIP",
      "RIGHT_HIP",
      "SACRUM",
      "FACE",
      "LEFT_GLUTEUS_MAXIMUS",
      "RIGHT_GLUTEUS_MAXIMUS",
      "LEFT_GLUTEUS_MEDIUS",
      "RIGHT_GLUTEUS_MEDIUS",
      "LEFT_GLUTEUS_MINIMUS",
      "RIGHT_GLUTEUS_MINIMUS",
      "LEFT_AUTOCHTHONOUS_BACK_MUSCLE",
      "RIGHT_AUTOCHTHONOUS_BACK_MUSCLE",
      "LEFT_ILIOPSOAS",
      "RIGHT_ILIOPSOAS",
      "URINARY_BLADDER"
    ],
    websiteUrl: "https://mhub.ai/models/totalsegmentator",
    githubUrl: "https://github.com/wasserth/TotalSegmentator",
    cite: "Jakob Wasserthal, Hanns-Christian Breit, Manfred T. Meyer, Maurice Pradella, Daniel Hinck, Alexander W. Sauter, Tobias Heye, Daniel T. Boll, Joshy Cyriac, Shan Yang, Michael Bach, and Martin Segeroth (2023). TotalSegmentator: Robust Segmentation of 104 Anatomic Structures in CT Images. Radiology Artificial Intelligence, 5:5",
    citeUrl: "https://pubs.rsna.org/doi/10.1148/ryai.230024"
  },
  {
    name: "nnunet_prostate_task24",
    label: "Whole Prostate Seg (nnU-Net)",
    description: "nnU-Net's whole prostate segmentation model is a single-modality (i.e. T2) input AI-based pipeline for the automated segmentation of the whole prostate on MRI scans.",
    modalities: [
      "MR"
    ],
    category: "Segmentation",
    bodyParts: [
      "Prostate"
    ],
    segments: [
      "PROSTATE"
    ],
    websiteUrl: "https://mhub.ai/models/nnunet_prostate_task24",
    githubUrl: "https://github.com/MIC-DKFZ/nnUNet/tree/nnunetv1",
    cite: "Isensee, F., Jaeger, P. F., Kohl, S. A., Petersen, J., & Maier-Hein, K. H. (2020). nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods, 1-9.",
    citeUrl: "https://www.nature.com/articles/s41592-020-01008-z"
  }
]);
function D2(t3) {
  return String(t3 || "").split("|").map((e) => e.trim().toUpperCase()).filter(Boolean).map((e) => e === "MRI" ? "MR" : e === "PET" ? "PT" : e);
}
function F2(t3, e) {
  const r = e.trim().toUpperCase();
  if (!r) return true;
  const i = r === "MRI" ? "MR" : r === "PET" ? "PT" : r;
  return t3.modalities.some((a) => D2(a).includes(i));
}
function ne3(t3) {
  const e = String(t3 || "").trim();
  return e ? f.filter((r) => F2(r, e)) : [...f];
}
function I2(t3) {
  return String(t3 || "").trim().toUpperCase().replace(/[\s_-]+/g, "");
}
function k2(t3, e) {
  const r = String(e || "").trim();
  if (!r) return [...t3];
  const i = I2(r);
  return t3.filter(
    (a) => (a.bodyParts || []).some((n) => I2(n) === i)
  );
}
function L(t3) {
  return String(t3 || "").trim().split(/[\s,;+/]+/).map((e) => e.trim().toUpperCase().replace(/[\s-]+/g, "_")).filter(Boolean);
}
function H2(t3, e = f) {
  const r = L(t3);
  if (!r.length) return [...e];
  const i = [];
  for (const a of e) {
    const n = (a.segments || []).map((s2) => String(s2).toUpperCase());
    if (!n.length) continue;
    let o = 0;
    for (const s2 of n)
      r.some((l) => s2.includes(l)) && (o += 1);
    o > 0 && i.push({ model: a, hits: o });
  }
  return i.sort((a, n) => n.hits - a.hits || a.model.label.localeCompare(n.model.label)), i.map((a) => a.model);
}
var V = [
  { key: "KIDNEY", label: "Kidney", patterns: [/\bkidn(?:ey|eys)?\b/i, /\brenal\b/i] },
  { key: "LIVER", label: "Liver", patterns: [/\bliver\b/i, /\bhepatic\b/i] },
  { key: "LUNG", label: "Lung", patterns: [/\blung(?:s)?\b/i, /\bpulmon/i] },
  { key: "CHEST", label: "Chest", patterns: [/\bchest\b/i, /\bthorax\b/i, /\bthoracic\b/i] },
  { key: "ABDOMEN", label: "Abdomen", patterns: [/\babdomen\b/i, /\babdominal\b/i] },
  { key: "PROSTATE", label: "Prostate", patterns: [/\bprostate\b/i] },
  { key: "BREAST", label: "Breast", patterns: [/\bbreast\b/i, /\bmammo/i] },
  { key: "SPINE", label: "Spine", patterns: [/\bspine\b/i, /\bspinal\b/i, /\bvertebra/i] },
  { key: "WHOLEBODY", label: "WHOLEBODY", patterns: [/\bwhole\s*body\b/i, /\bwb\b/i] }
];
function M3(t3) {
  const e = String(t3 || "").trim();
  if (!e) return "";
  for (const r of V)
    if (r.patterns.some((i) => i.test(e))) return r.label;
  return "";
}
function q(t3) {
  let e = "", r = "";
  if (!Array.isArray(t3))
    return { modality: e, description: r, bodyPart: "" };
  const i = (o) => {
    let s2 = String(o || "").trim().toUpperCase();
    return s2 === "MRI" && (s2 = "MR"), s2 === "PET" && (s2 = "PT"), s2 === "CT" || s2 === "CTAC" ? "CT" : s2 === "MR" || s2 === "PT" || s2 === "NM" ? s2 === "NM" ? "PT" : s2 : "";
  }, a = (o) => {
    if (!o) return "";
    if (typeof o == "string") return i(o);
    if (Array.isArray(o)) {
      for (const s2 of o) {
        const l = a(s2);
        if (l) return l;
      }
      return "";
    }
    if (typeof o == "object") {
      const s2 = o;
      if (s2.coding != null) return a(s2.coding);
      if (s2.code != null) return i(String(s2.code));
      if (s2.text != null) return i(String(s2.text));
    }
    return "";
  };
  for (const o of t3) {
    if (!o || typeof o != "object") continue;
    const s2 = String(o.key || ""), l = o.resource;
    if (!l || typeof l != "object") continue;
    const u = l;
    if (!r && u.description != null && (r = String(u.description).trim()), !e && u.modality != null && (e = a(u.modality)), !e && Array.isArray(u.series)) {
      for (const d of u.series)
        if (!(!d || typeof d != "object") && (e = a(
          d.modality
        ), e))
          break;
    }
    if (!e && (s2 === "files" || Array.isArray(u.files))) {
      const d = Array.isArray(u.files) ? u.files : [];
      for (const c of d) {
        if (!c || typeof c != "object") continue;
        const A2 = c, v2 = String(A2.role || "").trim().toLowerCase();
        if (!(v2 && v2 !== "volume") && (e = i(String(A2.label || "")), e))
          break;
      }
    }
  }
  const n = M3(r);
  return { modality: e, description: r, bodyPart: n };
}
var _2 = "https://github.com/MIC-DKFZ/nnunet-eucaim-docker";
var T = Object.freeze([
  {
    name: "abdominal_organ_segmentation",
    label: "Abdominal organ seg",
    description: "nnU-Net abdominal organ segmentation (EUCAIM Harbor task image).",
    modalities: ["CT"],
    category: "Segmentation",
    bodyParts: ["Abdomen"],
    segments: ["ABDOMEN"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "brain_tumour_pet",
    label: "Brain tumour PET",
    description: "nnU-Net brain tumour segmentation from PET (EUCAIM).",
    modalities: ["PT"],
    category: "Segmentation",
    bodyParts: ["Brain"],
    segments: ["BRAIN", "BRAIN+NEOPLASM_MALIGNANT_PRIMARY"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "colon_cancer",
    label: "Colon cancer",
    description: "nnU-Net colon cancer segmentation (EUCAIM).",
    modalities: ["CT"],
    category: "Segmentation",
    bodyParts: ["Colon"],
    segments: ["COLON", "COLON+NEOPLASM_MALIGNANT_PRIMARY"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "hippocampus_segmentation",
    label: "Hippocampus seg",
    description: "nnU-Net hippocampus segmentation (EUCAIM).",
    modalities: ["MR"],
    category: "Segmentation",
    bodyParts: ["Brain"],
    segments: ["HIPPOCAMPUS"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "kidney_tumour",
    label: "Kidney tumour",
    description: "nnU-Net kidney tumour segmentation (EUCAIM).",
    modalities: ["CT"],
    category: "Segmentation",
    bodyParts: ["Kidney"],
    segments: ["KIDNEY", "KIDNEY+NEOPLASM_MALIGNANT_PRIMARY"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "liver_tumour",
    label: "Liver tumour",
    description: "nnU-Net liver tumour segmentation (EUCAIM).",
    modalities: ["CT"],
    category: "Segmentation",
    bodyParts: ["Liver"],
    segments: ["LIVER", "LIVER+NEOPLASM_MALIGNANT_PRIMARY"],
    githubUrl: _2,
    websiteUrl: _2
  },
  {
    name: "pancreas_tumour",
    label: "Pancreas tumour",
    description: "nnU-Net pancreas tumour segmentation (EUCAIM).",
    modalities: ["CT"],
    category: "Segmentation",
    bodyParts: ["Pancreas"],
    segments: ["PANCREAS", "PANCREAS+NEOPLASM_MALIGNANT_PRIMARY"],
    githubUrl: _2,
    websiteUrl: _2
  }
]);
function K3(t3) {
  return String(t3 || "").split("|").map((e) => e.trim().toUpperCase()).filter(Boolean).map((e) => e === "MRI" ? "MR" : e === "PET" ? "PT" : e);
}
function Y2(t3, e) {
  const r = e.trim().toUpperCase();
  if (!r) return true;
  const i = r === "MRI" ? "MR" : r === "PET" ? "PT" : r;
  return t3.modalities.some((a) => K3(a).includes(i));
}
function oe2(t3) {
  const e = String(t3 || "").trim();
  return e ? T.filter((r) => Y2(r, e)) : [...T];
}
function _e2(t3, e) {
  return k2(t3, e);
}
function ce2(t3, e = T) {
  return H2(t3, e);
}
function de4(t3) {
  return q(t3);
}
var E2 = [
  {
    id: "total",
    modality: "CT",
    group: "total",
    title: "total",
    licenseRequired: false,
    supportsFast: true,
    classes: ["spleen", "kidney_right", "kidney_left", "gallbladder", "liver", "stomach", "pancreas", "adrenal_gland_right", "adrenal_gland_left", "lung_upper_lobe_left", "lung_lower_lobe_left", "lung_upper_lobe_right", "lung_middle_lobe_right", "lung_lower_lobe_right", "esophagus", "trachea", "thyroid_gland", "small_bowel", "duodenum", "colon", "urinary_bladder", "prostate", "kidney_cyst_left", "kidney_cyst_right", "sacrum", "vertebrae_S1", "vertebrae_L5", "vertebrae_L4", "vertebrae_L3", "vertebrae_L2", "vertebrae_L1", "vertebrae_T12", "vertebrae_T11", "vertebrae_T10", "vertebrae_T9", "vertebrae_T8", "vertebrae_T7", "vertebrae_T6", "vertebrae_T5", "vertebrae_T4", "vertebrae_T3", "vertebrae_T2", "vertebrae_T1", "vertebrae_C7", "vertebrae_C6", "vertebrae_C5", "vertebrae_C4", "vertebrae_C3", "vertebrae_C2", "vertebrae_C1", "heart", "aorta", "pulmonary_vein", "brachiocephalic_trunk", "subclavian_artery_right", "subclavian_artery_left", "common_carotid_artery_right", "common_carotid_artery_left", "brachiocephalic_vein_left", "brachiocephalic_vein_right", "atrial_appendage_left", "superior_vena_cava", "inferior_vena_cava", "portal_vein_and_splenic_vein", "iliac_artery_left", "iliac_artery_right", "iliac_vena_left", "iliac_vena_right", "humerus_left", "humerus_right", "scapula_left", "scapula_right", "clavicula_left", "clavicula_right", "femur_left", "femur_right", "hip_left", "hip_right", "spinal_cord", "gluteus_maximus_left", "gluteus_maximus_right", "gluteus_medius_left", "gluteus_medius_right", "gluteus_minimus_left", "gluteus_minimus_right", "autochthon_left", "autochthon_right", "iliopsoas_left", "iliopsoas_right", "brain", "skull", "rib_left_1", "rib_left_2", "rib_left_3", "rib_left_4", "rib_left_5", "rib_left_6", "rib_left_7", "rib_left_8", "rib_left_9", "rib_left_10", "rib_left_11", "rib_left_12", "rib_right_1", "rib_right_2", "rib_right_3", "rib_right_4", "rib_right_5", "rib_right_6", "rib_right_7", "rib_right_8", "rib_right_9", "rib_right_10", "rib_right_11", "rib_right_12", "sternum", "costal_cartilages"]
  },
  {
    id: "total_mr",
    modality: "MR",
    group: "total",
    title: "total",
    licenseRequired: false,
    supportsFast: true,
    classes: ["spleen", "kidney_right", "kidney_left", "gallbladder", "liver", "stomach", "pancreas", "adrenal_gland_right", "adrenal_gland_left", "lung_left", "lung_right", "esophagus", "small_bowel", "duodenum", "colon", "urinary_bladder", "prostate", "sacrum", "vertebrae", "intervertebral_discs", "spinal_cord", "heart", "aorta", "inferior_vena_cava", "portal_vein_and_splenic_vein", "iliac_artery_left", "iliac_artery_right", "iliac_vena_left", "iliac_vena_right", "humerus_left", "humerus_right", "scapula_left", "scapula_right", "clavicula_left", "clavicula_right", "femur_left", "femur_right", "hip_left", "hip_right", "gluteus_maximus_left", "gluteus_maximus_right", "gluteus_medius_left", "gluteus_medius_right", "gluteus_minimus_left", "gluteus_minimus_right", "autochthon_left", "autochthon_right", "iliopsoas_left", "iliopsoas_right", "brain"]
  },
  {
    id: "body",
    modality: "CT",
    group: "body",
    title: "body",
    licenseRequired: false,
    supportsFast: true,
    classes: ["body_trunc", "body_extremities"]
  },
  {
    id: "body_mr",
    modality: "MR",
    group: "body",
    title: "body",
    licenseRequired: false,
    supportsFast: true,
    classes: ["body_trunc", "body_extremities"]
  },
  {
    id: "vertebrae_mr",
    modality: "MR",
    group: "spine",
    title: "vertebrae",
    licenseRequired: false,
    supportsFast: true,
    classes: ["sacrum", "vertebrae_L5", "vertebrae_L4", "vertebrae_L3", "vertebrae_L2", "vertebrae_L1", "vertebrae_T12", "vertebrae_T11", "vertebrae_T10", "vertebrae_T9", "vertebrae_T8", "vertebrae_T7", "vertebrae_T6", "vertebrae_T5", "vertebrae_T4", "vertebrae_T3", "vertebrae_T2", "vertebrae_T1", "vertebrae_C7", "vertebrae_C6", "vertebrae_C5", "vertebrae_C4", "vertebrae_C3", "vertebrae_C2", "vertebrae_C1"]
  },
  {
    id: "vertebrae_pp",
    modality: "CT",
    group: "spine",
    title: "vertebrae (postprocess)",
    licenseRequired: false,
    supportsFast: false,
    classes: ["vertebrae_C1", "vertebrae_C2", "vertebrae_C3", "vertebrae_C4", "vertebrae_C5", "vertebrae_C6", "vertebrae_C7", "vertebrae_T1", "vertebrae_T2", "vertebrae_T3", "vertebrae_T4", "vertebrae_T5", "vertebrae_T6", "vertebrae_T7", "vertebrae_T8", "vertebrae_T9", "vertebrae_T10", "vertebrae_T11", "vertebrae_T12", "vertebrae_L1", "vertebrae_L2", "vertebrae_L3", "vertebrae_L4", "vertebrae_L5"]
  },
  {
    id: "vertebrae_pp_refined",
    modality: "CT",
    group: "spine",
    title: "vertebrae (refined)",
    licenseRequired: false,
    supportsFast: false,
    classes: ["vertebrae_C1", "vertebrae_C2", "vertebrae_C3", "vertebrae_C4", "vertebrae_C5", "vertebrae_C6", "vertebrae_C7", "vertebrae_T1", "vertebrae_T2", "vertebrae_T3", "vertebrae_T4", "vertebrae_T5", "vertebrae_T6", "vertebrae_T7", "vertebrae_T8", "vertebrae_T9", "vertebrae_T10", "vertebrae_T11", "vertebrae_T12", "vertebrae_L1", "vertebrae_L2", "vertebrae_L3", "vertebrae_L4", "vertebrae_L5"]
  },
  {
    id: "vertebrae_body",
    modality: "CT",
    group: "spine",
    title: "vertebrae body",
    licenseRequired: false,
    supportsFast: false,
    classes: ["vertebrae_body", "intervertebral_discs"]
  },
  {
    id: "lung_nodules",
    modality: "CT",
    group: "lung",
    title: "nodules",
    licenseRequired: false,
    supportsFast: false,
    classes: ["lung", "lung_nodules"]
  },
  {
    id: "lung_vessels",
    modality: "CT",
    group: "lung",
    title: "vessels and airways",
    licenseRequired: false,
    supportsFast: true,
    classes: ["lung_airways", "lung_airways_wall", "lung_arteries", "lung_veins"]
  },
  {
    id: "liver_lesions",
    modality: "CT",
    group: "liver",
    title: "lesions",
    licenseRequired: false,
    supportsFast: false,
    classes: ["liver_lesions"]
  },
  {
    id: "liver_lesions_mr",
    modality: "MR",
    group: "liver",
    title: "lesions",
    licenseRequired: false,
    supportsFast: false,
    classes: ["liver_lesions"]
  },
  {
    id: "liver_segments",
    modality: "CT",
    group: "liver",
    title: "segments",
    licenseRequired: false,
    supportsFast: false,
    classes: ["liver_segment_1", "liver_segment_2", "liver_segment_3", "liver_segment_4", "liver_segment_5", "liver_segment_6", "liver_segment_7", "liver_segment_8"]
  },
  {
    id: "liver_segments_mr",
    modality: "MR",
    group: "liver",
    title: "segments",
    licenseRequired: false,
    supportsFast: false,
    classes: ["liver_segment_1", "liver_segment_2", "liver_segment_3", "liver_segment_4", "liver_segment_5", "liver_segment_6", "liver_segment_7", "liver_segment_8"]
  },
  {
    id: "liver_vessels",
    modality: "CT",
    group: "liver",
    title: "vessels",
    licenseRequired: false,
    supportsFast: false,
    classes: ["liver_vessels", "liver_tumor"]
  },
  {
    id: "kidney_cysts",
    modality: "CT",
    group: "kidney",
    title: "cysts",
    licenseRequired: false,
    supportsFast: false,
    classes: ["kidney_cyst_left", "kidney_cyst_right"]
  },
  {
    id: "breasts",
    modality: "CT",
    group: "breast",
    title: "breasts",
    licenseRequired: false,
    supportsFast: false,
    classes: ["breast"]
  },
  {
    id: "abdominal_muscles",
    modality: "CT",
    group: "abdomen",
    title: "abdominal muscles",
    licenseRequired: false,
    supportsFast: false,
    classes: ["pectoralis_major_right", "pectoralis_major_left", "rectus_abdominis_right", "rectus_abdominis_left", "serratus_anterior_right", "serratus_anterior_left", "latissimus_dorsi_right", "latissimus_dorsi_left", "trapezius_right", "trapezius_left", "external_oblique_right", "external_oblique_left", "internal_oblique_right", "internal_oblique_left", "erector_spinae_right", "erector_spinae_left", "transversospinalis_right", "transversospinalis_left", "psoas_major_right", "psoas_major_left", "quadratus_lumborum_right", "quadratus_lumborum_left"]
  },
  {
    id: "trunk_cavities",
    modality: "CT",
    group: "abdomen",
    title: "trunk cavities",
    licenseRequired: false,
    supportsFast: false,
    classes: ["abdominal_cavity", "thoracic_cavity", "pericardium", "mediastinum"]
  },
  {
    id: "craniofacial_structures",
    modality: "CT",
    group: "head",
    title: "craniofacial structures",
    licenseRequired: false,
    supportsFast: false,
    classes: ["mandible", "teeth_lower", "skull", "head", "sinus_maxillary", "sinus_frontal", "teeth_upper"]
  },
  {
    id: "head_glands_cavities",
    modality: "CT",
    group: "head",
    title: "glands and cavities",
    licenseRequired: false,
    supportsFast: false,
    classes: ["eye_left", "eye_right", "eye_lens_left", "eye_lens_right", "optic_nerve_left", "optic_nerve_right", "parotid_gland_left", "parotid_gland_right", "submandibular_gland_right", "submandibular_gland_left", "nasopharynx", "oropharynx", "hypopharynx", "nasal_cavity_right", "nasal_cavity_left", "auditory_canal_right", "auditory_canal_left", "soft_palate", "hard_palate"]
  },
  {
    id: "head_muscles",
    modality: "CT",
    group: "head",
    title: "muscles",
    licenseRequired: false,
    supportsFast: false,
    classes: ["masseter_right", "masseter_left", "temporalis_right", "temporalis_left", "lateral_pterygoid_right", "lateral_pterygoid_left", "medial_pterygoid_right", "medial_pterygoid_left", "tongue", "digastric_right", "digastric_left"]
  },
  {
    id: "oculomotor_muscles",
    modality: "CT",
    group: "head",
    title: "oculomotor muscles",
    licenseRequired: false,
    supportsFast: false,
    classes: ["skull", "eyeball_right", "lateral_rectus_muscle_right", "superior_oblique_muscle_right", "levator_palpebrae_superioris_right", "superior_rectus_muscle_right", "medial_rectus_muscle_left", "inferior_oblique_muscle_right", "inferior_rectus_muscle_right", "optic_nerve_left", "eyeball_left", "lateral_rectus_muscle_left", "superior_oblique_muscle_left", "levator_palpebrae_superioris_left", "superior_rectus_muscle_left", "medial_rectus_muscle_right", "inferior_oblique_muscle_left", "inferior_rectus_muscle_left", "optic_nerve_right"]
  },
  {
    id: "teeth",
    modality: "CT",
    group: "head",
    title: "teeth",
    licenseRequired: false,
    supportsFast: false,
    classes: ["lower_jawbone", "upper_jawbone", "left_inferior_alveolar_canal", "right_inferior_alveolar_canal", "left_maxillary_sinus", "right_maxillary_sinus", "pharynx", "bridge", "crown", "implant", "upper_right_central_incisor_fdi11", "upper_right_lateral_incisor_fdi12", "upper_right_canine_fdi13", "upper_right_first_premolar_fdi14", "upper_right_second_premolar_fdi15", "upper_right_first_molar_fdi16", "upper_right_second_molar_fdi17", "upper_right_third_molar_fdi18", "upper_left_central_incisor_fdi21", "upper_left_lateral_incisor_fdi22", "upper_left_canine_fdi23", "upper_left_first_premolar_fdi24", "upper_left_second_premolar_fdi25", "upper_left_first_molar_fdi26", "upper_left_second_molar_fdi27", "upper_left_third_molar_fdi28", "lower_left_central_incisor_fdi31", "lower_left_lateral_incisor_fdi32", "lower_left_canine_fdi33", "lower_left_first_premolar_fdi34", "lower_left_second_premolar_fdi35", "lower_left_first_molar_fdi36", "lower_left_second_molar_fdi37", "lower_left_third_molar_fdi38", "lower_right_central_incisor_fdi41", "lower_right_lateral_incisor_fdi42", "lower_right_canine_fdi43", "lower_right_first_premolar_fdi44", "lower_right_second_premolar_fdi45", "lower_right_first_molar_fdi46", "lower_right_second_molar_fdi47", "lower_right_third_molar_fdi48", "left_mandibular_incisive_canal_fdi103", "right_mandibular_incisive_canal_fdi104", "lingual_canal", "upper_right_central_incisor_pulp_fdi111", "upper_right_lateral_incisor_pulp_fdi112", "upper_right_canine_pulp_fdi113", "upper_right_first_premolar_pulp_fdi114", "upper_right_second_premolar_pulp_fdi115", "upper_right_first_molar_pulp_fdi116", "upper_right_second_molar_pulp_fdi117", "upper_right_third_molar_pulp_fdi118", "upper_left_central_incisor_pulp_fdi121", "upper_left_lateral_incisor_pulp_fdi122", "upper_left_canine_pulp_fdi123", "upper_left_first_premolar_pulp_fdi124", "upper_left_second_premolar_pulp_fdi125", "upper_left_first_molar_pulp_fdi126", "upper_left_second_molar_pulp_fdi127", "upper_left_third_molar_pulp_fdi128", "lower_left_central_incisor_pulp_fdi131", "lower_left_lateral_incisor_pulp_fdi132", "lower_left_canine_pulp_fdi133", "lower_left_first_premolar_pulp_fdi134", "lower_left_second_premolar_pulp_fdi135", "lower_left_first_molar_pulp_fdi136", "lower_left_second_molar_pulp_fdi137", "lower_left_third_molar_pulp_fdi138", "lower_right_central_incisor_pulp_fdi141", "lower_right_lateral_incisor_pulp_fdi142", "lower_right_canine_pulp_fdi143", "lower_right_first_premolar_pulp_fdi144", "lower_right_second_premolar_pulp_fdi145", "lower_right_first_molar_pulp_fdi146", "lower_right_second_molar_pulp_fdi147", "lower_right_third_molar_pulp_fdi148"]
  },
  {
    id: "headneck_bones_vessels",
    modality: "CT",
    group: "headneck",
    title: "bones and vessels",
    licenseRequired: false,
    supportsFast: false,
    classes: ["larynx_air", "thyroid_cartilage", "hyoid", "cricoid_cartilage", "zygomatic_arch_right", "zygomatic_arch_left", "styloid_process_right", "styloid_process_left", "internal_carotid_artery_right", "internal_carotid_artery_left", "internal_jugular_vein_right", "internal_jugular_vein_left"]
  },
  {
    id: "headneck_muscles",
    modality: "CT",
    group: "headneck",
    title: "muscles",
    licenseRequired: false,
    supportsFast: false,
    classes: ["sternocleidomastoid_right", "sternocleidomastoid_left", "superior_pharyngeal_constrictor", "middle_pharyngeal_constrictor", "inferior_pharyngeal_constrictor", "trapezius_right", "trapezius_left", "platysma_right", "platysma_left", "levator_scapulae_right", "levator_scapulae_left", "anterior_scalene_right", "anterior_scalene_left", "middle_scalene_right", "middle_scalene_left", "posterior_scalene_right", "posterior_scalene_left", "sterno_thyroid_right", "sterno_thyroid_left", "thyrohyoid_right", "thyrohyoid_left", "prevertebral_right", "prevertebral_left"]
  },
  {
    id: "brain_aneurysm",
    modality: "MR",
    group: "brain",
    title: "aneurysm (TOF MRI)",
    licenseRequired: false,
    supportsFast: false,
    classes: ["brain_aneurysm"]
  },
  {
    id: "cerebral_bleed",
    modality: "CT",
    group: "brain",
    title: "cerebral bleed",
    licenseRequired: false,
    supportsFast: false,
    classes: ["intracerebral_hemorrhage"]
  },
  {
    id: "brain_structures",
    modality: "CT",
    group: "brain",
    title: "structures",
    licenseRequired: true,
    supportsFast: false,
    classes: ["brainstem", "subarachnoid_space", "venous_sinuses", "septum_pellucidum", "cerebellum", "caudate_nucleus", "lentiform_nucleus", "insular_cortex", "internal_capsule", "ventricle", "central_sulcus", "frontal_lobe", "parietal_lobe", "occipital_lobe", "temporal_lobe", "thalamus"]
  },
  {
    id: "ventricle_parts",
    modality: "CT",
    group: "brain",
    title: "ventricle parts",
    licenseRequired: false,
    supportsFast: false,
    classes: ["ventricle_frontal_horn_left", "ventricle_occipital_horn_left", "ventricle_body_left", "ventricle_temporal_horn_left", "ventricle_trigone_left", "ventricle_frontal_horn_right", "ventricle_occipital_horn_right", "ventricle_body_right", "ventricle_temporal_horn_right", "ventricle_trigone_right", "third_ventricle", "fourth_ventricle"]
  },
  {
    id: "aortic_sinuses",
    modality: "CT",
    group: "heart",
    title: "aortic sinuses",
    licenseRequired: true,
    supportsFast: false,
    classes: ["left_ventricular_outflow_tract", "right_coronary_cusp", "left_coronary_cusp", "non_coronary_cusp"]
  },
  {
    id: "heartchambers_highres",
    modality: "CT",
    group: "heart",
    title: "chambers highres",
    licenseRequired: true,
    supportsFast: false,
    classes: ["heart_myocardium", "heart_atrium_left", "heart_ventricle_left", "heart_atrium_right", "heart_ventricle_right", "aorta", "pulmonary_artery"]
  },
  {
    id: "coronary_arteries",
    modality: "CT",
    group: "heart",
    title: "coronary arteries",
    licenseRequired: true,
    supportsFast: false,
    classes: ["coronary_arteries"]
  },
  {
    id: "pleural_pericard_effusion",
    modality: "CT",
    group: "heart",
    title: "pleural / pericardial effusion",
    licenseRequired: false,
    supportsFast: false,
    classes: ["lung_pleural", "pleural_effusion", "pericardial_effusion"]
  },
  {
    id: "appendicular_bones",
    modality: "CT",
    group: "bones",
    title: "appendicular bones",
    licenseRequired: true,
    supportsFast: false,
    classes: ["patella", "tibia", "fibula", "tarsal", "metatarsal", "phalanges_feet", "ulna", "radius", "carpal", "metacarpal", "phalanges_hand"]
  },
  {
    id: "appendicular_bones_mr",
    modality: "MR",
    group: "bones",
    title: "appendicular bones",
    licenseRequired: true,
    supportsFast: false,
    classes: ["patella", "tibia", "fibula", "tarsal", "metatarsal", "phalanges_feet", "ulna", "radius"]
  },
  {
    id: "hip_implant",
    modality: "CT",
    group: "bones",
    title: "hip implant",
    licenseRequired: false,
    supportsFast: false,
    classes: ["hip_implant"]
  },
  {
    id: "tissue_4_types",
    modality: "CT",
    group: "tissue",
    title: "tissue 4 types",
    licenseRequired: true,
    supportsFast: false,
    classes: ["subcutaneous_fat", "torso_fat", "skeletal_muscle", "intermuscular_fat"]
  },
  {
    id: "tissue_types",
    modality: "CT",
    group: "tissue",
    title: "tissue types",
    licenseRequired: true,
    supportsFast: false,
    classes: ["subcutaneous_fat", "torso_fat", "skeletal_muscle"]
  },
  {
    id: "tissue_types_mr",
    modality: "MR",
    group: "tissue",
    title: "tissue types",
    licenseRequired: true,
    supportsFast: false,
    classes: ["subcutaneous_fat", "torso_fat", "skeletal_muscle"]
  },
  {
    id: "face",
    modality: "CT",
    group: "face",
    title: "face",
    licenseRequired: true,
    supportsFast: false,
    classes: ["face"]
  },
  {
    id: "face_mr",
    modality: "MR",
    group: "face",
    title: "face",
    licenseRequired: true,
    supportsFast: false,
    classes: ["face"]
  },
  {
    id: "thigh_shoulder_muscles",
    modality: "CT",
    group: "muscles",
    title: "thigh and shoulder muscles",
    licenseRequired: true,
    supportsFast: false,
    classes: ["quadriceps_femoris_left", "quadriceps_femoris_right", "thigh_medial_compartment_left", "thigh_medial_compartment_right", "thigh_posterior_compartment_left", "thigh_posterior_compartment_right", "sartorius_left", "sartorius_right", "deltoid", "supraspinatus", "infraspinatus", "subscapularis", "coracobrachial", "trapezius", "pectoralis_minor", "serratus_anterior", "teres_major", "triceps_brachii"]
  },
  {
    id: "thigh_shoulder_muscles_mr",
    modality: "MR",
    group: "muscles",
    title: "thigh and shoulder muscles",
    licenseRequired: true,
    supportsFast: false,
    classes: ["quadriceps_femoris_left", "quadriceps_femoris_right", "thigh_medial_compartment_left", "thigh_medial_compartment_right", "thigh_posterior_compartment_left", "thigh_posterior_compartment_right", "sartorius_left", "sartorius_right", "deltoid", "supraspinatus", "infraspinatus", "subscapularis", "coracobrachial", "trapezius", "pectoralis_minor", "serratus_anterior", "teres_major", "triceps_brachii"]
  }
];
var J2 = new Map(E2.map((t3) => [t3.id, t3]));
function W2(t3) {
  const e = t3.licenseRequired ? " [license required]" : "";
  return `${t3.title}${e}`;
}
E2.map((t3) => ({
  value: t3.id,
  title: W2(t3)
}));

// inference-info-dialog.ts
var INFERENCE_MODAL_ANCHORED = "wl-modal-backdrop-anchored";
function escapeHtml2(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function statusLabel(state, serverId) {
  if (!state) return null;
  const status = state.inferenceStatus.get(serverId) || "unknown";
  if (status === "online") return "Online";
  if (status === "offline") return "Offline";
  return null;
}
function renderViewerHintHtml(serverTitle) {
  const title = escapeHtml2(serverTitle);
  return `<p class="wl-inference-viewer-hint">Open a study and use the <strong>Evidence Creators</strong> control in the viewer to use ${title}.</p>`;
}
function findWorklistServer(serverId) {
  return INFERENCE_SERVERS.find((s2) => s2.id === serverId) || null;
}
function resolveStudyModalityHints(state, hints) {
  if (!hints.modality && state?.openWorklistSampleId) {
    const sample = findWorklistSample(
      state.openWorklistSampleId,
      state.allStudies || []
    );
    const fromSample = String(
      sample?.modalities?.[0] || sample?.segroulette?.m || ""
    ).trim().toUpperCase();
    if (fromSample === "MRI" || fromSample === "MR") hints.modality = "MR";
    else if (fromSample === "PET" || fromSample === "PT" || fromSample === "NM") {
      hints.modality = "PT";
    } else if (fromSample === "CT" || fromSample === "CTAC") {
      hints.modality = "CT";
    }
  }
  return hints;
}
function modelRowHtml(model) {
  const website = String(model.websiteUrl || "").trim();
  const label = escapeHtml2(model.label);
  const desc = String(model.description || "").trim();
  const title = desc ? ` title="${escapeHtml2(desc)}"` : "";
  const link = website ? ` <a class="wl-mhub-model-link" href="${escapeHtml2(website)}" target="_blank" rel="noopener noreferrer">\u2197</a>` : "";
  return `<li class="wl-mhub-model"${title}><span class="wl-mhub-model-label">${label}</span>${link}</li>`;
}
function renderModelsPanelHtml(opts) {
  const hints = resolveStudyModalityHints(
    opts.state,
    opts.contextHints(opts.state?.lastImagingStudyOpenContext || [])
  );
  const modality = hints.modality || "";
  let models = opts.listModels(modality || null);
  if (hints.bodyPart) {
    models = opts.listForBodyPart(models, hints.bodyPart);
  }
  const q2 = String(opts.findQuery || "").trim();
  if (q2) models = opts.findByAnatomy(q2, models);
  const filterBits = [];
  if (modality) filterBits.push(modality);
  if (hints.bodyPart) {
    filterBits.push(
      hints.bodyPart === "WHOLEBODY" ? "Whole body" : hints.bodyPart
    );
  }
  if (q2) filterBits.push(`anatomy \u201C${escapeHtml2(q2)}\u201D`);
  const contextLine = !modality && !hints.description ? `<p class="wl-mhub-context-note">No open study \u2014 showing all models. Open a study to filter.</p>` : filterBits.length ? `<p class="wl-mhub-context-note">${models.length} model${models.length === 1 ? "" : "s"} \xB7 ${filterBits.join(" \xB7 ")}${hints.bodyPart && !q2 ? " (from study)" : ""}</p>` : `<p class="wl-mhub-context-note">${models.length} model${models.length === 1 ? "" : "s"}${modality ? ` \xB7 ${escapeHtml2(modality)}` : ""}</p>`;
  const list = models.length === 0 ? `<p class="wl-mhub-empty">No models match.</p>` : `<ul class="wl-mhub-model-list" aria-label="Applicable ${escapeHtml2(opts.productLabel)} models">${models.map(modelRowHtml).join("")}</ul>`;
  return `<div class="wl-mhub-models-panel" ${opts.panelAttr}><div class="wl-mhub-find-row"><label for="${opts.findInputId}">Find models by anatomy</label><input type="search" id="${opts.findInputId}" class="wl-mhub-find" placeholder="e.g. liver kidney" autocomplete="off" value="${escapeHtml2(q2)}" aria-label="Find ${escapeHtml2(opts.productLabel)} models by anatomy" /></div>` + contextLine + list + `</div>`;
}
function renderMhubModelsPanelHtml(state, findQuery) {
  return renderModelsPanelHtml({
    state,
    findQuery,
    productLabel: "MHub",
    findInputId: "wlMhubFind",
    panelAttr: "data-mhub-models-panel",
    listModels: ne3,
    listForBodyPart: k2,
    findByAnatomy: H2,
    contextHints: q
  });
}
function renderEucaimModelsPanelHtml(state, findQuery) {
  return renderModelsPanelHtml({
    state,
    findQuery,
    productLabel: "EUCAIM",
    findInputId: "wlEucaimFind",
    panelAttr: "data-eucaim-models-panel",
    listModels: oe2,
    listForBodyPart: _e2,
    findByAnatomy: ce2,
    contextHints: de4
  });
}
var mhubFindWired = false;
var mhubFindQuery = "";
var mhubDialogState;
var eucaimFindWired = false;
var eucaimFindQuery = "";
var eucaimDialogState;
function wireMhubFindOnce() {
  if (mhubFindWired) return;
  mhubFindWired = true;
  document.addEventListener("input", (ev) => {
    const t3 = ev.target;
    if (!(t3 instanceof HTMLInputElement) || t3.id !== "wlMhubFind") return;
    mhubFindQuery = String(t3.value || "").trim();
    refreshMhubModelsPanel();
  });
}
function wireEucaimFindOnce() {
  if (eucaimFindWired) return;
  eucaimFindWired = true;
  document.addEventListener("input", (ev) => {
    const t3 = ev.target;
    if (!(t3 instanceof HTMLInputElement) || t3.id !== "wlEucaimFind") return;
    eucaimFindQuery = String(t3.value || "").trim();
    refreshEucaimModelsPanel();
  });
}
function refreshMhubModelsPanel() {
  const bodyEl = document.getElementById("inferenceInfoBody");
  if (!bodyEl) return;
  const panel = bodyEl.querySelector("[data-mhub-models-panel]");
  if (!panel) return;
  panel.outerHTML = renderMhubModelsPanelHtml(mhubDialogState, mhubFindQuery);
  const input = document.getElementById("wlMhubFind");
  if (input) {
    input.focus();
    const len = input.value.length;
    input.setSelectionRange(len, len);
  }
}
function refreshEucaimModelsPanel() {
  const bodyEl = document.getElementById("inferenceInfoBody");
  if (!bodyEl) return;
  const panel = bodyEl.querySelector("[data-eucaim-models-panel]");
  if (!panel) return;
  panel.outerHTML = renderEucaimModelsPanelHtml(
    eucaimDialogState,
    eucaimFindQuery
  );
  const input = document.getElementById(
    "wlEucaimFind"
  );
  if (input) {
    input.focus();
    const len = input.value.length;
    input.setSelectionRange(len, len);
  }
}
function openInferenceInfoDialog(serverId, state, anchor) {
  const server = findWorklistServer(serverId);
  const modal = document.getElementById("inferenceInfoModal");
  const titleEl = document.getElementById("inferenceInfoTitle");
  const bodyEl = document.getElementById("inferenceInfoBody");
  if (!server || !modal || !titleEl || !bodyEl) return;
  const isLocalCapable = server.localCapable === true;
  const status = isLocalCapable ? "Available" : statusLabel(state, server.id);
  titleEl.textContent = status ? `${server.title} \xB7 ${status}` : server.title;
  mhubDialogState = state;
  eucaimDialogState = state;
  const dialog = modal.querySelector(
    ".wl-inference-info-modal"
  );
  if (serverId === "mhub") {
    wireMhubFindOnce();
    mhubFindQuery = "";
    dialog?.classList.add("wl-inference-info-modal-wide");
    bodyEl.innerHTML = Xs(server) + renderMhubModelsPanelHtml(state, mhubFindQuery) + renderViewerHintHtml(server.title);
  } else if (serverId === "eucaim") {
    wireEucaimFindOnce();
    eucaimFindQuery = "";
    dialog?.classList.add("wl-inference-info-modal-wide");
    bodyEl.innerHTML = Xs(server) + renderEucaimModelsPanelHtml(state, eucaimFindQuery) + renderViewerHintHtml(server.title);
  } else {
    dialog?.classList.remove("wl-inference-info-modal-wide");
    bodyEl.innerHTML = Xs(server) + renderViewerHintHtml(server.title);
  }
  modal.hidden = false;
  Ze({
    overlay: modal,
    dialog,
    anchor: anchor ?? null,
    anchoredClass: INFERENCE_MODAL_ANCHORED,
    // Right-align so the header close control sits under the clicked button.
    align: "end"
  });
}
function clampDialogPos(left, top, dialog) {
  const margin = 8;
  const w2 = dialog.offsetWidth || 340;
  const h = dialog.offsetHeight || 200;
  const maxL = Math.max(margin, window.innerWidth - w2 - margin);
  const maxT = Math.max(margin, window.innerHeight - h - margin);
  return {
    left: Math.min(maxL, Math.max(margin, left)),
    top: Math.min(maxT, Math.max(margin, top))
  };
}
function installInferenceInfoDrag() {
  const modal = document.getElementById("inferenceInfoModal");
  const handle = modal?.querySelector(
    "[data-wl-inference-drag]"
  );
  const dialog = modal?.querySelector(
    ".wl-inference-info-modal"
  );
  if (!modal || !handle || !dialog || handle.dataset.wlDragBound === "1") {
    return;
  }
  handle.dataset.wlDragBound = "1";
  let dragging = false;
  let startX = 0;
  let startY = 0;
  let originLeft = 0;
  let originTop = 0;
  const onMove = (ev) => {
    if (!dragging) return;
    const next = clampDialogPos(
      originLeft + (ev.clientX - startX),
      originTop + (ev.clientY - startY),
      dialog
    );
    dialog.style.position = "absolute";
    dialog.style.margin = "0";
    dialog.style.left = `${next.left}px`;
    dialog.style.top = `${next.top}px`;
    dialog.style.right = "auto";
  };
  const onUp = (ev) => {
    if (!dragging) return;
    dragging = false;
    handle.classList.remove("wl-dragging");
    try {
      handle.releasePointerCapture(ev.pointerId);
    } catch {
    }
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onUp);
  };
  handle.addEventListener("pointerdown", (ev) => {
    if (ev.button !== 0) return;
    const t3 = ev.target;
    if (t3?.closest("button, a, input, select, textarea, label")) return;
    dragging = true;
    handle.classList.add("wl-dragging");
    startX = ev.clientX;
    startY = ev.clientY;
    const rect = dialog.getBoundingClientRect();
    originLeft = rect.left;
    originTop = rect.top;
    dialog.style.position = "absolute";
    dialog.style.margin = "0";
    dialog.style.left = `${originLeft}px`;
    dialog.style.top = `${originTop}px`;
    dialog.style.right = "auto";
    modal.classList.add(INFERENCE_MODAL_ANCHORED);
    try {
      handle.setPointerCapture(ev.pointerId);
    } catch {
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    ev.preventDefault();
  });
}
function closeInferenceInfoDialog() {
  const modal = document.getElementById("inferenceInfoModal");
  if (!modal) return;
  const dialog = modal.querySelector(
    ".wl-inference-info-modal"
  );
  modal.hidden = true;
  dialog?.classList.remove("wl-inference-info-modal-wide");
  Te2(modal, dialog, INFERENCE_MODAL_ANCHORED);
}
function wireInferenceInfoButtons(state) {
  installInferenceInfoDrag();
  applyInferenceServerButtonVisibility();
  for (const server of INFERENCE_SERVERS) {
    const btn = document.getElementById(server.worklistButtonId);
    if (!btn) continue;
    btn.addEventListener("click", () => {
      if (server.id === "txrv" || server.id === "flexray" || server.id === "vox2seglam") {
        const orgSelect = document.getElementById(
          "worklistOrgSelect"
        );
        if (orgSelect) {
          orgSelect.value = server.id === "flexray" ? WORKLIST_ORG_FLEXRAY : server.id === "vox2seglam" ? WORKLIST_ORG_VOX2SEGLAM : WORKLIST_ORG_TXRV;
          orgSelect.dispatchEvent(new Event("change"));
        }
      }
      openInferenceInfoDialog(
        server.id,
        state,
        btn instanceof HTMLElement ? btn : null
      );
    });
  }
}

// worklist.ts
function applyTheme() {
  document.documentElement.dataset.theme = THEME_SLICERLIVE;
  setStoredTheme(THEME_SLICERLIVE);
}
var MODAL_ANCHORED = "wl-modal-backdrop-anchored";
function wireMenus(state) {
  const helpBtn = document.getElementById(
    "castHelpBtn"
  );
  const helpMenu = document.getElementById("castHelpMenu");
  const helpModal = document.getElementById("helpModal");
  const helpDialog = helpModal.querySelector(".wl-modal");
  const closeHelpMenu = () => {
    if (helpMenu) closeMenus(helpMenu);
    helpBtn?.setAttribute("aria-expanded", "false");
  };
  const closeHelpModal = () => {
    helpModal.hidden = true;
    Te2(helpModal, helpDialog, MODAL_ANCHORED);
  };
  const openHelpModal = () => {
    closeHelpMenu();
    showHelp(helpModal);
    Ze({
      overlay: helpModal,
      dialog: helpDialog,
      anchor: helpBtn,
      anchoredClass: MODAL_ANCHORED,
      align: "end"
    });
  };
  helpBtn?.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (!helpMenu) {
      openHelpModal();
      return;
    }
    const open = helpMenu.hidden;
    closeHelpMenu();
    helpMenu.hidden = !open;
    helpBtn.setAttribute("aria-expanded", open ? "true" : "false");
  });
  document.addEventListener("click", () => {
    closeHelpMenu();
  });
  helpMenu?.addEventListener("click", (ev) => ev.stopPropagation());
  document.getElementById("castHelpOpenBtn")?.addEventListener("click", () => {
    openHelpModal();
  });
  document.querySelectorAll("[data-close-modal]").forEach((el6) => {
    el6.addEventListener("click", () => {
      closeHelpModal();
    });
  });
  helpModal.addEventListener("click", (ev) => {
    if (ev.target === helpModal) closeHelpModal();
  });
  document.querySelectorAll("[data-close-inference-info]").forEach((el6) => {
    el6.addEventListener("click", () => closeInferenceInfoDialog());
  });
  document.getElementById("inferenceInfoModal")?.addEventListener("click", (ev) => {
    if (ev.target === ev.currentTarget) closeInferenceInfoDialog();
  });
}
function wireViewerButtons(state, onWorklistChanged) {
  const map = [
    { id: "openReportingBtn", kind: "reporting" },
    { id: "openIraBtn", kind: "ira" },
    { id: "openOhifBtn", kind: "ohif" },
    { id: "openSlimBtn", kind: "slim" }
  ];
  for (const { id, kind } of map) {
    document.getElementById(id)?.addEventListener("click", () => {
      openHubViewer(state, kind);
    });
  }
  document.getElementById("openSt444Btn")?.addEventListener("click", (ev) => {
    handleClassroomOpenClick(state, ev);
  });
  document.getElementById("openSlicerMirrorBtn")?.addEventListener("click", () => {
    openSlicerMirrorViewer(state);
  });
  document.getElementById("openSegrouletteBtn")?.addEventListener("click", () => {
    openSegrouletteDialog({
      onOpen: (entry2) => publishSegrouletteOpen(state, entry2).catch((err) => {
        console.error(`${LOG_PREFIX} SegRoulette open failed`, err);
      }),
      onAddToWorklist: (entry2) => addSegrouletteToWorklist(state, entry2).then(() => {
        const orgSelect = document.getElementById(
          "worklistOrgSelect"
        );
        if (orgSelect) orgSelect.value = WORKLIST_ORG_MINE;
        onWorklistChanged();
      }).catch((err) => {
        console.error(`${LOG_PREFIX} SegRoulette add failed`, err);
      })
    });
  });
}
async function boot() {
  try {
    window.name = as;
  } catch {
  }
  await initI18n();
  applyTheme();
  const state = createInitialState();
  state.allStudies = mergeMyWorklistStudies(
    state.allStudies,
    loadMyWorklistFromStorage()
  );
  const spaSelect = document.getElementById(
    "spaSourceSelect"
  );
  if (spaSelect) {
    spaSelect.value = getSpaSource();
    spaSelect.addEventListener("change", () => {
      setSpaSource(normalizeSpaSource(spaSelect.value));
      syncClassroomOpenLink(state, state.connection === "connected");
    });
  }
  const defaultViewerSelect = document.getElementById(
    "defaultViewerSelect"
  );
  if (defaultViewerSelect) {
    defaultViewerSelect.value = getDefaultViewer();
    defaultViewerSelect.addEventListener("change", () => {
      setDefaultViewer(normalizeDefaultViewer(defaultViewerSelect.value));
    });
  }
  let statusWrap = null;
  const tableBody = document.getElementById("worklistBody");
  const emptyRow = document.getElementById("worklistEmpty");
  const orgSelect = document.getElementById(
    "worklistOrgSelect"
  );
  loadIdcCustomWorklistsFromSession();
  refreshOrgSelectWithCustomWorklists(orgSelect);
  selectDefaultWorklistOrg();
  const refreshTable = () => renderWorklistTable(tableBody, emptyRow, state, orgSelect.value);
  const sizeSortBtn = document.getElementById(
    "worklistSizeSortBtn"
  );
  sizeSortBtn?.addEventListener("click", () => {
    toggleSizeSortDir();
    syncSizeSortHeader();
    refreshTable();
  });
  syncSizeSortHeader();
  const setFooter = (_msg) => {
  };
  setStatusListener((s2) => {
    updateConnectionStatusUi(statusWrap, s2);
    setViewerButtonsEnabled(s2.connection === "connected", s2);
  });
  setWorklistListener(() => refreshTable());
  let conferenceDialog = null;
  let inviteController = null;
  let openConferenceDialog = (_anchor) => {
    console.warn("[@slicer-hub/worklist] conference dialog not available");
  };
  try {
    conferenceDialog = ut2({
      classPrefix: "hub-conference",
      strings: conferenceStrings(),
      getSession: () => ({
        hubEndpoint: hubEndpoint(state),
        topic: state.topic,
        subscriberName: state.subscriberName,
        userName: state.userName,
        connected: state.connection === "connected",
        accessToken: state.client?.getConnectionState?.()?.token?.trim() || ""
      }),
      onConferenceChange: (view) => {
        setConferenceView(state, view);
      },
      onFollowChange: (followHost) => {
        setConferenceFollowHost(state, followHost);
      },
      onUserNameChange: async (userName) => {
        await rebindSessionUserName(state, userName);
      }
    });
    setSessionStatusControl(conferenceDialog.getSessionControl());
    statusWrap = conferenceDialog.getSessionControl().label;
    openConferenceDialog = (anchor) => conferenceDialog.open(anchor ?? null);
  } catch (err) {
    console.error("[@slicer-hub/worklist] conference dialog init failed", err);
  }
  try {
    inviteController = ft2({
      classPrefix: "hub-conference-invite",
      strings: conferenceStrings(),
      getSession: () => ({
        hubEndpoint: hubEndpoint(state),
        topic: state.topic,
        subscriberName: state.subscriberName,
        userName: state.userName,
        connected: state.connection === "connected",
        accessToken: state.client?.getConnectionState?.()?.token?.trim() || ""
      }),
      shouldShow: () => dt2({
        selfActors: [WORKLIST_ACTOR],
        connectedActors: connectedActorsFromState(state)
      }),
      onConferenceChange: (view) => {
        setConferenceView(state, view);
      },
      onFollowChange: (followHost, invite) => {
        setConferenceFollowHost(state, followHost);
        if (followHost) {
          ensureSlicerLiveViewer(state, { reason: "conference-join-follow" });
        }
        const hostTopic = String(invite?.hostTopic || "").trim();
        if (followHost && hostTopic) {
          void requestStatusFromHostWorklist(state, hostTopic);
        }
      },
      onLeadChange: (info) => {
        const label = String(info?.leaderLabel || info?.leaderUserName || "").trim() || "Someone";
        yt2(`${label} took over`);
      }
    });
    setConferenceHubHandler(
      (message) => inviteController.handleHubMessage(message)
    );
  } catch (err) {
    console.error("[@slicer-hub/worklist] conference invite init failed", err);
  }
  const helpModalEl = document.getElementById("helpModal");
  onLanguageChanged(() => {
    applyChromeLabels();
    setViewerButtonsEnabled(state.connection === "connected", state);
    renderWorklistContext(state);
    renderConferenceRoster(state);
    refreshHelpIfOpen(helpModalEl);
    conferenceDialog?.setStrings?.(conferenceStrings());
    inviteController?.setStrings?.(conferenceStrings());
    const refreshTableOnLang = () => renderWorklistTable(tableBody, emptyRow, state, orgSelect.value);
    refreshTableOnLang();
  });
  document.getElementById("closeContextBtn")?.addEventListener("click", () => {
    void handleWorklistClose(state).catch((err) => {
      console.error(`${LOG_PREFIX} close context failed`, err);
    });
  });
  const startConferenceBtn = document.getElementById("startConferenceBtn");
  if (startConferenceBtn) {
    startConferenceBtn.innerHTML = St;
    startConferenceBtn.addEventListener("click", (ev) => {
      const btn = ev.currentTarget instanceof HTMLElement ? ev.currentTarget : null;
      openConferenceDialog(btn);
    });
  }
  document.getElementById("endConferenceBtn")?.addEventListener("click", () => {
    const view = state.conference;
    if (!view || state.connection !== "connected") return;
    const endBtn = document.getElementById(
      "endConferenceBtn"
    );
    const hostAction = Boolean(view.isConferenceOwner);
    if (endBtn) {
      endBtn.disabled = true;
      endBtn.textContent = hostAction ? "Ending\u2026" : "Leaving\u2026";
    }
    void Ss(
      hubEndpoint(state),
      view.hostTopic,
      hostAction ? void 0 : state.topic,
      state.client?.getConnectionState?.()?.token?.trim() || ""
    ).then(() => {
      setConferenceView(state, null);
    }).catch((err) => {
      console.error("[@slicer-hub/worklist] end conference failed", err);
    }).finally(() => {
      updateConnectionStatusUi(statusWrap, state);
    });
  });
  document.getElementById("stopFollowingBtn")?.addEventListener("click", () => {
    if (!state.conference || !state.conferenceFollowHost) return;
    setConferenceFollowHost(state, false);
  });
  document.getElementById("resumeFollowingBtn")?.addEventListener("click", () => {
    if (!state.conference || state.conferenceFollowHost) return;
    if (state.conference.selfRole === "leading") return;
    setConferenceFollowHost(state, true);
  });
  document.getElementById("takeOverConferenceBtn")?.addEventListener("click", () => {
    void (async () => {
      const view = state.conference;
      if (!view || state.connection !== "connected" || !state.topic) return;
      if (view.selfRole === "leading" || state.conferenceFollowHost) return;
      const ok = await gt2({
        strings: conferenceStrings()
      });
      if (!ok) return;
      try {
        await _s(
          hubEndpoint(state),
          view.hostTopic,
          state.topic,
          state.userName || void 0,
          state.client?.getConnectionState?.()?.token?.trim() || ""
        );
      } catch (err) {
        console.error("[@slicer-hub/worklist] take over failed", err);
        yt2(
          err instanceof Error ? err.message : "Failed to take over"
        );
      }
    })();
  });
  document.getElementById("downloadWorklistBtn")?.addEventListener("click", () => {
    const payload = {
      version: 1,
      studies: myWorklistStudies(state.allStudies)
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "my-worklist.json";
    a.click();
    URL.revokeObjectURL(url);
  });
  const uploadModal = document.getElementById(
    "uploadWorklistModal"
  );
  const uploadFileInput = document.getElementById(
    "uploadWorklistFile"
  );
  const uploadStatus = document.getElementById(
    "uploadWorklistStatus"
  );
  const uploadConfirmBtn = document.getElementById(
    "uploadWorklistConfirmBtn"
  );
  const closeUploadModal = () => {
    if (!uploadModal) return;
    uploadModal.hidden = true;
    if (uploadFileInput) uploadFileInput.value = "";
    if (uploadStatus) uploadStatus.textContent = "";
    if (uploadConfirmBtn) uploadConfirmBtn.disabled = true;
  };
  document.getElementById("uploadWorklistBtn")?.addEventListener("click", () => {
    if (uploadFileInput) uploadFileInput.value = "";
    if (uploadStatus) uploadStatus.textContent = "";
    if (uploadConfirmBtn) uploadConfirmBtn.disabled = true;
    if (uploadModal) uploadModal.hidden = false;
  });
  document.querySelectorAll("[data-close-upload-worklist]").forEach((el6) => {
    el6.addEventListener("click", () => closeUploadModal());
  });
  uploadModal?.addEventListener("click", (ev) => {
    if (ev.target === uploadModal) closeUploadModal();
  });
  uploadFileInput?.addEventListener("change", () => {
    if (uploadStatus) uploadStatus.textContent = "";
    if (uploadConfirmBtn) {
      uploadConfirmBtn.disabled = !uploadFileInput.files?.length;
    }
  });
  uploadConfirmBtn?.addEventListener("click", () => {
    const file = uploadFileInput?.files?.[0];
    if (!file) {
      if (uploadStatus) uploadStatus.textContent = "Choose a JSON file first.";
      return;
    }
    uploadConfirmBtn.disabled = true;
    if (uploadStatus) uploadStatus.textContent = "Reading\u2026";
    void file.text().then((text) => {
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error("File is not valid JSON");
      }
      const incoming = parseMyWorklistFile(data);
      if (!incoming.length) {
        throw new Error("No studies found in that file");
      }
      state.allStudies = mergeMyWorklistStudies(state.allStudies, incoming);
      orgSelect.value = WORKLIST_ORG_MINE;
      dismissOpenStartHint();
      refreshTable();
      closeUploadModal();
    }).catch((err) => {
      const msg = err instanceof Error ? err.message : "Failed to upload worklist";
      if (uploadStatus) uploadStatus.textContent = msg;
      if (uploadConfirmBtn) uploadConfirmBtn.disabled = false;
      console.error("[@slicer-hub/worklist] upload worklist failed", err);
    });
  });
  document.getElementById("openIdcNlBtn")?.addEventListener("click", () => {
    openIdcNlDialog({
      getState: () => state,
      onStudiesChanged: () => refreshTable(),
      setOrgFilter: (organization) => {
        dismissOpenStartHint();
        orgSelect.value = organization;
        refreshOrgSelectWithCustomWorklists(orgSelect);
        orgSelect.value = organization;
        refreshTable();
      }
    });
  });
  document.getElementById("openIdcAgentBtn")?.addEventListener("click", () => {
    openIdcSearchDialog({
      getState: () => state,
      onStudiesChanged: () => refreshTable(),
      setOrgFilter: (organization) => {
        dismissOpenStartHint();
        orgSelect.value = organization;
        refreshOrgSelectWithCustomWorklists(orgSelect);
        orgSelect.value = organization;
        refreshTable();
      }
    });
  });
  orgSelect.addEventListener("change", () => {
    dismissOpenStartHint();
    refreshTable();
    if (orgSelect.value === "cbct-dental") {
      void ensureCbctDentalLoaded(state, setFooter).then(() => {
        refreshTable();
      }).catch(() => {
        refreshTable();
      });
    }
    if (orgSelect.value === WORKLIST_ORG_TXRV) {
      void ensureTxrvLoaded(state, setFooter).then(() => {
        refreshTable();
      }).catch(() => {
        refreshTable();
      });
    }
    if (orgSelect.value === WORKLIST_ORG_FLEXRAY) {
      void ensureFlexrayLoaded(state, setFooter).then(() => {
        refreshTable();
      }).catch(() => {
        refreshTable();
      });
    }
    if (orgSelect.value === WORKLIST_ORG_VOX2SEGLAM) {
      void ensureVox2SegLamLoaded(state, setFooter).then(() => {
        refreshTable();
      }).catch(() => {
        refreshTable();
      });
    }
    if (isIdcCategoryFilterValue(orgSelect.value)) {
      void ensureIdcSegmentationsLoaded(state, setFooter).then(() => {
        refreshTable();
        if (state.connection === "connected") {
          updateConnectionStatusUi(statusWrap, state);
        }
      }).catch(() => {
        refreshTable();
      });
    }
  });
  wireLanguagePicker({
    getLocale,
    setLocale
  });
  applyChromeLabels();
  wireMenus(state);
  wireViewerButtons(state, refreshTable);
  wireInferenceInfoButtons(state);
  updateConnectionStatusUi(statusWrap, state);
  setViewerButtonsEnabled(state.connection === "connected", state);
  refreshTable();
  void ensureIdcWsiLoaded(state, setFooter).then(() => {
    refreshTable();
  }).catch(() => {
    refreshTable();
  });
  void ensureSlicerScenesLoaded(state, setFooter).then(() => {
    refreshTable();
  }).catch(() => {
    refreshTable();
  });
  void ensureCbctDentalLoaded(state, setFooter).then(() => {
    refreshTable();
  }).catch(() => {
    refreshTable();
  });
  void ensureFlexrayLoaded(state, setFooter).then(() => {
    refreshTable();
  }).catch(() => {
    refreshTable();
  });
  void ensureVox2SegLamLoaded(state, setFooter).then(() => {
    refreshTable();
  }).catch(() => {
    refreshTable();
  });
  if (isIdcCategoryFilterValue(orgSelect.value)) {
    void ensureIdcSegmentationsLoaded(state, setFooter).then(() => {
      refreshTable();
      if (state.connection === "connected") {
        updateConnectionStatusUi(statusWrap, state);
      }
    }).catch(() => {
      refreshTable();
    });
  }
  console.info(
    "[@slicer-hub/worklist] boot hub=",
    state.hubKey,
    hubEndpoint(state),
    "topic=",
    state.topic || "(from token)"
  );
  autoConnect(state).catch((err) => {
    console.error("[@slicer-hub/worklist] auto-connect error", err);
  });
}
void boot();
